#!/usr/bin/env python3
"""
AR.T.L.A.S. · Pruebas automáticas
  python3 tests/suite.py            → prueba dist/fullstack y dist/web-only (compilar antes: node build.mjs)
Variables opcionales (para correr sin internet):
  ARTLAS_LIBS     carpeta node_modules con jszip, xlsx, chart.js, sql.js, pdfjs-dist
  ARTLAS_PYODIDE  carpeta del paquete npm «pyodide» (sin numpy/matplotlib: esas pruebas se omiten)
Las APIs de los modelos y de búsqueda siempre se simulan: no se gasta cuota ni se toca Supabase.
Escribe tests/ultimo-reporte.json y devuelve código 1 si alguna prueba falla.
"""
import asyncio, json, os, sys, threading, functools, zipfile, tempfile, time, re
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from playwright.async_api import async_playwright

R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open(os.path.join(R, "artlas.config.json")))
LIBS = os.environ.get("ARTLAS_LIBS", "")
PYO = os.environ.get("ARTLAS_PYODIDE", "")
DATA = os.path.join(R, "tests", "datos")

# ---------------- registro de resultados ----------------
SUITES = []
def suite(nombre):
    s = {"nombre": nombre, "total": 0, "ok": 0, "fallas": []}; SUITES.append(s); print(f"\n▶ {nombre}"); return s
def ck(s, nombre, cond, det=""):
    s["total"] += 1
    if cond: s["ok"] += 1; print(f"  ✓ {nombre}")
    else: s["fallas"].append(f"{nombre} {det}".strip()); print(f"  ✗ {nombre}  {det}")

# ---------------- servidores locales ----------------
class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
def serve(folder):
    h = functools.partial(Quiet, directory=folder)
    srv = ThreadingHTTPServer(("127.0.0.1", 0), h)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return f"http://127.0.0.1:{srv.server_address[1]}/"

# ---------------- simulaciones de red ----------------
LIBMAP = {"jszip.min.js": "jszip/dist/jszip.min.js", "xlsx.full.min.js": "xlsx/dist/xlsx.full.min.js", "chart.umd.min.js": "chart.js/dist/chart.umd.js",
          "sql-wasm.js": "sql.js/dist/sql-wasm.js", "sql-wasm.wasm": "sql.js/dist/sql-wasm.wasm", "pdf.min.js": "pdfjs-dist/build/pdf.min.js", "pdf.worker.min.js": "pdfjs-dist/build/pdf.worker.min.js"}
async def r_lib(route):
    fn = route.request.url.split("/")[-1].split("?")[0]
    p = os.path.join(LIBS, LIBMAP.get(fn, "__no__"))
    if os.path.exists(p):
        await route.fulfill(status=200, body=open(p, "rb").read(), content_type="application/wasm" if fn.endswith(".wasm") else "application/javascript")
    else: await route.fulfill(status=404, body="")
async def r_pyo(route):
    fn = route.request.url.split("/full/")[-1].split("?")[0]; p = os.path.join(PYO, fn)
    ct = {"mjs": "text/javascript", "js": "text/javascript", "wasm": "application/wasm", "json": "application/json", "zip": "application/zip"}.get(fn.rsplit(".", 1)[-1], "application/octet-stream")
    if os.path.exists(p): await route.fulfill(status=200, body=open(p, "rb").read(), content_type=ct, headers={"Access-Control-Allow-Origin": "*"})
    else: await route.fulfill(status=404, body="", headers={"Access-Control-Allow-Origin": "*"})

AI = {"calls": [], "fn": None, "anth_status": 200}
def default_reply(sysm, user):
    if "llam" in user.lower(): return "Soy **AR.T.L.A.S.**." if ("IDENTIDAD" in sysm or "IDENTITY" in sysm) else "¡Hola! Soy ChatGPT."
    if "QPSK" in user: return "### Comparación\n\nUn *compromiso* entre **eficiencia** y robustez.\n\n| Modulación | Bits |\n|---|---:|\n| QPSK | 2 |\n| 64-QAM | 6 |\n\n```python\nprint(2+2)\n```"
    if "astra" in user.lower() and "RESULTADOS DE BÚSQUEDA WEB" not in sysm: return "No tengo información sobre ASTRa."
    if "RESULTADOS DE BÚSQUEDA WEB" in sysm: return "Según [1], ASTRa es un agente."
    return "Respuesta simulada a: " + user[:40]
async def r_ai(route):
    req = route.request; host = req.url.split("/")[2]
    try: body = json.loads(req.post_data or "{}")
    except Exception: body = {}
    msgs = body.get("messages", [])
    sysm = body.get("system", "") if isinstance(body.get("system"), str) else ""
    if msgs and msgs[0].get("role") == "system": sysm = msgs[0].get("content") or ""
    us = [m for m in msgs if m.get("role") == "user"]
    user = us[-1]["content"] if us else ""
    if isinstance(user, list): user = " ".join(x.get("text", "") for x in user if isinstance(x, dict))
    AI["calls"].append({"host": host, "sys": sysm, "user": str(user), "n": len(msgs)})
    if "anthropic" in host and AI["anth_status"] != 200:
        await route.fulfill(status=AI["anth_status"], content_type="application/json", body=json.dumps({"error": {"message": "Overloaded (simulado)"}})); return
    txt = (AI["fn"] or default_reply)(sysm, str(user))
    if "anthropic" in host: out = {"content": [{"type": "text", "text": txt}]}
    else: out = {"choices": [{"message": {"content": txt}}]}
    await route.fulfill(status=200, content_type="application/json", body=json.dumps(out))
SEARCH = {"n": 0}
DDG = '<div class="result web-result"><a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fopenai.com%2Fastra">OpenAI presenta ASTRa</a><a class="result__snippet">ASTRa es un agente.</a></div>'
async def r_jina(route):
    SEARCH["n"] += 1; u = route.request.url
    body = DDG if "duckduckgo" in u else ("<rss><channel></channel></rss>" if "news.google" in u else "Markdown Content:\n" + "texto de la página " * 30)
    await route.fulfill(status=200, body=body, content_type="text/html", headers={"Access-Control-Allow-Origin": "*"})

async def new_ctx(b, **kw):
    ctx = await b.new_context(viewport={"width": 1340, "height": 800}, **kw)
    await ctx.add_init_script("window.ARTLAS_DIRECT_ONLY=true;")
    if LIBS:
        await ctx.route("https://cdnjs.cloudflare.com/**", r_lib)
        await ctx.route(re.compile(r"https://cdn\.jsdelivr\.net/(?!pyodide/).*"), r_lib)
    if PYO: await ctx.route("https://cdn.jsdelivr.net/pyodide/**", r_pyo)
    await ctx.route(re.compile(r"https://[^/]*supabase\.co/.*"), lambda r: r.abort())
    for h in ["api.openai.com", "api.anthropic.com", "api.groq.com"]: await ctx.route(f"https://{h}/**", r_ai)
    await ctx.route("https://r.jina.ai/**", r_jina)
    await ctx.route(re.compile(r"https://[a-z]+\.wikipedia\.org/.*"), lambda r: r.fulfill(status=200, content_type="application/json", body='{"query":{"pages":{}}}', headers={"Access-Control-Allow-Origin": "*"}))
    await ctx.route("https://api.duckduckgo.com/**", lambda r: r.fulfill(status=200, content_type="application/json", body="{}"))
    return ctx
async def new_page(ctx, url):
    pg = await ctx.new_page(); pg.set_default_timeout(20000)
    pg.errs = []
    pg.on("pageerror", lambda e: pg.errs.append(str(e)))
    pg.on("dialog", lambda d: asyncio.ensure_future(d.accept()))
    await pg.goto(url); await pg.wait_for_function("typeof V60!=='undefined' && typeof v61GateGuest==='function'")
    await pg.wait_for_timeout(500)
    return pg
async def ev(pg, js): return await pg.evaluate(js)
async def guest(pg): await ev(pg, "v61GateGuest();0"); await pg.wait_for_timeout(800)
async def say(pg, q, new=True, wait=0):
    n0 = len(AI["calls"])
    await ev(pg, ("go('chat');newChat();" if new else "") + "inp.value=%s;send();0" % json.dumps(q))
    await pg.wait_for_function("!busy", timeout=30000); await pg.wait_for_timeout(300 + wait)
    return len(AI["calls"]) - n0

# =====================================================================
async def main():
    FS = serve(os.path.join(R, "dist", "fullstack")); WO = serve(os.path.join(R, "dist", "web-only"))
    async with async_playwright() as p:
        b = await p.chromium.launch()
        ctx = await new_ctx(b, permissions=["clipboard-read", "clipboard-write"])

        # ---------- 1. carga e ingreso ----------
        s = suite("Carga, ingreso y compilación")
        pg = await new_page(ctx, FS + "app.html")
        ck(s, "versión " + CFG["ver"], await ev(pg, "V60.ver") == CFG["ver"])
        ck(s, "pantalla de ingreso visible", await ev(pg, "getComputedStyle($('v61-gate')).display") != "none")
        await ev(pg, "document.dispatchEvent(new Event('keydown',{bubbles:true}));0")
        ck(s, "autocompletado (keydown sin tecla) sin errores", not pg.errs, str(pg.errs[:1]))
        await guest(pg)
        ck(s, "invitado entra al chat", await ev(pg, "curView") == "chat" and await ev(pg, "getComputedStyle($('v61-gate')).display") == "none")
        ck(s, "recursos (íconos, RAG, manual) cargados aparte", await ev(pg, "typeof MANUAL_B64==='string'&&typeof RAGLOCAL_FILES==='object'&&typeof ARTLAS_ICO_B64==='string'"))
        bi = await ev(pg, "window.__ARTLAS_BUILD__")
        ck(s, "información de compilación incluida", bool(bi) and bi.get("ver") == CFG["ver"] and len(bi.get("modulos", [])) >= 10)
        ck(s, "app.js minificado (< 720 KB)", bool(bi) and bi.get("minificado") and bi.get("min", 9e9) < 720 * 1024, str(bi and bi.get("min")))
        sal = await ev(pg, "[[5,59],[6,0],[12,0],[12,1],[20,0],[20,1],[0,30]].map(([h,m])=>v60Saludo(new Date(2026,0,1,h,m)))")
        ck(s, "saludo según la hora (día 6–12 · tardes 12:01–20 · noches 20:01–5:59)", sal == ["Buenas noches", "Buen día", "Buen día", "Buenas tardes", "Buenas tardes", "Buenas noches", "Buenas noches"], str(sal))
        await ev(pg, "user={id:'u',email:'a@b.c'};v62Layout();0")
        h2 = await ev(pg, "document.querySelector('#empty h2').textContent")
        ck(s, "chat: «<saludo> · ¿en qué te puedo ayudar?»", h2.startswith(await ev(pg, "v60Saludo()")) and h2.endswith("¿en qué te puedo ayudar?"), h2)
        await ev(pg, "user=null;v62Layout();0")
        txt = await ev(pg, "document.body.innerText")
        ck(s, "sin números de iteración visibles", not re.search(r"\bv(5\d|6[0-9])\b", txt), str(re.findall(r"\bv(?:5\d|6[0-9])\b", txt)[:3]))
        ck(s, "sin errores de JavaScript", not pg.errs, str(pg.errs[:1]))

        # ---------- 2. router ----------
        s = suite("Router y fallback")
        await ev(pg, "cfg.openai={key:'sk-test-OA'};cfg.anthropic={key:'sk-ant-TEST'};save();renderMenu();v60ApplyStrategy('best');0")
        AI["anth_status"] = 529
        await say(pg, "escribí un script python que lea un CSV")
        last = await ev(pg, "cur().msgs.slice(-1)[0]")
        ck(s, "Anthropic falla (529) → responde OpenAI", "Fallback" in (last.get("meta") or "") and "simulada" in last["content"], str(last.get("meta")))
        ck(s, "telemetría registra la falla", await ev(pg, "V60.usage.tot.fail") >= 1)
        AI["anth_status"] = 200
        await ev(pg, "v60ApplyStrategy('manual');curModel='medium';save();renderMenu();0")

        # ---------- 3. chat ----------
        s = suite("Chat: identidad, formato y acciones")
        await say(pg, "¿Cómo te llamás?")
        ck(s, "instrucción de identidad enviada", "IDENTIDAD" in AI["calls"][-1]["sys"])
        ck(s, "se presenta como AR.T.L.A.S.", "AR.T.L.A.S." in await ev(pg, "cur().msgs.slice(-1)[0].content"))
        await say(pg, "Compará QPSK y 64-QAM", new=False)
        r = await ev(pg, "(()=>{const c=[...document.querySelectorAll('#msgs .row.bot')].pop().querySelector('.content');return {t:c.querySelectorAll('table tr').length,em:c.querySelectorAll('em').length,h:!!c.querySelector('h4'),raw:/\\|---|###|\\*\\*/.test(c.innerText),run:!!c.querySelector('.v67-run')}})()")
        ck(s, "tabla, cursiva y título interpretados", r["t"] == 3 and r["em"] >= 1 and r["h"], str(r))
        ck(s, "sin Markdown crudo", not r["raw"])
        ck(s, "bloque Python con «▶ Ejecutar»", r["run"])
        await pg.click("#msgs .row.v66-last .v66-acts button:first-child"); await pg.wait_for_timeout(200)
        ck(s, "Copiar copia el Markdown original", (await ev(pg, "navigator.clipboard.readText()")).startswith("### Comparación"))
        n = await ev(pg, "cur().msgs.length"); c0 = len(AI["calls"])
        await pg.click("#msgs .row.v66-last .v66-regen"); await pg.wait_for_function("!busy"); await pg.wait_for_timeout(300)
        ck(s, "Regenerar reemplaza la última respuesta", await ev(pg, "cur().msgs.length") == n and len(AI["calls"]) == c0 + 1)
        await pg.click("#msgs > .row.user >> nth=0 >> text=Editar")
        await pg.fill("#msgs .v66-edit textarea", "Explicame OFDM"); await pg.press("#msgs .v66-edit textarea", "Enter")
        await pg.wait_for_function("!busy"); await pg.wait_for_timeout(300)
        ck(s, "Editar reenvía desde ese mensaje", await ev(pg, "cur().msgs.map(m=>m.role).join()") == "user,assistant" and "OFDM" in await ev(pg, "cur().msgs[0].content"))
        await say(pg, "Usá **negrita** <b>x</b>")
        ck(s, "el texto del usuario se muestra tal cual", "&lt;b&gt;" in await ev(pg, "[...document.querySelectorAll('#msgs .row.user .content')].pop().innerHTML"))
        await ev(pg, "agents.unshift({name:'Agente Radio',type:'Asistente',goal:'Radioenlaces',caps:[],skills:[],docs:[]});agentChat(0);inp.value='hola';send();0")
        await pg.wait_for_function("!busy"); await pg.wait_for_timeout(300)
        ck(s, "los agentes conservan su propio nombre (sin identidad)", "IDENTIDAD" not in AI["calls"][-1]["sys"] and "Agente Radio" in AI["calls"][-1]["sys"])
        ck(s, "sin errores de JavaScript", not pg.errs, str(pg.errs[:1]))

        # ---------- 4. búsqueda ----------
        s = suite("Búsqueda web a pedido")
        n0 = SEARCH["n"]; await say(pg, "¿Cuáles son las últimas noticias de OpenAI hoy?")
        ck(s, "no busca por su cuenta", SEARCH["n"] == n0)
        n0 = SEARCH["n"]; await say(pg, "Buscá información sobre ASTRa de OpenAI", wait=500)
        ck(s, "busca cuando el usuario lo pide", SEARCH["n"] > n0 and "🔎 web" in (await ev(pg, "cur().msgs.slice(-1)[0].meta") or ""))
        n0 = SEARCH["n"]; await say(pg, "¿Qué es ASTRa de OpenAI?")
        ck(s, "si el modelo no sabe, ofrece buscar", await ev(pg, "!!document.querySelector('.v63-offer')") and SEARCH["n"] == n0)
        await pg.click(".v63-offer .btn.dark"); await pg.wait_for_function("!busy"); await pg.wait_for_timeout(500)
        ck(s, "al aceptar, busca y responde con fuentes", "Fuentes" in await ev(pg, "cur().msgs.slice(-1)[0].content"))
        await ev(pg, "agentWebPending=true;newChat();0")
        ck(s, "una conversación nueva no hereda la navegación de un agente", await ev(pg, "agentWebPending") is False)

        # ---------- 5. herramientas ----------
        s = suite("Herramientas de agentes")
        calc = await ev(pg, """(()=>{const t=e=>{try{return v67CalcFmt(v67Calc(e))}catch(x){return 'ERR'}};
          return [t('20*log10(25)+20*log10(5800)+32.44'),t('fspl(10,5800)'),t('2^3^2'),t('-2**2'),t('w2dbm(1)'),t('1,5*2'),t('round(pi,3)'),t('fresnel(5,5,5.8)'),t('alert(1)'),t('sqrt(-1)')]})()""")
        ck(s, "calculadora: FSPL 25 km a 5,8 GHz = 135,67 dB", calc[0].startswith("135.667"), calc[0])
        ck(s, "calculadora: función fspl()", calc[1].startswith("127.708"), calc[1])
        ck(s, "calculadora: potencias y signos", calc[2] == "512" and calc[3] == "-4", f"{calc[2]} {calc[3]}")
        ck(s, "calculadora: unidades (W→dBm) y coma decimal", calc[4] == "30" and calc[5] == "3", f"{calc[4]} {calc[5]}")
        ck(s, "calculadora: round(), fresnel()", calc[6] == "3.142" and calc[7].startswith("11.37"), f"{calc[6]} {calc[7]}")
        ck(s, "calculadora: rechaza código y resultados inválidos", calc[8] == "ERR" and calc[9] == "ERR")
        await ev(pg, "go('agents');0"); await pg.wait_for_timeout(300)
        ck(s, "Agent Studio muestra las herramientas", await ev(pg, "document.querySelectorAll('#a-tools .chk').length") == 3)
        await pg.fill("#a-name", "Agente Enlaces"); await pg.click("#a-tools .chk[data-tool=calc]"); await pg.click("#a-tools .chk[data-tool=python]")
        await ev(pg, "agDocs=[];0"); await pg.click("#a-create-btn"); await pg.wait_for_timeout(400)
        ck(s, "el agente guarda sus herramientas", await ev(pg, "JSON.stringify(agents[0].tools)") == '["calc","python"]')
        def tool_fn(sysm, user):
            if "RESULTADO de tool:calc" in user: return "A 25 km la pérdida es de 135,7 dB."
            if "HERRAMIENTAS DISPONIBLES" in sysm: return "Calculo primero:\n```tool:calc\n20*log10(25)+20*log10(5800)+32.44\n```"
            return "sin herramientas"
        AI["fn"] = tool_fn; c0 = len(AI["calls"])
        await ev(pg, "agentChat(0);inp.value='¿Cuánto da la FSPL a 25 km?';send();0")
        await pg.wait_for_function("!busy", timeout=30000); await pg.wait_for_timeout(300)
        m = await ev(pg, "cur().msgs.slice(-1)[0]")
        ck(s, "el agente pide la calculadora y recibe el resultado", any("135.667" in c["user"] for c in AI["calls"][c0:]))
        ck(s, "la respuesta muestra los pasos", "Pasos del agente" in m["content"] and "Calculadora" in m["content"] and "135,7 dB" in m["content"], m["content"][:120])
        ck(s, "los bloques de herramienta no quedan en la respuesta", "tool:calc" not in m["content"])
        ck(s, "la conversación recuerda las herramientas", await ev(pg, "JSON.stringify(cur().tools)") == '["calc","python"]')
        AI["fn"] = None
        ck(s, "sin errores de JavaScript", not pg.errs, str(pg.errs[:1]))

        # ---------- 6. python ----------
        s = suite("Python en el navegador")
        if not PYO and not os.environ.get("CI"):
            print("  (sin Pyodide local ni CI: se omite)")
        else:
            r = await ev(pg, "v67PyRun('import math\\nprint(\"hola\", round(math.log10(5800),4))\\n6*7')")
            ck(s, "ejecuta código y captura print()", r.get("ok") and "hola 3.7634" in r.get("out", "") and r.get("res") == "42", str(r)[:200])
            r = await ev(pg, "v67PyRun('1/0')")
            ck(s, "muestra el error de Python legible", (not r.get("ok")) and "ZeroDivisionError" in r.get("err", "") and "_pyodide" not in r.get("err", ""), r.get("err", "")[:160])
            r = await ev(pg, "v67PyRun('import js\\ntry:\\n  js.localStorage.getItem(\"atlas_cfg\")\\n  print(\"VISIBLE\")\\nexcept Exception:\\n  print(\"aislado\")')")
            ck(s, "aislado: no puede leer las claves (localStorage)", "aislado" in r.get("out", ""), str(r)[:160])
            r = await ev(pg, "v67PyRun('import js\\nprint(js.indexedDB)')")
            ck(s, "aislado: sin acceso a IndexedDB", "None" in r.get("out", "") or not r.get("ok"), str(r)[:160])
            await ev(pg, "V67PY.limit=3000")
            r = await ev(pg, "v67PyRun('while True: pass')")
            ck(s, "corta los bucles infinitos (límite de tiempo)", "Tiempo máximo" in r.get("err", ""))
            r = await ev(pg, "v67PyRun('print(2+2)')")
            ck(s, "se reinicia y vuelve a funcionar", r.get("ok") and r.get("out", "").strip() == "4")
            await ev(pg, "V67PY.limit=60000")
            ck(s, "arranca desde python-worker.js del propio sitio", await ev(pg, "V67PY.kind") == "file")
            reset = "try{V67PY.w&&V67PY.w.terminate()}catch(e){};V67PY.w=null;V67PY.tried=[];V67PY.fails=[];V67PY.booted=false;0"
            await pg.route("**/python-worker.js*", lambda r: r.fulfill(status=404, body=""))
            await ev(pg, reset); r = await ev(pg, "v67PyRun('print(7*6)')")
            ck(s, "si el archivo del worker falla, usa otra estrategia", r.get("ok") and r.get("out", "").strip() == "42" and await ev(pg, "V67PY.kind") == "blob-module", str(r)[:160])
            await pg.unroute("**/python-worker.js*")
            if not PYO:   # el interceptor local no sirve importScripts dentro de un worker clásico: se verifica en CI
                await ev(pg, "V67PY.strategies=['blob-classic'];" + reset); r = await ev(pg, "v67PyRun('print(\"clasico\")')")
                ck(s, "también funciona como worker clásico", r.get("ok") and "clasico" in r.get("out", ""), str(r)[:200])
                await ev(pg, "V67PY.strategies=null;" + reset)
            await ev(pg, "V67PY.strategies=null;" + reset)
            await pg.route("https://cdn.jsdelivr.net/pyodide/**", lambda r: r.fulfill(status=404, body="", headers={"Access-Control-Allow-Origin": "*"}))
            r = await ev(pg, "v67PyRun('print(1)')")
            ck(s, "si Python no se puede descargar, explica el motivo", (not r.get("ok")) and "cdn.jsdelivr.net" in r.get("err", "") and "Detalle técnico" in r.get("err", ""), r.get("err", "")[:200])
            await pg.unroute("https://cdn.jsdelivr.net/pyodide/**"); await ev(pg, reset)
            await ev(pg, "V67PY.strategies=['blob-classic','iframe'];" + reset)
            r = await ev(pg, "v67PyRun(`print('respaldo')`)")
            ck(s, "si un modo falla al descargar, pasa al siguiente (iframe aislado)", r.get("ok") and "respaldo" in r.get("out", "") and await ev(pg, "V67PY.mode") == "iframe", str(r)[:200])
            await ev(pg, "V67PY.strategies=null;" + reset)
            r = await ev(pg, "v67PyRun(`n=input('Nombre: ')\nprint('Hola', n)`,null,['Mario'])")
            ck(s, "input(): usa los datos cargados, en orden", r.get("ok") and r.get("out", "") == "Nombre: Mario\nHola Mario\n", repr(r.get("out")))
            r = await ev(pg, "v67PyRun(`import sys\nprint('fin')\nsys.exit(0)`)")
            ck(s, "sys.exit(0) no se muestra como error", r.get("ok") and "fin" in r.get("out", ""))
            r = await ev(pg, "v67PyRun('from tensorflow.keras.preprocessing.image import ImageDataGenerator\\nimport keras')")
            ck(s, "TensorFlow/Keras: avisa que no corre en el navegador", r.get("noweb") == ["tensorflow", "keras"] and "TensorFlow, Keras" in r.get("err", ""), str(r)[:200])
            await say(pg, "Compará QPSK y 64-QAM")
            await pg.click("#msgs .row.v66-last .v67-run"); await pg.wait_for_selector("#msgs .row.v66-last .v67-out .v67-ol", timeout=60000)
            ck(s, "«▶ Ejecutar» muestra la salida en la respuesta", "4" in await ev(pg, "document.querySelector('#msgs .row.v66-last .v67-out').innerText"))
            AI["fn"] = lambda sysm, user: "```python\nimport tensorflow as tf\nprint(tf.__version__)\n```"
            await say(pg, "Red neuronal con Keras")
            await pg.click("#msgs .row.v66-last .v67-run"); await pg.wait_for_selector("#msgs .row.v66-last .v67-colab", timeout=10000)
            ck(s, "TensorFlow/Keras: ofrece abrirlo en Google Colab", "Colab" in await ev(pg, "document.querySelector('#msgs .row.v66-last .v67-colab').innerText"))
            ck(s, "botón «Colab ↗» en todos los bloques Python", await ev(pg, "[...document.querySelectorAll('#msgs .v66-code')].filter(c=>/python/.test(c.querySelector('.v66-cbar span').textContent)).every(c=>!!c.querySelector('.v67-colab-mini'))"))
            AI["fn"] = lambda sysm, user: "```python\nn = input('Distancia: ')\nprint('km', float(n) * 2)\n```"
            await say(pg, "Programa con input")
            await pg.click("#msgs .row.v66-last .v67-run"); await pg.wait_for_selector("#msgs .row.v66-last .v67-stdin textarea")
            await pg.fill("#msgs .row.v66-last .v67-stdin textarea", "12.5"); await pg.click("#msgs .row.v66-last .v67-stdin button")
            await pg.wait_for_selector("#msgs .row.v66-last .v67-out .v67-ol", timeout=60000)
            ck(s, "input(): cuadro para cargar los datos antes de ejecutar", "km 25.0" in await ev(pg, "document.querySelector('#msgs .row.v66-last .v67-out').innerText"))
            AI["fn"] = None
            if not PYO:   # en CI (con internet): paquetes científicos y gráficos
                r = await ev(pg, "v67PyRun('import numpy as np\\nimport matplotlib.pyplot as plt\\nd=np.linspace(1,20,20)\\nplt.plot(d,20*np.log10(d))\\nplt.show()\\nprint(int(np.arange(5).sum()))')")
                ck(s, "numpy y matplotlib (gráfico generado)", r.get("ok") and r.get("out", "").strip() == "10" and len(r.get("figs") or []) == 1, (r.get("err") or "")[:160])
            def py_fn(sysm, user):
                if "RESULTADO de tool:python" in user: return "Listo: el resultado es " + ("1024" if "1024" in user else "?")
                if "HERRAMIENTAS DISPONIBLES" in sysm: return "```tool:python\nprint(2**10)\n```"
                return "sin herramientas"
            AI["fn"] = py_fn
            await ev(pg, "agentChat(agents.findIndex(a=>a.name==='Agente Enlaces'));inp.value='potencia';send();0")
            await pg.wait_for_function("!busy", timeout=60000); await pg.wait_for_timeout(300)
            ck(s, "el agente usa Python como herramienta", "1024" in await ev(pg, "cur().msgs.slice(-1)[0].content"))
            AI["fn"] = None
            ck(s, "sin errores de JavaScript", not pg.errs, str(pg.errs[:1]))

        # ---------- 7. bóveda ----------
        s = suite("Bóveda y modos de claves")
        await ev(pg, "cfg.openai={key:'sk-test-OA'};save();v60SetKeyMode('vault');0"); await pg.wait_for_timeout(300)
        await pg.fill("#vm-p1", "frase-segura-123"); await pg.fill("#vm-p2", "frase-segura-123"); await pg.click("#vm-ok"); await pg.wait_for_timeout(1500)
        st = await ev(pg, "({mode:v60KeyMode(),plain:localStorage.getItem('atlas_cfg').includes('sk-test'),vault:!!localStorage.getItem('atlas_vault')})")
        ck(s, "las claves quedan cifradas (no en texto plano)", st["mode"] == "vault" and not st["plain"] and st["vault"], str(st))
        await pg.reload(); await pg.wait_for_function("typeof v61GateHide==='function'"); await pg.wait_for_timeout(600); await ev(pg, "v61GateHide(true);0"); await pg.wait_for_timeout(800)
        ck(s, "al recargar, la bóveda queda bloqueada", await ev(pg, "v60VaultLocked()"))
        await pg.fill("#vm-p1", "mala-frase"); await pg.click("#vm-ok"); await pg.wait_for_timeout(1300)
        ck(s, "rechaza una frase incorrecta", len(await pg.inner_text("#vm-msg")) > 3)
        await pg.fill("#vm-p1", "frase-segura-123"); await pg.click("#vm-ok"); await pg.wait_for_timeout(1500)
        ck(s, "con la frase correcta recupera las claves", await ev(pg, "!v60VaultLocked()&&cfg.openai&&cfg.openai.key==='sk-test-OA'"))
        await ev(pg, "v60SetKeyMode('session');0"); await pg.wait_for_timeout(300)
        ck(s, "modo sesión: claves solo en la pestaña", await ev(pg, "!localStorage.getItem('atlas_cfg').includes('sk-test')&&(sessionStorage.getItem('atlas_keys_s')||'').includes('sk-test')"))
        await ev(pg, "v60SetKeyMode('local');0")
        ck(s, "👁 en los campos de clave", await ev(pg, "document.querySelectorAll('.v63-eye').length") >= 3)

        # ---------- 8. analytics ----------
        s = suite("Analytics")
        await ev(pg, "go('analytics');0")
        await pg.set_input_files("#an-file", [os.path.join(DATA, "ventas.csv"), os.path.join(DATA, "sitios.json")])
        await pg.wait_for_function("anFiles.length===2 && anRows.length>0", timeout=30000); await pg.wait_for_timeout(800)
        ck(s, "carga CSV y JSON", await ev(pg, "anFiles.length") == 2 and await ev(pg, "anRows.length") > 10)
        ck(s, "propone KPIs y gráficos", await ev(pg, "anKpiDefs.length") > 0 and await ev(pg, "anChartDefs.length") > 0)
        ck(s, "sin errores de JavaScript", not pg.errs, str(pg.errs[:1]))

        # ---------- 9. registro de errores ----------
        s = suite("Registro de errores")
        await ev(pg, "localStorage.removeItem('atlas_errlog');setTimeout(()=>{ throw new Error('prueba de registro sk-abcdefghijklmnop usuario@correo.com') },0);0"); await pg.wait_for_timeout(400)
        L = await ev(pg, "JSON.parse(localStorage.getItem('atlas_errlog')||'[]')")
        ck(s, "registra los errores de la app", len(L) == 1 and "prueba de registro" in L[0]["msg"], str(L)[:160])
        ck(s, "oculta claves y correos del mensaje", L and "abcdefghijklmnop" not in L[0]["msg"] and "usuario@correo.com" not in L[0]["msg"])
        ck(s, "guarda la versión", L and L[0].get("ver") == CFG["ver"], str(L and L[0].get("ver")))
        await ev(pg, "go('control');0"); await pg.wait_for_timeout(500)
        ck(s, "«Salud de la plataforma» oculta para no administradores", await ev(pg, "!document.getElementById('v67-health')"))
        await ev(pg, "localStorage.removeItem('atlas_errlog');0")
        await pg.close()

        # ---------- 10. paquetes ----------
        s = suite("Paquetes: Web only, escritorio y portada")
        pg = await new_page(ctx, WO + "app.html")
        ck(s, "Web only: sin proxy (conexión directa)", await ev(pg, "window.ARTLAS_DIRECT_ONLY===true") and await ev(pg, "V60.ver") == CFG["ver"])
        ck(s, "Web only: sin errores", not pg.errs, str(pg.errs[:1]))
        dctx = await new_ctx(b, accept_downloads=True)
        dpg = await new_page(dctx, FS + "app.html")
        async with dpg.expect_download() as dl:
            await ev(dpg, "v61GateGuest();V61_buildDesktop();0")
        d = await dl.value; tmp = tempfile.mkdtemp(); zp = os.path.join(tmp, "e.zip"); await d.save_as(zp)
        z = zipfile.ZipFile(zp); z.extractall(tmp)
        ck(s, "escritorio: paquete " + d.suggested_filename, d.suggested_filename == f"ARTLAS-{CFG['ver']}-escritorio.zip" and "ARTLAS.html" in z.namelist())
        ep = await dctx.new_page(); ep.errs = []; ep.on("pageerror", lambda e: ep.errs.append(str(e)))
        await ep.goto("file://" + os.path.join(tmp, "ARTLAS.html")); await ep.wait_for_timeout(1500)
        ck(s, "escritorio: abre la versión correcta", await ep.evaluate("typeof V60!=='undefined'&&V60.ver") == CFG["ver"])
        ck(s, "escritorio: incluye los recursos (íconos, RAG, manual)", await ep.evaluate("typeof MANUAL_B64==='string'&&typeof RAGLOCAL_FILES==='object'"))
        ck(s, "escritorio: sin errores", not ep.errs, str(ep.errs[:1]))
        await ep.evaluate("v61GateHide(true);user={id:'u-esc',email:'escritorio@artlas.ar',user_metadata:{}};v69Close();downloadRagLocal();0"); await ep.wait_for_timeout(200)
        ck(s, "escritorio: descargar RAG exige aceptar la licencia", await ep.evaluate("!!document.getElementById('v69-modal')&&!!document.getElementById('v69-ck2')"))
        await ep.evaluate("v69Close();user=null;0")
        if PYO or os.environ.get("CI"):
            r = await ep.evaluate("v67PyRun('import math\\nprint(round(20*math.log10(10)+20*math.log10(5800)+32.44,1))')")
            ck(s, "escritorio: Python funciona (modo iframe aislado)", r.get("ok") and "127.7" in r.get("out", "") and await ep.evaluate("V67PY.mode") == "iframe", str(r)[:200])
            r = await ep.evaluate("v67PyRun(`import js\ntry:\n  js.localStorage.length\n  print('VISIBLE')\nexcept Exception:\n  print('aislado')`)")
            ck(s, "escritorio: Python sin acceso a las claves", "aislado" in r.get("out", ""), str(r)[:160])
            r = await ep.evaluate("v67PyRun('while True: pass')")
            ck(s, "escritorio: corta los bucles infinitos", "Tiempo máximo excedido" in r.get("err", ""), r.get("err", "")[-120:])
            wpg = await ctx.new_page(); wpg.errs = []; wpg.on("pageerror", lambda e: wpg.errs.append(str(e)))
            await wpg.goto("file://" + os.path.join(R, "dist", "web-only", "app.html")); await wpg.wait_for_timeout(1200)
            r = await wpg.evaluate("v67PyRun('print(6*7)')")
            ck(s, "Web only abierta desde el disco: Python funciona", r.get("ok") and r.get("out", "").strip() == "42", str(r)[:200])
        lp = await ctx.new_page(); lp.errs = []; lp.on("pageerror", lambda e: lp.errs.append(str(e)))
        await lp.goto(FS); await lp.wait_for_timeout(500)
        ck(s, "portada: carga y muestra la versión", CFG["ver"] in await lp.inner_text(".hero .foot") and not lp.errs)
        okfiles = True
        for f in ["robots.txt", "sitemap.xml", "googlec9092d167579b572.html", "og-image.png", "app-recursos.js", "python-worker.js"]:
            rr = await lp.goto(FS + f); okfiles = okfiles and rr.status == 200
        ck(s, "portada: robots, sitemap, verificación de Google, imagen y archivos de la app", okfiles)
        html = open(os.path.join(R, "dist", "fullstack", "app.html"), encoding="utf8").read()
        ck(s, "sin comentarios internos en app.html", "<!--" not in html and not re.search(r"/\*\s", html))

        # ---------- 11. app instalable (PWA) ----------
        s = suite("App instalable (registro obligatorio y actualización)")
        rr = await lp.goto(FS + "manifest.webmanifest"); man = json.loads(await rr.text()) if rr.status == 200 else {}
        ck(s, "manifiesto publicado (nombre, ícono, ventana propia)", man.get("short_name") == "AR.T.L.A.S." and man.get("display") == "standalone" and "app=1" in man.get("start_url", "") and any(i.get("purpose") == "maskable" for i in man.get("icons", [])), str(man)[:120])
        rr = await lp.goto(FS + "sw.js"); swt = await rr.text()
        ck(s, "service worker publicado con la versión", rr.status == 200 and f'const VER = "{CFG["ver"]}"' in swt)
        okic = True
        for f in ["icono-192.png", "icono-512.png", "icono-maskable-512.png", "apple-touch-icon.png"]:
            okic = okic and (await lp.goto(FS + f)).status == 200 and os.path.exists(os.path.join(R, "dist", "web-only", f))
        ck(s, "íconos de la app (también en Web only)", okic and os.path.exists(os.path.join(R, "dist", "web-only", "sw.js")))
        await lp.close()
        # invitado: no se ofrece instalar
        pctx = await new_ctx(b)
        gp = await new_page(pctx, FS + "app.html"); await guest(gp)
        r = await ev(gp, "(async()=>({man:!!document.querySelector('link[rel=manifest]'),sw:!!(await navigator.serviceWorker.getRegistration()),nav:(()=>{const b=document.querySelector('.v68-nav');return b?{dim:b.classList.contains('v61-dim'),lock:!!b.querySelector('.v61-padlock')}:null})(),card:!!document.getElementById('v68-card')}))()")
        ck(s, "invitado: sin manifiesto ni service worker (no se puede instalar)", not r["man"] and not r["sw"], str(r))
        ck(s, "invitado: «Instalar la app» difuminado y con candado", bool(r["nav"]) and r["nav"]["dim"] and r["nav"]["lock"] and not r["card"], str(r))
        await ev(gp, "v68Install();0"); await gp.wait_for_timeout(200)
        ck(s, "invitado: al tocar Instalar pide crear cuenta", not await ev(gp, "!!document.getElementById('v68-modal')"))
        # usuario registrado: se habilita
        await ev(gp, "user={id:'u-prueba',email:'prueba@artlas.ar'};updateUserUI();0")
        reg = await ev(gp, "(async()=>{const r=await Promise.race([navigator.serviceWorker.ready,new Promise(x=>setTimeout(()=>x(null),8000))]);return {ok:!!r,man:!!document.querySelector('link[rel=manifest]')}})()")
        ck(s, "registrado: manifiesto y service worker activos", reg["ok"] and reg["man"], str(reg))
        r = await ev(gp, "(()=>{const b=document.querySelector('.v68-nav');return {dim:b.classList.contains('v61-dim'),badge:!!b.querySelector('.v68-badge'),first:b.previousElementSibling&&b.previousElementSibling.classList.contains('sec-label'),card:!!document.getElementById('v68-card')}})()")
        ck(s, "registrado: «Instalar la app» primero en Descargas y tarjeta de instalación", not r["dim"] and r["badge"] and r["first"] and r["card"], str(r))
        await ev(gp, "v68Install();0"); await gp.wait_for_timeout(200)
        ck(s, "antes de instalar pide aceptar la licencia vigente", await ev(gp, "!!document.getElementById('v69-modal')&&$('v69-ok').disabled&&!document.getElementById('v68-modal')"))
        await gp.click("#v69-ck2"); await gp.click("#v69-ok"); await gp.wait_for_timeout(300)
        ck(s, "sin aviso del navegador: muestra los pasos para instalar", await ev(gp, "!!document.querySelector('#v68-modal ol li')&&!document.getElementById('v69-modal')"))
        await ev(gp, "v68ModalClose();window.__pr=0;const e=new Event('beforeinstallprompt');e.prompt=async()=>{window.__pr=1};e.userChoice=Promise.resolve({outcome:'accepted'});window.dispatchEvent(e);0")
        await ev(gp, "v68Install()"); await gp.wait_for_timeout(200)
        ck(s, "con aviso del navegador: abre la instalación nativa", await ev(gp, "window.__pr===1&&localStorage.getItem('atlas_pwa_inst')==='1'&&!document.getElementById('v68-card')"))
        await ev(gp, "v68CardClose();0")
        # sin conexión: abre desde la copia guardada
        await gp.reload(); await gp.wait_for_function("typeof V60!=='undefined'"); await gp.wait_for_timeout(600)
        ctrl = await ev(gp, "!!navigator.serviceWorker.controller")
        await pctx.set_offline(True)
        try:
            await gp.reload(); await gp.wait_for_function("typeof V60!=='undefined' && typeof v61GateGuest==='function'", timeout=8000)
            off = await ev(gp, "V60.ver") == CFG["ver"]
        except Exception as e: off = False
        await pctx.set_offline(False)
        ck(s, "sin conexión: la app abre igual (copia guardada)", ctrl and off, f"controlada={ctrl}")
        # actualización: se publica una versión nueva del service worker
        await ev(gp, "window.__antes=1;0")
        swp = os.path.join(R, "dist", "fullstack", "sw.js"); orig = open(swp, encoding="utf8").read()
        open(swp, "w", encoding="utf8").write(orig.replace(f'const VER = "{CFG["ver"]}"', 'const VER = "v9.9-prueba"'))
        try:
            await ev(gp, "(async()=>{const r=await navigator.serviceWorker.getRegistration();await r.update();})()")
            await gp.wait_for_selector("#v68-toast", timeout=10000)
            tt = await ev(gp, "document.getElementById('v68-toast').innerText")
            ck(s, "aviso «Hay una versión nueva» con la versión", "versión nueva" in tt and "v9.9-prueba" in tt, tt[:100])
            async with gp.expect_navigation(timeout=10000):
                await gp.click("#v68-toast .up")
            await gp.wait_for_function("typeof V60!=='undefined'")
            act = await ev(gp, "(async()=>{const ch=new MessageChannel();const p=new Promise(x=>{ch.port1.onmessage=e=>x(e.data.ver);setTimeout(()=>x(''),3000)});navigator.serviceWorker.controller.postMessage({type:'VER'},[ch.port2]);return await p})()")
            ck(s, "«Actualizar ahora» recarga con la versión nueva", act == "v9.9-prueba" and await ev(gp, "typeof window.__antes==='undefined'"), str(act))
        except Exception as e:
            ck(s, "aviso «Hay una versión nueva» con la versión", False, str(e)[:120]); ck(s, "«Actualizar ahora» recarga con la versión nueva", False)
        finally:
            open(swp, "w", encoding="utf8").write(orig)
        ck(s, "sin errores de JavaScript", not gp.errs, str(gp.errs[:1]))
        await pctx.close()
        # app instalada (ventana propia): exige cuenta
        ap = await new_page(ctx, FS + "app.html?app=1")
        r = await ev(ap, "(()=>{const g=document.getElementById('v61-gate');return {std:v68Standalone(),demo:!!g.querySelector('.g-btn.demo'),note:!!g.querySelector('.g-appnote'),nav:!!document.querySelector('.v68-nav')}})()")
        ck(s, "app instalada: sin «Ingresar como invitado» y con aviso de cuenta", r["std"] and not r["demo"] and r["note"], str(r))
        await ev(ap, "v61GateGuest();v61GateHide(true);0"); await ap.wait_for_timeout(300)
        ck(s, "app instalada: no se puede entrar sin cuenta", await ev(ap, "v61GateVisible()") and "requiere una cuenta" in await ev(ap, "$('g-msg').textContent"))
        hp = await new_page(ctx, FS + "app.html?app=1#demo")
        ck(s, "app instalada: tampoco con el atajo #demo", await ev(hp, "v61GateVisible()"))
        await hp.close()
        await ev(ap, "user={id:'u-prueba',email:'prueba@artlas.ar'};updateUserUI();0"); await ap.wait_for_timeout(200)
        await ev(ap, "document.querySelector('#v61-gate .g-btn.primary').click();0"); await ap.wait_for_timeout(500)
        ck(s, "app instalada: pide aceptar la licencia antes de entrar", await ev(ap, "v61GateVisible()&&!!document.getElementById('v69-modal')"))
        await ap.click("#v69-ck2"); await ap.click("#v69-ok"); await ap.wait_for_timeout(700)
        ck(s, "app instalada: con cuenta entra al chat", not await ev(ap, "v61GateVisible()") and await ev(ap, "curView") == "chat" and not r["nav"])
        await ev(ap, "doLogout()"); await ap.wait_for_timeout(500)
        ck(s, "app instalada: al cerrar sesión vuelve a la pantalla de ingreso", await ev(ap, "v61GateVisible()"))

        s = suite("Protección contra copia")
        await ev(ap, "user={id:'u-prueba',email:'prueba@artlas.ar'};updateUserUI();v61GateEnter();0"); await ap.wait_for_timeout(600)
        r = await ev(ap, """(()=>{const f=(t,o)=>{const e=new MouseEvent('contextmenu',Object.assign({bubbles:true,cancelable:true},o||{}));t.dispatchEvent(e);return e.defaultPrevented};
          const k=o=>{const e=new KeyboardEvent('keydown',Object.assign({bubbles:true,cancelable:true},o));document.body.dispatchEvent(e);return e.defaultPrevented};
          getSelection().removeAllRanges();
          return {menu:f(document.getElementById('msgs')||document.body),campo:f(document.getElementById('inp')),f12:k({key:'F12'}),ver:k({key:'u',ctrlKey:true}),guardar:k({key:'s',ctrlKey:true}),dev:k({key:'I',ctrlKey:true,shiftKey:true}),escribir:(()=>{const e=new KeyboardEvent('keydown',{bubbles:true,cancelable:true,key:'a'});document.getElementById('inp').dispatchEvent(e);return e.defaultPrevented})(),copiar:k({key:'c',ctrlKey:true})}})()""")
        ck(s, "app instalada: bloquea menú contextual, F12, Ctrl+U, Ctrl+S y Ctrl+Shift+I", r["menu"] and r["f12"] and r["ver"] and r["guardar"] and r["dev"], str(r))
        ck(s, "app instalada: permite escribir, copiar y el menú en campos de texto", not r["campo"] and not r["escribir"] and not r["copiar"], str(r))
        await ap.close()
        wp = await new_page(ctx, FS + "app.html")
        ck(s, "en el navegador el menú contextual sigue disponible", not await ev(wp, "(()=>{const e=new MouseEvent('contextmenu',{bubbles:true,cancelable:true});document.body.dispatchEvent(e);return e.defaultPrevented})()"))
        raw = await ev(wp, "fetch('app.js').then(r=>r.text())")
        ck(s, "app.js publicado codificado (no se lee el código)", raw.startswith("/*ARTLAS-P*/") and "v61GateRender" not in raw and "callProvider" not in raw and "sk-" not in raw[:2000] and "MMFC" in raw[:400])
        ck(s, "el código codificado se recupera solo para el paquete Escritorio", "function v61GateRender(" in await ev(wp, "fetch('app.js').then(r=>r.text()).then(t=>v68Unwrap(t))"))
        hosts = await ev(wp, "['artlas.ar','www.artlas.ar','ARTLAS.AR.','artlas.netlify.app','artlas-ai-arg.netlify.app','66fd1a2b--artlas.netlify.app','main--artlas-ai-arg.netlify.app','localhost','','artlas-os.netlify.app','artlas-ucasal.netlify.app','deploy-preview-3--artlas-os.netlify.app','main--artlas-ucasal.netlify.app','artlas.ar.copia.com','notartlas.ar','copia.com','mi-sitio.netlify.app','artlas2.netlify.app','x.artlas.netlify.app','a.b--artlas.netlify.app','artlas-os2.netlify.app','x.artlas-ucasal.netlify.app','artlas-ucasal.netlify.app.copia.com'].map(h=>v68HostOk(h))")
        ck(s, "dominios autorizados (artlas.ar, artlas.netlify.app, artlas-ai-arg, artlas-os y artlas-ucasal .netlify.app, con sus vistas previas)", hosts == [True] * 13 + [False] * 10, str(hosts))
        await wp.close()
        cctx = await new_ctx(b)
        DFS = os.path.join(R, "dist", "fullstack")
        async def r_copia(route):
            fn = route.request.url.split("copia-no-autorizada.example/")[-1].split("?")[0].split("#")[0] or "app.html"
            fp = os.path.join(DFS, fn)
            if os.path.isfile(fp):
                ct = {"html": "text/html", "js": "application/javascript", "png": "image/png", "webp": "image/webp"}.get(fn.rsplit(".", 1)[-1], "application/octet-stream")
                await route.fulfill(status=200, body=open(fp, "rb").read(), content_type=ct)
            else: await route.fulfill(status=404, body="")
        await cctx.route("https://copia-no-autorizada.example/**", r_copia)
        cp = await new_page(cctx, "https://copia-no-autorizada.example/app.html"); await cp.wait_for_timeout(1800)
        r = await ev(cp, "({ov:!!document.getElementById('v68-copia'),txt:(document.getElementById('v68-copia')||{}).innerText||'',log:JSON.parse(localStorage.getItem('atlas_errlog')||'[]').some(x=>x.kind==='copia')})")
        ck(s, "copia en otro dominio: bloqueada con aviso", r["ov"] and "Copia no autorizada" in r["txt"], str(r)[:120])
        ck(s, "copia en otro dominio: queda en el registro de errores", r["log"])
        await ev(cp, "document.getElementById('v68-copia').remove();0"); await cp.wait_for_timeout(100)
        ck(s, "copia en otro dominio: el aviso no se puede quitar", await ev(cp, "!!document.getElementById('v68-copia')"))
        await cctx.close()

        # ---------- 13. licencia ----------
        s = suite("Licencia, términos de uso y privacidad")
        LV = CFG["licencia"]["ver"]
        lpg = await new_page(ctx, FS + "app.html")
        rr = await lpg.request.get(FS + "licencia-artlas.pdf")
        ck(s, "PDF de la licencia publicado (también en Web only)", rr.status == 200 and (await rr.body())[:4] == b"%PDF" and os.path.exists(os.path.join(R, "dist", "web-only", "licencia-artlas.pdf")))
        r = await ev(lpg, "(()=>{const c=$('v69-ck');return {ok:!!c,marcada:c&&c.checked,txt:($('v69-row')||{}).innerText||'',antes:!!(c&&c.closest('#user-forms'))}})()")
        ck(s, "casilla en «Cuenta AR.T.L.A.S.», sin marcar", r["ok"] and not r["marcada"] and r["antes"], str(r))
        ck(s, "texto: «He leído y acepto la Política de Privacidad, los Términos de Uso y la Licencia AR.T.L.A.S. " + LV + "»", r["txt"].strip() == "He leído y acepto la Política de Privacidad, los Términos de Uso y la Licencia AR.T.L.A.S. " + LV, r["txt"])
        await ev(lpg, "window.__su=null;supa={auth:{signUp:async o=>{window.__su=o;return {error:null}}}};$('u-email').value='nuevo@artlas.ar';$('u-pass').value='secreta123';0")
        await ev(lpg, "doSignup()")
        ck(s, "sin marcar la casilla no se puede crear la cuenta", await ev(lpg, "window.__su===null") and "aceptar" in await ev(lpg, "$('u-msg').textContent"))
        await ev(lpg, "$('v69-ck').checked=true;0"); await ev(lpg, "doSignup()")
        su = await ev(lpg, "window.__su")
        ck(s, "al registrarse guarda la aceptación en la cuenta (versión, fecha, origen)", bool(su) and su["options"]["data"]["artlas_lic"]["ver"] == LV and su["options"]["data"]["artlas_lic"]["origen"] == "registro" and "T" in su["options"]["data"]["artlas_lic"]["t"], str(su)[:200])
        ck(s, "y también en el navegador", await ev(lpg, "JSON.parse(localStorage.getItem('atlas_lic'))['nuevo@artlas.ar'].ver") == LV)
        # ingreso con usuario y clave (v6.8.3)
        MOCK = """window.__out=0;supa={auth:{signInWithPassword:async o=>({data:{user:window.__U,session:{}},error:null}),signOut:async()=>{window.__out++;return {}},updateUser:async d=>({data:{user:Object.assign({},window.__U,{user_metadata:d.data})}})},from:()=>{throw new Error('sin base')}};"""
        await ev(lpg, MOCK + "localStorage.removeItem('atlas_lic');user=null;updateUserUI();window.__U={id:'u-in',email:'ingreso@artlas.ar',user_metadata:{}};$('u-email').value='ingreso@artlas.ar';$('u-pass').value='secreta123';$('v69-ck').checked=false;0")
        await ev(lpg, "doLogin()"); await lpg.wait_for_timeout(200)
        ck(s, "ingresar sin tildar (cuenta sin aceptación): no entra y cierra esa sesión", await ev(lpg, "user===null&&window.__out===1") and "aceptar" in await ev(lpg, "$('u-msg').textContent"), await ev(lpg, "$('u-msg').textContent"))
        await ev(lpg, "$('v69-ck').checked=true;0"); await ev(lpg, "doLogin()"); await lpg.wait_for_timeout(300)
        r = await ev(lpg, "({u:!!user,acc:v69Accepted(),meta:user&&user.user_metadata&&user.user_metadata.artlas_lic&&user.user_metadata.artlas_lic.origen,modal:!!document.getElementById('v69-modal')})")
        ck(s, "ingresar tildando: entra y registra la aceptación en la cuenta (origen «ingreso»)", r["u"] and r["acc"] and r["meta"] == "ingreso" and not r["modal"], str(r))
        await ev(lpg, "user=null;updateUserUI();localStorage.removeItem('atlas_lic');window.__U={id:'u-ok',email:'ya@artlas.ar',user_metadata:{artlas_lic:{ver:'" + LV + "'}}};$('v69-ck').checked=false;0")
        await ev(lpg, "doLogin()"); await lpg.wait_for_timeout(200)
        ck(s, "cuenta que ya aceptó esta versión: entra sin volver a tildar", await ev(lpg, "!!user&&user.email==='ya@artlas.ar'"))
        await ev(lpg, "user={id:'u-ses',email:'sesion@artlas.ar',user_metadata:{}};v61GateShow();0")
        await ev(lpg, "v61GateEnter();0"); await lpg.wait_for_timeout(200)
        ck(s, "sesión recuperada sin aceptación: al entrar pide aceptar (la pantalla de ingreso sigue)", await ev(lpg, "!!document.getElementById('v69-modal')&&v61GateVisible()"))
        await lpg.click("#v69-modal .acts .btn:not(.dark)"); await lpg.wait_for_timeout(400)
        ck(s, "«Cancelar y cerrar sesión»: cierra la sesión y vuelve al ingreso", await ev(lpg, "user===null&&v61GateVisible()&&!document.getElementById('v69-modal')"))
        await ev(lpg, "v61GateHide(true);user={id:'u-den',email:'adentro@artlas.ar',user_metadata:{}};updateUserUI();0"); await lpg.wait_for_timeout(200)
        ck(s, "sesión que aparece ya adentro de la plataforma: también pide aceptar", await ev(lpg, "!!document.getElementById('v69-modal')"))
        await ev(lpg, "v69Close();user=null;updateUserUI();supa=null;0")
        await ev(lpg, "supa=null;0")
        await ev(lpg, "v69Ver();0")
        r = await ev(lpg, "({h:document.querySelectorAll('#v69-modal .v69-doc h4').length,ck:!!document.getElementById('v69-ck2'),pdf:document.querySelector('#v69-modal .v69-pdf').getAttribute('href'),txt:document.querySelector('#v69-modal .v69-doc').innerText})")
        ck(s, "el documento completo se lee en la app (19 secciones, anexo de privacidad e historial) con el PDF", r["h"] == 21 and not r["ck"] and r["pdf"] == "licencia-artlas.pdf" and "Ley N.º 25.326" in r["txt"] and "cite" not in r["txt"], str({k: r[k] for k in ("h", "ck", "pdf")}))
        await lpg.click("#v69-modal .v69-tabs button[data-l=en]")
        r = await ev(lpg, "({h:document.querySelectorAll('#v69-modal .v69-doc h4').length,txt:document.querySelector('#v69-modal .v69-doc').innerText,f:$('v69-fecha').textContent,on:document.querySelector('#v69-modal .v69-tabs button.on').dataset.l})")
        ck(s, "versión en inglés en la misma versión del documento (botón Español / English)", r["h"] == 21 and r["on"] == "en" and "Law No. 25,326" in r["txt"] and "Spanish version prevails" in r["txt"] and "effective" in r["f"], str({k: r[k] for k in ("h", "on", "f")}))
        import subprocess
        try: ptxt = subprocess.run(["pdftotext", os.path.join(R, "dist", "fullstack", "licencia-artlas.pdf"), "-"], capture_output=True, text=True).stdout
        except Exception: ptxt = ""
        ck(s, "el PDF trae el español y el inglés", (not ptxt) or ("Política de Privacidad, Términos de Uso y Licencia de Usuario" in ptxt and "Privacy Policy, Terms of Use and End-User License" in ptxt and "Annex I" in ptxt))
        await ev(lpg, "v69Close();v61GateShow();0")
        ck(s, "enlace al documento en la pantalla de ingreso y en la barra lateral", await ev(lpg, "!!document.querySelector('#v61-gate .g-lic')&&!!document.querySelector('#side-bottom .v69-foot')"))
        await lpg.close()
        lctx = await new_ctx(b, accept_downloads=True)
        dp = await new_page(lctx, FS + "app.html"); await guest(dp)
        await ev(dp, "user={id:'u-lic',email:'descarga@artlas.ar'};updateUserUI();buildDesktop();0"); await dp.wait_for_timeout(300)
        ck(s, "descargar Escritorio pide aceptar la licencia vigente", await ev(dp, "!!document.getElementById('v69-modal')"))
        async with dp.expect_download() as dl:
            await dp.click("#v69-ck2"); await dp.click("#v69-ok")
        d = await dl.value; tmp = tempfile.mkdtemp(); zp = os.path.join(tmp, "e.zip"); await d.save_as(zp)
        ck(s, "el zip de Escritorio incluye la licencia en PDF", "licencia-artlas.pdf" in zipfile.ZipFile(zp).namelist() and "ARTLAS.html" in zipfile.ZipFile(zp).namelist())
        async with dp.expect_download() as dl:
            await ev(dp, "downloadRagLocal();0")
        d = await dl.value; zp2 = os.path.join(tmp, "r.zip"); await d.save_as(zp2)
        ck(s, "aceptada una vez: RAG descarga directo, con la licencia en PDF", "ARTLAS_RAG/LICENCIA-AR.T.L.A.S.pdf" in zipfile.ZipFile(zp2).namelist() and not await ev(dp, "!!document.getElementById('v69-modal')"))
        ck(s, "sin errores de JavaScript", not dp.errs, str(dp.errs[:1]))
        await lctx.close()

        # ---------- AR.T.L.A.S. OS (núcleo, IA local, ofimática, asistente) ----------
        import importlib.util as _iu
        _sp = _iu.spec_from_file_location("os_pruebas", os.path.join(R, "tests", "os_pruebas.py")); _m = _iu.module_from_spec(_sp); _sp.loader.exec_module(_m)
        await _m.run(sys.modules[__name__], b, FS)
        await b.close()

    tot = sum(x["total"] for x in SUITES); ok = sum(x["ok"] for x in SUITES)
    rep = {"fecha": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "ver": CFG["ver"], "total": tot, "ok": ok,
           "suites": [{"nombre": x["nombre"], "total": x["total"], "ok": x["ok"], "fallas": x["fallas"]} for x in SUITES]}
    json.dump(rep, open(os.path.join(R, "tests", "ultimo-reporte.json"), "w"), ensure_ascii=False, indent=1)
    print(f"\n{'✓' if ok == tot else '✗'} {ok}/{tot} pruebas aprobadas")
    sys.exit(0 if ok == tot else 1)

if __name__ == "__main__":
    asyncio.run(main())
