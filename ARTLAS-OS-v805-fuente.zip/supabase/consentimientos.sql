-- AR.T.L.A.S. · Registro de aceptación de la Política de Privacidad, Términos de Uso y Licencia
-- Ejecutar UNA vez en Supabase → SQL Editor → New query → Run
-- (después de registro-errores.sql, que crea la función atlas_is_admin()).
-- Cada usuario puede registrar SU aceptación y leer la suya. Nadie puede modificarla ni borrarla
-- desde la app. La fecha/hora y la IP las pone el servidor, no el navegador.

create table if not exists public.atlas_consents (
  id          bigserial primary key,
  user_id     uuid not null references auth.users(id) on delete cascade,
  email       text,
  doc_ver     text not null,
  accepted_at timestamptz not null default now(),
  app_ver     text,
  origen      text,
  ua          text,
  ip          text,
  unique (user_id, doc_ver)
);
alter table public.atlas_consents enable row level security;

-- fecha/hora e IP del servidor (PostgREST expone los encabezados de la solicitud)
create or replace function public.atlas_consents_sello()
returns trigger language plpgsql security definer set search_path = public as $$
declare h json;
begin
  new.accepted_at := now();
  new.email := coalesce(auth.jwt() ->> 'email', new.email);
  begin
    h := current_setting('request.headers', true)::json;
    new.ip := split_part(coalesce(h ->> 'cf-connecting-ip', h ->> 'x-forwarded-for', h ->> 'x-real-ip', ''), ',', 1);
  exception when others then new.ip := null;
  end;
  return new;
end $$;
drop trigger if exists atlas_consents_sello on public.atlas_consents;
create trigger atlas_consents_sello before insert on public.atlas_consents
  for each row execute function public.atlas_consents_sello();

drop policy if exists "atlas_consents_insert" on public.atlas_consents;
create policy "atlas_consents_insert" on public.atlas_consents
  for insert to authenticated
  with check (auth.uid() = user_id and char_length(coalesce(ua,'')) <= 220 and char_length(doc_ver) <= 20);

drop policy if exists "atlas_consents_select" on public.atlas_consents;
create policy "atlas_consents_select" on public.atlas_consents
  for select to authenticated
  using (auth.uid() = user_id or public.atlas_is_admin());

-- Consulta útil para el administrador:
-- select email, doc_ver, accepted_at, origen, app_ver, ip from public.atlas_consents order by accepted_at desc;
