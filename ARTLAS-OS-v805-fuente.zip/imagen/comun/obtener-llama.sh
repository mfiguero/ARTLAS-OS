#!/bin/bash
# AR.T.L.A.S. OS · descarga el llama-server oficial (ggml-org/llama.cpp) FUERA de la imagen, en el runner,
# para copiarlo a /opt/artlas/llama. Uso: obtener-llama.sh <x64|arm64> <carpeta destino>
# v8.0.2: sin la API de GitHub (límite de consultas): lee las versiones de la página de releases y prueba las
# más nuevas hasta encontrar el paquete publicado (desde 2026 los binarios son .tar.gz: llama-bNNNN-bin-ubuntu-x64.tar.gz).
set -uo pipefail
ARQ="$1"; DEST="$2"; mkdir -p "$DEST"; T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
TAGS=$(curl -fsSL https://github.com/ggml-org/llama.cpp/releases | grep -o '/ggml-org/llama.cpp/releases/tag/b[0-9]*' | sed 's|.*/||' | awk '!s[$0]++' | head -8)
[ -n "$TAGS" ] || { echo "::warning::No se pudo leer la lista de versiones de llama.cpp"; exit 1; }
for TAG in $TAGS; do
  for EXT in tar.gz zip; do
    URL="https://github.com/ggml-org/llama.cpp/releases/download/$TAG/llama-$TAG-bin-ubuntu-$ARQ.$EXT"
    if curl -fsSL "$URL" -o "$T/l.$EXT"; then
      mkdir -p "$T/x"; if [ "$EXT" = zip ]; then unzip -q "$T/l.zip" -d "$T/x"; else tar -xzf "$T/l.tar.gz" -C "$T/x"; fi
      LS=$(find "$T/x" -type f -name llama-server | head -1)
      if [ -n "$LS" ]; then
        cp -a "$(dirname "$LS")"/. "$DEST"/; chmod 0755 "$DEST/llama-server"; echo "$TAG" > "$DEST/VERSION"
        echo "OK: llama-server $TAG ($ARQ) listo en $DEST ($(du -sh "$DEST" | cut -f1))"; exit 0
      fi
      rm -rf "$T/x" "$T/l.$EXT"
    fi
  done
done
echo "::warning::No se encontró llama-server para ubuntu-$ARQ en las últimas versiones"; exit 1
