#!/bin/bash
# AR.T.L.A.S. OS · se ejecuta DENTRO del sistema que se está construyendo (chroot), en la ISO y en la Raspberry Pi.
# Requiere que ya estén copiados /opt/artlas/{app,nucleo,rag} y los archivos de imagen/comun/raiz.
set -euo pipefail
TINY=0; [ "$(cat /etc/artlas-edicion 2>/dev/null)" = tiny ] && TINY=1   # v8.0: edición Tiny
echo "== AR.T.L.A.S. OS: configurando el sistema =="
chmod 0440 /etc/sudoers.d/artlas
chmod 0755 /usr/local/sbin/artlas-sistema /usr/local/sbin/artlas-primer-arranque /usr/local/bin/artlas-kiosco
sed -i 's/^# *\(es_AR.UTF-8\)/\1/; s/^# *\(en_US.UTF-8\)/\1/' /etc/locale.gen || true
locale-gen || true
update-locale LANG=es_AR.UTF-8 || true
ln -sf /usr/share/zoneinfo/America/Argentina/Buenos_Aires /etc/localtime || true
systemctl enable artlas-primer-arranque.service artlas-nucleo.service NetworkManager.service || true
# v7.8.2: arranque más rápido (no esperar la red para mostrar la interfaz) y memoria comprimida (zram) para 4 GB
systemctl disable NetworkManager-wait-online.service systemd-networkd-wait-online.service 2>/dev/null || true
systemctl mask NetworkManager-wait-online.service 2>/dev/null || true
printf 'ALGO=zstd\nPERCENT=60\nPRIORITY=100\n' > /etc/default/zramswap; systemctl enable zramswap.service 2>/dev/null || true
[ -f /etc/default/grub ] && sed -i 's/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT=1/' /etc/default/grub || true
chmod 0755 /usr/local/bin/artlas-portapapeles 2>/dev/null || true

echo "== Software adicional: Flathub (VS Code, GIMP, VLC…) =="
[ "$TINY" = 1 ] || flatpak remote-add --system --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo || echo "AVISO: no se pudo agregar Flathub"
chmod 0755 /usr/local/bin/artlas-sesion 2>/dev/null || true

echo "== Ollama (modelos de IA locales; se descargan desde Modelos IA) =="
if [ "${ARTLAS_CON_OLLAMA:-0}" = "1" ]; then   # v7.8: el motor local es el propio (llama.cpp); Ollama queda opcional
  if curl -fsSL https://ollama.com/install.sh -o /tmp/ollama-install.sh; then
    sh /tmp/ollama-install.sh || echo "AVISO: no se pudo instalar Ollama"
    systemctl enable ollama.service 2>/dev/null || true
  else echo "AVISO: sin acceso a ollama.com"; fi
fi

echo "== AR.T.L.A.S. RAG (entorno Python con llama.cpp) =="
if [ -f /opt/artlas/rag/rag_local.py ] && [ "$TINY" = 0 ]; then
  python3 -m venv /opt/artlas/rag/venv
  /opt/artlas/rag/venv/bin/pip install --no-cache-dir --upgrade pip
  /opt/artlas/rag/venv/bin/pip install --no-cache-dir flask huggingface_hub pypdf python-docx openpyxl
  /opt/artlas/rag/venv/bin/pip install --no-cache-dir --prefer-binary llama-cpp-python \
      --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu \
    || CMAKE_ARGS="-DGGML_NATIVE=OFF" /opt/artlas/rag/venv/bin/pip install --no-cache-dir llama-cpp-python \
    || echo "AVISO: llama-cpp-python no se pudo instalar; RAG pedirá instalarlo"
  # servidor compatible con OpenAI de llama.cpp: el motor de IA local de AR.T.L.A.S. OS (sin Ollama ni GPU)
  /opt/artlas/rag/venv/bin/pip install --no-cache-dir fastapi uvicorn sse-starlette starlette-context pydantic-settings || echo "AVISO: faltan dependencias del servidor llama.cpp"
  if /opt/artlas/rag/venv/bin/python3 -c "import llama_cpp" 2>/dev/null; then echo "OK: llama_cpp disponible para el motor de IA local"
  else echo "::warning::llama_cpp NO se pudo importar: el motor de IA local no va a funcionar"; fi
  rm -f /opt/artlas/rag/*.bat /opt/artlas/rag/*.ico
fi
echo "== Motor de IA local: llama.cpp oficial (llama-server, sin Python) =="
# v7.8.3: el binario oficial evita depender de llama-cpp-python (sin ruedas para Python 3.13 y sin compilar en la imagen)
ARQ=$(dpkg --print-architecture)
# v8.0.2: construir.sh ya dejó el binario oficial en /opt/artlas/llama (descargado en el runner, fuera de la imagen)
LS=""; [ -x /opt/artlas/llama/llama-server ] && LS=/opt/artlas/llama/llama-server
if [ -z "$LS" ] && [ "$ARQ" = amd64 ] && [ "$TINY" = 0 ]; then   # respaldo: compilar llama-server (≈ 5–10 min)
  apt-get install -y -q --no-install-recommends git >/dev/null 2>&1 || true
  if git clone --depth 1 https://github.com/ggml-org/llama.cpp /tmp/llama.cpp; then
    cmake -S /tmp/llama.cpp -B /tmp/llama.cpp/b -DGGML_NATIVE=OFF -DLLAMA_CURL=OFF -DBUILD_SHARED_LIBS=OFF -DCMAKE_BUILD_TYPE=Release >/dev/null \
      && cmake --build /tmp/llama.cpp/b --target llama-server -j"$(nproc)" >/dev/null \
      && mkdir -p /opt/artlas/llama && cp /tmp/llama.cpp/b/bin/llama-server /opt/artlas/llama/ && LS=/opt/artlas/llama/llama-server
    rm -rf /tmp/llama.cpp
  fi
fi
if [ -n "$LS" ]; then
  chmod 0755 "$LS"
  printf '#!/bin/bash\n# AR.T.L.A.S. OS · llama-server oficial con sus bibliotecas\nD="%s"\nexport LD_LIBRARY_PATH="$D${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"\nexec "$D/llama-server" "$@"\n' "$(dirname "$LS")" > /usr/local/bin/artlas-llama-server
  chmod 0755 /usr/local/bin/artlas-llama-server
  /usr/local/bin/artlas-llama-server --version >/dev/null 2>&1 && echo "OK: llama-server listo" || echo "::warning::llama-server no arranca en esta imagen"
else
  echo "::warning::No se pudo obtener llama-server; queda el respaldo con Python (llama_cpp)"
fi

apt-get clean
rm -rf /var/lib/apt/lists/* /tmp/* 2>/dev/null || true
echo "== AR.T.L.A.S. OS listo =="
