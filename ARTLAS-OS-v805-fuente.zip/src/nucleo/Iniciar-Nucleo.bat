@echo off
chcp 65001 >nul
title AR.T.L.A.S. OS - Nucleo local
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Falta Node.js 18 o superior. Descargalo desde https://nodejs.org ^(version LTS^) y volve a abrir este archivo.
  echo.
  pause
  exit /b 1
)
node "%~dp0artlas-nucleo.mjs" %*
pause
