# AR.T.L.A.S. OS · servidor mínimo del motor de IA local (llama.cpp), compatible con la API de OpenAI.
# Solo usa la biblioteca estándar + llama_cpp (el mismo entorno de AR.T.L.A.S. RAG); escucha solo en 127.0.0.1.
import argparse, json, sys, threading, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
ap = argparse.ArgumentParser()
ap.add_argument("--model", required=True); ap.add_argument("--port", type=int, default=8771)
ap.add_argument("--n_ctx", type=int, default=2048); ap.add_argument("--n_threads", type=int, default=2)
a = ap.parse_args()
print("Cargando modelo:", a.model, flush=True)
try:
    from llama_cpp import Llama
except Exception as e:
    print("ERROR: no se pudo importar llama_cpp:", repr(e), flush=True); sys.exit(3)
t0 = time.time()
llm = Llama(model_path=a.model, n_ctx=a.n_ctx, n_threads=a.n_threads, verbose=False)
print("Modelo listo en %.1f s" % (time.time() - t0), flush=True)
LOCK = threading.Lock(); NAME = a.model.rsplit("/", 1)[-1]
class H(BaseHTTPRequestHandler):
    def log_message(self, *x): pass
    def _j(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path.startswith("/v1/models"): return self._j(200, {"object": "list", "data": [{"id": NAME, "object": "model"}]})
        self._j(404, {"error": "no encontrado"})
    def do_POST(self):
        if not self.path.startswith("/v1/chat/completions"): return self._j(404, {"error": "no encontrado"})
        n = int(self.headers.get("Content-Length") or 0)
        try: req = json.loads(self.rfile.read(n) or b"{}")
        except Exception: return self._j(400, {"error": "JSON inválido"})
        kw = {"messages": req.get("messages") or [], "max_tokens": int(req.get("max_tokens") or 512), "temperature": float(req.get("temperature", 0.7))}
        try:
            with LOCK: out = llm.create_chat_completion(**kw)
            self._j(200, out)
        except Exception as e:
            self._j(500, {"error": str(e)})
ThreadingHTTPServer(("127.0.0.1", a.port), H).serve_forever()
