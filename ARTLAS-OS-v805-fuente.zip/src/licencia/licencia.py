#!/usr/bin/env python3
"""
AR.T.L.A.S. · Política de Privacidad, Términos de Uso y Licencia
Fuente única del documento. Genera:
  - src/recursos/40-licencia.js   (texto para ver dentro de la app: ARTLAS_LIC_HTML)
  - src/sitio/licencia-artlas.pdf (PDF que se publica y va en los paquetes)
Uso:  python3 src/licencia/licencia.py     (requiere Playwright con Chromium)
La versión y la fecha del documento se toman de artlas.config.json → "licencia".
Texto original: Prof. Ing. Mario M. Figueroa de la Cruz (5/10/2026). Traducción al inglés: src/licencia/licencia_en.py.
"""
import json, os, html, asyncio

R = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CFG = json.load(open(os.path.join(R, "artlas.config.json"), encoding="utf8"))
LIC = CFG["licencia"]
M = LIC.get("marca", "®")
A = "AR.T.L.A.S."
AM = A + M
CONTACTO = LIC["contacto"]

TITULO = "Política de Privacidad, Términos de Uso y Licencia de Usuario"
ALCANCE = f"{A} OS · {A} Desktop · {A} RAG · {A} Apps · Plataforma y componentes asociados"
META = [("Versión del documento", f"Licencia {A} {LIC.get('original', LIC['ver'])} (original, {LIC.get('fecha_original', LIC['fecha'])})"),
        ("Versión nueva", f"Licencia {A} {LIC['ver']} · {A} OS"), ("Fecha de vigencia", LIC["fecha"]),
        ("Titular / Autor", "Prof. Ing. Mario M. Figueroa de la Cruz"), ("Marca / Ecosistema", "AI-TECH.ar · ARTLAS.ar y subdominios"),
        ("Contacto", CONTACTO)]
IMPORTANTE = (f"El acceso, registro, descarga o utilización de cualquier versión de {A} implica que el usuario declara haber leído y "
              f"aceptado este documento. La gratuidad de {A} no significa que el software sea de código abierto ni que se conceda "
              "autorización para copiarlo, modificarlo, redistribuirlo, sublicenciarlo o incorporarlo a otros productos.")

# cada sección: (título, [bloques]); bloque = str (párrafo) o ("lista", [ítems])
S = [
 ("Objeto y alcance", [
  f"Este documento establece las condiciones bajo las cuales se autoriza el acceso y uso de {A} y de sus diferentes distribuciones, incluyendo, sin limitación, {A} Desktop, {A} RAG, aplicaciones, interfaces web, módulos, componentes, documentación, diseños, recursos gráficos, configuraciones, scripts y demás elementos que formen parte del ecosistema {A}, salvo aquellos componentes de terceros que se encuentren expresamente sujetos a sus propias licencias. La autorización concedida es una licencia limitada de uso y no constituye una venta, cesión de derechos de propiedad intelectual ni transferencia de titularidad."]),
 ("Gratuidad y carácter no exclusivo de la licencia", [
  f"{A} puede ser puesto a disposición del usuario en forma gratuita. La gratuidad se refiere al derecho de utilización autorizado por el titular y no implica una licencia Open Source, una licencia de dominio público ni una autorización general para reutilizar el software o sus componentes. La licencia es personal, limitada, revocable, no exclusiva y no transferible, salvo autorización expresa y escrita del titular."]),
 ("Propiedad intelectual", [
  f"El código fuente y/o código objeto, arquitectura, estructura, organización, interfaz, diseño, documentación, textos, nombres, logotipos, elementos visuales, configuraciones originales y demás componentes propios de {A} constituyen propiedad intelectual de sus respectivos titulares. En particular, los derechos correspondientes al desarrollo original de {A} pertenecen a su autor/titular, salvo los elementos de terceros expresamente identificados. La legislación argentina reconoce expresamente a los programas de computación, tanto en sus versiones fuente como objeto, dentro del régimen de propiedad intelectual, y contempla contratos de licencia para el uso o reproducción de software."]),
 ("Usos expresamente permitidos", [
  "El usuario podrá, mientras mantenga vigente esta licencia:",
  ("lista", [f"a) Descargar e instalar una copia legítima de {A} obtenida desde una fuente autorizada.",
             f"b) Utilizar {A} para fines personales, académicos, profesionales, de investigación o institucionales lícitos.",
             "c) Ejecutar el software en los equipos para los cuales se haya autorizado su utilización.",
             "d) Realizar una única copia de seguridad cuando ello resulte necesario para proteger el ejemplar legítimamente obtenido, siempre que dicha copia permanezca bajo control del usuario y no sea utilizada para redistribución o para crear productos derivados."]),
  "Cualquier uso no contemplado expresamente en esta sección se considera no autorizado, salvo permiso escrito del titular."]),
 ("Usos prohibidos", [
  "Sin autorización previa, expresa y escrita del titular, queda prohibido:",
  ("lista", [f"a) Copiar, clonar, duplicar o reproducir {A} total o parcialmente con el propósito de crear otra aplicación, plataforma, producto o servicio.",
             f"b) Copiar, extraer, reutilizar o incorporar código fuente, código objeto, scripts, módulos, algoritmos implementados, estructuras de datos, componentes, configuraciones o lógica propia de {A} en otro software.",
             f"c) Crear obras derivadas, forks, reimplementaciones o versiones modificadas de {A} destinadas a ser distribuidas, publicadas o explotadas como producto independiente.",
             f"d) Cambiar, eliminar, ocultar o sustituir los nombres de {A}, sus autores, titulares, avisos de copyright, marcas, créditos o referencias de autoría.",
             f"e) Redistribuir, vender, alquilar, sublicenciar, publicar o poner a disposición de terceros copias de {A} fuera de los canales expresamente autorizados.",
             f"f) Incorporar {A} o partes sustanciales de su código, diseño o arquitectura dentro de otra aplicación o producto.",
             "g) Descompilar, desensamblar, realizar ingeniería inversa o intentar obtener el código fuente, salvo cuando una excepción legal obligatoria resulte aplicable.",
             f"h) Utilizar {A} como base para desarrollar un producto que sea presentado como propio o que induzca a confusión respecto de su autoría, origen o titularidad.",
             "i) Eliminar o alterar mecanismos de identificación, licenciamiento, atribución, protección o control incorporados por el titular.",
             f"j) Utilizar, publicar o distribuir componentes propietarios de {A} de manera independiente del producto autorizado.",
             f"k) Registrar como propia una aplicación, marca, nombre, diseño o producto que reproduzca sustancialmente elementos protegidos de {A} o que pueda generar confusión sobre su origen."]),
  "Estas restricciones no pretenden impedir el uso legítimo de bibliotecas, frameworks, modelos o componentes de terceros que posean licencias independientes y que sean identificados como tales."]),
 ("Componentes y licencias de terceros", [
  f"{A} puede integrar, comunicarse con o distribuir componentes de terceros, bibliotecas, modelos de IA, APIs, frameworks, servicios y otros recursos sometidos a sus propias condiciones de licencia. Las restricciones de este documento se aplican a los elementos propios de {A}. Los componentes de terceros continúan sujetos a sus respectivas licencias. Nada de este documento pretende restringir derechos que una licencia de terceros conceda legítimamente al usuario. Cuando corresponda, la distribución de {A} deberá incluir o señalar las licencias aplicables a dichos componentes."]),
 ("Autoría, nombres y atribución", [
  f"El usuario no podrá suprimir ni modificar las referencias de autoría o titularidad de {A}. No se autoriza a presentar como propio el desarrollo, arquitectura, código, documentación o diseño original de {A}. El reconocimiento académico o técnico de {A}, cuando corresponda, es bienvenido y compatible con esta licencia, siempre que no implique atribuir al usuario la autoría del software."]),
 ("Distribución y publicación", [
  f"La publicación de enlaces oficiales hacia los sitios de descarga o distribución autorizados no constituye una infracción de esta licencia, siempre que el enlace dirija a la fuente legítima y no se altere el software. No se autoriza alojar, empaquetar, republicar o redistribuir instaladores, ejecutables, paquetes o copias de {A} en repositorios, sitios web, tiendas, servicios de almacenamiento o canales de terceros sin autorización expresa.",
  f"Son sitios oficiales de distribución y uso de {A}: artlas.ar y sus subdominios, artlas.netlify.app, artlas-ai-arg.netlify.app, artlas-os.netlify.app y artlas-ucasal.netlify.app, junto con las vistas previas que Netlify genera para cada uno de ellos, además de los que el titular autorice por escrito. Una copia de {A} publicada o ejecutada desde otra dirección no está autorizada y la aplicación puede negarse a funcionar en ella."]),
 ("Privacidad y protección de datos personales", [
  f"Cuando el registro, acceso o utilización de {A} implique la recopilación, almacenamiento, tratamiento o procesamiento de datos personales, dichos datos serán tratados de conformidad con la legislación vigente y aplicable en materia de protección de datos personales. En la República Argentina, el tratamiento de datos personales se encuentra regulado, entre otras normas aplicables, por la Ley N.º 25.326 de Protección de los Datos Personales, que establece principios y obligaciones relacionados con el consentimiento del titular, la información, la finalidad del tratamiento, la seguridad y confidencialidad de los datos, así como los derechos de acceso, rectificación, actualización y supresión.",
  f"{A} procurará recopilar únicamente aquellos datos que resulten necesarios para permitir el registro, autenticación, funcionamiento, mantenimiento, seguridad y mejora de los servicios ofrecidos, evitando la recopilación de información que resulte innecesaria o desproporcionada respecto de las finalidades declaradas. El usuario será informado, de manera clara y comprensible, acerca de los datos que podrán ser recopilados, las finalidades para las cuales serán utilizados, los terceros o servicios externos que eventualmente puedan intervenir en su procesamiento y los derechos que le correspondan respecto de sus datos personales.",
  f"Cuando determinadas funcionalidades de {A} requieran la utilización de servicios, plataformas, APIs, modelos de inteligencia artificial, proveedores de infraestructura u otras tecnologías de terceros, el tratamiento de la información podrá quedar sujeto adicionalmente a las políticas de privacidad y condiciones de uso de dichos proveedores. El detalle de los datos que efectivamente recopila esta versión, sus finalidades, su almacenamiento, los servicios de terceros involucrados y el procedimiento para ejercer los derechos del titular se informa en el Anexo I de este documento."]),
 ("Datos introducidos por el usuario y contenido generado", [
  f"El usuario conserva los derechos que le correspondan sobre los datos, documentos, textos y demás contenidos que introduzca legítimamente en {A}, sujetos a las condiciones de los servicios externos que decida utilizar. El usuario es responsable de no introducir información cuya utilización esté prohibida por la ley, información de terceros sin autorización, secretos comerciales, credenciales, datos personales sensibles o material sujeto a restricciones contractuales, salvo que disponga de una base legal o autorización suficiente para hacerlo."]),
 ("Servicios de inteligencia artificial y proveedores externos", [
  f"{A} puede permitir la conexión con modelos, APIs, servicios de IA, proveedores cloud o herramientas de terceros. En esos casos, el procesamiento de datos puede depender de las condiciones del proveedor seleccionado por el usuario. El usuario deberá revisar las condiciones y políticas del proveedor externo antes de enviar información sensible o confidencial. {A} no asume automáticamente las obligaciones contractuales de cada proveedor externo."]),
 ("Incumplimiento y medidas", [
  "El incumplimiento de esta licencia podrá producir la suspensión o revocación inmediata de la autorización de uso y podrá dar lugar, según la naturaleza del hecho, a acciones extrajudiciales, administrativas, civiles y/o penales que correspondan conforme a la legislación aplicable. La Ley 11.723 contempla, entre otros supuestos, la reproducción o edición no autorizada y la alteración dolosa del nombre del autor o del título de una obra como conductas que pueden configurar defraudación de derechos de autor. El titular podrá preservar evidencia técnica disponible, formular denuncias ante organismos competentes y ejercer las acciones legales que estime pertinentes para proteger sus derechos."]),
 ("Aviso específico sobre clonación, forks y reutilización de código", [
  f"{A} no se distribuye bajo una licencia que autorice la creación libre de forks o aplicaciones derivadas. En consecuencia, descargar {A}, analizar su funcionamiento, utilizarlo como usuario o estudiar sus capacidades no concede por sí mismo autorización para copiar su código, arquitectura implementada, interfaz, módulos o componentes propietarios para desarrollar otro producto. Cualquier autorización para reutilización, integración, modificación, fork, licenciamiento OEM, white-label, distribución comercial o incorporación de componentes deberá constar expresamente por escrito y ser emitida por el titular."]),
 ("Limitación de garantía", [
  f"{A} se proporciona en la modalidad y estado en que sea puesto a disposición, sin perjuicio de las garantías que no puedan excluirse legalmente. El titular no garantiza que todas las funciones estén permanentemente disponibles, libres de errores o compatibles con todos los entornos. El usuario debe mantener copias de seguridad de sus datos y adoptar medidas razonables de seguridad para sus credenciales, API keys y demás información sensible."]),
 ("Modificaciones del documento", [
  "El titular podrá actualizar esta licencia, las condiciones de uso o la política de privacidad cuando sea necesario para reflejar cambios técnicos, legales o funcionales. Las versiones posteriores deberán identificarse mediante número de versión y fecha de vigencia. Cuando el cambio requiera consentimiento específico por la normativa aplicable, se solicitará la aceptación correspondiente."]),
 ("Aceptación electrónica", [
  f"Para crear una cuenta, ingresar con ella, descargar {A} Desktop, {A} RAG o el núcleo local de {A} OS, instalar la aplicación o ingresar a la aplicación instalada, el usuario debe aceptar expresamente este documento mediante una casilla de aceptación no premarcada, con el texto: “He leído y acepto la Política de Privacidad, los Términos de Uso y la Licencia {A} {LIC['ver']}”. La versión vigente del documento se indica en la propia casilla.",
  "Si la cuenta no tiene registrada la aceptación de la versión vigente, el ingreso no se completa: la sesión iniciada se cierra en el acto y se solicita la aceptación. Lo mismo ocurre con las sesiones que se recuperan automáticamente o mediante un código de recuperación de clave: antes de continuar se solicita la aceptación y, si el usuario la rechaza, la sesión se cierra. La aceptación se solicita una vez por cada versión del documento; cada nueva versión requiere una nueva aceptación.",
  "El sistema registra la fecha y hora de la aceptación, la versión del documento aceptado, la versión de la aplicación, la acción en la que se aceptó (registro, ingreso, descarga o instalación), el navegador utilizado y la dirección IP desde la que se realizó, con la única finalidad de acreditar el consentimiento otorgado."]),
 ("Legislación aplicable", [
  "Este documento se interpretará de conformidad con la legislación aplicable de la República Argentina, sin perjuicio de las normas imperativas que resulten aplicables al usuario por su lugar de residencia o utilización del servicio. Las cuestiones de competencia territorial deberán ser definidas en la versión contractual definitiva por asesoramiento jurídico profesional, especialmente si AR.T.L.A.S. se ofrece internacionalmente."]),
 ("Contacto y autorizaciones especiales", [
  f"Las solicitudes de autorización para integrar, modificar, reutilizar, redistribuir, licenciar, comercializar o incorporar componentes de {A} a otros productos deberán realizarse por escrito a través del canal oficial de AI-TECH.ar / ARTLAS.ar: {CONTACTO}. La ausencia de respuesta o de autorización expresa no deberá interpretarse como consentimiento."]),
 ("AR.T.L.A.S. OS: núcleo local, archivos, aplicaciones y navegación", [
  f"{A} OS es un entorno de trabajo que se ejecuta en el navegador del usuario. Su componente opcional, el «núcleo local», es un programa que el usuario descarga, ejecuta y controla en su propio equipo: escucha únicamente en la dirección local 127.0.0.1 y solo atiende a los navegadores que el propio usuario empareja mediante un código que se muestra en su equipo. Las carpetas habilitadas y los permisos se configuran exclusivamente en ese equipo.",
  "Con la autorización del usuario, el núcleo local puede:",
  ("lista", ["a) Leer, crear, modificar, renombrar y mover archivos, y enviarlos a una papelera restaurable, únicamente dentro de las carpetas que el usuario habilita.",
             "b) Listar y abrir las aplicaciones instaladas, consultar los procesos y la información del sistema y ejecutar comandos de diagnóstico incluidos en una lista blanca.",
             "c) Crear, convertir y abrir documentos con LibreOffice u OpenOffice, cuando estén instalados en el equipo.",
             "d) Comunicarse con modelos de inteligencia artificial que se ejecutan en el equipo (por ejemplo, mediante Ollama) y leer páginas web públicas a pedido del usuario o del asistente."]),
  "Las acciones que modifican archivos, abren aplicaciones o ejecutan comandos a pedido del asistente requieren la aprobación previa del usuario, que puede revisarlas una por una y rechazarlas. El núcleo deja constancia de esas acciones en un registro de actividad que permanece en el equipo del usuario. El usuario es responsable de las carpetas y permisos que habilita y de las acciones que aprueba; se recomienda mantener copias de seguridad de la información importante.",
  f"Cuando el usuario pide al asistente trabajar con el contenido de un archivo o de una página web, ese contenido se envía al modelo seleccionado. Si se trata de un modelo local, que se ejecuta en el navegador o en el equipo, la información no sale del equipo; si se trata de un proveedor externo, rige lo dispuesto en «Servicios de inteligencia artificial y proveedores externos». La opción «El contenido de mis archivos solo lo procesa un modelo local» impide enviarlo a proveedores externos.",
  "Por seguridad, el núcleo no accede a direcciones de la red local del usuario al leer páginas web. Los sitios que el usuario visita se rigen por sus propias condiciones de uso y políticas de privacidad.",
  "Para que el usuario pueda iniciarlo desde la interfaz de AR.T.L.A.S. OS, el núcleo registra en el sistema, solo para el usuario actual y sin permisos de administrador, un acceso propio («artlas-nucleo://»); el navegador solicita confirmación antes de abrirlo. Si el usuario lo activa, el núcleo también puede iniciarse automáticamente al ingresar al sistema. Ambas funciones pueden desactivarse desde la configuración del núcleo, y el inicio automático, también desde AR.T.L.A.S. OS.",
  "Cuando el navegador impide modificar ciertos archivos de una carpeta conectada desde el navegador, la operación puede realizarse a través del núcleo, siempre que esa carpeta se encuentre entre las habilitadas. Para habilitar una carpeta nueva, el usuario la elige en su equipo mediante el selector de carpetas del propio sistema operativo; la interfaz web no puede indicar rutas ni habilitar carpetas por sí misma.",
  f"El núcleo local forma parte de {A} y se encuentra alcanzado por todas las disposiciones de este documento, en particular por las relativas a propiedad intelectual y usos prohibidos."]),
]
DECLARACION = (f"{A} se ofrece gratuitamente para fomentar el acceso, la investigación, la educación y el uso legítimo de tecnologías de inteligencia artificial. "
               "La gratuidad constituye una facilidad de acceso y no una renuncia a los derechos de propiedad intelectual del titular. El usuario recibe una autorización de uso, "
               "no la propiedad del software. Todo derecho no concedido expresamente por este documento queda reservado al titular, en la medida permitida por la legislación aplicable.")
ANEXO = ("Anexo I · Datos que trata esta versión de " + A, [
  ("lista", [
   f"<b>Cuenta.</b> Correo electrónico y contraseña. La autenticación la gestiona Supabase; la contraseña se guarda cifrada (hash) en ese servicio y {A} no tiene acceso a ella.",
   "<b>Preferencias en la nube.</b> Con la sesión iniciada se guardan en la cuenta del usuario el modelo elegido, el modo del router y la configuración de proveedores. Solo el propio usuario puede leerlas. Las API keys se sincronizan únicamente si el usuario activa la opción «Sincronizar API keys con mi cuenta».",
   f"<b>Conversaciones, documentos, agentes y workflows.</b> Se guardan en el navegador o en el equipo del usuario. {A} no los almacena en sus servidores.",
   f"<b>Consultas a modelos de IA.</b> Se envían al proveedor que elija el usuario (por ejemplo OpenAI, Anthropic, Google, Groq o DeepSeek), directamente desde el navegador o, en la versión Full-Stack, a través de un intermediario técnico alojado en Netlify que no guarda el contenido. La búsqueda web se realiza solo cuando el usuario la pide, mediante servicios de búsqueda y lectura de páginas (DuckDuckGo, Wikipedia y Jina Reader). El código Python se ejecuta en el navegador del usuario.",
   f"<b>{A} Desktop y {A} RAG.</b> Se ejecutan en el equipo del usuario. {A} RAG procesa los documentos localmente, sin enviarlos a la nube.",
   f"<b>{A} OS y núcleo local.</b> Los archivos, la lista de aplicaciones y procesos, los íconos, el registro de actividad, las copias temporales de documentos y la configuración del núcleo se procesan y guardan en el equipo del usuario (carpeta .artlas-nucleo) y no se envían a los servidores de {A}. El contenido de un archivo o de una página solo sale del equipo cuando el usuario elige un proveedor de IA externo o realiza una búsqueda web (sección 19).",
   "<b>Registro de errores técnicos.</b> Tipo y mensaje del error (sin claves ni correos), versión, sección y navegador, para el mantenimiento y la seguridad de la plataforma.",
   "<b>Registro de aceptación.</b> Correo, versión del documento, fecha y hora, versión de la aplicación, acción, navegador y dirección IP, para acreditar el consentimiento (sección 16).",
   "<b>Finalidades.</b> Registro y autenticación, sincronización de preferencias, funcionamiento, seguridad, prevención de usos no autorizados y mantenimiento. Los datos no se venden ni se ceden a terceros, ni se usan para publicidad o elaboración de perfiles.",
   "<b>Servicios de terceros.</b> Supabase (cuentas y base de datos), Netlify (alojamiento del sitio), jsDelivr y cdnjs (bibliotecas) y los proveedores de IA o búsqueda que el usuario elija. Sus servidores pueden estar ubicados fuera de la República Argentina.",
   "<b>Conservación.</b> Mientras la cuenta esté activa. El registro de aceptación se conserva mientras resulte necesario para acreditar el consentimiento.",
   f"<b>Derechos del titular.</b> Acceso, rectificación, actualización y supresión de los datos, solicitándolos por escrito a {CONTACTO}."]),
  "El titular de los datos personales tiene la facultad de ejercer el derecho de acceso a los mismos en forma gratuita a intervalos no inferiores a seis meses, salvo que se acredite un interés legítimo al efecto conforme lo establecido en el artículo 14, inciso 3 de la Ley N.º 25.326. La Agencia de Acceso a la Información Pública, en su carácter de Órgano de Control de la Ley N.º 25.326, tiene la atribución de atender las denuncias y reclamos que interpongan quienes resulten afectados en sus derechos por incumplimiento de las normas vigentes en materia de protección de datos personales."])

HISTORIAL = [("v6.8.2", "5 de octubre de 2026", "Versión inicial."),
             ("v6.8.3", "5 de octubre de 2026", "La aceptación se exige también para ingresar con la cuenta y para continuar una sesión recuperada (sección 16). Se agrega la versión en inglés."),
             ("v7.1", "7 de octubre de 2026", f"Versión nueva para {A} OS, sobre la base de la v6.8.3 original: se incorpora la sección 19 (núcleo local, archivos, aplicaciones y navegación), el núcleo se suma al alcance y a la aceptación electrónica (sección 16) y el Anexo I detalla los datos que se procesan en el equipo del usuario. Requiere una nueva aceptación."),
             ("v7.4", "8 de octubre de 2026", f"Se actualiza para {A} OS v7.4: la sección 19 incorpora el inicio del núcleo desde la interfaz (acceso «artlas-nucleo://» e inicio automático opcional) y la habilitación de carpetas mediante el selector del sistema operativo; la sección 8 enumera los sitios oficiales de distribución y uso. Requiere una nueva aceptación.")]

# ---------- versiones por idioma ----------
import sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import licencia_en
ES = dict(TITULO=TITULO, ALCANCE=ALCANCE, META=META, IMP_T="IMPORTANTE.", IMPORTANTE=IMPORTANTE, S=S, DECL_T="Declaración final del titular",
          DECLARACION=DECLARACION, ANEXO=ANEXO, HIST_T="Historial de versiones del documento", HISTORIAL=HISTORIAL,
          FIRMA=f'Titular / Autor: Prof. Ing. Mario M. Figueroa de la Cruz · Ecosistema: AI-TECH.ar · ARTLAS.ar y subdominios<br>Documento: {TITULO} · Licencia {A} {LIC["ver"]} · {LIC["fecha"]}',
          NOTA="Este documento se publica en español (versión original) y en inglés (traducción de cortesía). Ante cualquier discrepancia, prevalece la versión en español.")
EN = licencia_en.contenido(A, LIC, CONTACTO)
if len(EN["S"]) != len(S) or len(EN["ANEXO"][1][0][1]) != len(ANEXO[1][0][1]): raise SystemExit("La versión en inglés no coincide con la española (secciones o ítems)")

def bloques(bs):
    out = ""
    for b in bs:
        if isinstance(b, tuple): out += "<ul>" + "".join(f"<li>{x}</li>" for x in b[1]) + "</ul>"
        else: out += f"<p>{b}</p>"
    return out

def cuerpo(d=None):
    d = d or ES
    h = f'<div class="lic-imp"><b>{d["IMP_T"]}</b> {d["IMPORTANTE"]}</div>'
    for i, (t, bs) in enumerate(d["S"], 1): h += f'<h4>{i}. {t}</h4>' + bloques(bs)
    h += f'<div class="lic-decl"><b>{d["DECL_T"]}</b><p>{d["DECLARACION"]}</p></div>'
    h += f'<h4>{d["ANEXO"][0]}</h4>' + bloques(d["ANEXO"][1])
    h += f'<h4>{d["HIST_T"]}</h4><ul>' + "".join(f"<li><b>{v}</b> · {f} · {x}</li>" for v, f, x in d["HISTORIAL"]) + '</ul>'
    h += f'<p class="lic-firma">{d["FIRMA"]}</p>'
    return h

def meta_html(d=None):
    # las dos primeras filas (versión original y, abajo, versión nueva) ocupan todo el ancho
    return "".join(f"<div{' class=\"full\"' if i < 2 else ''}><span>{k}</span><b>{html.escape(v)}</b></div>" for i, (k, v) in enumerate((d or ES)["META"]))

PDF_CSS = """
@page{size:A4;margin:22mm 18mm 20mm 18mm}
*{box-sizing:border-box} body{font-family:'Liberation Sans','DejaVu Sans',Arial,sans-serif;color:#1d2b3c;font-size:10.4pt;line-height:1.5;margin:0}
.cab{background:linear-gradient(120deg,#0b1f45 0%,#0d2b5e 55%,#0e4c8a 100%);color:#fff;border-radius:10px;padding:20px 22px 18px;margin-bottom:14px;position:relative;overflow:hidden}
.cab:after{content:"";position:absolute;right:-40px;top:-40px;width:180px;height:180px;border-radius:50%;border:2px solid rgba(42,167,224,.45)}
.cab .marca{font-size:24pt;font-weight:800;letter-spacing:4px} .cab .marca sup{font-size:11pt;color:#7fd3f5}
.cab h1{font-size:15pt;margin:4px 0 6px;font-weight:700} .cab .al{font-size:9.2pt;color:#bfe3f6}
.meta{display:grid;grid-template-columns:1fr 1fr;gap:6px 18px;border:1px solid #cfe0f1;border-radius:8px;padding:10px 14px;margin-bottom:12px;background:#f5f9fd;font-size:9.2pt}
.meta div{display:flex;flex-direction:column} .meta div.full{grid-column:1/-1} .meta span{color:#5d7186;font-size:8pt;text-transform:uppercase;letter-spacing:.6px} .meta b{color:#0d2b5e}
.lic-imp{border-left:4px solid #2aa7e0;background:#eef8fd;padding:10px 14px;border-radius:0 8px 8px 0;margin:4px 0 10px}
h4{color:#0d2b5e;font-size:11.6pt;margin:14px 0 4px;padding-bottom:3px;border-bottom:1.5px solid #2aa7e0;page-break-after:avoid}
p{margin:4px 0 6px;text-align:justify} ul{margin:4px 0 8px;padding-left:16px} li{margin:2px 0;text-align:justify;list-style:none}
.lic-decl{margin-top:16px;border:1.5px solid #0d2b5e;border-radius:8px;padding:10px 14px;background:#f5f9fd;page-break-inside:avoid} .lic-decl b{color:#0d2b5e;text-transform:uppercase;letter-spacing:.8px;font-size:10pt}
.lic-firma{margin-top:16px;font-size:8.8pt;color:#5d7186;border-top:1px solid #cfe0f1;padding-top:8px}
.corte{page-break-after:always}
.cab .lang{font-size:8pt;letter-spacing:2px;color:#7fd3f5;font-weight:700;margin-bottom:4px}
.nota{font-size:8.8pt;color:#5d7186;font-style:italic;margin:-4px 0 10px}
"""

def pdf_html():
    marca = A + (f"<sup>{M}</sup>" if M else "")
    def parte(d, lang, idioma):
        return (f'<section lang="{lang}"><div class="cab"><div class="lang">{idioma}</div><div class="marca">{marca}</div><h1>{d["TITULO"]}</h1><div class="al">{d["ALCANCE"]}</div></div>'
                f'<div class="meta">{meta_html(d)}</div><p class="nota">{d["NOTA"]}</p>{cuerpo(d)}</section>')
    return f"""<!doctype html><html lang="es"><head><meta charset="utf-8"><style>{PDF_CSS}</style></head><body>
{parte(ES, "es", "ESPAÑOL · VERSIÓN ORIGINAL")}<div class="corte"></div>{parte(EN, "en", "ENGLISH · COURTESY TRANSLATION")}</body></html>"""

async def hacer_pdf(dst):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page()
        await pg.set_content(pdf_html(), wait_until="load")
        pie = f'<div style="font-size:7.5pt;color:#5d7186;width:100%;padding:0 18mm;display:flex;justify-content:space-between;font-family:Arial"><span>{AM} — Política de Privacidad, Términos de Uso y Licencia · Privacy Policy, Terms of Use and License · {LIC["ver"]}</span><span><span class="pageNumber"></span> / <span class="totalPages"></span></span></div>'
        await pg.pdf(path=dst, format="A4", print_background=True, display_header_footer=True, header_template="<span></span>", footer_template=pie,
                     margin={"top": "16mm", "bottom": "18mm", "left": "16mm", "right": "16mm"})
        await b.close()

if __name__ == "__main__":
    app = {"ver": LIC["ver"], "original": LIC.get("original", ""), "fecha": LIC["fecha"], "fecha_en": LIC["fecha_en"], "titulo": TITULO, "titulo_en": EN["TITULO"],
           "html": cuerpo(ES), "html_en": cuerpo(EN), "nota": ES["NOTA"], "nota_en": EN["NOTA"]}
    js = ("/* AR.T.L.A.S. · Política de Privacidad, Términos de Uso y Licencia, en español e inglés (generado por src/licencia/licencia.py; no editar a mano) */\n"
          "const ARTLAS_LIC=" + json.dumps(app, ensure_ascii=False) + ";\n")
    open(os.path.join(R, "src", "recursos", "40-licencia.js"), "w", encoding="utf8").write(js)
    asyncio.run(hacer_pdf(os.path.join(R, "src", "sitio", "licencia-artlas.pdf")))
    print("Licencia", LIC["ver"], "(ES + EN) → src/recursos/40-licencia.js y src/sitio/licencia-artlas.pdf")
