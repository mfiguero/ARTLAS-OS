/* ==================================================================
   v6.8 · App instalable (PWA)
   Se instala desde Chrome o Edge en la PC y queda como ícono en el celular.
   Se actualiza sola: el service worker (sw.js) avisa cuando hay versión nueva.
   Igual que la versión Escritorio, es SOLO para usuarios registrados:
     · el manifiesto y el service worker se activan recién con la sesión iniciada;
     · la app instalada no ofrece «Ingresar como invitado».
   ================================================================== */
const V68={prompt:null,reg:null,swOk:false,toast:false,waiting:null,wantReload:false,installed:false};

function v68Standalone(){
  try{
    if(/[?&]app=1(&|$)/.test(location.search)) return true;
    if(window.matchMedia&&["standalone","window-controls-overlay","minimal-ui","fullscreen"].some(m=>matchMedia("(display-mode: "+m+")").matches)) return true;
    return navigator.standalone===true;
  }catch(e){ return false; }
}
function v68Https(){ try{ return location.protocol!=="file:"&&!!window.isSecureContext&&("serviceWorker" in navigator); }catch(e){ return false; } }
function v68IOS(){ const u=navigator.userAgent||""; return /iPhone|iPad|iPod/.test(u)||(/Macintosh/.test(u)&&(navigator.maxTouchPoints||0)>1); }
function v68Android(){ return /Android/i.test(navigator.userAgent||""); }
function v68Dismissed(){ try{ return localStorage.getItem("atlas_pwa_card")==="0"||localStorage.getItem("atlas_pwa_inst")==="1"; }catch(e){ return false; } }

/* manifiesto + service worker: solo con sesión iniciada (así el navegador ofrece instalar solo a usuarios registrados) */
function v68Enable(){
  if(!v68Https()||!v61Logged()) return false;
  if(!document.querySelector('link[rel="manifest"]')){
    const l=document.createElement("link"); l.rel="manifest"; l.href="manifest.webmanifest"; document.head.appendChild(l);
  }
  if(!V68.swOk){
    V68.swOk=true;
    navigator.serviceWorker.register("sw.js",{scope:"./"}).then(reg=>{ V68.reg=reg; v68WatchUpdates(reg); })
      .catch(e=>{ V68.swOk=false; try{ v67LogErr("app","No se pudo registrar el service worker: "+((e&&e.message)||e)); }catch(_){} });
  }
  return true;
}

/* ---------------- actualización automática ---------------- */
function v68WatchUpdates(reg){
  if(!reg||reg.__v68) return; reg.__v68=1;
  const chk=()=>{ if(reg.waiting&&navigator.serviceWorker.controller) v68UpdateReady(reg.waiting); };
  chk();
  reg.addEventListener("updatefound",()=>{ const w=reg.installing; if(!w) return; w.addEventListener("statechange",()=>{ if(w.state==="installed") chk(); }); });
  setInterval(()=>{ try{ reg.update(); }catch(e){} },60*60*1000);
  document.addEventListener("visibilitychange",()=>{ if(document.visibilityState==="visible"){ try{ reg.update(); }catch(e){} } });
}
function v68UpdateReady(w){
  if(V68.toast) return; V68.toast=true; V68.waiting=w;
  let done=false;
  const show=ver=>{ if(done) return; done=true; v68Toast(ver&&ver!==V60.ver?ver:""); };
  try{ const ch=new MessageChannel(); ch.port1.onmessage=e=>show((e.data||{}).ver||""); w.postMessage({type:"VER"},[ch.port2]); }catch(e){}
  setTimeout(()=>show(""),1500);
}
function v68Toast(ver){
  v68ToastClose();
  const t=document.createElement("div"); t.className="v68-toast"; t.id="v68-toast";
  t.innerHTML=`<span>✨ ${v60L("Hay una versión nueva de AR.T.L.A.S.","A new version of AR.T.L.A.S. is available")}${ver?" ("+v60Esc(ver)+")":""}</span>
    <button class="up" onclick="v68Update()">${v60L("Actualizar ahora","Update now")}</button>
    <button class="later" onclick="v68ToastClose()">${v60L("Más tarde","Later")}</button>`;
  document.body.appendChild(t);
}
function v68ToastClose(){ const t=$("v68-toast"); if(t) t.remove(); }
function v68Update(){
  const w=V68.waiting||(V68.reg&&V68.reg.waiting);
  V68.wantReload=true; v68ToastClose();
  try{ if(typeof save==="function") save(); }catch(e){}
  if(w) w.postMessage({type:"SKIP_WAITING"}); else location.reload();
  setTimeout(()=>{ if(V68.wantReload) location.reload(); },4000);
}

/* ---------------- instalación ---------------- */
window.addEventListener("beforeinstallprompt",e=>{ e.preventDefault(); V68.prompt=e; try{ renderNav(); }catch(_){} });
window.addEventListener("appinstalled",()=>{
  V68.prompt=null; V68.installed=true;
  try{ localStorage.setItem("atlas_pwa_inst","1"); }catch(e){}
  try{ renderNav(); }catch(e){}
});
function v68Modal(title,body){
  v68ModalClose();
  const m=document.createElement("div"); m.className="v68-modal"; m.id="v68-modal";
  m.onclick=e=>{ if(e.target===m) v68ModalClose(); };
  m.innerHTML=`<div class="v68-box" role="dialog" aria-modal="true"><h3><img src="${v61Emblem()}" alt="">${title}</h3>${body}
    <div class="acts"><button class="btn dark" onclick="v68ModalClose()">${v60L("Entendido","Got it")}</button></div></div>`;
  document.body.appendChild(m);
}
function v68ModalClose(){ const m=$("v68-modal"); if(m) m.remove(); }
function v68Steps(){
  const L=v60L;
  if(v68IOS()) return `<p>${L("En el iPhone o iPad, desde <b>Safari</b>:","On iPhone or iPad, in <b>Safari</b>:")}</p><ol>
    <li>${L("Tocá <b>Compartir</b> ⬆︎ (abajo).","Tap <b>Share</b> ⬆︎ (bottom bar).")}</li>
    <li>${L("Elegí <b>«Agregar a pantalla de inicio»</b>.","Choose <b>“Add to Home Screen”</b>.")}</li>
    <li>${L("Tocá <b>Agregar</b>. AR.T.L.A.S. queda como ícono y abre a pantalla completa.","Tap <b>Add</b>. AR.T.L.A.S. becomes an icon and opens full screen.")}</li></ol>`;
  if(v68Android()) return `<p>${L("En Android, desde <b>Chrome</b>:","On Android, in <b>Chrome</b>:")}</p><ol>
    <li>${L("Tocá el menú <b>⋮</b> (arriba a la derecha).","Tap the <b>⋮</b> menu (top right).")}</li>
    <li>${L("Elegí <b>«Instalar app»</b> o <b>«Agregar a la pantalla principal»</b>.","Choose <b>“Install app”</b> or <b>“Add to Home screen”</b>.")}</li>
    <li>${L("Confirmá con <b>Instalar</b>. Queda como ícono junto a tus otras apps.","Confirm with <b>Install</b>. It appears next to your other apps.")}</li></ol>`;
  return `<p>${L("En la PC, con <b>Chrome</b> o <b>Edge</b>:","On a PC, with <b>Chrome</b> or <b>Edge</b>:")}</p><ol>
    <li>${L("Tocá el ícono <b>⊕ Instalar</b> a la derecha de la barra de direcciones,","Click the <b>⊕ Install</b> icon at the right of the address bar,")}</li>
    <li>${L("o el menú <b>⋮</b> → <b>«Transmitir, guardar y compartir» → «Instalar página como app»</b> (en Edge: <b>…</b> → <b>Aplicaciones → Instalar este sitio como aplicación</b>).","or the <b>⋮</b> menu → <b>“Cast, save and share” → “Install page as app”</b> (in Edge: <b>…</b> → <b>Apps → Install this site as an app</b>).")}</li>
    <li>${L("AR.T.L.A.S. abre en su propia ventana y queda en el menú Inicio y la barra de tareas.","AR.T.L.A.S. opens in its own window and is added to the Start menu and taskbar.")}</li></ol>`;
}
async function v68Install(){
  const L=v60L, T=L("Instalar AR.T.L.A.S.","Install AR.T.L.A.S.");
  if(v68Standalone()){ v68Modal("✓ "+L("App instalada","App installed"),`<p>${L("Ya estás usando la app instalada de AR.T.L.A.S. Se actualiza sola: cuando haya una versión nueva vas a ver un aviso.","You are already using the installed AR.T.L.A.S. app. It updates itself: you will see a notice when a new version is out.")}</p>`); return; }
  if(!v61Logged()){
    alert(L("La app instalable de AR.T.L.A.S. está disponible para usuarios registrados, igual que la versión Escritorio. Creá tu cuenta gratuita o iniciá sesión.","The installable AR.T.L.A.S. app is available to registered users, like the Desktop version. Create your free account or sign in."));
    v61GateLogin(true); return;
  }
  if(!v68Https()){ v68Modal(T,`<p>${L("Para instalar la app abrí AR.T.L.A.S. desde <b>https://artlas.ar</b> en Chrome o Edge. Desde un archivo del disco no se puede instalar.","To install the app, open AR.T.L.A.S. from <b>https://artlas.ar</b> in Chrome or Edge. It can’t be installed from a file on disk.")}</p>`); return; }
  v68Enable();
  if(V68.prompt){
    const p=V68.prompt; V68.prompt=null;
    try{ await p.prompt(); const r=await p.userChoice; if(r&&r.outcome==="accepted"){ try{ localStorage.setItem("atlas_pwa_inst","1"); }catch(e){} } }catch(e){}
    try{ renderNav(); }catch(e){}
    return;
  }
  v68Modal(T,v68Steps()+`<p style="font-size:12.5px;color:#5d6b7a;margin-top:8px">${L("Se actualiza sola y, para la mayoría de los usuarios, reemplaza al zip de Escritorio.","It updates itself and, for most users, replaces the Desktop zip.")}</p>`);
}
/* tarjeta «Instalá AR.T.L.A.S.»: siempre a la vista, al pie de la barra lateral (se puede cerrar) */
function v68CardPaint(logged){
  const sb=$("side-bottom"); let c=$("v68-card");
  const want=logged&&!v68Standalone()&&v68Https()&&!v68Dismissed()&&!V68.installed;
  if(!want){ if(c) c.remove(); return; }
  if(c||!sb) return;
  sb.insertAdjacentHTML("afterbegin",`<div class="v68-card" id="v68-card"><div style="font-size:20px;line-height:1">📲</div><div><b>${v60L("Instalá AR.T.L.A.S.","Install AR.T.L.A.S.")}</b>${v60L("Abrila con un clic, en su propia ventana, y siempre actualizada.","Open it with one click, in its own window, always up to date.")}<br><button class="go" onclick="v68Install()">${v60L("Instalar","Install")}</button></div><button class="x" title="${v60L("Cerrar","Close")}" onclick="v68CardClose()">✕</button></div>`);
}
function v68CardClose(){ try{ localStorage.setItem("atlas_pwa_card","0"); }catch(e){} const c=$("v68-card"); if(c) c.remove(); }

/* navegación: «📲 Instalar la app» primero en Descargas (difuminado y con candado para invitados) + tarjeta */
const V68_renderNav=renderNav;
renderNav=function(){
  V68_renderNav.apply(this,arguments);
  try{
    const el=$("nav-v60"); if(!el) return;
    if(v68Standalone()){ v68CardPaint(false); return; }   // en la app instalada no hace falta
    const logged=v61Logged();
    const lab=[...el.querySelectorAll(".sec-label")].find(x=>/^(Descargas|Downloads)$/.test(x.textContent.trim()));
    if(!lab||el.querySelector(".v68-nav")) return;
    const tip=logged?"":` title="${v60Esc(v60L("Registrate para instalar la app","Sign up to install the app"))}"`;
    lab.insertAdjacentHTML("afterend",`<button class="side-btn v68-nav ${logged?"":"v61-dim"}"${tip} onclick="v68Install()">📲&nbsp; ${v60L("Instalar la app","Install the app")}${logged?`<span class="v68-badge">${v60L("IDEAL","BEST")}</span>`:'<span class="v61-padlock">🔒</span>'}</button>`);
    v68CardPaint(logged);
  }catch(e){ console.error("v68 nav",e); }
};

/* sesión: al iniciarla se habilita la instalación */
const V68_updateUserUI=updateUserUI;
updateUserUI=function(){ V68_updateUserUI.apply(this,arguments); try{ v68Enable(); }catch(e){} };

/* ---------------- la app instalada exige cuenta ---------------- */
function v68AppNote(){ return `<div class="g-appnote">🔒 ${v60L("La app instalada es para usuarios registrados. Iniciá sesión o creá tu cuenta gratuita.","The installed app is for registered users. Sign in or create your free account.")}</div>`; }
const V68_gateRender=v61GateRender;
v61GateRender=function(){
  V68_gateRender.apply(this,arguments);
  if(!v68Standalone()) return;
  const g=$("v61-gate"); if(!g) return;
  const d=g.querySelector(".g-btn.demo"); if(d) d.remove();
  const a=g.querySelector(".g-actions"); if(a&&!a.querySelector(".g-appnote")&&!v61Logged()) a.insertAdjacentHTML("beforeend",v68AppNote());
};
const V68_gateGuest=v61GateGuest;
v61GateGuest=function(){
  if(v68Standalone()&&!v61Logged()){ const m=$("g-msg"); if(m) m.textContent=v60L("La app instalada requiere una cuenta. Iniciá sesión o creá tu cuenta gratuita.","The installed app requires an account. Sign in or create your free account."); return; }
  return V68_gateGuest.apply(this,arguments);
};
const V68_gateHide=v61GateHide;
v61GateHide=function(){
  if(v68Standalone()&&!v61Logged()){ v60SSset("atlas_demo",null); if(!v61GateVisible()) v61GateShow(); return; }   // no se puede saltear el ingreso (p. ej. con #demo)
  return V68_gateHide.apply(this,arguments);
};
const V68_doLogout=doLogout;
doLogout=async function(){
  const r=await V68_doLogout.apply(this,arguments);
  try{ if(v68Standalone()){ try{ closeUser(); }catch(e){} v61GateShow(); } }catch(e){}
  return r;
};

function v68Init(){
  try{
    if(v68Standalone()){ document.documentElement.classList.add("v68-app"); try{ localStorage.setItem("atlas_pwa_inst","1"); }catch(e){} }
    if(v68Https()){
      navigator.serviceWorker.addEventListener("controllerchange",()=>{ if(V68.wantReload){ V68.wantReload=false; location.reload(); } });
      navigator.serviceWorker.getRegistration().then(r=>{ if(r){ V68.reg=r; V68.swOk=true; v68WatchUpdates(r); } }).catch(()=>{});
    }
    v68Enable();
  }catch(e){ console.error("v68Init",e); }
}
v68Init();
