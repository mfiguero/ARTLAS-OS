
/* =====================================================================
   AR.T.L.A.S. · Módulo 98 · AR.T.L.A.S. OS — OFICINA
   Herramientas ofimáticas listas para usar:
     · Con el núcleo y LibreOffice instalado: crear Word/ODT/PDF y Excel/ODS,
       convertir entre formatos (docx↔pdf↔odt, xlsx↔ods↔csv, pptx→pdf) y abrir
       Writer, Calc o Impress. Apache OpenOffice se detecta y abre documentos,
       pero no permite crear ni convertir en modo automático.
     · Sin núcleo o sin LibreOffice: .docx y .xlsx/.ods/.csv se generan en el
       navegador (JSZip / SheetJS) y se guardan en cualquier carpeta del OS.
   El asistente suma office.crear / office.convertir / office.abrir (piden
   aprobación) y office.estado (lectura). Envuelve funciones de 94 y 96; no
   cambia la base.
   ===================================================================== */
AOS_IC.office='<path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4M9 11h7M9 14h7M9 17h4"/>';
const AOS_OF_SHEET=/^(xlsx|ods|xls|csv)$/, AOS_OF_DOC=/^(docx|odt|pdf|rtf|doc|html|htm|txt|md)$/, AOS_OF_SLIDES=/^(pptx|odp|ppt)$/;
const AOS_OF_ANY=/^(docx|doc|odt|rtf|xlsx|xls|ods|csv|pptx|ppt|odp)$/;
const AOSOF={st:null,t:0};
/* íconos propios (se usan si el núcleo no entrega los de LibreOffice) */
const AOS_OF_SVG={
  writer:'<svg viewBox="0 0 48 48"><defs><linearGradient id="ofw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4fa3ff"/><stop offset="1" stop-color="#1565c0"/></linearGradient></defs><path d="M10 4h20l10 10v30H10z" fill="url(#ofw)"/><path d="M30 4v10h10z" fill="#bcdcff"/><path d="M16 22h16M16 28h16M16 34h11" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/></svg>',
  calc:'<svg viewBox="0 0 48 48"><defs><linearGradient id="ofc" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3fd08a"/><stop offset="1" stop-color="#108a4c"/></linearGradient></defs><path d="M10 4h20l10 10v30H10z" fill="url(#ofc)"/><path d="M30 4v10h10z" fill="#c4f1da"/><path d="M15 21h18v16H15zM15 29h18M24 21v16" fill="none" stroke="#fff" stroke-width="2.3"/></svg>',
  impress:'<svg viewBox="0 0 48 48"><defs><linearGradient id="ofi" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffab4a"/><stop offset="1" stop-color="#e2610c"/></linearGradient></defs><path d="M10 4h20l10 10v30H10z" fill="url(#ofi)"/><path d="M30 4v10h10z" fill="#ffe0bd"/><rect x="15" y="21" width="18" height="12" rx="1.5" fill="none" stroke="#fff" stroke-width="2.3"/><path d="M24 33v4M20 37h8" stroke="#fff" stroke-width="2.3" stroke-linecap="round"/></svg>',
  ia:'<svg viewBox="0 0 24 24" fill="none" stroke="#1976d2" stroke-width="1.8" stroke-linecap="round"><path d="M12 3l1.8 4.6L18 9l-4.2 1.4L12 15l-1.8-4.6L6 9l4.2-1.4z"/><path d="M18.5 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/></svg>',
  conv:'<svg viewBox="0 0 24 24" fill="none" stroke="#1976d2" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h13l-3-3M20 16H7l3 3"/></svg>',
  blank:'<svg viewBox="0 0 24 24" fill="none" stroke="#1976d2" stroke-width="1.8" stroke-linejoin="round"><path d="M6 3h8l4 4v14H6z"/><path d="M12 10v6M9 13h6" stroke-linecap="round"/></svg>'
};

/* ---------- estado de la suite ofimática ---------- */
async function aosOfEstado(force){
  if(!aosNucOk()){ AOSOF.st={nucleo:false,disponible:false}; return AOSOF.st; }
  if(AOSOF.st&&AOSOF.st.nucleo&&!force&&Date.now()-AOSOF.t<60000) return AOSOF.st;
  try{ AOSOF.st=Object.assign({nucleo:true},await aosNuc("office.estado",{actualizar:!!force})); }
  catch(e){ AOSOF.st={nucleo:true,disponible:false,error:e.message}; }
  AOSOF.t=Date.now(); return AOSOF.st;
}
function aosOfLO(st){ return !!(st&&st.disponible&&st.suite==="LibreOffice"); }

/* ---------- Markdown → HTML (documentos) ---------- */
function aosOfInline(t){
  return aosEsc(t).replace(/\*\*([^*]+)\*\*/g,"<b>$1</b>").replace(/(^|[^*])\*([^*\s][^*]*)\*/g,"$1<i>$2</i>").replace(/`([^`]+)`/g,"<code>$1</code>")
    .replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g,'<a href="$2">$1</a>');
}
function aosOfMd2Html(md){
  const L=String(md||"").replace(/\r/g,"").split("\n"); const out=[]; let i=0;
  const isRow=l=>/^\s*\|.*\|\s*$/.test(l), cells=l=>l.trim().replace(/^\||\|$/g,"").split("|").map(c=>c.trim());
  while(i<L.length){
    const l=L[i];
    if(/^\s*```/.test(l)){ const b=[]; i++; while(i<L.length&&!/^\s*```/.test(L[i])) b.push(L[i++]); i++; out.push("<pre>"+aosEsc(b.join("\n"))+"</pre>"); continue; }
    let m=l.match(/^(#{1,4})\s+(.*)$/); if(m){ out.push(`<h${m[1].length}>${aosOfInline(m[2])}</h${m[1].length}>`); i++; continue; }
    if(isRow(l)&&i+1<L.length&&/^\s*\|?\s*:?-{2,}/.test(L[i+1])){
      const h=cells(l); i+=2; const rows=[]; while(i<L.length&&isRow(L[i])) rows.push(cells(L[i++]));
      out.push("<table><thead><tr>"+h.map(c=>"<th>"+aosOfInline(c)+"</th>").join("")+"</tr></thead><tbody>"+rows.map(r=>"<tr>"+r.map(c=>"<td>"+aosOfInline(c)+"</td>").join("")+"</tr>").join("")+"</tbody></table>"); continue; }
    if(/^\s*([-*+]|\d+[.)])\s+/.test(l)){ const ol=/^\s*\d/.test(l); const it=[]; while(i<L.length&&/^\s*([-*+]|\d+[.)])\s+/.test(L[i])) it.push(L[i++].replace(/^\s*([-*+]|\d+[.)])\s+/,""));
      out.push(`<${ol?"ol":"ul"}>`+it.map(x=>"<li>"+aosOfInline(x)+"</li>").join("")+`</${ol?"ol":"ul"}>`); continue; }
    if(/^\s*>/.test(l)){ const q=[]; while(i<L.length&&/^\s*>/.test(L[i])) q.push(L[i++].replace(/^\s*>\s?/,"")); out.push("<blockquote>"+aosOfInline(q.join(" "))+"</blockquote>"); continue; }
    if(/^\s*(---|\*\*\*)\s*$/.test(l)){ out.push("<hr>"); i++; continue; }
    if(!l.trim()){ i++; continue; }
    const p=[]; while(i<L.length&&L[i].trim()&&!/^(#{1,4}\s|\s*```|\s*([-*+]|\d+[.)])\s|\s*>)/.test(L[i])&&!isRow(L[i])) p.push(L[i++]);
    out.push("<p>"+aosOfInline(p.join(" "))+"</p>");
  }
  return out.join("\n");
}
function aosOfHtmlDoc(md,titulo){
  return `<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><title>${aosEsc(titulo||"Documento")}</title><style>
body{font-family:Calibri,"Liberation Sans",Arial,sans-serif;font-size:11pt;line-height:1.4;color:#1d2533}
h1{font-size:20pt;color:#0d2b5e;margin:0 0 8pt}h2{font-size:15pt;color:#0d2b5e;margin:14pt 0 6pt}h3{font-size:12.5pt;color:#1976d2;margin:12pt 0 4pt}h4{font-size:11pt;color:#1976d2}
table{border-collapse:collapse;margin:6pt 0}th,td{border:1px solid #9fb3cf;padding:3pt 6pt}th{background:#dbe6f3;color:#0d2b5e}
blockquote{border-left:3pt solid #1976d2;margin:6pt 0;padding-left:8pt;color:#44546a}pre,code{font-family:Consolas,"Liberation Mono",monospace;font-size:9.5pt}
</style></head><body>${aosOfMd2Html(md)}</body></html>`;
}

/* ---------- .docx en el navegador (sin LibreOffice) ---------- */
function aosOfX(t){ return String(t).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function aosOfRuns(t,base){
  const parts=String(t).split(/(\*\*[^*]+\*\*)/g).filter(Boolean);
  return parts.map(p=>{ const b=/^\*\*.*\*\*$/.test(p); const txt=b?p.slice(2,-2):p;
    return `<w:r><w:rPr>${base||""}${b?"<w:b/>":""}</w:rPr><w:t xml:space="preserve">${aosOfX(txt.replace(/`/g,""))}</w:t></w:r>`; }).join("");
}
async function aosOfDocx(md){
  if(typeof JSZip==="undefined") await loadScript("https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js");
  const L=String(md||"").replace(/\r/g,"").split("\n"); const body=[]; let i=0;
  const P=(runs,ppr)=>`<w:p>${ppr?"<w:pPr>"+ppr+"</w:pPr>":""}${runs}</w:p>`;
  const H={1:'<w:sz w:val="40"/><w:color w:val="0D2B5E"/><w:b/>',2:'<w:sz w:val="30"/><w:color w:val="0D2B5E"/><w:b/>',3:'<w:sz w:val="25"/><w:color w:val="1976D2"/><w:b/>',4:'<w:sz w:val="22"/><w:color w:val="1976D2"/><w:b/>'};
  const isRow=l=>/^\s*\|.*\|\s*$/.test(l), cells=l=>l.trim().replace(/^\||\|$/g,"").split("|").map(c=>c.trim());
  while(i<L.length){
    const l=L[i]; let m=l.match(/^(#{1,4})\s+(.*)$/);
    if(m){ body.push(P(aosOfRuns(m[2].replace(/\*\*/g,""),H[m[1].length]),'<w:spacing w:before="240" w:after="120"/><w:keepNext/>')); i++; continue; }
    if(isRow(l)&&i+1<L.length&&/^\s*\|?\s*:?-{2,}/.test(L[i+1])){
      const rows=[cells(l)]; i+=2; while(i<L.length&&isRow(L[i])) rows.push(cells(L[i++]));
      const bd='<w:tblBorders>'+["top","left","bottom","right","insideH","insideV"].map(k=>`<w:${k} w:val="single" w:sz="4" w:color="9FB3CF"/>`).join("")+'</w:tblBorders>';
      body.push(`<w:tbl><w:tblPr><w:tblW w:w="0" w:type="auto"/>${bd}</w:tblPr>`+rows.map((r,ri)=>"<w:tr>"+r.map(c=>`<w:tc><w:tcPr>${ri===0?'<w:shd w:val="clear" w:fill="DBE6F3"/>':""}</w:tcPr>${P(aosOfRuns(c,ri===0?'<w:b/><w:color w:val="0D2B5E"/>':""))}</w:tc>`).join("")+"</w:tr>").join("")+"</w:tbl>"+P(""));
      continue; }
    m=l.match(/^\s*([-*+]|\d+[.)])\s+(.*)$/);
    if(m){ const mark=/\d/.test(m[1])?m[1].replace(")",".")+" ":"• "; body.push(P(aosOfRuns(mark+m[2]),'<w:ind w:left="360" w:hanging="240"/><w:spacing w:after="40"/>')); i++; continue; }
    if(/^\s*```/.test(l)){ i++; while(i<L.length&&!/^\s*```/.test(L[i])){ body.push(P(`<w:r><w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas"/><w:sz w:val="19"/></w:rPr><w:t xml:space="preserve">${aosOfX(L[i])}</w:t></w:r>`,'<w:spacing w:after="0"/>')); i++; } i++; continue; }
    if(!l.trim()){ i++; continue; }
    body.push(P(aosOfRuns(l.replace(/^\s*>\s?/,"")),'<w:spacing w:after="120"/>')); i++;
  }
  const z=new JSZip();
  z.file("[Content_Types].xml",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>');
  z.file("_rels/.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
  z.file("word/document.xml",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'+body.join("")+'<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1418" w:right="1418" w:bottom="1418" w:left="1418" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>');
  return z.generateAsync({type:"blob",mimeType:"application/vnd.openxmlformats-officedocument.wordprocessingml.document"});
}

/* ---------- hojas de cálculo en el navegador (SheetJS) ---------- */
async function aosOfXlsx(){ if(typeof XLSX==="undefined") await loadScript("https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"); }
function aosOfCleanCsv(t){ return String(t||"").replace(/^\uFEFF/,"").replace(/^\s*```[a-z]*\s*\n?/i,"").replace(/\n?```\s*$/,"").trim()+"\n"; }
async function aosOfSheetBlob(csv,fmt){
  await aosOfXlsx();
  const wb=XLSX.read(aosOfCleanCsv(csv),{type:"string",raw:false});
  if(fmt==="csv") return new Blob(["\uFEFF"+XLSX.utils.sheet_to_csv(wb.Sheets[wb.SheetNames[0]])],{type:"text/csv"});
  const ws=wb.Sheets[wb.SheetNames[0]]; const ref=ws["!ref"]; if(ref){ const r=XLSX.utils.decode_range(ref); ws["!cols"]=[]; for(let c=r.s.c;c<=r.e.c;c++){ let w=8; for(let rr=r.s.r;rr<=Math.min(r.e.r,200);rr++){ const v=ws[XLSX.utils.encode_cell({r:rr,c})]; if(v) w=Math.max(w,String(v.v).length+2); } ws["!cols"].push({wch:Math.min(w,48)}); } }
  const out=XLSX.write(wb,{bookType:fmt==="xls"?"biff8":fmt,type:"array"});
  return new Blob([out],{type:aosMime(fmt)||"application/octet-stream"});
}

/* ---------- operaciones ---------- */
async function aosOfCreate(uri,contenido,opt){
  opt=opt||{}; const e=aosExt(uri);
  if(AOS_OF_SLIDES.test(e)) throw new Error(aosL("Las presentaciones no se generan automáticamente todavía: creá el documento y abrí Impress (office.abrir), o convertí un .pptx existente.","Presentations can't be generated automatically yet: create the document and open Impress, or convert an existing .pptx."));
  if(!AOS_OF_SHEET.test(e)&&!AOS_OF_DOC.test(e)) throw new Error(aosL("Formato no admitido: .","Unsupported format: .")+e);
  const sheet=AOS_OF_SHEET.test(e); const st=aosScheme(uri)==="pc"?await aosOfEstado():{disponible:false};
  if(aosScheme(uri)==="pc"&&aosOfLO(st)&&!/^(md|txt|html|htm|csv)$/.test(e)){
    const r=await aosNuc("office.crear",{ruta:aosPathOf(uri),contenido:sheet?aosOfCleanCsv(contenido):aosOfHtmlDoc(contenido,aosBase(uri).replace(/\.[^.]+$/,"")),origen:sheet?"csv":"html",sobrescribir:!!opt.sobrescribir});
    return {uri:"pc:"+r.ruta,via:st.suite};
  }
  let data;
  if(sheet) data=await aosOfSheetBlob(contenido,e);
  else if(e==="docx") data=await aosOfDocx(contenido);
  else if(e==="md"||e==="txt") data=String(contenido||"");
  else if(e==="html"||e==="htm") data=aosOfHtmlDoc(contenido,aosBase(uri));
  else throw new Error(aosL("Para crear .","To create .")+e+aosL(" hace falta LibreOffice en tu PC (núcleo local). Sin él puedo crear .docx, .xlsx, .ods, .csv, .md o .html."," you need LibreOffice on your PC (local core). Without it I can create .docx, .xlsx, .ods, .csv, .md or .html."));
  await AOSFS.write(uri,data,{sobrescribir:!!opt.sobrescribir});
  return {uri,via:aosL("navegador","browser")};
}
async function aosOfConvert(uri,fmt,destino,opt){
  opt=opt||{}; fmt=String(fmt||"pdf").toLowerCase().replace(/^\./,""); const e=aosExt(uri);
  const dst=destino||aosJoin(aosParentUri(uri),aosBase(uri).replace(/\.[^.]+$/,"")+"."+fmt);
  const st=aosScheme(uri)==="pc"?await aosOfEstado():{disponible:false};
  if(aosScheme(uri)==="pc"&&aosScheme(dst)==="pc"&&aosOfLO(st)){
    const r=await aosNuc("office.convertir",{ruta:aosPathOf(uri),formato:fmt,destino:aosPathOf(dst),sobrescribir:!!opt.sobrescribir}); return {uri:"pc:"+r.ruta,via:st.suite};
  }
  if(AOS_OF_SHEET.test(e)&&AOS_OF_SHEET.test(fmt)){   // entre hojas de cálculo: SheetJS
    await aosOfXlsx(); const b=await AOSFS.blob(uri); const wb=XLSX.read(await b.arrayBuffer(),{type:"array"});
    const ws=wb.Sheets[wb.SheetNames[0]]; const csv=XLSX.utils.sheet_to_csv(ws);
    await AOSFS.write(dst,fmt==="csv"?"\uFEFF"+csv:await aosOfSheetBlob(csv,fmt),{sobrescribir:!!opt.sobrescribir}); return {uri:dst,via:aosL("navegador","browser")};
  }
  if(st.disponible&&!aosOfLO(st)) throw new Error(aosL("Apache OpenOffice no convierte en modo automático. Instalá LibreOffice (gratis, libreoffice.org): pueden convivir.","Apache OpenOffice can't convert automatically. Install LibreOffice (free, libreoffice.org): both can coexist."));
  throw new Error(aosL("Para convertir a .","To convert to .")+fmt+aosL(" hace falta el núcleo local con LibreOffice instalado, y el archivo en una carpeta de la PC."," you need the local core with LibreOffice installed and the file in a PC folder."));
}
async function aosOfOpen(arg){
  const st=await aosOfEstado();
  if(!st.nucleo) throw new Error(aosL("Para abrir LibreOffice hace falta el núcleo local (Configuración → Núcleo local).","Opening LibreOffice needs the local core (Settings → Local core)."));
  if(!st.disponible) throw new Error(aosL("No encuentro LibreOffice ni OpenOffice en tu PC. Instalá LibreOffice desde libreoffice.org.","LibreOffice/OpenOffice not found. Install LibreOffice from libreoffice.org."));
  if(arg&&/^(pc|fsa|opfs):/.test(arg)){ if(aosScheme(arg)!=="pc") throw new Error(aosL("Solo se abren en LibreOffice los archivos del disco de la PC.","Only PC disk files open in LibreOffice.")); return aosNuc("office.abrir",{ruta:aosPathOf(arg)}); }
  return aosNuc("office.abrir",{app:arg||"writer"});
}

/* ---------- app Oficina ---------- */
const AOS_OF_TIPOS=[["docx",()=>aosL("Documento Word (.docx)","Word document (.docx)")],["odt",()=>aosL("Documento de texto ODF (.odt)","ODF text document (.odt)")],["pdf",()=>"PDF (.pdf)"],
  ["xlsx",()=>aosL("Hoja de cálculo Excel (.xlsx)","Excel spreadsheet (.xlsx)")],["ods",()=>aosL("Hoja de cálculo ODF (.ods)","ODF spreadsheet (.ods)")],["csv",()=>"CSV (.csv)"]];
aosRegister("oficina",{title:()=>aosL("Oficina","Office"),sub:()=>aosL("Documentos y hojas de cálculo con LibreOffice","Documents and spreadsheets with LibreOffice"),icon:"office",desk:true,order:35,w:820,h:640,
  kw:"oficina office libreoffice openoffice word excel writer calc impress documento hoja planilla pdf convertir",
  render(win,opts){ win.state={draft:null,conv:(opts&&opts.uri)||""}; win.body.innerHTML=`<div class="aos-pad aosof"></div>`; aosOfPaint(win); },
  reopen(win,opts){ if(opts&&opts.uri){ win.state.conv=opts.uri; } aosOfPaint(win); }
});
async function aosOfPaint(win){
  const B=win.body.querySelector(".aosof"); if(!B) return;
  const st=await aosOfEstado(); const lo=aosOfLO(st);
  const srcs=await AOSFS.sources().catch(()=>[]);
  const stHtml=!st.nucleo?`<span class="aos-pill">${aosL("Sin núcleo","No core")}</span> ${aosL("Creo .docx, .xlsx, .ods y .csv en el navegador. Con el núcleo y LibreOffice sumás PDF, ODT, conversiones y abrir Writer, Calc e Impress.","I create .docx, .xlsx, .ods and .csv in the browser. With the core and LibreOffice you add PDF, ODT, conversions and opening Writer, Calc and Impress.")} <a href="#" class="aosof-cfg">${aosL("Configurar el núcleo","Set up the core")}</a>`
    :lo?`<span class="aos-pill ok">${aosEsc(st.suite)} ${aosEsc(st.version||"")}</span> ${aosL("Listo para crear, convertir y abrir documentos.","Ready to create, convert and open documents.")}`
    :st.disponible?`<span class="aos-pill">${aosEsc(st.suite)}</span> ${aosL("Abre documentos, pero no crea ni convierte en modo automático. Instalá también LibreOffice:","Opens documents but can't create or convert automatically. Also install LibreOffice:")} <a href="https://www.libreoffice.org/download/" target="_blank" rel="noopener">libreoffice.org</a>`
    :`<span class="aos-pill">${aosL("Sin LibreOffice","No LibreOffice")}</span> ${aosL("No lo encuentro en tu PC. Instalalo gratis desde","Not found on your PC. Install it free from")} <a href="https://www.libreoffice.org/download/" target="_blank" rel="noopener">libreoffice.org</a> ${aosL("y tocá «Volver a buscar».","and tap «Search again».")} <button class="aos-btn sm aosof-re">${aosL("Volver a buscar","Search again")}</button>`;
  const dest=srcs.map(s=>`<option value="${aosEsc(s.uri)}">${aosEsc(s.grupo==="pc"?aosL("PC · ","PC · ")+s.nombre:s.nombre)}</option>`).join("");
  const d=win.state.draft;
  B.innerHTML=`<style>.aosof-tiles{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px}
    .aosof-tile{width:132px;display:flex;flex-direction:column;align-items:center;gap:4px;padding:14px 8px 11px;border:1px solid #dbe6f3;border-radius:14px;background:linear-gradient(180deg,#fff,#f4f8fd);cursor:pointer;transition:transform .12s,box-shadow .12s}
    .aosof-tile:hover{transform:translateY(-2px);box-shadow:0 6px 16px rgba(13,43,94,.12);border-color:#9cc3f5}
    .aosof-tile .ic{width:48px;height:48px;display:flex;align-items:center;justify-content:center}.aosof-tile .ic img,.aosof-tile .ic svg{width:46px;height:46px;filter:drop-shadow(0 2px 3px rgba(13,43,94,.18))}
    .aosof-tile .n{font-size:13px;color:#0d2b5e;font-weight:600}.aosof-tile .m{font-size:11px;color:#8a97ab}
    .aosof-h{display:flex;align-items:center;gap:8px}.aosof-h svg{width:20px;height:20px}</style>
  <p class="aos-sub" style="margin-top:0">${stHtml}</p>
  <div class="aos-h aosof-h">${AOS_OF_SVG.blank}${aosL("Abrir en blanco","Open blank")}</div>
  <div class="aosof-tiles">
    ${[["writer",aosL("Documento","Document"),"Writer"],["calc",aosL("Hoja de cálculo","Spreadsheet"),"Calc"],["impress",aosL("Presentación","Presentation"),"Impress"]].map(([k,n,m])=>`<button class="aosof-tile" data-ofa="${k}"><span class="ic" data-oic="${k}">${AOSOF.ico&&AOSOF.ico[k]?`<img src="${AOSOF.ico[k]}" alt="">`:AOS_OF_SVG[k]}</span><span class="n">${n}</span><span class="m">${m}</span></button>`).join("")}</div>
  <div class="aos-h aosof-h">${AOS_OF_SVG.ia}${aosL("Crear con AR.T.L.A.S.","Create with AR.T.L.A.S.")}</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px;margin-bottom:8px">
    <label style="font-size:12px;color:#6b7a90">${aosL("Tipo","Type")}<select class="aos-in aosof-tipo" style="width:100%;margin-top:3px">${AOS_OF_TIPOS.map(([v,n])=>`<option value="${v}" ${(d?d.tipo:"docx")===v?"selected":""} ${!lo&&/^(odt|pdf)$/.test(v)?"disabled":""}>${n()}${!lo&&/^(odt|pdf)$/.test(v)?aosL(" · requiere LibreOffice"," · needs LibreOffice"):""}</option>`).join("")}</select></label>
    <label style="font-size:12px;color:#6b7a90">${aosL("Guardar en","Save to")}<select class="aos-in aosof-dest" style="width:100%;margin-top:3px">${dest}</select></label>
    <label style="font-size:12px;color:#6b7a90">${aosL("Nombre","Name")}<input class="aos-in aosof-nom" style="width:100%;margin-top:3px" value="${aosEsc(d?d.nombre:"")}" placeholder="${aosEsc(aosL("Informe de enlace","Link report"))}"></label></div>
  <textarea class="aos-in aosof-q" rows="3" style="width:100%;resize:vertical" placeholder="${aosEsc(aosL("Qué tiene que contener. Ej.: planilla de notas de Teleinformática II con 10 alumnos, parciales, TP y promedio","What it should contain. E.g.: grade sheet with 10 students, midterms, project and average"))}">${aosEsc(d?d.q:"")}</textarea>
  <div style="display:flex;gap:6px;align-items:center;margin:6px 0 10px"><button class="aos-btn ${d?"":"pri"} aosof-gen">${aosL("Generar borrador","Generate draft")}</button><span class="aosof-msg" style="font-size:12px;color:#6b7a90"></span></div>
  ${d?`<div class="aos-card" style="padding:10px 12px;margin-bottom:16px"><div style="font-size:12px;color:#6b7a90;margin-bottom:4px">${aosL("Borrador (podés editarlo antes de guardar) · ","Draft (edit before saving) · ")}${d.sheet?"CSV":"Markdown"}</div>
    <textarea class="aos-in aosof-draft" rows="10" style="width:100%;font:12px/1.45 Consolas,Menlo,monospace;resize:vertical">${aosEsc(d.texto)}</textarea>
    <div style="display:flex;gap:6px;margin-top:6px"><button class="aos-btn pri aosof-save">${aosL("Guardar","Save")}</button><button class="aos-btn aosof-disc">${aosL("Descartar","Discard")}</button></div></div>`:`<div style="margin-bottom:16px"></div>`}
  <div class="aos-h aosof-h">${AOS_OF_SVG.conv}${aosL("Convertir un archivo","Convert a file")}</div>
  <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center"><input class="aos-in aosof-src" style="flex:1;min-width:220px" value="${aosEsc(win.state.conv||"")}" placeholder="${aosEsc(aosL("Elegilo en Archivos → «Convertir» o pegá la ruta pc:…","Pick it in Files → «Convert» or paste the pc:… path"))}">
    <select class="aos-in aosof-fmt">${["pdf","docx","odt","xlsx","ods","csv"].map(f=>`<option>${f}</option>`).join("")}</select>
    <button class="aos-btn aosof-conv">${aosL("Convertir","Convert")}</button><button class="aos-btn aosof-pick">${aosL("Elegir en Archivos","Pick in Files")}</button></div>
  <div class="aosof-cmsg" style="font-size:12px;color:#6b7a90;margin-top:6px"></div>`;
  const q=s=>B.querySelector(s);
  if(st.disponible&&!AOSOF.ico) aosNuc("office.iconos",{}).then(r=>{ AOSOF.ico=r.iconos||{}; Object.entries(AOSOF.ico).forEach(([k,src])=>{ if(!src) return; B.querySelectorAll(`[data-oic="${k}"]`).forEach(el=>el.innerHTML=`<img src="${src}" alt="">`); }); }).catch(()=>{ AOSOF.ico={}; });
  if(d&&d.dest) q(".aosof-dest").value=d.dest; else { const pc=srcs.find(s=>s.grupo==="pc"&&/document/i.test(s.nombre))||srcs.find(s=>s.grupo==="pc"); if(pc) q(".aosof-dest").value=pc.uri; }
  if(q(".aosof-cfg")) q(".aosof-cfg").onclick=ev=>{ ev.preventDefault(); aosLaunch("config"); };
  if(q(".aosof-re")) q(".aosof-re").onclick=async()=>{ await aosOfEstado(true); aosOfPaint(win); };
  B.querySelectorAll("[data-ofa]").forEach(b=>b.onclick=async()=>{ try{ const r=await aosOfOpen(b.dataset.ofa); aosToast(aosL("Abriendo ","Opening ")+(r.suite||"LibreOffice")+"…","ok"); }catch(e){ aosToast(e.message,"err",7000); } });
  q(".aosof-gen").onclick=()=>aosOfGenerate(win);
  if(q(".aosof-save")) q(".aosof-save").onclick=()=>aosOfSaveDraft(win);
  if(q(".aosof-disc")) q(".aosof-disc").onclick=()=>{ win.state.draft=null; aosOfPaint(win); };
  q(".aosof-pick").onclick=()=>{ aosLaunch("archivos"); aosToast(aosL("Elegí un archivo y tocá «Convertir»","Pick a file and tap «Convert»"),"",4000); };
  q(".aosof-conv").onclick=async()=>{ const m=q(".aosof-cmsg"); const src=q(".aosof-src").value.trim(); if(!src){ m.textContent=aosL("Elegí primero un archivo.","Pick a file first."); return; }
    m.textContent=aosL("Convirtiendo…","Converting…"); win.state.conv=src;
    try{ const r=await aosOfConvert(/^(pc|fsa|opfs):/.test(src)?src:(aosNucOk()?"pc:"+src:src),q(".aosof-fmt").value); m.innerHTML=aosL("Listo: ","Done: ")+`<a href="#" class="aosof-open">${aosEsc(aosBase(r.uri))}</a> · ${aosEsc(r.via)}`; m.querySelector(".aosof-open").onclick=ev=>{ ev.preventDefault(); aosOpenFile(r.uri); }; aosOfRefreshFiles(); }
    catch(e){ m.innerHTML=`<span style="color:#c0272d">${aosEsc(e.message)}</span>`; } };
}
async function aosOfGenerate(win){
  const B=win.body; const q=s=>B.querySelector(s); const msg=q(".aosof-msg");
  const tipo=q(".aosof-tipo").value, pedido=q(".aosof-q").value.trim(); const sheet=AOS_OF_SHEET.test(tipo);
  if(!pedido){ msg.textContent=aosL("Escribí qué tiene que contener.","Describe what it should contain."); return; }
  const nombre=(q(".aosof-nom").value.trim()||pedido.split(/\s+/).slice(0,5).join(" ")).replace(/[\\\/:*?"<>|]/g,"").slice(0,60);
  const sys=sheet?aosL("Generás hojas de cálculo. Respondé SOLO con CSV: primera fila de encabezados, coma como separador, punto decimal, comillas si un campo tiene comas. Para columnas calculadas (promedios, totales) podés escribir fórmulas de planilla que empiecen con = usando referencias de celda (p. ej. =PROMEDIO(B2:D2) se escribe =AVERAGE(B2:D2)). Sin explicaciones ni bloques de código.","You generate spreadsheets. Reply ONLY with CSV: header row first, comma separator, dot decimals, quotes when a field contains commas. For computed columns you may write spreadsheet formulas starting with = using cell references (e.g. =AVERAGE(B2:D2)). No explanations, no code fences.")
    :aosL("Redactás documentos profesionales en español rioplatense formal. Respondé SOLO con el documento en Markdown: un título con #, secciones con ## y ###, párrafos, listas y tablas con | cuando sirvan. Sin comentarios antes ni después.","You write professional documents. Reply ONLY with the document in Markdown: a # title, ## and ### sections, paragraphs, lists and | tables when useful. No comments before or after.");
  const btn=q(".aosof-gen"); btn.disabled=true;
  let pk; try{ pk=aosMotorPick(pedido); }catch(e){ msg.textContent=e.message; btn.disabled=false; return; }
  msg.textContent=aosL("Redactando con ","Drafting with ")+aosPkLabel(pk)+"…";
  try{
    const txt=await callProvider(pk,cfg[pk]||{},[{role:"user",content:pedido}],sys,[],aosIsLocal(pk)?1500:4000);
    let t=String(txt||"").trim().replace(/^```[a-z]*\s*\n/i,"").replace(/\n```\s*$/,"");
    win.state.draft={tipo,sheet,nombre,q:pedido,dest:q(".aosof-dest").value,texto:t}; aosOfPaint(win);
  }catch(e){ msg.innerHTML=`<span style="color:#c0272d">${aosEsc((e.message||e)+"")}</span>`; }
  finally{ btn.disabled=false; }
}
async function aosOfSaveDraft(win){
  const d=win.state.draft; if(!d) return; const B=win.body;
  d.texto=B.querySelector(".aosof-draft").value; d.dest=B.querySelector(".aosof-dest").value; d.tipo=B.querySelector(".aosof-tipo").value; d.nombre=(B.querySelector(".aosof-nom").value.trim()||d.nombre).replace(/[\\\/:*?"<>|]/g,"");
  const uri=aosJoin(d.dest,(d.nombre||"documento")+"."+d.tipo);
  try{
    let r; try{ r=await aosOfCreate(uri,d.texto); }
    catch(e){ if(!/existe|exists/i.test(e.message)||!confirm(aosL("Ya existe «","«")+aosBase(uri)+aosL("». ¿Reemplazarlo? (la versión anterior va a la papelera)","» already exists. Replace it? (the previous version goes to trash)"))) throw e; r=await aosOfCreate(uri,d.texto,{sobrescribir:true}); }
    aosToast(aosL("Guardado: ","Saved: ")+aosBase(r.uri)+" · "+r.via,"ok",5000);
    win.state.draft=null; win.state.conv=r.uri; aosOfPaint(win); aosOfRefreshFiles();
  }catch(e){ aosToast(e.message,"err",8000); }
}
function aosOfRefreshFiles(){ try{ AOS.wins.filter(w=>w.app==="archivos"&&w.state.uri).forEach(w=>aosfGo(w,w.state.uri)); }catch(e){} }

/* ---------- Archivos: acciones ofimáticas sobre el archivo elegido ---------- */
const V98_aosfAct=aosfAct;
aosfAct=function(win){
  V98_aosfAct.apply(this,arguments);
  try{
    const e=win.state.sel, A=win.body.querySelector(".aosf-act"); if(!e||!A||e.tipo==="dir") return;
    const x=aosExt(e.nombre); if(!AOS_OF_ANY.test(x)) return;
    const pc=aosScheme(e.uri)==="pc"; const add=(t,fn)=>{ const b=document.createElement("button"); b.className="aos-btn sm"; b.textContent=t; b.onclick=fn; const del=A.querySelector('[data-x="del"]'); A.insertBefore(b,del); };
    if(pc&&x!=="pdf") add(aosL("PDF","PDF"),async()=>{ try{ aosToast(aosL("Convirtiendo a PDF…","Converting to PDF…")); const r=await aosOfConvert(e.uri,"pdf"); aosToast(aosL("Listo: ","Done: ")+aosBase(r.uri),"ok"); aosfGo(win,win.state.uri); }catch(er){ if(/existe|exists/i.test(er.message)&&confirm(aosL("El PDF ya existe. ¿Reemplazarlo?","The PDF already exists. Replace it?"))){ try{ await aosOfConvert(e.uri,"pdf",null,{sobrescribir:true}); aosToast(aosL("PDF actualizado","PDF updated"),"ok"); aosfGo(win,win.state.uri); }catch(e2){ aosToast(e2.message,"err",7000); } } else aosToast(er.message,"err",7000); } });
    add(aosL("Convertir…","Convert…"),()=>aosLaunch("oficina",{uri:e.uri}));
    if(aosNucOk()) add("LibreOffice",()=>aosOfOpenDoc(e.uri));
    else if(/^(docx|docm|dotx|xlsx?|xlsm|ods|csv)$/.test(x)) add(aosL("Vista previa","Preview"),()=>aosLaunch("vistadoc",{uri:e.uri,nuevo:true}));
  }catch(er){}
};

/* ---------- asistente: herramientas ofimáticas ---------- */
["office.crear","office.convertir","office.abrir","office.estado"].forEach(o=>AOS_OPS.add(o)); AOS_READ.add("office.estado");
const V98_aosSysPrompt=aosSysPrompt;
aosSysPrompt=function(srcs,small){
  const base=V98_aosSysPrompt.apply(this,arguments); const st=AOSOF.st||{}; const lo=aosOfLO(st);
  const extra=aosL(
`OFIMÁTICA (${lo?st.suite+" disponible en la PC":"sin LibreOffice: en el navegador se crean .docx, .xlsx, .ods y .csv"}):
office.crear {ruta, contenido} → ruta con extensión .docx, .odt, .pdf (documentos: contenido en Markdown con #, ##, listas y tablas |) o .xlsx, .ods, .csv (hojas: contenido en CSV con encabezados; fórmulas en inglés con =, p. ej. =AVERAGE(B2:D2))
office.convertir {ruta, formato, destino?} (pdf, docx, odt, xlsx, ods, csv) · office.abrir {ruta} o {app: writer|calc|impress} · office.estado {}
Para un documento o planilla nuevos usá office.crear con el contenido completo (no fs.escribir).`,
`OFFICE (${lo?st.suite+" available on the PC":"no LibreOffice: .docx, .xlsx, .ods and .csv are created in the browser"}):
office.crear {ruta, contenido} → path with extension .docx, .odt, .pdf (documents: Markdown content with #, ##, lists and | tables) or .xlsx, .ods, .csv (sheets: CSV with headers; formulas with =, e.g. =AVERAGE(B2:D2))
office.convertir {ruta, formato, destino?} (pdf, docx, odt, xlsx, ods, csv) · office.abrir {ruta} or {app: writer|calc|impress} · office.estado {}
For a new document or spreadsheet use office.crear with the full content (not fs.escribir).`);
  return base.replace(/\nREGLAS:|\nRULES:/,m=>"\n"+extra+m);
};
const V98_aosOpDesc=aosOpDesc;
aosOpDesc=function(o){
  const b=u=>aosEsc(aosBase(u)||u);
  if(o.op==="office.crear") return aosL("Crear el documento ","Create the document ")+"<b>"+b(o.ruta)+"</b>"+(o.contenido?` <span style="color:#7a5a20">(${String(o.contenido).length} ${aosL("caracteres","chars")})</span>`:"");
  if(o.op==="office.convertir") return aosL("Convertir ","Convert ")+"<b>"+b(o.ruta)+"</b> → "+aosEsc((o.formato||"pdf").toUpperCase());
  if(o.op==="office.abrir") return o.ruta?aosL("Abrir en LibreOffice ","Open in LibreOffice ")+"<b>"+b(o.ruta)+"</b>":aosL("Abrir LibreOffice ","Open LibreOffice ")+"<b>"+aosEsc(o.app||"writer")+"</b>";
  return V98_aosOpDesc.apply(this,arguments);
};
const V98_aosExec=aosExec;
aosExec=async function(o,ctx){
  if(!/^office\./.test(o&&o.op||"")) return V98_aosExec.apply(this,arguments);
  const t0=performance.now(); const done=(text,short,extra)=>({ok:true,text,short,ms:performance.now()-t0,...(extra||{})});
  try{
    if(o.op==="office.estado"){ const s=await aosOfEstado(true); return done(JSON.stringify(s),aosL("revisó la suite ofimática","checked the office suite")); }
    if(o.op==="office.crear"){ if(!o.ruta) throw new Error(aosL("Falta la ruta","Missing path")); const r=await aosOfCreate(aosNormUri(o.ruta),o.contenido??o.texto??"",{sobrescribir:!!o.sobrescribir}); return done("OK: "+r.uri+" ("+r.via+")",aosL("creó ","created ")+aosBase(r.uri),{changed:r.uri}); }
    if(o.op==="office.convertir"){ const r=await aosOfConvert(aosNormUri(o.ruta),o.formato,o.destino?aosNormUri(o.destino):null,{sobrescribir:!!o.sobrescribir}); return done("OK: "+r.uri+" ("+r.via+")",aosL("convirtió a ","converted to ")+aosBase(r.uri),{changed:r.uri}); }
    if(o.op==="office.abrir"){ const r=await aosOfOpen(o.ruta?aosNormUri(o.ruta):(o.app||"writer")); return done("OK, "+aosL("abierto","opened")+": "+(r.abierto||""),aosL("abrió ","opened ")+(o.ruta?aosBase(o.ruta):(o.app||"writer"))); }
  }catch(e){ return {ok:false,text:"ERROR: "+(e.message||e),short:"⚠ "+(e.message||e),ms:performance.now()-t0}; }
};
const V98_aosAgentAsk=aosAgentAsk;
aosAgentAsk=async function(){ try{ await aosOfEstado(); }catch(e){} return V98_aosAgentAsk.apply(this,arguments); };
const V98_aosQuick=aosQuick;
aosQuick=async function(q){
  const t=String(q||"").trim().replace(/[.!¡¿?]+$/,"").toLowerCase();
  const m=t.match(/^(?:abr[ií](?:me)?|abrir|open|inici[aá]|nuevo|nueva|cre[aá])\s+(?:el\s+|la\s+|un\s+|una\s+)?(libreoffice|openoffice|writer|calc|impress|documento(?: en blanco)?|hoja de c[aá]lculo|planilla|presentaci[oó]n)(?: en blanco)?$/i);
  if(m){ const k=m[1]; const app=/calc|hoja|planilla/.test(k)?"calc":/impress|presentaci/.test(k)?"impress":"writer"; return [{op:"office.abrir",app}]; }
  return V98_aosQuick.apply(this,arguments);
};

/* ---------- abrir documentos de oficina (v6.9.2) ----------
   · Disco de la PC (pc:): LibreOffice si está; si no, la app predeterminada del sistema.
   · Carpetas conectadas en el navegador (fsa:) o Unidad AR.T.L.A.S. (opfs:): el núcleo abre una COPIA;
     al volver al navegador, si la copia cambió, se ofrece guardar los cambios en el original.
   · Sin núcleo: vista previa en el navegador (.docx con mammoth; .xlsx/.xls/.ods/.csv con SheetJS). */
const AOS_OF_OPEN=/^(docx?|docm|dotx|odt|ott|rtf|xlsx?|xlsm|xltx|ods|ots|csv|pptx?|ppsx?|odp|otp|odg)$/;
AOSOF.copias={};
function aosOfB64(blob){ return blob.arrayBuffer().then(buf=>{ const u=new Uint8Array(buf); let s=""; for(let i=0;i<u.length;i+=32768) s+=String.fromCharCode.apply(null,u.subarray(i,i+32768)); return btoa(s); }); }
async function aosOfOpenDoc(u,forceView){
  const e=aosExt(u), st=forceView?{nucleo:false}:await aosOfEstado();
  try{
    if(st.nucleo&&aosScheme(u)==="pc"){
      if(st.disponible){ await aosNuc("office.abrir",{ruta:aosPathOf(u)}); aosToast(aosL("Abriendo en ","Opening in ")+st.suite+": "+aosBase(u),"ok"); }
      else { await AOSFS.openSystem(u); aosToast(aosL("Abriendo con la aplicación del sistema: ","Opening with the system app: ")+aosBase(u),"ok"); }
      return;
    }
    if(st.nucleo){
      const b=await AOSFS.blob(u); if(b.size>40*1024*1024) throw new Error(aosL("El archivo supera 40 MB: abrilo desde una carpeta del núcleo.","File over 40 MB: open it from a core folder."));
      let r; try{ r=await aosNuc("fs.abrirCopia",{nombre:aosBase(u),base64:await aosOfB64(b)}); }
      catch(er){ if(/desconocida|unknown/i.test(er.message||"")){ aosToast(aosL("Tu núcleo es de una versión anterior: descargalo de nuevo desde Configuración → Núcleo local para abrir documentos de estas carpetas. Mientras tanto, te muestro una vista previa.","Your core is outdated: download it again from Settings → Local core. Meanwhile, here's a preview."),"warn",9000); if(/^(docx|docm|dotx|xlsx?|xlsm|ods|csv)$/.test(e)) aosLaunch("vistadoc",{uri:u,nuevo:true}); return; } throw er; }
      AOSOF.copias[r.id]={uri:u,mod:r.mod,nombre:aosBase(u),t:Date.now()};
      aosToast(aosL("Abriendo en ","Opening in ")+(r.con==="sistema"?aosL("la app del sistema","the system app"):r.con)+aosL(". Es una copia: cuando guardes y vuelvas acá, te ofrezco pasar los cambios al original."," . It's a copy: when you save and come back, I'll offer to copy the changes to the original."),"ok",8000);
      return;
    }
    if(/^(docx|docm|dotx)$/.test(e)||/^(xlsx?|xlsm|ods|csv)$/.test(e)) return aosLaunch("vistadoc",{uri:u,nuevo:true});
    aosToast(aosL("Para abrir ."+e+" hace falta el núcleo local con LibreOffice (Configuración → Núcleo local). Mientras tanto, podés pedirle a AR.T.L.A.S. que lo lea.","To open ."+e+" you need the local core with LibreOffice (Settings → Local core). Meanwhile, ask AR.T.L.A.S. to read it."),"warn",8000);
  }catch(er){ aosToast(er.message||String(er),"err",8000); }
}
const V98_aosOpenFile=aosOpenFile;
aosOpenFile=function(u){ if(AOS_OF_OPEN.test(aosExt(u))) return aosOfOpenDoc(u); return V98_aosOpenFile.apply(this,arguments); };
async function aosOfSyncCopias(){
  const ids=Object.keys(AOSOF.copias); if(!ids.length||!aosNucOk()||AOSOF._sync) return; AOSOF._sync=true;
  try{
    for(const id of ids){
      const c=AOSOF.copias[id]; if(Date.now()-c.t>12*3600e3){ delete AOSOF.copias[id]; continue; }
      let s; try{ s=await aosNuc("fs.estadoCopia",{id}); }catch(e){ delete AOSOF.copias[id]; continue; }
      if(s.mod<=c.mod) continue;
      if(!confirm(aosL("Guardaste cambios en la copia de «"+c.nombre+"». ¿Los copio al archivo original?\n(La versión anterior va a la papelera.)","You saved changes to the copy of «"+c.nombre+"». Copy them to the original file?\n(The previous version goes to trash.)"))){ c.mod=s.mod; continue; }
      try{ const r=await aosNuc("fs.leerCopia",{id}); const bin=Uint8Array.from(atob(r.base64),ch=>ch.charCodeAt(0));
        await AOSFS.write(c.uri,new Blob([bin]),{sobrescribir:true}); c.mod=r.mod; aosToast(aosL("Cambios guardados en «","Changes saved to «")+c.nombre+"»","ok"); aosOfRefreshFiles(); }
      catch(e){ aosToast(e.message||String(e),"err",8000); }
    }
  }finally{ AOSOF._sync=false; }
}
window.addEventListener("focus",()=>{ if(AOS.on) setTimeout(aosOfSyncCopias,400); });
document.addEventListener("visibilitychange",()=>{ if(!document.hidden&&AOS.on) setTimeout(aosOfSyncCopias,400); });

/* vista previa de documentos en el navegador (sin núcleo) */
aosRegister("vistadoc",{title:()=>aosL("Vista previa","Preview"),icon:"office",desk:false,single:false,w:860,h:600,
  async render(win,opts){
    const u=opts.uri, e=aosExt(u); aosTitle(win,aosBase(u));
    win.body.innerHTML=`<div class="aos-pad" style="font-size:13px;color:#6b7a90">${aosL("Cargando…","Loading…")}</div>`;
    try{
      const b=await AOSFS.blob(u); let html="";
      if(/^(docx|docm|dotx)$/.test(e)){
        if(typeof mammoth==="undefined") await loadScript("https://cdn.jsdelivr.net/npm/mammoth@1.6.0/mammoth.browser.min.js");
        const r=await mammoth.convertToHtml({arrayBuffer:await b.arrayBuffer()}); html=`<div class="aosvd-doc">${r.value}</div>`;
      } else {
        await aosOfXlsx(); const wb=XLSX.read(await b.arrayBuffer(),{type:"array"});
        html=wb.SheetNames.slice(0,8).map(n=>`<h3>${aosEsc(n)}</h3><div class="aosvd-tb">${XLSX.utils.sheet_to_html(wb.Sheets[n],{header:"",footer:""})}</div>`).join("");
      }
      win.body.innerHTML=`<style>.aosvd{padding:18px 22px;user-select:text}.aosvd-doc{max-width:780px;margin:0 auto;font:14px/1.55 Calibri,"Liberation Sans",Arial,sans-serif;color:#1d2533}.aosvd-doc h1,.aosvd-doc h2{color:#0d2b5e}.aosvd table{border-collapse:collapse;font-size:12.5px}.aosvd td,.aosvd th{border:1px solid #c9d6e8;padding:3px 7px}.aosvd-tb{overflow:auto;margin-bottom:14px}.aosvd h3{color:#0d2b5e;font-size:14px;margin:6px 0}.aosvd img{max-width:100%}</style>
        <div class="aos-tbar" style="background:#fdf6ea;color:#633806;font-size:12.5px">${aosL("Vista previa de solo lectura. Para editar, conectá el núcleo local con LibreOffice.","Read-only preview. To edit, connect the local core with LibreOffice.")}</div><div class="aosvd">${html}</div>`;
    }catch(er){ win.body.innerHTML=`<div class="aos-empty">${aosEsc(aosL("No pude mostrar el documento: ","Couldn't show the document: ")+(er.message||er))}</div>`; }
  }
});
