
/* =====================================================================
   AR.T.L.A.S. · Módulo 94 · AR.T.L.A.S. OS — ARCHIVOS
   Sistema de archivos unificado con tres orígenes:
     pc:<ruta>          disco de la PC, a través del núcleo local
     fsa:<nombre>/<…>   carpetas conectadas con permiso del navegador (Chrome/Edge)
     opfs:/<…>          «Unidad AR.T.L.A.S.», espacio privado del navegador
   Borrar nunca es definitivo: va a una papelera restaurable.
   Apps: Archivos, Editor y Visor.
   ===================================================================== */
const AOSF={handles:{}, perm:{}, dbp:null};
const AOS_TXT=/^(txt|md|markdown|py|js|mjs|ts|json|csv|tsv|html|htm|css|xml|yml|yaml|ini|log|sql|c|h|cpp|hpp|java|cs|go|rs|rb|php|sh|bat|ps1|cmd|cfg|conf|tex|r|m|ipynb|env|toml|gitignore|svg)$/i;
const AOS_IMG=/^(png|jpe?g|gif|webp|bmp|ico|avif)$/i, AOS_MED=/^(mp3|wav|ogg|m4a|mp4|webm|mov)$/i, AOS_DOC=/^(pdf|docx|doc|xlsx|xls)$/i;
function aosExt(n){ const m=String(n||"").match(/\.([^.\/\\]+)$/); return m?m[1].toLowerCase():""; }
function aosMime(e){ return {png:"image/png",jpg:"image/jpeg",jpeg:"image/jpeg",gif:"image/gif",webp:"image/webp",bmp:"image/bmp",svg:"image/svg+xml",ico:"image/x-icon",avif:"image/avif",pdf:"application/pdf",mp3:"audio/mpeg",wav:"audio/wav",ogg:"audio/ogg",m4a:"audio/mp4",mp4:"video/mp4",webm:"video/webm",mov:"video/quicktime",txt:"text/plain",html:"text/html",json:"application/json",csv:"text/csv"}[e]||"application/octet-stream"; }

/* ---------- rutas ---------- */
function aosScheme(u){ return String(u||"").split(":")[0]; }
function aosPathOf(u){ return String(u||"").slice(aosScheme(u).length+1); }
function aosSep(u){ return aosScheme(u)==="pc"&&/\\/.test(aosPathOf(u))?"\\":"/"; }
function aosBase(u){ const p=aosPathOf(u).replace(/[\\\/]+$/,""); const i=Math.max(p.lastIndexOf("/"),p.lastIndexOf("\\")); return i>=0?p.slice(i+1):p; }
function aosJoin(u,name){ const s=aosSep(u); return u.replace(/[\\\/]+$/,"")+s+name; }
function aosParentUri(u){ const p=u.replace(/[\\\/]+$/,""); const i=Math.max(p.lastIndexOf("/"),p.lastIndexOf("\\")); if(i<=p.indexOf(":")) return null; const r=p.slice(0,i); return /^[a-z]+:$/.test(r)?r+"/":(/^pc:[A-Za-z]:$/.test(r)?r+"\\":r); }

/* ---------- IndexedDB para las carpetas conectadas ---------- */
function aosDb(){
  if(AOSF.dbp) return AOSF.dbp;
  AOSF.dbp=new Promise((ok,ko)=>{ const r=indexedDB.open("atlas_os",1); r.onupgradeneeded=()=>r.result.createObjectStore("h"); r.onsuccess=()=>ok(r.result); r.onerror=()=>ko(r.error); });
  return AOSF.dbp;
}
async function aosDbOp(mode,fn){ const db=await aosDb(); return new Promise((ok,ko)=>{ const tx=db.transaction("h",mode); const st=tx.objectStore("h"); const r=fn(st); tx.oncomplete=()=>ok(r&&r.result); tx.onerror=()=>ko(tx.error); }); }
async function aosFsaLoad(){
  try{ const db=await aosDb(); await new Promise((ok)=>{ const tx=db.transaction("h","readonly"); const st=tx.objectStore("h"); const c=st.openCursor(); c.onsuccess=()=>{ const cur=c.result; if(cur){ AOSF.handles[cur.key]=cur.value; cur.continue(); } else ok(); }; c.onerror=()=>ok(); }); }catch(e){}
  for(const [k,h] of Object.entries(AOSF.handles)){ try{ AOSF.perm[k]=await h.queryPermission({mode:"readwrite"}); }catch(e){ AOSF.perm[k]="prompt"; } }
}
async function aosFsaConnect(){
  if(!window.showDirectoryPicker) throw new Error(aosL("Tu navegador no permite conectar carpetas. Usá Chrome o Edge, o el núcleo local.","Your browser can't connect folders. Use Chrome or Edge, or the local core."));
  const h=await window.showDirectoryPicker({mode:"readwrite",id:"artlas-os"});
  let name=h.name, n=2; while(AOSF.handles[name]&&!(await AOSF.handles[name].isSameEntry(h).catch(()=>false))) name=h.name+" ("+(n++)+")";
  AOSF.handles[name]=h; AOSF.perm[name]="granted"; await aosDbOp("readwrite",st=>st.put(h,name)); return "fsa:"+name+"/";
}
async function aosFsaForget(name){ delete AOSF.handles[name]; delete AOSF.perm[name]; await aosDbOp("readwrite",st=>st.delete(name)); }
async function aosFsaRegrant(name){ const h=AOSF.handles[name]; if(!h) return false; AOSF.perm[name]=await h.requestPermission({mode:"readwrite"}); return AOSF.perm[name]==="granted"; }

/* ---------- resolución de handles (fsa y opfs) ---------- */
async function aosOpfsRoot(sub){ const r=await navigator.storage.getDirectory(); return r.getDirectoryHandle(sub||"artlas-unidad",{create:true}); }
async function aosRootHandle(u){
  const sc=aosScheme(u);
  if(sc==="opfs") return {root:await aosOpfsRoot(), segs:aosPathOf(u).split("/").filter(Boolean)};
  if(sc==="fsa"){
    const p=aosPathOf(u).split("/").filter(Boolean); const name=p.shift(); const h=AOSF.handles[name];
    if(!h) throw new Error(aosL("Carpeta no conectada: ","Folder not connected: ")+name);
    if(AOSF.perm[name]!=="granted"){ let st="prompt"; try{ st=await h.queryPermission({mode:"readwrite"}); }catch(e){} AOSF.perm[name]=st; if(st!=="granted") throw new Error(aosL("Hay que volver a dar permiso a «"+name+"» (Archivos → Reconectar).","Grant access to «"+name+"» again (Files → Reconnect).")); }
    return {root:h, segs:p};
  }
  throw new Error("Origen no soportado: "+sc);
}
async function aosHandle(u,want){   // want: "dir" | "file" | undefined
  const {root,segs}=await aosRootHandle(u); let d=root;
  for(let i=0;i<segs.length;i++){
    const last=i===segs.length-1;
    if(!last){ d=await d.getDirectoryHandle(segs[i]); continue; }
    if(want==="file") return {h:await d.getFileHandle(segs[i]),dir:d,name:segs[i]};
    if(want==="dir") return {h:await d.getDirectoryHandle(segs[i]),dir:d,name:segs[i]};
    try{ return {h:await d.getDirectoryHandle(segs[i]),dir:d,name:segs[i]}; }catch(e){ return {h:await d.getFileHandle(segs[i]),dir:d,name:segs[i]}; }
  }
  return {h:d,dir:null,name:""};
}
async function aosParentHandle(u,create){
  const {root,segs}=await aosRootHandle(u); let d=root; const name=segs.pop(); if(!name) throw new Error("Ruta inválida");
  for(const s of segs) d=await d.getDirectoryHandle(s,{create:!!create});
  return {dir:d,name};
}
async function aosExists(dir,name){ try{ await dir.getFileHandle(name); return true; }catch(e){} try{ await dir.getDirectoryHandle(name); return true; }catch(e){} return false; }
async function aosCopyHandle(src,dstDir,name){
  if(src.kind==="file"){ const f=await src.getFile(); const fh=await dstDir.getFileHandle(name,{create:true}); const w=await fh.createWritable(); await w.write(f); await w.close(); return; }
  const nd=await dstDir.getDirectoryHandle(name,{create:true});
  for await (const [n,h] of src.entries()) await aosCopyHandle(h,nd,n);
}

/* ---------- API unificada ---------- */
const AOSFS={
  async sources(){
    const out=[];
    if(aosNucOk()){ try{ (await aosNuc("fs.raices")).forEach(r=>out.push({uri:"pc:"+r.ruta,nombre:r.nombre,grupo:"pc",disco:r.disco})); }catch(e){} }
    Object.keys(AOSF.handles).forEach(n=>out.push({uri:"fsa:"+n+"/",nombre:n,grupo:"fsa",perm:AOSF.perm[n]}));
    if(navigator.storage&&navigator.storage.getDirectory) out.push({uri:"opfs:/",nombre:aosL("Unidad AR.T.L.A.S.","AR.T.L.A.S. drive"),grupo:"opfs"});
    return out;
  },
  async list(u){
    if(aosScheme(u)==="pc"){ const r=await aosNuc("fs.listar",{ruta:aosPathOf(u)}); return {uri:"pc:"+r.ruta,parent:r.padre?"pc:"+r.padre:null,entries:r.entradas.map(e=>({...e,uri:aosJoin("pc:"+r.ruta,e.nombre)}))}; }
    const {h}=await aosHandle(u,aosPathOf(u).split("/").filter(Boolean).length>(aosScheme(u)==="fsa"?1:0)?"dir":undefined); const out=[];
    for await (const [n,c] of h.entries()){
      if(n.startsWith(".")) continue;
      if(c.kind==="file"){ let f=null; try{ f=await c.getFile(); }catch(e){} out.push({nombre:n,tipo:"archivo",tam:f?f.size:0,mod:f?f.lastModified:0,ext:aosExt(n),uri:aosJoin(u,n)}); }
      else out.push({nombre:n,tipo:"dir",tam:0,mod:0,ext:"",uri:aosJoin(u,n)});
      if(out.length>=3000) break;
    }
    out.sort((x,y)=>x.tipo===y.tipo?x.nombre.localeCompare(y.nombre,"es",{numeric:true}):x.tipo==="dir"?-1:1);
    const segs=aosPathOf(u).split("/").filter(Boolean); const isRoot=aosScheme(u)==="fsa"?segs.length<=1:segs.length===0;
    return {uri:u,parent:isRoot?null:aosParentUri(u),entries:out};
  },
  async blob(u){
    if(aosScheme(u)==="pc"){ const r=await aosNuc("fs.leer",{ruta:aosPathOf(u),modo:"base64",max:25*1024*1024}); const b=Uint8Array.from(atob(r.base64),c=>c.charCodeAt(0)); return new Blob([b],{type:aosMime(aosExt(u))}); }
    const {h}=await aosHandle(u,"file"); return await h.getFile();
  },
  async readText(u,max){
    max=max||2*1024*1024;
    if(aosScheme(u)==="pc"){ const r=await aosNuc("fs.leer",{ruta:aosPathOf(u),max}); if(r.texto==null) throw new Error(aosL("Es un archivo binario","It's a binary file")); return {texto:r.texto,tam:r.tam,truncado:r.truncado}; }
    const f=await this.blob(u); const t=await f.slice(0,max).text(); return {texto:t,tam:f.size,truncado:f.size>max};
  },
  async readForAI(u,max){   // texto útil para la IA: PDF, Word y Excel con los lectores de la plataforma
    max=max||60000; const e=aosExt(u);
    if(AOS_DOC.test(e)&&typeof extractText==="function"){ const b=await this.blob(u); const t=await extractText(new File([b],aosBase(u),{type:b.type})); return {texto:t.slice(0,max),tam:b.size,truncado:t.length>max}; }
    return this.readText(u,max);
  },
  async write(u,data,opt){
    opt=opt||{};
    if(aosScheme(u)==="pc"){
      const a={ruta:aosPathOf(u),sobrescribir:!!opt.sobrescribir};
      if(typeof data==="string") a.texto=data; else { const buf=new Uint8Array(await data.arrayBuffer()); let s=""; for(let i=0;i<buf.length;i+=32768) s+=String.fromCharCode.apply(null,buf.subarray(i,i+32768)); a.base64=btoa(s); }
      return aosNuc("fs.escribir",a);
    }
    const {dir,name}=await aosParentHandle(u,true);
    if(await aosExists(dir,name)){ if(!opt.sobrescribir) throw new Error(aosL("Ya existe: ","Already exists: ")+name); await aosTrashHandle(u,"copia"); }
    const fh=await dir.getFileHandle(name,{create:true}); const w=await fh.createWritable(); await w.write(data); await w.close(); return {ruta:u};
  },
  async mkdir(u){ if(aosScheme(u)==="pc") return aosNuc("fs.crearCarpeta",{ruta:aosPathOf(u)}); const {dir,name}=await aosParentHandle(u,true); await dir.getDirectoryHandle(name,{create:true}); return {ruta:u}; },
  async copy(a,b){
    if(aosScheme(a)==="pc"&&aosScheme(b)==="pc") return aosNuc("fs.copiar",{de:aosPathOf(a),a:aosPathOf(b)});
    if(aosScheme(a)!=="pc"&&aosScheme(b)!=="pc"){ const {h}=await aosHandle(a); const {dir,name}=await aosParentHandle(b,true); if(await aosExists(dir,name)) throw new Error(aosL("El destino ya existe","Destination exists")); await aosCopyHandle(h,dir,name); return {a:b}; }
    const blob=await this.blob(a); return this.write(b,blob);   // entre orígenes: solo archivos
  },
  async move(a,b){
    if(aosScheme(a)==="pc"&&aosScheme(b)==="pc") return aosNuc("fs.mover",{de:aosPathOf(a),a:aosPathOf(b)});
    if(aosScheme(a)!=="pc"&&aosScheme(a)===aosScheme(b)&&aosRootName(a)===aosRootName(b)){   // v6.9.4: mover/renombrar nativo de Chrome (sin copiar ni reescribir el archivo)
      let h=null; try{ h=(await aosHandle(a)).h; }catch(e){}
      if(h&&typeof h.move==="function"){
        const {dir,name}=await aosParentHandle(b); if(await aosExists(dir,name)) throw new Error(aosL("Ya existe: ","Already exists: ")+name);
        try{ if(aosParentUri(a)===aosParentUri(b)) await h.move(name); else await h.move(dir,name); return {a:b}; }catch(e){ if(e&&e.name==="SecurityError") throw e; }
      }
    }
    await this.copy(a,b); await this.remove(a,true); return {a:b};
  },
  async rename(u,nuevo){ if(/[\\\/:*?"<>|]/.test(nuevo)) throw new Error(aosL("Nombre inválido","Invalid name")); return this.move(u,aosJoin(aosParentUri(u),nuevo)); },
  async remove(u,silent){
    if(aosScheme(u)==="pc") return aosNuc("fs.papelera",{ruta:aosPathOf(u)});
    const id=await aosTrashHandle(u,"borrado"); const {dir,name}=await aosParentHandle(u);
    try{ await dir.removeEntry(name,{recursive:true}); }
    catch(e){ try{ const tr=await aosOpfsRoot("artlas-papelera"); await tr.removeEntry(id,{recursive:true}); localStorage.setItem("atlas_os_trash",JSON.stringify(aosTrashDb().filter(x=>x.id!==id))); }catch(x){} throw e; }
    return {id};
  },
  async search(q,base){
    if((!base&&aosNucOk())||aosScheme(base||"")==="pc"){ const r=await aosNuc("fs.buscar",{patron:q,ruta:base?aosPathOf(base):undefined,max:200}); return r.resultados.map(x=>({...x,uri:"pc:"+x.ruta})); }
    const out=[]; const ql=String(q).toLowerCase(); const rx=/[*?]/.test(ql)?new RegExp("^"+ql.replace(/[.+^${}()|[\]\\]/g,"\\$&").replace(/\*/g,".*").replace(/\?/g,".")+"$"):null;
    const roots=base?[base]:(await this.sources()).filter(s=>s.grupo!=="pc").map(s=>s.uri);
    async function walk(u,d){ if(out.length>=200||d<0) return; let L; try{ L=await AOSFS.list(u); }catch(e){ return; }
      for(const e of L.entries){ const n=e.nombre.toLowerCase(); if(rx?rx.test(n):n.includes(ql)) out.push({ruta:e.uri,nombre:e.nombre,tipo:e.tipo,uri:e.uri}); if(e.tipo==="dir") await walk(e.uri,d-1); } }
    for(const r of roots) await walk(r,6); return out;
  },
  async openSystem(u){ if(aosScheme(u)!=="pc") throw new Error(aosL("Solo los archivos del disco (núcleo) se abren con las apps del sistema","Only disk files (core) open with system apps")); return aosNuc("fs.abrir",{ruta:aosPathOf(u)}); }
};
/* papelera del navegador (fsa / opfs) */
function aosTrashDb(){ try{ return JSON.parse(localStorage.getItem("atlas_os_trash")||"[]"); }catch(e){ return []; } }
async function aosTrashHandle(u,motivo){
  const {h}=await aosHandle(u); const id=Date.now().toString(36)+Math.random().toString(36).slice(2,6);
  const tr=await aosOpfsRoot("artlas-papelera"); const d=await tr.getDirectoryHandle(id,{create:true}); await aosCopyHandle(h,d,h.name);
  const db=aosTrashDb(); db.unshift({id,original:u,nombre:h.name,tipo:h.kind==="file"?"archivo":"dir",t:new Date().toISOString(),motivo}); localStorage.setItem("atlas_os_trash",JSON.stringify(db.slice(0,300)));
  return id;
}
async function aosTrashRestore(id){
  const db=aosTrashDb(); const e=db.find(x=>x.id===id); if(!e) throw new Error("No está en la papelera");
  const tr=await aosOpfsRoot("artlas-papelera"); const d=await tr.getDirectoryHandle(id); const src=e.tipo==="archivo"?await d.getFileHandle(e.nombre):await d.getDirectoryHandle(e.nombre);
  const {dir,name}=await aosParentHandle(e.original,true); if(await aosExists(dir,name)) throw new Error(aosL("Ya existe un elemento con ese nombre","An item with that name exists"));
  await aosCopyHandle(src,dir,name); await tr.removeEntry(id,{recursive:true});
  localStorage.setItem("atlas_os_trash",JSON.stringify(db.filter(x=>x.id!==id)));
}

/* ---------- abrir un archivo con la app adecuada ---------- */
function aosOpenFile(u){
  const e=aosExt(u);
  if(AOS_TXT.test(e)&&e!=="svg") return aosLaunch("editor",{uri:u,nuevo:true});
  if(AOS_IMG.test(e)||e==="svg"||e==="pdf"||AOS_MED.test(e)) return aosLaunch("visor",{uri:u,nuevo:true});
  if(aosScheme(u)==="pc") return AOSFS.openSystem(u).then(()=>aosToast(aosL("Abriendo con la aplicación del sistema: ","Opening with the system app: ")+aosBase(u),"ok")).catch(er=>aosToast(er.message,"err"));
  aosToast(aosL("Sin visor para .","No viewer for .")+e+aosL(". Podés pedirle a AR.T.L.A.S. que lo lea.",". Ask AR.T.L.A.S. to read it."),"warn");
}
function aosFileIcon(e){ return e.tipo==="dir"?'<span style="color:#1976d2;display:flex">'+aosIcon("folder",17)+"</span>":'<span style="color:'+(AOS_IMG.test(e.ext)?"#7a4fd8":e.ext==="pdf"?"#ef4146":/xlsx?|csv/.test(e.ext)?"#10a37f":/docx?/.test(e.ext)?"#1976d2":"#6b7a90")+';display:flex">'+aosIcon("file",17)+"</span>"; }

/* ---------- app Archivos ---------- */
aosRegister("archivos",{title:()=>aosL("Archivos","Files"),sub:()=>aosL("Carpetas de la PC y del navegador","PC and browser folders"),icon:"folder",desk:true,order:20,single:false,w:900,h:560,kw:"archivos files carpetas explorador",
  async render(win,opts){
    win.state={uri:opts.uri||null,sel:null,hist:[]};
    win.body.innerHTML=`<div style="display:flex;flex:1;min-height:0">
      <div class="aosf-side" style="width:210px;flex:none;border-right:1px solid #e5e5e5;overflow:auto;background:#fafcff;padding:8px 6px"></div>
      <div style="flex:1;display:flex;flex-direction:column;min-width:0">
        <div class="aos-tbar">
          <button class="aos-btn sm" data-a="up" title="${aosEsc(aosL("Subir un nivel","Up one level"))}">${aosIcon("up",14)}</button>
          <span class="aosf-crumb" style="flex:1;min-width:120px;font-size:12.5px;color:#0d2b5e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"></span>
          <input class="aos-in aosf-q" placeholder="${aosEsc(aosL("Buscar…","Search…"))}" style="width:150px;padding:5px 9px;font-size:12.5px">
          <button class="aos-btn sm" data-a="mkdir">${aosL("Nueva carpeta","New folder")}</button>
          <button class="aos-btn sm" data-a="newf">${aosL("Nuevo archivo","New file")}</button>
          <button class="aos-btn sm" data-a="upload">${aosL("Subir","Upload")}</button>
          <input type="file" class="aosf-up" multiple style="display:none">
        </div>
        <div class="aosf-act aos-tbar" style="background:#f4f8fd"></div>
        <div class="aosf-list" style="flex:1;overflow:auto"></div>
        <div class="aosf-foot" style="padding:5px 12px;font-size:11.5px;color:#8f8f8f;border-top:1px solid #f0f0f0"></div>
      </div></div>`;
    const B=win.body;
    B.querySelector('[data-a="up"]').onclick=()=>{ const p=win.state.parent; if(p) aosfGo(win,p); };
    B.querySelector('[data-a="mkdir"]').onclick=()=>aosfMkdir(win);
    B.querySelector('[data-a="newf"]').onclick=()=>aosfNewFile(win);
    B.querySelector('[data-a="upload"]').onclick=()=>B.querySelector(".aosf-up").click();
    B.querySelector(".aosf-up").onchange=e=>aosfUpload(win,e.target.files);
    const q=B.querySelector(".aosf-q"); q.onkeydown=e=>{ if(e.key==="Enter") aosfSearch(win,q.value); if(e.key==="Escape"){ q.value=""; aosfGo(win,win.state.uri); } };
    B.addEventListener("dragover",e=>{ e.preventDefault(); }); B.addEventListener("drop",e=>{ e.preventDefault(); if(e.dataTransfer&&e.dataTransfer.files.length) aosfUpload(win,e.dataTransfer.files); });
    await aosfSide(win);
    if(win.state.uri) aosfGo(win,win.state.uri); else { const s=win.state.sources||[]; if(s.length) aosfGo(win,s[0].uri); else aosfPaintEmpty(win); }
  },
  reopen(win,opts){ if(opts&&opts.uri) aosfGo(win,opts.uri); }
});
async function aosfSide(win){
  const side=win.body.querySelector(".aosf-side"); if(!side) return;
  const S=await AOSFS.sources(); win.state.sources=S;
  const grp=(g,t)=>{ const it=S.filter(s=>s.grupo===g); return it.length?`<div class="grp" style="font-size:11px;color:#8f8f8f;font-weight:600;padding:8px 8px 3px">${t}</div>`+it.map(s=>`<button class="aos-row" style="padding:6px 8px;font-size:12.5px" data-u="${aosEsc(s.uri)}"><span class="ib">${aosIcon(g==="opfs"?"atlas":"folder",16)}</span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${aosEsc(s.nombre)}</span>${g==="fsa"&&s.perm!=="granted"?'<small style="color:#e8a13c">●</small>':""}</button>`).join(""):""; };
  side.innerHTML=grp("pc",aosL("Esta PC (núcleo)","This PC (core)"))
    +(aosNucOk()?"":`<div style="font-size:11.5px;color:#6b7a90;padding:8px;line-height:1.45">${aosL("Para ver todo el disco, abrí el núcleo local.","Start the local core to browse your disk.")} <a href="#" onclick="event.preventDefault();aosLaunch('config')">${aosL("Configurar","Set up")}</a></div>`)
    +grp("fsa",aosL("Carpetas conectadas","Connected folders"))
    +`<button class="aos-row" style="padding:6px 8px;font-size:12px;color:#1976d2" data-c="1"><span class="ib">${aosIcon("plug",15)}</span>${aosL("Conectar carpeta…","Connect folder…")}</button>`
    +grp("opfs",aosL("En el navegador","In the browser"))
    +`<button class="aos-row" style="padding:6px 8px;font-size:12.5px" data-t="1"><span class="ib">${aosIcon("trash",16)}</span>${aosL("Papelera","Trash")}</button>`;
  side.querySelectorAll("[data-u]").forEach(b=>b.onclick=async()=>{ const u=b.dataset.u; if(aosScheme(u)==="fsa"){ const n=aosPathOf(u).split("/")[0]; if(AOSF.perm[n]!=="granted"){ try{ await aosFsaRegrant(n); aosfSide(win); }catch(e){ aosToast(e.message,"err"); return; } } } aosfGo(win,u); });
  side.querySelector("[data-c]").onclick=async()=>{ try{ const u=await aosFsaConnect(); await aosfSide(win); aosfGo(win,u); }catch(e){ if(e&&e.name!=="AbortError") aosToast(e.message||String(e),"err"); } };
  side.querySelector("[data-t]").onclick=()=>aosfTrash(win);
}
function aosfPaintEmpty(win){ win.body.querySelector(".aosf-list").innerHTML=`<div class="aos-empty">${aosL("Conectá una carpeta o abrí el núcleo local para empezar.","Connect a folder or start the local core to begin.")}</div>`; }
async function aosfGo(win,u){
  const L=win.body.querySelector(".aosf-list"); if(!L) return;
  L.innerHTML=`<div class="aos-empty">${aosL("Cargando…","Loading…")}</div>`; win.state.sel=null; aosfAct(win);
  try{ let best=null; win.body.querySelectorAll(".aosf-side .aos-row[data-u]").forEach(b=>{ b.classList.remove("sel"); const d=b.dataset.u; if(String(u).startsWith(d)&&(!best||d.length>best.dataset.u.length)) best=b; }); if(best) best.classList.add("sel"); }catch(e){}
  try{
    const r=await AOSFS.list(u); win.state.uri=r.uri; win.state.parent=r.parent; win.state.entries=r.entries;
    win.body.querySelector(".aosf-crumb").textContent=aosScheme(r.uri)==="pc"?aosPathOf(r.uri):aosScheme(r.uri)==="opfs"?aosL("Unidad AR.T.L.A.S.","AR.T.L.A.S. drive")+" "+aosPathOf(r.uri):aosPathOf(r.uri);
    aosTitle(win,aosL("Archivos","Files")+" · "+(aosBase(r.uri)||aosL("Unidad AR.T.L.A.S.","AR.T.L.A.S. drive")));
    aosfPaint(win,r.entries);
  }catch(e){ L.innerHTML=`<div class="aos-empty">${aosEsc(e.message||e)}</div>`; }
}
function aosfOrden(win){ if(!win.state.orden){ try{ win.state.orden=JSON.parse(localStorage.getItem("atlas_os_orden")||"null"); }catch(e){} if(!win.state.orden||!win.state.orden.k) win.state.orden={k:"nombre",dir:1}; } return win.state.orden; }
function aosfSort(entries,o){
  const col=new Intl.Collator(atlasLang==="en"?"en":"es",{numeric:true,sensitivity:"base"});
  const by=o.k==="tam"?(a,b)=>(a.tam||0)-(b.tam||0):o.k==="mod"?(a,b)=>(a.mod||0)-(b.mod||0):(a,b)=>col.compare(a.nombre,b.nombre);
  return entries.slice().sort((a,b)=>{ const da=a.tipo==="dir"?0:1, db=b.tipo==="dir"?0:1; if(da!==db) return da-db;   // carpetas siempre primero
    const r=by(a,b)*o.dir; return r||col.compare(a.nombre,b.nombre); });
}
function aosfPaint(win,entries,searchMode){
  const L=win.body.querySelector(".aosf-list");
  const o=aosfOrden(win); if(entries.length) entries=aosfSort(entries,o);
  const th=(k,t,w)=>`<th data-ord="${k}" class="aosf-th${o.k===k?" on":""}" ${w?`style="width:${w}px"`:""} title="${aosEsc(aosL("Ordenar por ","Sort by ")+t.toLowerCase())}">${t}<span class="ar">${o.k===k?(o.dir>0?"▲":"▼"):"↕"}</span></th>`;
  if(!entries.length){ L.innerHTML=`<div class="aos-empty">${searchMode?aosL("Sin resultados.","No results."):aosL("Carpeta vacía. Arrastrá archivos acá para subirlos.","Empty folder. Drop files here to upload.")}</div>`; win.body.querySelector(".aosf-foot").textContent=""; return; }
  L.innerHTML=`<table class="aos-tbl"><thead><tr>${th("nombre",aosL("Nombre","Name"))}${searchMode?`<th style="width:90px"></th>`:th("tam",aosL("Tamaño","Size"),90)}${searchMode?`<th style="width:130px">${aosL("Ubicación","Location")}</th>`:th("mod",aosL("Modificado","Modified"),130)}</tr></thead><tbody>`+
    entries.map((e,i)=>`<tr data-i="${i}" style="cursor:default"><td><span style="display:flex;align-items:center;gap:8px">${aosFileIcon(e)}<span style="overflow:hidden;text-overflow:ellipsis">${aosEsc(e.nombre)}</span></span></td><td style="color:#6b7a90">${searchMode||e.tipo==="dir"?"":aosFmtBytes(e.tam)}</td><td style="color:#6b7a90;font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:220px">${searchMode?aosEsc(aosParentUri(e.uri)?aosPathOf(aosParentUri(e.uri)):""):aosFmtDate(e.mod)}</td></tr>`).join("")+"</tbody></table>";
  win.state.view=entries;
  L.querySelectorAll("th[data-ord]").forEach(h=>h.onclick=()=>{ const k=h.dataset.ord; const cur=aosfOrden(win); win.state.orden={k,dir:cur.k===k?-cur.dir:(k==="nombre"?1:-1)}; try{ localStorage.setItem("atlas_os_orden",JSON.stringify(win.state.orden)); }catch(e){}
    const selU=win.state.sel&&win.state.sel.uri; aosfPaint(win,entries,searchMode); if(selU){ const i=win.state.view.findIndex(x=>x.uri===selU); const tr=L.querySelector(`tr[data-i="${i}"]`); if(tr){ tr.classList.add("sel"); win.state.sel=win.state.view[i]; } } });
  L.querySelectorAll("tr[data-i]").forEach(tr=>{
    tr.onclick=()=>{ L.querySelectorAll("tr.sel").forEach(x=>x.classList.remove("sel")); tr.classList.add("sel"); win.state.sel=entries[+tr.dataset.i]; aosfAct(win); };
    tr.ondblclick=()=>{ const e=entries[+tr.dataset.i]; if(e.tipo==="dir") aosfGo(win,e.uri); else aosOpenFile(e.uri); };
  });
  const nd=entries.filter(e=>e.tipo==="dir").length; win.body.querySelector(".aosf-foot").textContent=`${nd} ${aosL("carpetas","folders")} · ${entries.length-nd} ${aosL("archivos","files")}`;
}
function aosfAct(win){
  const A=win.body.querySelector(".aosf-act"); const e=win.state.sel; if(!A) return;
  if(!e){ A.style.display=""; A.innerHTML=`<span class="aosf-hint">${aosL("Elegí un archivo o una carpeta para ver sus acciones · doble clic para abrir","Pick a file or folder to see its actions · double-click to open")}</span>`; return; }
  const pc=aosScheme(e.uri)==="pc";
  A.style.display="flex";
  A.innerHTML=`<b style="font-size:12px;color:#0d2b5e;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${aosEsc(e.nombre)}</b>
    <button class="aos-btn sm" data-x="open">${aosL("Abrir","Open")}</button>
    ${pc&&e.tipo!=="dir"?`<button class="aos-btn sm" data-x="sys">${aosL("Abrir con la app del sistema","Open with system app")}</button>`:""}
    ${e.tipo!=="dir"?`<button class="aos-btn sm" data-x="ask">${aosL("Preguntar a AR.T.L.A.S.","Ask AR.T.L.A.S.")}</button>`:""}
    <button class="aos-btn sm" data-x="ren">${aosL("Renombrar","Rename")}</button>
    <button class="aos-btn sm" data-x="mv">${aosL("Mover a…","Move to…")}</button>
    <button class="aos-btn sm" data-x="cp">${aosL("Duplicar","Duplicate")}</button>
    ${e.tipo!=="dir"?`<button class="aos-btn sm" data-x="dl">${aosL("Descargar","Download")}</button>`:""}
    <button class="aos-btn sm dan" data-x="del">${aosL("Borrar","Delete")}</button>`;
  A.querySelectorAll("[data-x]").forEach(b=>b.onclick=()=>aosfDo(win,b.dataset.x));
}
async function aosfDo(win,x){
  const e=win.state.sel; if(!e) return;
  try{
    if(x==="open"){ if(e.tipo==="dir") aosfGo(win,e.uri); else aosOpenFile(e.uri); return; }
    if(x==="sys"){ await AOSFS.openSystem(e.uri); aosToast(aosL("Abierto en tu PC","Opened on your PC"),"ok"); return; }
    if(x==="ask"){ const w=aosLaunch("asistente"); if(w&&typeof aosAgentAttach==="function") aosAgentAttach(w,e.uri); return; }
    if(x==="dl"){ const b=await AOSFS.blob(e.uri); const a=document.createElement("a"); a.href=URL.createObjectURL(b); a.download=e.nombre; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),4000); return; }
    if(x==="ren"){ let n=prompt(aosL("Nuevo nombre:","New name:"),e.nombre); if(!n) return; n=n.trim().replace(/[.\s]+$/,""); if(!n||n===e.nombre) return;
      const ex=aosExt(e.nombre); if(e.tipo!=="dir"&&ex&&!aosExt(n)) n+="."+ex;   // conserva la extensión si no se escribió
      await AOSFS.rename(e.uri,n); aosToast(aosL("Renombrado","Renamed"),"ok"); }
    if(x==="cp"){ const ext=e.tipo==="dir"?"":(e.nombre.match(/\.[^.]+$/)||[""])[0]; const base=ext?e.nombre.slice(0,-ext.length):e.nombre; await AOSFS.copy(e.uri,aosJoin(aosParentUri(e.uri),base+aosL(" (copia)"," (copy)")+ext)); aosToast(aosL("Duplicado","Duplicated"),"ok"); }
    if(x==="mv"){ const dst=await aosfPickFolder(win,aosL("Mover «","Move «")+e.nombre+"» "+aosL("a…","to…"),aosParentUri(e.uri)); if(!dst) return; if(dst===aosParentUri(e.uri)){ aosToast(aosL("Ya está en esa carpeta.","It's already in that folder."),"warn"); return; } await AOSFS.move(e.uri,aosJoin(dst,e.nombre)); aosToast(aosL("Movido a ","Moved to ")+aosBase(dst.replace(/[\\/]+$/,""))||dst,"ok"); }
    if(x==="del"){ if(!confirm(aosL("¿Mover a la papelera «"+e.nombre+"»? Se puede restaurar.","Move «"+e.nombre+"» to trash? It can be restored."))) return; await AOSFS.remove(e.uri); aosToast(aosL("Movido a la papelera","Moved to trash"),"ok"); }
    aosfGo(win,win.state.uri);
  }catch(er){ aosToast(aosFsErr(er,e.uri),"err",9000); }
}
async function aosfMkdir(win){ if(!win.state.uri) return; const n=prompt(aosL("Nombre de la carpeta:","Folder name:"),aosL("Nueva carpeta","New folder")); if(!n) return; try{ await AOSFS.mkdir(aosJoin(win.state.uri,n.trim())); aosfGo(win,win.state.uri); }catch(e){ aosToast(e.message,"err"); } }
async function aosfNewFile(win){ if(!win.state.uri) return; const n=prompt(aosL("Nombre del archivo:","File name:"),"nota.md"); if(!n) return; const u=aosJoin(win.state.uri,n.trim()); try{ await AOSFS.write(u,""); await aosfGo(win,win.state.uri); aosLaunch("editor",{uri:u,nuevo:true}); }catch(e){ aosToast(e.message,"err"); } }
async function aosfUpload(win,files){
  if(!win.state.uri) return aosToast(aosL("Elegí primero una carpeta","Pick a folder first"),"warn");
  let ok=0; for(const f of files){ try{ await AOSFS.write(aosJoin(win.state.uri,f.name),f); ok++; }catch(e){ aosToast(f.name+": "+e.message,"err"); } }
  if(ok) aosToast(ok+aosL(" archivo(s) subido(s)"," file(s) uploaded"),"ok"); aosfGo(win,win.state.uri);
}
async function aosfSearch(win,q){
  q=(q||"").trim(); if(!q) return aosfGo(win,win.state.uri);
  const L=win.body.querySelector(".aosf-list"); L.innerHTML=`<div class="aos-empty">${aosL("Buscando…","Searching…")}</div>`;
  try{ const r=await AOSFS.search(q,win.state.uri); aosfPaint(win,r.map(x=>({...x,ext:aosExt(x.nombre)})),true); }catch(e){ L.innerHTML=`<div class="aos-empty">${aosEsc(e.message)}</div>`; }
}
async function aosfTrash(win){
  aosTitle(win,aosL("Archivos · Papelera","Files · Trash")); win.state.uri=null; win.state.sel=null; aosfAct(win);
  win.body.querySelector(".aosf-crumb").textContent=aosL("Papelera","Trash");
  const L=win.body.querySelector(".aosf-list"); let items=aosTrashDb().map(x=>({...x,src:"web"}));
  if(aosNucOk()){ try{ items=items.concat((await aosNuc("fs.verPapelera")).map(x=>({...x,src:"pc",original:"pc:"+x.original}))); }catch(e){} }
  items.sort((a,b)=>String(b.t).localeCompare(String(a.t)));
  if(!items.length){ L.innerHTML=`<div class="aos-empty">${aosL("La papelera está vacía.","Trash is empty.")}</div>`; return; }
  L.innerHTML=`<table class="aos-tbl"><thead><tr><th>${aosL("Elemento","Item")}</th><th>${aosL("Ubicación original","Original location")}</th><th style="width:110px"></th></tr></thead><tbody>`+items.map((x,i)=>`<tr><td>${aosEsc(x.nombre)}${x.motivo==="copia"?` <span class="aos-pill">${aosL("copia previa","previous copy")}</span>`:""}<div style="font-size:11px;color:#8f8f8f">${aosFmtDate(Date.parse(x.t))}</div></td><td style="font-size:11.5px;color:#6b7a90;word-break:break-all">${aosEsc(aosScheme(x.original)==="pc"?aosPathOf(x.original):x.original)}</td><td><button class="aos-btn sm" data-r="${i}">${aosL("Restaurar","Restore")}</button></td></tr>`).join("")+"</tbody></table>";
  L.querySelectorAll("[data-r]").forEach(b=>b.onclick=async()=>{ const x=items[+b.dataset.r]; try{ if(x.src==="pc") await aosNuc("fs.restaurar",{id:x.id}); else await aosTrashRestore(x.id); aosToast(aosL("Restaurado","Restored"),"ok"); aosfTrash(win); }catch(e){ aosToast(e.message,"err"); } });
}

/* ---------- Editor ---------- */
aosRegister("editor",{title:()=>aosL("Editor","Editor"),sub:()=>aosL("Texto, código y notas","Text, code and notes"),icon:"edit",single:false,w:820,h:560,kw:"editor texto codigo notas",
  async render(win,opts){
    win.state={uri:opts.uri||null,dirty:false};
    win.body.innerHTML=`<div class="aos-tbar"><button class="aos-btn sm pri" data-a="save">${aosL("Guardar","Save")}</button><button class="aos-btn sm" data-a="saveas">${aosL("Guardar como…","Save as…")}</button>
      <button class="aos-btn sm" data-a="run" style="display:none">▶ ${aosL("Ejecutar Python","Run Python")}</button><button class="aos-btn sm" data-a="ask">${aosL("Preguntar a AR.T.L.A.S.","Ask AR.T.L.A.S.")}</button>
      <span class="aose-st" style="margin-left:auto;font-size:11.5px;color:#8f8f8f"></span></div>
      <textarea class="aose-ta" spellcheck="false" style="flex:1;border:none;outline:none;resize:none;padding:12px 14px;font:13px/1.55 ui-monospace,Consolas,'Cascadia Mono',monospace;color:#0d0d0d;tab-size:4"></textarea>
      <div class="aose-out" style="display:none;max-height:40%;overflow:auto;border-top:1px solid #e5e5e5;padding:8px 14px;background:#fafcff"></div>`;
    const ta=win.body.querySelector(".aose-ta"), st=win.body.querySelector(".aose-st");
    const mark=d=>{ win.state.dirty=d; st.textContent=(win.state.uri?aosBase(win.state.uri):aosL("Sin título","Untitled"))+(d?" · "+aosL("sin guardar","unsaved"):""); aosTitle(win,(d?"● ":"")+(win.state.uri?aosBase(win.state.uri):aosL("Sin título","Untitled"))); };
    ta.addEventListener("input",()=>mark(true));
    ta.addEventListener("keydown",e=>{ if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="s"){ e.preventDefault(); aoseSave(win,false); } if(e.key==="Tab"){ e.preventDefault(); const s=ta.selectionStart; ta.setRangeText("    ",s,ta.selectionEnd,"end"); mark(true); } });
    win.body.querySelector('[data-a="save"]').onclick=()=>aoseSave(win,false);
    win.body.querySelector('[data-a="saveas"]').onclick=()=>aoseSave(win,true);
    win.body.querySelector('[data-a="ask"]').onclick=()=>{ const w=aosLaunch("asistente"); if(w&&typeof aosAgentAttachText==="function") aosAgentAttachText(w,win.state.uri?aosBase(win.state.uri):"editor",ta.value); };
    const rb=win.body.querySelector('[data-a="run"]'); rb.onclick=()=>aoseRun(win);
    win.state.mark=mark;
    if(win.state.uri){
      try{ const r=await AOSFS.readText(win.state.uri); ta.value=r.texto; if(r.truncado) aosToast(aosL("Archivo grande: se muestra el comienzo","Large file: showing the beginning"),"warn"); }catch(e){ ta.value=""; aosToast(e.message,"err"); }
      if(aosExt(win.state.uri)==="py"&&typeof v67PyRun==="function") rb.style.display="";
    } else if(opts.texto) ta.value=opts.texto;
    mark(false); ta.focus();
  },
  beforeClose(win){ return !win.state.dirty||confirm(aosL("Hay cambios sin guardar. ¿Cerrar igual?","There are unsaved changes. Close anyway?")); }
});
async function aoseSave(win,as){
  const ta=win.body.querySelector(".aose-ta");
  try{
    let u=win.state.uri, over=true;
    if(as||!u){ const def=u?(aosScheme(u)==="pc"?aosPathOf(u):u):"opfs:/nota.md"; const p=prompt(aosL("Guardar en (ruta completa):","Save to (full path):"),def); if(!p) return; u=/^(pc|fsa|opfs):/.test(p)?p:(aosNucOk()?"pc:"+p:"opfs:/"+p.replace(/^\/+/,"")); over=false; }
    try{ await AOSFS.write(u,ta.value,{sobrescribir:over}); }
    catch(e){ if(/existe|exists/i.test(e.message)&&confirm(aosL("Ya existe. ¿Reemplazar? (se guarda una copia en la papelera)","It exists. Replace? (a copy goes to trash)"))) await AOSFS.write(u,ta.value,{sobrescribir:true}); else throw e; }
    win.state.uri=u; win.state.mark(false); aosToast(aosL("Guardado","Saved"),"ok");
  }catch(e){ aosToast(e.message||String(e),"err"); }
}
async function aoseRun(win){
  const out=win.body.querySelector(".aose-out"); out.style.display="block"; out.textContent=aosL("Ejecutando…","Running…");
  try{ const r=await v67PyRun(win.body.querySelector(".aose-ta").value); out.innerHTML=typeof v67OutHtml==="function"?v67OutHtml(r):aosEsc([r.out,r.res,r.err].filter(Boolean).join("\n")); }
  catch(e){ out.textContent="⚠ "+(e.message||e); }
}

/* ---------- Visor ---------- */
aosRegister("visor",{title:()=>aosL("Visor","Viewer"),icon:"eye",single:false,hidden:true,w:820,h:600,
  async render(win,opts){
    const u=opts.uri; aosTitle(win,aosBase(u)); win.body.innerHTML=`<div class="aos-empty">${aosL("Cargando…","Loading…")}</div>`;
    try{
      const b=await AOSFS.blob(u); const e=aosExt(u); const url=URL.createObjectURL(new Blob([b],{type:aosMime(e)})); win.state.url=url;
      win.body.style.background=AOS_IMG.test(e)||e==="svg"?"#1b2433":"#fff";
      win.body.innerHTML=AOS_IMG.test(e)||e==="svg"?`<div style="flex:1;display:flex;align-items:center;justify-content:center;padding:12px"><img src="${url}" style="max-width:100%;max-height:100%;object-fit:contain" alt="${aosEsc(aosBase(u))}"></div>`
        :e==="pdf"?`<iframe src="${url}" style="flex:1;border:none;width:100%"></iframe>`
        :/^(mp3|wav|ogg|m4a)$/.test(e)?`<div style="flex:1;display:flex;align-items:center;justify-content:center"><audio controls src="${url}"></audio></div>`
        :`<video controls src="${url}" style="flex:1;width:100%;background:#000"></video>`;
    }catch(er){ win.body.innerHTML=`<div class="aos-empty">${aosEsc(er.message)}</div>`; }
  },
  onClose(win){ if(win.state.url) URL.revokeObjectURL(win.state.url); }
});

/* ---------- archivos en el lanzador ---------- */
async function aosStartExtra(q){
  const box=$("aos-start-x"); if(!box) return;
  try{
    const r=(await AOSFS.search(q)).slice(0,8); if(!r.length||!$("aos-start-x")) return;
    box.innerHTML=`<div class="grp">${aosL("Archivos","Files")}</div>`+r.map((x,i)=>`<button class="aos-row" data-i="${i}"><span class="ib">${aosIcon(x.tipo==="dir"?"folder":"file",17)}</span>${aosEsc(x.nombre)}<small>${aosEsc(aosScheme(x.uri)==="pc"?aosPathOf(aosParentUri(x.uri)||""):"")}</small></button>`).join("");
    box.querySelectorAll("[data-i]").forEach(b=>b.onclick=()=>{ const x=r[+b.dataset.i]; aosStart(false); if(x.tipo==="dir") aosLaunch("archivos",{uri:x.uri,nuevo:true}); else aosOpenFile(x.uri); });
  }catch(e){}
}

/* v6.9.4 · errores del sistema de archivos de Chrome, explicados */
function aosRootName(u){ const p=aosPathOf(u).split("/").filter(Boolean); return aosScheme(u)==="fsa"?(p[0]||""):""; }
function aosFsErr(er,u){
  const m=(er&&er.message)||String(er||"");
  if((er&&er.name==="SecurityError")||/unsafe for access|too many calls|not allowed by the user agent|NotAllowedError/i.test(m)){
    const pc=aosNucOk();
    return aosL("Chrome no permitió modificar este archivo en la carpeta conectada desde el navegador (es una protección del propio Chrome para ciertos archivos y carpetas). ","Chrome didn't allow changing this file in the folder connected from the browser (a Chrome protection for certain files and folders). ")
      +(pc?aosL("Hacelo desde «Esta PC (núcleo)»: el núcleo actualizado ya incluye Imágenes, Música y Videos.","Do it from «This PC (core)»: the updated core includes Pictures, Music and Videos."):aosL("Conectá el núcleo local para trabajar sin esa limitación, o hacelo desde el Explorador de Windows.","Connect the local core to work without that limit, or use Windows Explorer."));
  }
  if(/NotFoundError|could not be found/i.test(m)) return aosL("El archivo ya no está (¿se movió o se borró desde fuera?). Actualizá la carpeta.","The file is gone (moved or deleted outside?). Refresh the folder.");
  return m;
}

/* ---------- v7.4 · «Mover a…» con selector de carpetas (orígenes conectados + navegación) ---------- */
function aosfPickFolder(win,titulo,inicio){
  return new Promise(async res=>{
    const S=await AOSFS.sources().catch(()=>[]); if(!S.length){ res(null); return; }
    const rootOf=u=>{ let b=null; S.forEach(x=>{ if(String(u||"").startsWith(x.uri)&&(!b||x.uri.length>b.uri.length)) b=x; }); return b; };
    let src=rootOf(inicio)||S[0], cur=(rootOf(inicio)?inicio:src.uri);
    const ov=document.createElement("div"); ov.className="aosf-pick";
    ov.style.cssText="position:absolute;inset:0;z-index:20;background:rgba(6,22,52,.35);display:flex;align-items:center;justify-content:center;padding:14px";
    const grupos=[["pc",aosL("Esta PC (núcleo)","This PC (core)")],["fsa",aosL("Carpetas conectadas","Connected folders")],["opfs",aosL("En el navegador","In the browser")]];
    ov.innerHTML=`<div style="background:#fff;border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.3);width:min(520px,100%);max-height:100%;display:flex;flex-direction:column;overflow:hidden">
      <div style="padding:12px 14px 8px;font-weight:700;color:#0d2b5e;font-size:14px">${aosEsc(titulo)}</div>
      <div style="padding:0 14px 8px"><select class="aos-in aosfp-src" style="width:100%">${grupos.map(([g,t])=>{ const it=S.filter(x=>x.grupo===g); return it.length?`<optgroup label="${aosEsc(t)}">${it.map(x=>`<option value="${aosEsc(x.uri)}">${aosEsc(x.nombre)}</option>`).join("")}</optgroup>`:""; }).join("")}</select></div>
      <div style="display:flex;align-items:center;gap:6px;padding:0 14px 6px"><button class="aos-btn sm aosfp-up" title="${aosEsc(aosL("Subir","Up"))}">↑</button><span class="aosfp-path" style="font-size:12px;color:#33445c;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1"></span></div>
      <div class="aosfp-list" style="flex:1;min-height:160px;max-height:300px;overflow:auto;border-top:1px solid #e5edf7;border-bottom:1px solid #e5edf7"></div>
      <div style="display:flex;gap:6px;justify-content:flex-end;padding:10px 14px"><button class="aos-btn aosfp-no">${aosL("Cancelar","Cancel")}</button><button class="aos-btn pri aosfp-ok">${aosL("Mover aquí","Move here")}</button></div></div>`;
    const host=win.el||win.body; host.appendChild(ov);
    const q=c=>ov.querySelector(c), fin=v=>{ ov.remove(); res(v); };
    q(".aosfp-src").value=src.uri;
    async function paint(){
      const rel=cur.slice(src.uri.length).replace(/^[\\/]+/,""); q(".aosfp-path").textContent=src.nombre+(rel?" › "+rel.split(/[\\/]+/).filter(Boolean).join(" › "):"");
      q(".aosfp-up").disabled=cur===src.uri; const L=q(".aosfp-list"); L.innerHTML=`<div class="aos-empty" style="padding:14px">${aosL("Cargando…","Loading…")}</div>`;
      try{ const r=await AOSFS.list(cur); const D=r.entries.filter(e=>e.tipo==="dir").sort((a,b)=>a.nombre.localeCompare(b.nombre));
        L.innerHTML=D.length?D.map((d,i)=>`<button class="aos-row" data-d="${i}" style="padding:7px 14px;border-radius:0"><span class="ib">${aosIcon("folder",15)}</span>${aosEsc(d.nombre)}<small>›</small></button>`).join(""):`<div class="aos-empty" style="padding:14px">${aosL("Sin subcarpetas: podés mover aquí.","No subfolders: you can move here.")}</div>`;
        L.querySelectorAll("[data-d]").forEach(b=>b.onclick=()=>{ cur=D[+b.dataset.d].uri; paint(); });
      }catch(e){ L.innerHTML=`<div class="aos-empty" style="padding:14px;color:#c0272d">${aosEsc(e.message||String(e))}</div>`; }
    }
    q(".aosfp-src").onchange=()=>{ src=S.find(x=>x.uri===q(".aosfp-src").value)||S[0]; cur=src.uri; paint(); };
    q(".aosfp-up").onclick=()=>{ if(cur!==src.uri){ const p=aosParentUri(cur); cur=p.length<src.uri.length?src.uri:p; paint(); } };
    q(".aosfp-no").onclick=()=>fin(null); q(".aosfp-ok").onclick=()=>fin(cur);
    ov.addEventListener("keydown",ev=>{ if(ev.key==="Escape") fin(null); });
    paint();
  });
}

/* ---------- v7.4 · cuando Chrome bloquea un cambio en una carpeta conectada, se hace con el núcleo ----------
   Chrome no deja borrar, renombrar ni mover por la web ciertos tipos de archivo (.doc, .xls, .exe, .lnk…), aunque haya permiso.
   Si la carpeta también está dentro de las carpetas del núcleo, se ubica (mismo nombre y mismo contenido) y la operación se
   hace por el disco. Si no está, se ofrece sumarla al núcleo eligiéndola en la PC con el diálogo del sistema. */
AOSF.pcMap=AOSF.pcMap||{};
function aosFsaBlocked(e){ const m=(e&&e.message)||""; return !!e&&(e.name==="SecurityError"||e.name==="NotAllowedError"||/unsafe for access|too many calls|not allowed/i.test(m)); }
async function aosFsaPcRoot(name,refresh){
  if(!aosNucOk()) return null; if(AOSF.pcMap[name]&&!refresh) return AOSF.pcMap[name];
  let want; try{ want=new Set((await AOSFS.list("fsa:"+name+"/")).entries.map(e=>e.nombre)); }catch(e){ return null; }
  const raices=await aosNuc("fs.raices",{}).catch(()=>[]); const cands=new Set();
  raices.forEach(r=>{ if(aosBase(String(r.ruta).replace(/[\\/]+$/,""))===name) cands.add(r.ruta); });
  if(!cands.size) for(const r of raices){ try{ const x=await aosNuc("fs.buscar",{patron:name,ruta:r.ruta,max:30}); (x.resultados||[]).forEach(e=>{ if(e.tipo==="dir"&&e.nombre===name) cands.add(e.ruta); }); }catch(e){} }
  let best=null,score=0;
  for(const c of cands){ try{ const l=await aosNuc("fs.listar",{ruta:c}); const got=(l.entradas||[]).map(e=>e.nombre); const inter=got.filter(n=>want.has(n)).length; const sc=inter/Math.max(want.size,got.length,1); if(sc>score){ score=sc; best=c; } }catch(e){} }
  if(best&&score>=0.8){ AOSF.pcMap[name]=best; return best; }
  return null;
}
async function aosFsaToPc(u,refresh){
  if(aosScheme(u)!=="fsa") return null; const name=aosRootName(u); const root=await aosFsaPcRoot(name,refresh); if(!root) return null;
  const rel=aosPathOf(u).split("/").filter(Boolean).slice(1); const sep=root.includes("\\")?"\\":"/";
  return "pc:"+[root.replace(/[\\/]+$/,""),...rel].join(sep);
}
async function aosFsaFallback(op,u,run){
  try{ return await run(u); }
  catch(e){
    if(aosScheme(u)!=="fsa"||!aosFsaBlocked(e)||!aosNucOk()) throw e;
    let pc=await aosFsaToPc(u);
    if(!pc){
      const name=aosRootName(u);
      if(!confirm(aosL("Chrome no permite "+op+" este tipo de archivo en carpetas conectadas desde el navegador.\n\n¿Sumar «"+name+"» a las carpetas del núcleo? Se abre una ventana en tu PC para elegirla (puede aparecer detrás del navegador).","Chrome doesn't allow this change in folders connected from the browser.\n\nAdd «"+name+"» to the core folders? A window opens on your PC to pick it (it may appear behind the browser)."))) throw e;
      aosToast(aosL("Elegí la carpeta «","Pick the folder «")+name+aosL("» en la ventana que se abrió en tu PC…","» in the window opened on your PC…"),"",15000);
      let r; try{ r=await aosNuc("fs.agregarRaiz",{sugerida:name}); }catch(x){ if(/desconocida|unknown/i.test(x.message||"")) throw new Error(aosL("Actualizá el núcleo (Configuración → Núcleo local) para poder hacerlo.","Update the core (Settings → Local core) to do this.")); throw x; }
      AOSF.pcMap[name]=r.ruta; pc=await aosFsaToPc(u);
      try{ AOS.wins.filter(w=>w.app==="archivos").forEach(w=>aosfSide(w)); }catch(x){}
    }
    const out=await run(pc); out&&typeof out==="object"&&(out.via="núcleo");
    aosToast(aosL("Hecho a través del núcleo (Chrome lo bloqueaba en la carpeta conectada).","Done through the core (Chrome blocked it in the connected folder)."),"ok",6000);
    return out||{via:"núcleo"};
  }
}
const V74_remove=AOSFS.remove.bind(AOSFS), V74_move=AOSFS.move.bind(AOSFS);
AOSFS.remove=function(u,silent){ return aosFsaFallback(aosL("borrar","delete"),u,x=>V74_remove(x,silent)); };
AOSFS.move=function(a,b){
  return aosFsaFallback(aosL("mover o renombrar","move or rename"),a,async x=>{
    if(x===a) return V74_move(a,b);
    let b2=b; if(aosScheme(b)==="fsa"&&aosRootName(b)===aosRootName(a)){ const pb=await aosFsaToPc(b); if(pb) b2=pb; }
    return V74_move(x,b2);
  });
};
