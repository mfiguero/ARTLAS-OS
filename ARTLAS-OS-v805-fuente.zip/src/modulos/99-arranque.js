
function v60RenderSkillsKeep(){ try{ v60SkillCollect(); }catch(e){} v60RenderSkillsUI(); }

/* ==================== WORKFLOW VISUAL (AI Workflow Engine) ==================== */
function v60WfPaint(steps, states, title){
  const el=$("wf-visual"); if(!el||!steps) return;
  const node=(s,i)=>{
    const st=(states&&states[i])||{};
    const lvl=(s.model&&s.model!=="auto"&&MODELS[s.model])?s.model:null;
    const label=st.pk?PROVIDERS[st.pk].label:(lvl?MODELS[lvl].name.replace(/^AR\.T\.L\.A\.S\.\s*/,""):v60L("Modelo actual","Current model"));
    const status=st.st==="run"?"⏳ "+v60L("ejecutando…","running…"):st.st==="ok"?`✓ ${(st.ms/1000).toFixed(1)} s · ≈${v60Num(st.tok)} tok`:st.st==="err"?"⚠ error":"";
    return `<div class="wf-node ${st.st||""}"><span class="m">${v60Esc(label)}</span><span class="n">${i+1}. ${v60Esc(s.title||"")}</span><span class="s">${status}</span></div>`;
  };
  el.innerHTML=`<div class="wf-chain">${title?`<div style="font-size:12px;font-weight:700;color:var(--navy);margin-bottom:8px">▶ ${v60Esc(title)}</div>`:""}<span class="wf-io">${v60L("Entrada","Input")}</span>${steps.map((s,i)=>'<span class="wf-arrow"></span>'+node(s,i)).join("")}<span class="wf-arrow"></span><span class="wf-io">${v60L("Salida","Output")}</span></div>`;
}
v60Wrap("renderWfSteps",()=>v60WfPaint(wfSteps));
document.addEventListener("change",e=>{ if(e.target.closest&&e.target.closest("#wf-steps")) v60WfPaint(wfSteps); });
runFlow=async function(ix){
  const f=flows[ix]; if(!f) return;
  let data=$("wf-input").value.trim();
  if(!data){ alert("Escribí la entrada inicial del workflow."); $("wf-input").focus(); return; }
  const out=$("wf-out"); out.innerHTML="";
  const states=f.steps.map(()=>({st:""}));
  v60WfPaint(f.steps,states,f.name);
  const t0=Date.now();
  for(let i=0;i<f.steps.length;i++){
    const s=f.steps[i];
    const lvl=(s.model&&s.model!=="auto"&&MODELS[s.model])?s.model:curModel;
    let pk=MODELS[lvl].prov; if(!connected(pk)) pk=connectedProviders()[0]||"basic";
    const prompt=s.prompt.includes("{{entrada}}")?s.prompt.split("{{entrada}}").join(data):s.prompt+"\n\nEntrada:\n"+data;
    states[i]={st:"run",pk}; v60WfPaint(f.steps,states,f.name);
    const box=document.createElement("div"); box.className="agent-card";
    box.innerHTML=`<b>Paso ${i+1}: ${esc(s.title)}</b> <span class="tag">${PROVIDERS[pk].label}</span><div class="content" style="font-size:13px;margin-top:6px;white-space:pre-wrap">⏳ ejecutando…</div>`;
    out.appendChild(box); box.scrollIntoView({behavior:"smooth",block:"end"});
    const ts=Date.now();
    try{
      const r=await callProvider(pk,cfg[pk]||{},[{role:"user",content:prompt}],MODELS[lvl].sys||null);
      states[i]={st:"ok",pk,ms:Date.now()-ts,tok:Math.round((prompt.length+(r||"").length)/4)};
      data=r; box.querySelector(".content").innerHTML=md(r);
    }catch(e){
      states[i]={st:"err",pk}; v60WfPaint(f.steps,states,f.name);
      box.querySelector(".content").innerHTML='<span class="err">⚠️ '+esc((e.message||e)+"")+'</span>'; return;
    }
    v60WfPaint(f.steps,states,f.name);
  }
  const tot=states.reduce((n,s)=>n+(s.tok||0),0);
  const fin=document.createElement("div"); fin.className="note";
  fin.textContent="✓ "+v60L("Workflow completado","Workflow completed")+" · "+((Date.now()-t0)/1000).toFixed(1)+" s · ≈"+v60Num(tot)+" tokens";
  out.appendChild(fin);
};
v60Wrap("renderFlows",()=>{ renderNav(); });

/* ==================== ANALYTICS: pipeline ==================== */
function v60AnPipe(){
  const el=$("an-pipe"); if(!el) return;
  let s=[];
  try{
    s=[[v60L("Cargar","Upload"),anFiles.length>0],[v60L("Perfilar","Profile"),anMeta.length>0],[v60L("Limpiar","Clean"),anRows.length>0],
       [v60L("Analizar","Analyze"),anSelKpis.length>0],[v60L("Minar","Mine"),V60.anMined],[v60L("Visualizar","Visualize"),anSelCharts.length>0],
       [v60L("Explicar","Explain"),!!anLastEval],[v60L("Reportar","Report"),V60.anReported]];
  }catch(e){ return; }
  el.innerHTML=s.map((x,i)=>(i?'<span class="pp-arr">→</span>':"")+`<span class="pp ${x[1]?"done":""}">${x[1]?"✓ ":""}${x[0]}</span>`).join("");
}
["anLoad","anRemoveFile","anRenderDash","anToggleKpi","anToggleChart","anAnalyze","anAnalyzeChange"].forEach(n=>v60Wrap(n,()=>v60AnPipe()));
v60Wrap("anMine",()=>{ V60.anMined=true; v60AnPipe(); });
v60Wrap("anReport",()=>{ V60.anReported=true; v60AnPipe(); });
v60Wrap("anWebpage",()=>{ V60.anReported=true; v60AnPipe(); });

/* ==================== otros enganches ==================== */
v60Wrap("updKbBadge",()=>{ renderNav(); if(curView==="home") v60RenderHome(); });
v60Wrap("goMod",()=>{ const v=document.querySelector("#view-mod .panel"); if(v) v.scrollTop=0; });
const V60_doLogin=doLogin;
doLogin=async function(){ await V60_doLogin.apply(this,arguments); if(user){ v60SSset("atlas_demo",null); setTimeout(()=>v61StartChat(),750); } };
v60Wrap("doLogout",()=>{ v60RefreshView(); });
const V60_toggleLang=toggleLang;
toggleLang=function(){
  V60_toggleLang.apply(this,arguments);
  try{ renderNav(); renderRoute(); v60Header(); v60RefreshView(); v60RenderSkillsKeep(); v60AnPipe(); v60WfPaint(wfSteps); if($("overlay").classList.contains("open")) v60SecBar(); }catch(e){ console.error(e); }
};

/* ==================== ARRANQUE v60 ==================== */
function v60Init(){
  v60UsageLoad();
  v60VaultDom();
  // botón importar agente
  try{
    const al=$("a-list");
    if(al&&!$("ag-imp")) al.insertAdjacentHTML("beforebegin",`<div style="margin:-4px 0 12px"><input type="file" id="ag-imp" accept=".json" style="display:none" onchange="v60AgentImport(this.files)"><button class="btn sm" onclick="$('ag-imp').click()">⬆ ${v60L("Importar agente (.json)","Import agent (.json)")}</button></div>`);
  }catch(e){}
  // keys según modo
  // estrategia por defecto para instalaciones nuevas: Auto Router
  try{ if(v60LS("atlas_strategy","")===""&&v60LS("atlas_route","")===""){ v60LSset("atlas_strategy","auto"); routeMode="smart"; v60LSset("atlas_route","smart"); } }catch(e){}
  const mode=v60KeyMode();
  try{
    if(mode==="session"){ v60MergeKeys(JSON.parse(v60SS("atlas_keys_s","{}")||"{}")); v60RestoreModel(); save(); }
    else if(mode==="local"){ /* v57 */ }
  }catch(e){ console.error("v60 keys",e); }
  // parámetros de entrada (desde la pantalla de acceso)
  const h=(location.hash||"").replace(/^#/,"");
  if(h==="demo") v60SSset("atlas_demo","1");
  if(h==="demo"||h==="login"||h==="signup"||h==="enter"){ v60SSset("atlas_entered","1"); try{ history.replaceState(null,"",location.pathname+location.search); }catch(e){} }
  try{ const ds=$("dsplash"); if(ds) ds.remove(); }catch(e){}      // splash de la versión escritorio → lo reemplaza la pantalla de ingreso
  // interfaz
  try{ if(typeof atlasLang!=="undefined"&&atlasLang==="en") i18nSweep(document.body,"es2en"); }catch(e){}
  renderNav(); renderRoute(); renderMenu(); v60Header(); v60RenderSkillsUI(); v60WfPaint(wfSteps); v60AnPipe();
  try{ v61Decorate(); }catch(e){ console.error("v61Decorate",e); }
  try{ v63Decorate(); }catch(e){ console.error("v63Decorate",e); }      // v63: ＋ › Buscar en la web + 👁 en campos de clave
  v61StartChat();                                   // v61: siempre arranca en una conversación nueva
  if(mode==="vault" && v60VaultRec()) V60.pendingVault=true;
  if(h==="demo"||h==="login"||h==="signup"||h==="enter") v61GateHide(true); else v61GateShow();   // v6.4: «enter» = llega desde la portada con sesión activa
  v61AuthErrorFromUrl();
  if(V61.recovery){ let n=0; const w=setInterval(async()=>{ n++; try{ const {data}=await supa.auth.getSession(); if(data&&data.session){ clearInterval(w); user=data.session.user; v61RecoveryShow(); } }catch(e){} if(n>20) clearInterval(w); },400); }   // v61: presentación siempre al abrir
  if(h==="login"||h==="signup"){
    setTimeout(()=>{ try{ v61GateLogin(h==="signup"); }catch(e){} },250);
  }
  // los agentes y la KB cargan de IndexedDB en forma asíncrona: refrescar contadores
  setTimeout(()=>{ try{ renderNav(); v60RefreshView(); }catch(e){} },900);
}
try{ v60Init(); }catch(e){ console.error("v60Init",e); }
