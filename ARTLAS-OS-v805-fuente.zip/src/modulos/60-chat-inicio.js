
/* ==========================================================================
   =====================  AR.T.L.A.S. v62 — PANTALLA DE CHAT  ================
   Chat vacío: saludo + línea de estado corta + cuadro de mensaje CENTRADO y
   sugerencias discretas (solo invitados o usuarios sin conversaciones).
   Tras el primer mensaje, el cuadro vuelve al pie. Encabezado en una línea.
   ========================================================================== */
const V62_CHIPS=[
  ["📡",["Explicame una red 5G standalone","Explain a 5G standalone network"],["Explicame la arquitectura de una red 5G standalone","Explain the architecture of a 5G standalone network"]],
  ["🐍",["Script Python para un CSV","Python script for a CSV"],["Escribí un script Python para analizar un CSV de tráfico","Write a Python script to analyze a traffic CSV"]],
  ["🔬",["Papers sobre ML en telecom","Papers on ML in telecom"],["Buscá papers sobre ML aplicado a telecomunicaciones","Find papers on ML applied to telecommunications"]],
  ["📚",["¿Qué es RAG?","What is RAG?"],["Resumime qué es RAG en 3 párrafos","Summarize what RAG is in 3 paragraphs"]]
];
function v62Chip(i){ const c=V62_CHIPS[i]; if(!c) return; inp.value=v60L(c[2][0],c[2][1]); send(); }
function v62Setup(){
  const ci=$("comp-inner"), fn=$("foot-note");
  if(ci&&fn&&!$("v62-chips")){
    const d=document.createElement("div"); d.id="v62-chips"; d.className="v62-chips";
    ci.insertBefore(d,fn);
  }
  const em=$("empty");
  if(em&&!V60._v62obs){ V60._v62obs=new MutationObserver(()=>v62Layout()); V60._v62obs.observe(em,{attributes:true,attributeFilter:["style"]}); }
  v62Layout();
}
function v62Layout(){
  const vc=$("view-chat"), em=$("empty"); if(!vc||!em) return;
  const empty=getComputedStyle(em).display!=="none";
  vc.classList.toggle("v62-empty",empty);
  if(!empty) return;
  const h=em.querySelector("h2");
  if(h){
    let t=v60L("¿En qué puedo ayudarte?","How can I help you?");
    if(v61Logged()) t=v60Saludo()+" · "+v60L("¿en qué te puedo ayudar?","how can I help you?");
    if(h.textContent!==t) h.textContent=t;
  }
  const chips=$("v62-chips");
  if(chips){
    const show=!v61Logged()||!(chats&&chats.length);
    chips.style.display=show?"flex":"none";
    chips.innerHTML=show?V62_CHIPS.map((c,i)=>`<button class="v62-chip" onclick="v62Chip(${i})">${c[0]} ${v60Esc(v60L(c[1][0],c[1][1]))}</button>`).join(""):"";
  }
}
/* línea de estado corta y nombre compacto en el selector (el encabezado entra en una línea) */
v60Wrap("renderMenu",()=>{
  try{
    const n=v60ConnList().length, st=v60Strategy(), mn=$("model-name"), sub=$("empty-sub");
    if(routeMode==="multi"||routeMode==="forest"){
      const k=taskCount();
      if(mn) mn.textContent=V60_STRATS[st].ic+" "+v60S(st,"short")+" · "+k+" "+v60L("modelos","models");
      if(sub) sub.textContent=routeMode==="forest"
        ?"🌳 "+v60L(`Consenso · ${k} modelos responden y AR.T.L.A.S. sintetiza la mejor respuesta`,`Consensus · ${k} models answer and AR.T.L.A.S. synthesises the best one`)
        :"⚡ "+v60L(`Simultáneo · ${k} modelos responden en paralelo`,`Parallel · ${k} models answer side by side`);
    }else if(routeMode==="smart"){
      if(mn) mn.textContent="🧭 "+v60S(st,"short");
      if(sub) sub.textContent="🧭 "+v60L(`Router ${v60S(st,"short")} · elige el mejor de tus ${n} modelos conectados`,`Router ${v60S(st,"short")} · picks the best of your ${n} connected models`);
    }
  }catch(e){}
  v62Layout();
});
v60Wrap("updateUserUI",()=>v62Layout());
v60Wrap("renderChats",()=>v62Layout());
v60Wrap("toggleLang",()=>{ v62Layout(); try{ renderMenu(); }catch(e){} });
try{ v62Setup(); }catch(e){ console.error("v62Setup",e); }
/* el saludo se actualiza solo si la pantalla queda abierta al cambiar el horario */
setInterval(()=>{ try{ v62Layout(); }catch(e){} },60000);
