
/* =====================================================================
   AR.T.L.A.S. · Módulo 96 · AR.T.L.A.S. OS — ASISTENTE DEL SISTEMA
   Agente que trabaja sobre la computadora con herramientas reales.
   Protocolo (igual de independiente del proveedor que el módulo 86):
     ```tool:os
     {"op":"fs.listar","ruta":"pc:C:\\Users\\MMFC\\Downloads"}
     ```
   o una lista JSON de operaciones para un plan de varias acciones.
   · Las lecturas se ejecutan solas; lo que modifica algo pide aprobación
     en una tarjeta (se puede destildar cada acción).
   · Atajos sin modelo para órdenes cortas («abrí la calculadora», «ping 8.8.8.8»).
   · Hasta 10 pasos por pedido.
   ===================================================================== */
const AOS_READ=new Set(["fs.listar","fs.leer","fs.buscar","fs.info","app.listar","proc.listar","sys.info","calc","python","ui.abrir"]);
const AOS_OPS=new Set([...AOS_READ,"fs.escribir","fs.crearCarpeta","fs.mover","fs.copiar","fs.borrar","fs.abrir","app.abrir","proc.cerrar","shell"]);
const AOS_UI_APPS={archivos:"archivos",files:"archivos",explorador:"archivos",terminal:"terminal",consola:"terminal",monitor:"monitor","administrador de tareas":"monitor",procesos:"monitor",modelos:"modelos","modelos ia":"modelos",configuración:"config",configuracion:"config",ajustes:"config",editor:"editor",notas:"editor",aplicaciones:"apps",apps:"apps"};

function aosSysPrompt(srcs,small){
  const pc=srcs.filter(s=>s.grupo==="pc"), fsa=srcs.filter(s=>s.grupo==="fsa");
  const map=[
    pc.length?aosL("- Disco de la PC (núcleo local) → prefijo pc:. Carpetas permitidas: ","- PC disk (local core) → prefix pc:. Allowed folders: ")+pc.map(s=>s.uri).join(" · "):aosL("- El núcleo local NO está conectado: no hay acceso al disco completo, a las aplicaciones ni a los procesos.","- The local core is NOT connected: no full disk, apps or processes."),
    fsa.length?aosL("- Carpetas conectadas en el navegador → ","- Browser-connected folders → ")+fsa.map(s=>s.uri).join(" · "):"",
    aosL("- Unidad AR.T.L.A.S. (privada del navegador) → opfs:/","- AR.T.L.A.S. drive (browser-private) → opfs:/")
  ].filter(Boolean).join("\n");
  const ops=aosL(
`fs.listar {ruta} · fs.leer {ruta} · fs.buscar {patron, ruta?} (acepta * y ?) · fs.info {ruta}
fs.escribir {ruta, texto, sobrescribir?} · fs.crearCarpeta {ruta} · fs.mover {de, a} · fs.copiar {de, a} · fs.borrar {ruta} (va a la papelera) · fs.abrir {ruta}
app.listar {filtro?} · app.abrir {nombre} · proc.listar {filtro?} · proc.cerrar {pid} · sys.info {}
shell {cmd} (solo diagnóstico: ping, ipconfig, tracert, nslookup, netstat, systeminfo, git status…)
calc {expr} · python {codigo} · ui.abrir {app: archivos|terminal|monitor|modelos|editor, ruta?}`,
`fs.listar {ruta} · fs.leer {ruta} · fs.buscar {patron, ruta?} (* and ?) · fs.info {ruta}
fs.escribir {ruta, texto, sobrescribir?} · fs.crearCarpeta {ruta} · fs.mover {de, a} · fs.copiar {de, a} · fs.borrar {ruta} (to trash) · fs.abrir {ruta}
app.listar {filtro?} · app.abrir {nombre} · proc.listar {filtro?} · proc.cerrar {pid} · sys.info {}
shell {cmd} (diagnostics only: ping, ipconfig, tracert, nslookup, netstat, systeminfo, git status…)
calc {expr} · python {codigo} · ui.abrir {app: archivos|terminal|monitor|modelos|editor, ruta?}`);
  return aosL(
`Sos AR.T.L.A.S. OS, el asistente del sistema operativo de IA de AR.T.L.A.S. (AI-TECH, por MMFC). Trabajás sobre la computadora del usuario con herramientas reales.
DÓNDE PODÉS TRABAJAR:
${map}
HERRAMIENTAS: para usar una, respondé SOLO con un bloque así (JSON válido; en Windows escapá las barras: "pc:C:\\\\Users"):
\`\`\`tool:os
{"op":"fs.listar","ruta":"<ruta con prefijo>"}
\`\`\`
Para un plan de varias acciones mandá una lista: [{"op":"fs.crearCarpeta","ruta":"…"},{"op":"fs.mover","de":"…","a":"…"}]
OPERACIONES:
${ops}
REGLAS:
- Primero mirá (listar, buscar, leer) y después actuá. No inventes rutas, nombres ni resultados.
- Lo que modifica algo (escribir, mover, copiar, borrar, abrir, cerrar procesos, shell) lo aprueba el usuario: AR.T.L.A.S. se lo pide. Proponé el plan completo en UN bloque.
- Para cálculos usá calc o python. ${small?"Sé breve.":""}
- Cuando termines, respondé al usuario en español rioplatense, claro y breve, sin bloque de herramienta.`,
`You are AR.T.L.A.S. OS, the system assistant of the AR.T.L.A.S. AI operating system (AI-TECH, by MMFC). You work on the user's computer with real tools.
WHERE YOU CAN WORK:
${map}
TOOLS: to use one, reply ONLY with a block like this (valid JSON; on Windows escape backslashes: "pc:C:\\\\Users"):
\`\`\`tool:os
{"op":"fs.listar","ruta":"<prefixed path>"}
\`\`\`
For a multi-step plan send a list: [{"op":"fs.crearCarpeta","ruta":"…"},{"op":"fs.mover","de":"…","a":"…"}]
OPERATIONS:
${ops}
RULES:
- Look first (list, search, read), then act. Never invent paths, names or results.
- Anything that changes something (write, move, copy, delete, open, kill processes, shell) is approved by the user: AR.T.L.A.S. asks. Propose the whole plan in ONE block.
- Use calc or python for maths. ${small?"Be brief.":""}
- When done, answer the user in English, clearly and briefly, with no tool block.`);
}

/* ---------- interpretación de las respuestas ---------- */
function aosParseOps(reply){
  const m=String(reply||"").match(/```\s*tool\s*[:\-_ ]\s*(os|calc|python)[^\n]*\n([\s\S]*?)```/i);
  if(!m) return null;
  const kind=m[1].toLowerCase(), body=m[2].trim();
  if(kind==="calc") return [{op:"calc",expr:body}];
  if(kind==="python") return [{op:"python",codigo:body}];
  let j=null;
  const tries=[body, body.replace(/\\(?![\\"\/bfnrtu])/g,"\\\\"), body.replace(/,\s*([\]}])/g,"$1")];
  for(const t of tries){ try{ j=JSON.parse(t); break; }catch(e){} }
  if(j==null){ const lines=body.split("\n").map(l=>l.trim()).filter(Boolean); const arr=[]; for(const l of lines){ try{ arr.push(JSON.parse(l.replace(/\\(?![\\"\/bfnrtu])/g,"\\\\"))); }catch(e){ return [{op:"_error",error:"JSON inválido"}]; } } j=arr; }
  const list=(Array.isArray(j)?j:(j&&Array.isArray(j.ops)?j.ops:[j])).filter(x=>x&&typeof x==="object");
  return list.slice(0,40).map(o=>{ const op=String(o.op||o.operacion||"").trim(); return {...o,op:op==="shell.ejecutar"?"shell":op==="fs.papelera"?"fs.borrar":op}; });
}
function aosStripOps(t){ return String(t||"").replace(/```\s*tool\s*[:\-_ ]\s*(os|calc|python)[^\n]*\n[\s\S]*?```/gi,"").trim(); }
function aosNormUri(p,srcs){
  p=String(p||"").trim().replace(/^["']|["']$/g,"");
  if(!p) return p;
  if(/^(pc|fsa|opfs):/.test(p)) return p;
  if(/^(~|[A-Za-z]:[\\\/]|\/)/.test(p)&&aosNucOk()) return "pc:"+p;
  const fsa=(srcs||[]).find(s=>s.grupo==="fsa"&&p.toLowerCase().startsWith(s.nombre.toLowerCase()+"/"));
  if(fsa) return "fsa:"+p;
  return "opfs:/"+p.replace(/^\/+/,"");
}
function aosOpDesc(o){
  const b=u=>aosEsc(aosScheme(u)==="pc"?aosPathOf(u):u);
  switch(o.op){
    case "fs.escribir": return aosL("Escribir ","Write ")+"<b>"+aosEsc(aosBase(o.ruta))+"</b> "+aosL("en ","in ")+b(aosParentUri(o.ruta)||"")+(o.sobrescribir?" · "+aosL("reemplaza (con copia)","replaces (with backup)"):"");
    case "fs.crearCarpeta": return aosL("Crear la carpeta ","Create folder ")+"<b>"+b(o.ruta)+"</b>";
    case "fs.mover": return aosL("Mover ","Move ")+"<b>"+aosEsc(aosBase(o.de))+"</b> → "+b(o.a);
    case "fs.copiar": return aosL("Copiar ","Copy ")+"<b>"+aosEsc(aosBase(o.de))+"</b> → "+b(o.a);
    case "fs.borrar": return aosL("Mover a la papelera ","Move to trash ")+"<b>"+b(o.ruta)+"</b>";
    case "fs.abrir": return aosL("Abrir ","Open ")+"<b>"+b(o.ruta)+"</b>";
    case "app.abrir": return aosL("Abrir la aplicación ","Open the app ")+"<b>"+aosEsc(o.nombre||o.id)+"</b>";
    case "proc.cerrar": return aosL("Cerrar el proceso ","Close process ")+"<b>"+aosEsc(o.nombre||"")+" PID "+aosEsc(o.pid)+"</b>";
    case "shell": return aosL("Ejecutar ","Run ")+"<code>"+aosEsc(o.cmd)+"</code>";
  }
  return aosEsc(o.op);
}

/* ---------- ejecución de una operación ---------- */
async function aosExec(o,ctx){
  const t0=performance.now(); const lim=ctx.small?3500:14000;
  const done=(text,short,extra)=>({ok:true,text:String(text).slice(0,lim),short,ms:performance.now()-t0,...(extra||{})});
  try{
    if(!AOS_OPS.has(o.op)) throw new Error(aosL("Operación desconocida: ","Unknown operation: ")+o.op);
    switch(o.op){
      case "fs.listar":{ const r=await AOSFS.list(o.ruta); const L=r.entries.slice(0,250).map(e=>e.tipo==="dir"?"[carpeta] "+e.nombre+"/":e.nombre+"  ("+aosFmtBytes(e.tam)+(e.mod?", "+aosFmtDate(e.mod):"")+")");
        return done(aosL("Contenido de ","Contents of ")+r.uri+" ("+r.entries.length+"):\n"+(L.join("\n")||aosL("(vacía)","(empty)"))+(r.entries.length>250?"\n…":""), aosL("listó ","listed ")+(aosBase(r.uri)||r.uri)+" · "+r.entries.length); }
      case "fs.leer":{
        if(ctx.priv&&!aosIsLocal(ctx.pk)) return done(aosL("[Contenido retenido por privacidad: el usuario pidió que sus archivos solo los procese un modelo local. Pedile que cargue uno en Modelos IA.]","[Content withheld for privacy: the user asked that files be processed only by a local model. Ask them to load one in AI Models.]"),"🔒 "+aosL("retuvo ","withheld ")+aosBase(o.ruta));
        const r=await AOSFS.readForAI(o.ruta,lim); return done(aosL("Archivo ","File ")+o.ruta+" ("+aosFmtBytes(r.tam)+(r.truncado?", "+aosL("recortado","truncated"):"")+"):\n"+r.texto, aosL("leyó ","read ")+aosBase(o.ruta)); }
      case "fs.buscar":{ const r=await AOSFS.search(o.patron||o.nombre||"",o.ruta||undefined); return done(r.length?r.slice(0,120).map(x=>(x.tipo==="dir"?"[carpeta] ":"")+x.uri).join("\n"):aosL("Sin resultados","No results"), aosL("buscó «","searched «")+(o.patron||"")+"» · "+r.length); }
      case "fs.info":{ if(aosScheme(o.ruta)==="pc"){ const r=await aosNuc("fs.info",{ruta:aosPathOf(o.ruta)}); return done(JSON.stringify(r),aosL("info de ","info on ")+aosBase(o.ruta)); } const b=await AOSFS.blob(o.ruta); return done(JSON.stringify({ruta:o.ruta,tam:b.size}),aosL("info de ","info on ")+aosBase(o.ruta)); }
      case "fs.escribir":{ await AOSFS.write(o.ruta,String(o.texto??o.contenido??""),{sobrescribir:!!o.sobrescribir}); return done("OK: "+o.ruta,aosL("escribió ","wrote ")+aosBase(o.ruta),{changed:o.ruta}); }
      case "fs.crearCarpeta":{ await AOSFS.mkdir(o.ruta); return done("OK: "+o.ruta,aosL("creó ","created ")+aosBase(o.ruta),{changed:o.ruta}); }
      case "fs.mover":{ const r=await AOSFS.move(o.de,o.a); return done("OK: "+o.de+" → "+(r&&r.a?(aosScheme(o.a)==="pc"?"pc:"+r.a:r.a):o.a),aosL("movió ","moved ")+aosBase(o.de),{changed:o.a}); }
      case "fs.copiar":{ await AOSFS.copy(o.de,o.a); return done("OK: "+o.de+" → "+o.a,aosL("copió ","copied ")+aosBase(o.de),{changed:o.a}); }
      case "fs.borrar":{ await AOSFS.remove(o.ruta); return done("OK, en la papelera: "+o.ruta,aosL("a la papelera: ","to trash: ")+aosBase(o.ruta),{changed:o.ruta}); }
      case "fs.abrir":{ if(aosScheme(o.ruta)==="pc"&&!(AOS_TXT.test(aosExt(o.ruta))||AOS_IMG.test(aosExt(o.ruta)))) await AOSFS.openSystem(o.ruta); else aosOpenFile(o.ruta); return done("OK, abierto: "+o.ruta,aosL("abrió ","opened ")+aosBase(o.ruta)); }
      case "app.listar":{ const L=await aosNuc("app.listar",{}); const f=String(o.filtro||"").toLowerCase(); const r=L.filter(a=>!f||a.nombre.toLowerCase().includes(f)); return done(r.slice(0,160).map(a=>a.nombre).join("\n")||aosL("Sin coincidencias","No matches"),aosL("listó apps · ","listed apps · ")+r.length); }
      case "app.abrir":{ const r=await aosNuc("app.abrir",{nombre:o.nombre||o.id}); return done("OK, abierta: "+r.abierta,aosL("abrió ","opened ")+r.abierta); }
      case "proc.listar":{ const L=await aosNuc("proc.listar"); const g={}; L.forEach(p=>{ const k=p.nombre; g[k]=g[k]||{n:k,c:0,m:0,pids:[]}; g[k].c++; g[k].m+=p.memoria||0; if(g[k].pids.length<4) g[k].pids.push(p.pid); });
        const f=String(o.filtro||"").toLowerCase(); const arr=Object.values(g).filter(x=>!f||x.n.toLowerCase().includes(f)).sort((a,b)=>b.m-a.m).slice(0,40);
        return done(arr.map(x=>`${x.n} · ${x.c} proc. · ${aosFmtBytes(x.m)} · PID ${x.pids.join(",")}`).join("\n"),aosL("revisó procesos","checked processes")); }
      case "proc.cerrar":{ const r=await aosNuc("proc.cerrar",{pid:+o.pid,forzar:!!o.forzar}); return done("OK, cerrado: "+r.cerrado,aosL("cerró ","closed ")+r.cerrado); }
      case "sys.info":{ const s=await aosNuc("sys.info"); return done(aosSysText(s),aosL("leyó el estado del sistema","read system status")); }
      case "shell":{ const r=await aosNuc("shell.ejecutar",{cmd:o.cmd,confirmado:true}); return done((r.salida||"")+(r.error?"\n"+r.error:"")+(r.timeout?"\n(tiempo agotado)":""),"$ "+String(o.cmd).slice(0,40)); }
      case "calc": case "python":{ const r=await v67ExecTool({tool:o.op,input:o.op==="calc"?String(o.expr||o.expresion||""):String(o.codigo||o.code||"")}); if(!r.ok) throw new Error(r.text); return done(r.text,o.op==="calc"?"🧮 "+(r.short||""):"🐍 "+(r.short||""),{figs:r.figs}); }
      case "ui.abrir":{ const id=AOS_UI_APPS[String(o.app||"").toLowerCase()]||o.app; aosLaunch(id,o.ruta?{uri:o.ruta,nuevo:id==="archivos"}:{}); return done("OK, ventana abierta: "+id,aosL("abrió la ventana ","opened window ")+id); }
    }
  }catch(e){ return {ok:false,text:"ERROR: "+(e.message||e),short:"⚠ "+(e.message||e),ms:performance.now()-t0}; }
}
function aosSysText(s){
  const g=n=>aosFmtBytes(n);
  return [`${aosL("Equipo","Computer")}: ${s.equipo} (${s.usuario}) · ${s.so} · ${s.arquitectura}`,
    `CPU: ${s.cpu} · ${s.nucleos} ${aosL("núcleos","cores")} · ${aosL("uso","usage")} ${s.cpuUso}%`,
    `${aosL("Memoria","Memory")}: ${g(s.memoria.total-s.memoria.libre)} ${aosL("de","of")} ${g(s.memoria.total)} (${Math.round(100*(1-s.memoria.libre/s.memoria.total))}%)`,
    ...(s.discos||[]).map(d=>`${aosL("Disco","Disk")} ${d.unidad}: ${g(d.libre)} ${aosL("libres de","free of")} ${g(d.total)}`),
    ...(s.red||[]).map(n=>`${aosL("Red","Network")} ${n.interfaz}: ${n.ip}`),
    `${aosL("Encendido hace","Up for")} ${Math.floor(s.encendido/3600)} h ${Math.floor(s.encendido%3600/60)} min`].join("\n");
}

/* ---------- atajos sin modelo (órdenes cortas) ---------- */
async function aosQuick(q){
  const t=q.trim().replace(/[.!¡¿?]+$/,""); if(t.split(/\s+/).length>6||/\s(y|and|luego|después)\s/i.test(t)) return null;
  let m=t.match(/^(?:abr[ií](?:me)?|abrir|open|inici[aá]|ejecut[aá]|lanz[aá])\s+(?:la\s+app\s+|la\s+aplicaci[oó]n\s+|el\s+programa\s+|el\s+|la\s+|los\s+|las\s+|mis\s+)?(.+)$/i);
  if(m){ const n=m[1].trim().toLowerCase();
    if(AOS_UI_APPS[n]) return [{op:"ui.abrir",app:AOS_UI_APPS[n]}];
    const roots={descargas:/download|descarga/i,documentos:/document/i,escritorio:/desktop|escritorio/i};
    for(const [k,rx] of Object.entries(roots)) if(n===k||n==="carpeta "+k){ const s=(await AOSFS.sources()).find(x=>x.grupo==="pc"&&rx.test(x.nombre)); if(s) return [{op:"ui.abrir",app:"archivos",ruta:s.uri}]; }
    if(aosNucOk()&&!/[\\\/.]/.test(n)){ try{ const L=await aosNuc("app.listar",{}); const a=L.find(x=>x.nombre.toLowerCase()===n)||L.find(x=>x.nombre.toLowerCase().startsWith(n))||L.find(x=>x.nombre.toLowerCase().includes(n)); if(a) return [{op:"app.abrir",nombre:a.nombre}]; }catch(e){} }
    return null; }
  if(/^ping\s+[\w.\-:]+$/i.test(t)&&aosNucOk()) return [{op:"shell",cmd:t}];
  if(/^(estado del (sistema|equipo)|system status|cu[aá]nta (memoria|ram)|cu[aá]nto (espacio|disco)( libre)?( me queda)?)$/i.test(t)&&aosNucOk()) return [{op:"sys.info",_reply:true}];
  return null;
}

/* ---------- app Asistente ---------- */
aosRegister("asistente",{title:()=>"AR.T.L.A.S.",sub:()=>aosL("Asistente del sistema","System assistant"),icon:"chat",desk:true,order:10,w:560,h:620,kw:"asistente chat ia artlas",
  render(win){
    win.state={hist:[],ctx:[],busy:false};
    win.body.innerHTML=`<div class="aosa-h" style="display:flex;align-items:center;gap:6px;padding:7px 12px;border-bottom:1px solid #eef2f7;flex-wrap:wrap"></div>
      <div class="aosa-m" style="flex:1;overflow:auto;padding:14px 14px 6px;display:flex;flex-direction:column;gap:10px"></div>
      <div class="aosa-ctx" style="display:none;padding:4px 12px;gap:6px;flex-wrap:wrap"></div>
      <form class="aosa-f" style="display:flex;gap:8px;padding:10px 12px;border-top:1px solid #eef2f7;align-items:flex-end">
        <textarea class="aos-in aosa-in" rows="1" placeholder="${aosEsc(aosL("Pedile algo sobre tu computadora…","Ask something about your computer…"))}" style="flex:1;resize:none;max-height:140px;line-height:1.45"></textarea>
        <button class="aos-btn pri" type="submit" aria-label="${aosEsc(aosL("Enviar","Send"))}">${aosIcon("send",15)}</button></form>`;
    const f=win.body.querySelector(".aosa-f"), ta=win.body.querySelector(".aosa-in");
    f.onsubmit=e=>{ e.preventDefault(); const q=ta.value.trim(); if(!q) return; ta.value=""; ta.style.height="auto"; aosAgentAsk(win,q); };
    ta.addEventListener("keydown",e=>{ if(e.key==="Enter"&&!e.shiftKey){ e.preventDefault(); f.requestSubmit(); } });
    ta.addEventListener("input",()=>{ ta.style.height="auto"; ta.style.height=Math.min(140,ta.scrollHeight)+"px"; });
    aosaHead(win); aosaEmpty(win);
  }
});
function aosaHead(win){
  const h=win.body.querySelector(".aosa-h"); if(!h) return; const mi=aosMotorInfo();
  h.innerHTML=`<span class="aos-pill ${mi.local?"ok":""}" style="cursor:pointer" onclick="aosLaunch('modelos')" title="${aosEsc(aosL("Cambiar el motor","Change engine"))}">${aosIcon("chip",12)} ${aosEsc(mi.label)}</span>
    ${aosPriv()?`<span class="aos-pill ok">🔒 ${aosL("archivos solo en local","files local only")}</span>`:""}
    <span class="aos-pill ${aosNucOk()?"ok":"off"}" style="cursor:pointer" onclick="aosLaunch('config')">${aosIcon("plug",12)} ${aosNucOk()?aosL("PC conectada","PC connected"):aosL("sin núcleo","no core")}</span>
    <span style="flex:1"></span><button class="aos-btn sm" onclick="aosaReset(aosWin('${win.id}'))">${aosL("Nueva","New")}</button>`;
}
function aosaReset(win){ if(!win) return; win.state.hist=[]; win.state.ctx=[]; aosaCtx(win); win.body.querySelector(".aosa-m").innerHTML=""; aosaEmpty(win); aosaHead(win); }
function aosaEmpty(win){
  const M=win.body.querySelector(".aosa-m");
  const s=aosNucOk()?[aosL("¿Cuánto espacio libre me queda?","How much free space do I have?"),aosL("Ordená mis Descargas en carpetas por tipo","Sort my Downloads into folders by type"),aosL("Buscá los PDF de esta semana y resumime el más reciente","Find this week's PDFs and summarize the newest"),aosL("¿Qué programas están usando más memoria?","Which programs use the most memory?")]
    :[aosL("Conectá una carpeta y ordenala por tipo de archivo","Connect a folder and sort it by file type"),aosL("Creá un archivo con un plan de estudio de redes","Create a networking study plan file"),aosL("Calculá la pérdida en espacio libre a 12 km y 5,8 GHz","Compute free-space loss at 12 km and 5.8 GHz")];
  M.innerHTML=`<div style="margin:auto 0;text-align:center;padding:10px">
    <div style="font-size:18px;font-weight:700;color:#0d2b5e;margin-bottom:4px">${aosEsc((typeof v60Saludo==="function"?v60Saludo():aosL("Hola","Hello"))+aosL(", ¿qué hacemos en tu equipo?",", what shall we do on your computer?"))}</div>
    <div style="font-size:12.5px;color:#6b7a90;margin-bottom:14px">${aosL("Leo carpetas, ordeno archivos, abro aplicaciones y reviso el sistema. Antes de cambiar algo, te pido aprobación.","I read folders, organize files, open apps and check the system. I ask before changing anything.")}</div>
    <div style="display:flex;flex-direction:column;gap:6px;align-items:stretch;max-width:420px;margin:0 auto">${s.map(x=>`<button class="aos-btn" style="justify-content:flex-start;text-align:left" data-s="${aosEsc(x)}">${aosEsc(x)}</button>`).join("")}</div></div>`;
  M.querySelectorAll("[data-s]").forEach(b=>b.onclick=()=>aosAgentAsk(win,b.dataset.s));
}
function aosaCtx(win){
  const c=win.body.querySelector(".aosa-ctx"); if(!c) return; const L=win.state.ctx;
  c.style.display=L.length?"flex":"none";
  c.innerHTML=L.map((x,i)=>`<span class="aos-pill">${aosIcon("file",12)} ${aosEsc(x.nombre)} <a href="#" style="color:#8f8f8f;text-decoration:none" data-i="${i}">✕</a></span>`).join("");
  c.querySelectorAll("[data-i]").forEach(a=>a.onclick=e=>{ e.preventDefault(); L.splice(+a.dataset.i,1); aosaCtx(win); });
}
function aosAgentAttach(win,uri){ if(!win) return; if(!win.state.ctx.some(x=>x.uri===uri)) win.state.ctx.push({uri,nombre:aosBase(uri)}); aosaCtx(win); const ta=win.body.querySelector(".aosa-in"); if(ta){ ta.placeholder=aosL("¿Qué querés saber de ","What do you want to know about ")+aosBase(uri)+"?"; ta.focus(); } }
function aosAgentAttachText(win,nombre,texto){ if(!win) return; win.state.ctx.push({nombre,texto:String(texto||"")}); aosaCtx(win); const ta=win.body.querySelector(".aosa-in"); if(ta) ta.focus(); }
function aosaBubble(win,role,html){
  const M=win.body.querySelector(".aosa-m"); if(M.querySelector(".aos-btn[data-s]")) M.innerHTML="";
  const d=document.createElement("div");
  d.style.cssText=role==="user"?"align-self:flex-end;max-width:85%;background:#f4f4f4;border-radius:14px 14px 4px 14px;padding:8px 12px;font-size:13.5px;white-space:pre-wrap":"align-self:stretch;font-size:13.5px;line-height:1.55";
  d.innerHTML=html; M.appendChild(d); M.scrollTop=M.scrollHeight; return d;
}
function aosaSteps(box,steps){
  if(!steps.length){ box.innerHTML=""; return; }
  box.innerHTML=`<div style="border:1px solid #e5e5e5;border-radius:10px;padding:6px 10px;background:#fafcff;font-size:12px;color:#44546a;margin-bottom:6px">
    <div style="font-weight:600;color:#0d2b5e;margin-bottom:2px">${aosL("Pasos del asistente","Assistant steps")}</div>${steps.map(s=>`<div style="display:flex;gap:6px"><span style="color:${s.ok?"#10a37f":s.ok===false?"#ef4146":"#8f8f8f"}">${s.ok?"✓":s.ok===false?"✗":"…"}</span><span style="flex:1">${aosEsc(s.short)}</span><span style="color:#8f8f8f">${s.ms!=null?(s.ms/1000).toFixed(1)+" s":""}</span></div>`).join("")}</div>`;
}
function aosaConfirm(win,ops){
  return new Promise(res=>{
    const d=aosaBubble(win,"a",`<div style="border:1px solid #e8a13c;background:#fdf6ea;border-radius:12px;padding:10px 12px;color:#4a2f04">
      <div style="font-weight:700;margin-bottom:6px">${aosL("Requiere tu aprobación","Needs your approval")} · ${ops.length} ${ops.length===1?aosL("acción","action"):aosL("acciones","actions")}</div>
      <div style="max-height:220px;overflow:auto;display:flex;flex-direction:column;gap:3px;margin-bottom:8px">${ops.map((o,i)=>`<label style="display:flex;gap:7px;align-items:flex-start;font-size:12.5px;word-break:break-word"><input type="checkbox" checked data-i="${i}" style="margin-top:3px">${aosOpDesc(o)}</label>`).join("")}</div>
      <div style="display:flex;gap:6px"><button class="aos-btn sm pri" data-k="ok">${aosL("Aprobar","Approve")}</button><button class="aos-btn sm" data-k="no">${aosL("Cancelar","Cancel")}</button>
      <span style="font-size:11px;color:#7a5a20;margin-left:auto;align-self:center">${aosL("Borrar = papelera restaurable","Delete = restorable trash")}</span></div></div>`);
    const fin=ok=>{ const sel=[...d.querySelectorAll("input[data-i]")].filter(x=>x.checked).map(x=>+x.dataset.i); d.querySelectorAll("button,input").forEach(x=>x.disabled=true); d.querySelector('[data-k="ok"]').textContent=ok?aosL("Aprobado","Approved"):aosL("Cancelado","Cancelled"); res(ok?sel:null); };
    d.querySelector('[data-k="ok"]').onclick=()=>fin(true); d.querySelector('[data-k="no"]').onclick=()=>fin(false);
  });
}
async function aosModelCall(win,pk,sys,small){
  const hist=win.state.hist.slice(small?-8:-24);
  try{ return {pk,txt:await callProvider(pk,cfg[pk]||{},hist,sys,[],small?700:2500)}; }
  catch(e){
    if(aosMotor()==="solo-local") throw e;
    const alt=[aosLocalPk(),"basic"].find(p=>p&&p!==pk&&connected(p));
    if(!alt) throw e;
    aosToast(aosPkLabel(pk)+aosL(" no respondió; sigo con "," failed; continuing with ")+aosPkLabel(alt),"warn");
    return {pk:alt,txt:await callProvider(alt,cfg[alt]||{},hist,sys,[],aosIsLocal(alt)?700:2500)};
  }
}
async function aosAgentAsk(win,q){
  if(!win||win.state.busy) return; win.state.busy=true;
  const B=win.body; const btn=B.querySelector('.aosa-f button'); if(btn) btn.disabled=true;
  aosaBubble(win,"user",aosEsc(q)+(win.state.ctx.length?"<div style='font-size:11.5px;color:#6b7a90;margin-top:3px'>📎 "+win.state.ctx.map(x=>aosEsc(x.nombre)).join(", ")+"</div>":""));
  const out=aosaBubble(win,"a",`<div class="aosa-steps"></div><div class="aosa-txt" style="color:#8f8f8f">${aosL("Pensando…","Thinking…")}</div>`);
  const stepsEl=out.querySelector(".aosa-steps"), txtEl=out.querySelector(".aosa-txt"); const steps=[];
  const scroll=()=>{ const M=B.querySelector(".aosa-m"); M.scrollTop=M.scrollHeight; };
  try{
    const srcs=await AOSFS.sources().catch(()=>[]);
    // atajos sin modelo
    const quick=win.state.ctx.length?null:await aosQuick(q);
    if(quick){
      const needOk=quick.filter(o=>!AOS_READ.has(o.op));
      let run=quick;
      if(needOk.length){ txtEl.textContent=""; const sel=await aosaConfirm(win,needOk); B.querySelector(".aosa-m").appendChild(out); if(!sel){ txtEl.innerHTML=aosL("Listo, no hice nada.","OK, I did nothing."); return; } run=quick.filter(o=>AOS_READ.has(o.op)||sel.includes(needOk.indexOf(o))); }
      let reply="";
      for(const o of run){ const st={short:o.op}; steps.push(st); aosaSteps(stepsEl,steps); const r=await aosExec(o,{small:false}); Object.assign(st,r); aosaSteps(stepsEl,steps); if(o._reply) reply=r.ok?"```\n"+r.text+"\n```":r.text; else reply=r.ok?"✓ "+r.short:r.text; }
      txtEl.style.color=""; txtEl.innerHTML=md(reply); win.state.hist.push({role:"user",content:q},{role:"assistant",content:reply}); return;
    }
    let pk=aosMotorPick(q); let small=aosIsLocal(pk);
    const sys=aosSysPrompt(srcs,small);
    let user=q;
    for(const c of win.state.ctx){
      try{
        if(c.texto!=null){ user+=`\n\n[${c.nombre}]\n`+c.texto.slice(0,small?4000:30000); continue; }
        if(aosPriv()&&!aosIsLocal(pk)){ user+=`\n\n[${aosL("Archivo adjunto","Attached file")}: ${c.uri} — ${aosL("contenido retenido por privacidad","content withheld for privacy")}]`; continue; }
        const r=await AOSFS.readForAI(c.uri,small?4000:30000); user+=`\n\n[${aosL("Archivo","File")}: ${c.uri}]\n${r.texto}`;
      }catch(e){ user+=`\n\n[${c.nombre}: ${e.message}]`; }
    }
    win.state.ctx=[]; aosaCtx(win);
    win.state.hist.push({role:"user",content:user});
    let final="", figs=[];
    for(let step=0;step<10;step++){
      txtEl.textContent=aosL("Pensando con ","Thinking with ")+aosPkLabel(pk)+"…"; scroll();
      const r=await aosModelCall(win,pk,sys,small); if(r.pk!==pk){ pk=r.pk; small=aosIsLocal(pk); }
      const reply=r.txt||""; const ops=aosParseOps(reply);
      win.state.hist.push({role:"assistant",content:reply});
      if(!ops||!ops.length){ final=aosStripOps(reply); break; }
      if(ops[0].op==="_error"){ win.state.hist.push({role:"user",content:aosL("RESULTADO: el bloque tool:os no es JSON válido. Corregilo.","RESULT: the tool:os block isn't valid JSON. Fix it.")}); continue; }
      ops.forEach(o=>{ ["ruta","de","a"].forEach(k=>{ if(o[k]) o[k]=aosNormUri(o[k],srcs); }); });
      const pre=aosStripOps(reply); if(pre) { const p=document.createElement("div"); p.innerHTML=md(pre); p.style.cssText="font-size:13px;color:#44546a;margin-bottom:4px"; stepsEl.before(p); }
      const writes=ops.filter(o=>!AOS_READ.has(o.op)); let allowed=null;
      if(writes.length){ txtEl.textContent=""; const sel=await aosaConfirm(win,writes); B.querySelector(".aosa-m").appendChild(out); allowed=sel?new Set(sel.map(i=>writes[i])):new Set(); txtEl.textContent=aosL("Trabajando…","Working…"); }
      const results=[];
      for(const o of ops){
        if(!AOS_READ.has(o.op)&&!allowed.has(o)){ results.push(`${o.op}: ${aosL("CANCELADO por el usuario","CANCELLED by the user")}`); steps.push({ok:false,short:aosL("cancelado: ","cancelled: ")+o.op}); continue; }
        const st={short:o.op+" …"}; steps.push(st); aosaSteps(stepsEl,steps); scroll();
        const res=await aosExec(o,{small,priv:aosPriv(),pk}); Object.assign(st,res); if(res.figs) figs=figs.concat(res.figs); aosaSteps(stepsEl,steps);
        results.push(`${o.op} ${o.ruta||o.de||o.nombre||o.cmd||""}\n${res.text}`);
      }
      aosaSteps(stepsEl,steps);
      if(writes.length&&allowed&&!allowed.size&&!ops.some(o=>AOS_READ.has(o.op))){ final=aosL("Cancelaste el plan: no modifiqué nada.","You cancelled the plan: nothing was changed."); win.state.hist.push({role:"user",content:"RESULTADO: el usuario canceló todas las acciones."}); break; }
      win.state.hist.push({role:"user",content:aosL("RESULTADOS DE LAS HERRAMIENTAS:\n","TOOL RESULTS:\n")+results.join("\n---\n").slice(0,small?5000:24000)+aosL("\n\nContinuá. Si ya está, respondé al usuario sin bloque de herramienta.","\n\nContinue. If done, answer the user with no tool block.")});
      if(step===9) final=aosL("Llegué al límite de pasos. Esto es lo que hice hasta ahora.","I reached the step limit. Here's what I did so far.");
    }
    txtEl.style.color=""; txtEl.innerHTML=md(final||aosL("Listo.","Done."));
    figs.slice(0,3).forEach(b=>{ const i=document.createElement("img"); i.src="data:image/png;base64,"+b; i.style.cssText="max-width:100%;border-radius:8px;margin-top:6px"; out.appendChild(i); });
    AOS.wins.filter(w=>w.app==="archivos"&&w.state.uri).forEach(w=>{ if(steps.some(s=>s.changed)) aosfGo(w,w.state.uri); });
  }catch(e){ txtEl.style.color="#c0272d"; txtEl.textContent="⚠ "+(e.message||e); }
  finally{ win.state.busy=false; if(btn) btn.disabled=false; aosaHead(win); scroll(); }
}
