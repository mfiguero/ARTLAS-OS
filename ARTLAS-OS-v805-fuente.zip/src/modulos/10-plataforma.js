

/* ==========================================================================
   ==========================================================================
   ===  AR.T.L.A.S. v60 — CAPA DE PLATAFORMA (AI Orchestration Platform)  ===
   ==========================================================================
   Esta sección se agrega AL FINAL de app.js y NO reescribe la lógica v57:
   solo reasigna (envuelve) funciones existentes y agrega módulos nuevos.
     · Command Center (inicio) · navegación por áreas
     · AR.T.L.A.S. Router: estrategias, intención, fallback, probador, log
     · Control Center: estado de proveedores y uso real medido
     · Seguridad de API keys: localStorage / solo sesión / bóveda AES-GCM
     · Skills para agentes (formato SKILL.md compatible con Agent Skills)
     · Workflow visual con estado por nodo · pipeline de Analytics
   Va dentro del mismo archivo para que la "Versión escritorio" cifrada
   (que empaqueta app.html + app.js) la incluya automáticamente.
   ========================================================================== */

const V60 = { ver:"v60", vaultKey:null, vaultSalt:null, vaultQ:Promise.resolve(), usage:null, rlog:null,
              anMined:false, anReported:false, skEdit:null, _ut:null, vmResolve:null, vmMode:null };

function v60L(es,en){ return (typeof atlasLang!=="undefined" && atlasLang==="en") ? en : es; }
function v60Esc(t){ return String(t==null?"":t).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;"); }
function v60LS(k,d){ try{ const v=localStorage.getItem(k); return v==null?d:v; }catch(e){ return d; } }
function v60LSset(k,v){ try{ localStorage.setItem(k,v); return true; }catch(e){ return false; } }
function v60J(k,d){ try{ const v=JSON.parse(localStorage.getItem(k)||"null"); return v==null?d:v; }catch(e){ return d; } }
function v60SS(k,d){ try{ const v=sessionStorage.getItem(k); return v==null?d:v; }catch(e){ return d; } }
function v60SSset(k,v){ try{ if(v==null) sessionStorage.removeItem(k); else sessionStorage.setItem(k,v); }catch(e){} }
function v60Num(n){ n=+n||0; return n>=1e6?(n/1e6).toFixed(1)+"M":n>=1e4?(n/1e3).toFixed(1)+"k":Math.round(n).toLocaleString(v60L("es-AR","en-US")); }
function v60Ago(ts){
  const s=Math.max(0,(Date.now()-(+ts||0))/1000);
  if(s<60) return v60L("recién","just now");
  if(s<3600) return v60L("hace "+Math.floor(s/60)+" min", Math.floor(s/60)+" min ago");
  if(s<86400) return v60L("hace "+Math.floor(s/3600)+" h", Math.floor(s/3600)+" h ago");
  const d=Math.floor(s/86400); return v60L("hace "+d+" d", d+" d ago");
}
function v60Wrap(name, after){
  const o=window[name]; if(typeof o!=="function") return;
  window[name]=function(){
    const args=[...arguments], r=o.apply(this,arguments);   // after(...args): recibe los mismos argumentos
    if(r && typeof r.then==="function") return r.then(v=>{ try{ after.apply(null,args); }catch(e){ console.error("v60 after "+name,e); } return v; });
    try{ after.apply(null,args); }catch(e){ console.error("v60 after "+name,e); }
    return r;
  };
}
function v60Demo(){ return v60SS("atlas_demo","")==="1" && !(typeof user!=="undefined" && user); }
function v60ConnList(){ try{ return connectedProviders(); }catch(e){ return ["basic"]; } }

/* ---------------- i18n: textos estáticos nuevos de v60 ---------------- */
function v60Dict(o){
  try{ Object.keys(o).forEach(k=>{ const kk=i18nNorm(k), vv=o[k]; I18N_ES2EN[kk]=vv; if(!(i18nNorm(vv) in I18N_EN2ES)) I18N_EN2ES[i18nNorm(vv)]=kk; }); }catch(e){}
}
v60Dict({
  "🔌 Proveedores de modelos":"🔌 Model Providers",
  "Proveedores de modelos":"Model Providers",
  "Conectá cada proveedor con tu propia API key. Sin clave, el modelo responde en modo simulado.":"Connect each provider with your own API key. Without a key, the model replies in simulated mode.",
  "👤 Cuenta AR.T.L.A.S.":"👤 AR.T.L.A.S. Account",
  "Mis agentes":"My agents",
  "Describilo. AR.T.L.A.S. lo construye.":"Describe it. AR.T.L.A.S. builds it.",
  "✨ Construir":"✨ Build",
  "Tus datos pueden permanecer en tu equipo":"Your data can stay on your own machine",
  "Para universidades, empresas y organismos con información sensible: AR.T.L.A.S. puede razonar sobre tus documentos con modelos que corren en tu propia computadora, sin enviar datos a la nube.":"For universities, companies and public bodies handling sensitive information: AR.T.L.A.S. can reason over your documents with models that run on your own computer, without sending data to the cloud.",
  "RAG local por CPU (Flask + llama-cpp). Endpoint OpenAI-compatible que entra al Router como modelo":"Local CPU RAG (Flask + llama-cpp). OpenAI-compatible endpoint that joins the Router as the model",
  "🖥️ AR.T.L.A.S. Local (navegador)":"🖥️ AR.T.L.A.S. Local (browser)",
  "Modelo chico que corre dentro del navegador con WebGPU. Configuralo en Proveedores de modelos.":"Small model that runs inside the browser with WebGPU. Configure it in Model Providers.",
  "Modelos open source self-hosted (Llama, Qwen, Mistral) en tu PC o servidor.":"Self-hosted open-source models (Llama, Qwen, Mistral) on your PC or server.",
  "Skills del agente (procedimientos reutilizables que el agente aplica cuando corresponde)":"Agent skills (reusable procedures the agent applies when relevant)",
  "Arquitectura":"Architecture"
});

/* ---------------- Navegación: nuevas vistas y nombres ---------------- */
(function(){
  const setT=(id,t,i)=>{ const n=NAV.find(x=>x.id===id); if(n){ if(t)n.t=t; if(i)n.i=i; } };
  if(!NAV.find(x=>x.id==="home")) NAV.unshift({id:"home",t:"Command Center",i:"🏠",view:"view-home"});
  if(!NAV.find(x=>x.id==="router")) NAV.push({id:"router",t:"AR.T.L.A.S. Router",i:"🧭",view:"view-router"});
  if(!NAV.find(x=>x.id==="control")) NAV.push({id:"control",t:"Control Center",i:"🎛️",view:"view-control"});
  setT("art","AR.T.L.A.S. Build","✨");
  setT("agents","Agent Studio","🤖");
  setT("analytics","AR.T.L.A.S. Analytics","📈");
  setT("desk","Local Intelligence","🧠");
})();

const V60_GROUPS=[
  {es:"Inteligencia",   en:"Intelligence", items:[["nav","chat"],["nav","agents"],["nav","router"],["mod","know"],["mod","res"]]},
  {es:"Creación",       en:"Creation",     items:[["nav","art"],["mod","web"],["mod","image"],["mod","code"],["mod","pres"]]},
  {es:"Datos",          en:"Data",         items:[["nav","analytics"]]},
  {es:"Automatización", en:"Automation",   items:[["nav","builder"]]},
  {es:"Plataforma",     en:"Platform",     items:[["nav","control"],["fn","providers"],["nav","arch"],["mod","mcp"],["mod","cowork"],["nav","manual"]]}
];

renderNav = function(){
  const el=$("nav-v60"); if(!el) return;
  const nb=n=>n?`<span class="nb">${n}</span>`:"";
  const item=(kind,id)=>{
    if(kind==="nav"){
      const n=NAV.find(x=>x.id===id); if(!n) return "";
      let badge="";
      try{
        if(id==="agents") badge=nb(agents.length);
        else if(id==="builder") badge=nb(flows.length);
        else if(id==="router") badge='<span class="live" title="Router activo"></span>';
      }catch(e){}
      return `<button class="side-btn ${curView===id?"active":""}" onclick="go('${id}')">${n.i}&nbsp; ${n.t}${badge}</button>`;
    }
    if(kind==="mod"){
      const m=MODULES[id]; if(!m) return "";
      let badge=""; try{ if(id==="know") badge=nb(kb.length); }catch(e){}
      return `<button class="side-btn ${curView===id?"active":""}" onclick="goMod('${id}')">${m.i}&nbsp; ${m.t}${badge}</button>`;
    }
    if(kind==="fn"&&id==="providers") return `<button class="side-btn" onclick="openSettings()">🔌&nbsp; ${v60L("Proveedores de modelos","Model Providers")}</button>`;
    return "";
  };
  let h=`<button class="side-btn home-btn ${curView==="home"?"active":""}" onclick="go('home')">🏠&nbsp; Command Center</button>`;
  V60_GROUPS.forEach(g=>{ h+=`<div class="sec-label">${v60L(g.es,g.en)}</div>`+g.items.map(([k,id])=>item(k,id)).join(""); });
  el.innerHTML=h;
};

const V60_go=go;
go=function(id){
  V60_go(id);
  try{
    if(id==="home") v60RenderHome();
    else if(id==="router") v60RenderRouter();
    else if(id==="control") v60RenderControl();
    else if(id==="analytics") v60AnPipe();
    else if(id==="builder") v60WfPaint(wfSteps);
    else if(id==="agents") v60RenderSkillsKeep();
    const v=document.querySelector(".view.on .panel"); if(v) v.scrollTop=0;
  }catch(e){ console.error("v60 go",e); }
};
function v60RefreshView(){
  try{
    renderNav();
    if(curView==="home") v60RenderHome();
    else if(curView==="router") v60RenderRouter();
    else if(curView==="control") v60RenderControl();
  }catch(e){ console.error("v60 refresh",e); }
}
function v60Header(){
  const el=$("hdr-models"); if(!el) return;
  const n=v60ConnList().length;
  el.innerHTML=`<span class="st on"></span>${n} ${v60L(n===1?"modelo conectado":"modelos conectados", n===1?"model connected":"models connected")}`;
}

/* ==================== TELEMETRÍA REAL DE USO ==================== */
function v60UsageLoad(){
  V60.usage=v60J("atlas_usage_v60",null);
  if(!V60.usage||!V60.usage.tot) V60.usage={since:Date.now(),tot:{req:0,fail:0,ms:0,inC:0,outC:0},by:{},ev:[]};
  V60.rlog=v60J("atlas_router_log",[]);
}
function v60UsageRec(e){
  const u=V60.usage; if(!u) return;
  const add=(o)=>{ o.req++; if(!e.ok)o.fail++; o.ms+=e.ms; o.inC+=e.inC; o.outC+=e.outC; };
  add(u.tot); add(u.by[e.pk]||(u.by[e.pk]={req:0,fail:0,ms:0,inC:0,outC:0}));
  u.ev.unshift(e); if(u.ev.length>150) u.ev.length=150;
  clearTimeout(V60._ut); V60._ut=setTimeout(()=>{ v60LSset("atlas_usage_v60",JSON.stringify(u)); },300);
  if(curView==="control") v60RenderControl();
}
function v60UsageReset(){
  if(!confirm(v60L("¿Reiniciar las métricas de uso y el log del Router?","Reset usage metrics and the Router log?"))) return;
  V60.usage=null; localStorage.removeItem("atlas_usage_v60"); localStorage.removeItem("atlas_router_log"); v60UsageLoad(); v60RefreshView();
}
function v60UsageCsv(){
  const rows=[["fecha","proveedor","modelo","latencia_ms","ok","chars_entrada","chars_salida","tokens_estimados","error"]];
  (V60.usage.ev||[]).forEach(e=>rows.push([new Date(e.t).toISOString(),e.pk,e.model||"",e.ms,e.ok?1:0,e.inC,e.outC,Math.round((e.inC+e.outC)/4),(e.err||"").replace(/[\r\n,]+/g," ")]));
  const blob=new Blob([rows.map(r=>r.join(",")).join("\n")],{type:"text/csv"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="artlas-uso-modelos.csv"; a.click();
}
const V60_callProvider=callProvider;
callProvider=async function(pk,c,messages,sys,imgs,maxTok){
  const t0=(performance&&performance.now)?performance.now():Date.now();
  const model=(c&&c.model)||((PROVIDERS[pk]||{}).defModel)||"";
  let inC=(sys||"").length;
  try{ (messages||[]).forEach(m=>{ if(typeof m.content==="string") inC+=m.content.length; else if(Array.isArray(m.content)) m.content.forEach(p=>{ if(p&&typeof p.text==="string") inC+=p.text.length; }); }); }catch(e){}
  const ms=()=>Math.round(((performance&&performance.now)?performance.now():Date.now())-t0);
  try{
    const r=await V60_callProvider.apply(this,arguments);
    v60UsageRec({t:Date.now(),pk,model,ms:ms(),ok:true,inC,outC:(typeof r==="string"?r.length:0)});
    return r;
  }catch(err){
    v60UsageRec({t:Date.now(),pk,model,ms:ms(),ok:false,inC,outC:0,err:((err&&err.message)||err+"").slice(0,160)});
    throw err;
  }
};

/* ==================== AR.T.L.A.S. ROUTER ==================== */
const V60_STRATS={
  auto:     {grp:["Inteligente","Smart"], ic:"🔀", n:["Auto Router","Auto Router"], short:"Auto", mode:"smart", metric:null,
             d:["Analiza intención y complejidad de cada consulta y elige modelo y métrica automáticamente.","Analyses intent and complexity of every request and picks model and metric automatically."]},
  fast:     {grp:["Inteligente","Smart"], ic:"⚡", n:["Fast","Fast"], short:"Fast", mode:"smart", metric:"velocidad",
             d:["Prioriza la velocidad de respuesta (Groq, Gemini Flash, GLM…).","Prioritises response speed (Groq, Gemini Flash, GLM…)."]},
  balanced: {grp:["Inteligente","Smart"], ic:"⚖️", n:["Balanced","Balanced"], short:"Balanced", mode:"smart", metric:"equilibrio",
             d:["Equilibrio entre calidad, velocidad y costo para el uso diario.","Balance of quality, speed and cost for daily use."]},
  best:     {grp:["Inteligente","Smart"], ic:"🎯", n:["Best model","Best model"], short:"Best", mode:"smart", metric:"calidad",
             d:["Siempre el modelo de mayor calidad disponible según la tarea.","Always the highest-quality model available for the task."]},
  reasoning:{grp:["Fija","Fixed"], ic:"🧠", n:["Reasoning","Reasoning"], short:"Reasoning", mode:"single",
             d:["Razonamiento explícito paso a paso (AR.T.L.A.S. Thinking con Claude, o Deep Thinking con OpenAI).","Explicit step-by-step reasoning (AR.T.L.A.S. Thinking with Claude, or Deep Thinking with OpenAI)."]},
  economy:  {grp:["Fija","Fixed"], ic:"💰", n:["Economy","Economy"], short:"Economy", mode:"single",
             d:["Prioriza proveedores gratuitos o de bajo costo (Groq, GLM Flash, Gemini, OpenRouter :free, Básico).","Prioritises free or low-cost providers (Groq, GLM Flash, Gemini, OpenRouter :free, Basic)."]},
  manual:   {grp:["Fija","Fixed"], ic:"📌", n:["Modelo fijo","Fixed model"], short:["Fijo","Fixed"], mode:"single",
             d:["Responde siempre el modelo que elegís en el selector superior.","Always answers with the model you pick in the top selector."]},
  multi:    {grp:["Multi-modelo","Multi-model"], ic:"⚡", n:["Simultáneo","Parallel"], short:["Simultáneo","Parallel"], mode:"multi",
             d:["Varias LLM conectadas responden en paralelo, una debajo de la otra.","Several connected LLMs answer in parallel, one below the other."]},
  forest:   {grp:["Multi-modelo","Multi-model"], ic:"🌳", n:["Consenso (Random Forest)","Consensus (Random Forest)"], short:["Consenso","Consensus"], mode:"forest",
             d:["Varias LLM responden y otra sintetiza la mejor respuesta de consenso.","Several LLMs answer and another one synthesises the best consensus answer."]}
};
function v60S(st,f){ const S=V60_STRATS[st]; const v=S&&S[f]; return Array.isArray(v)?v60L(v[0],v[1]):v; }
function v60Strategy(){
  const s=v60LS("atlas_strategy","");
  if(V60_STRATS[s]){
    const S=V60_STRATS[s];
    if((S.mode==="smart"&&routeMode==="smart")||(S.mode===routeMode)) return s;
  }
  return routeMode==="smart"?(routeMetric==="velocidad"?"fast":routeMetric==="calidad"?"best":"balanced"):routeMode==="multi"?"multi":routeMode==="forest"?"forest":"manual";
}
function v60FixedLevel(st){
  if(st==="reasoning"){
    if(connected("anthropic")) return "thinking";
    if(connected("openai")) return "deepthink";
    const p=["gemini","deepseek","groq","hf","other","zai","kimi","felo"].find(connected); return p?levelOf(p):"free";
  }
  if(st==="economy"){ const p=["groq","zai","gemini","other","hf","basic"].find(connected); return levelOf(p||"basic"); }
  return null;
}
function v60ApplyStrategy(st){
  const S=V60_STRATS[st]; if(!S) return;
  v60LSset("atlas_strategy",st);
  if(S.mode==="smart"){ routeMode="smart"; if(S.metric) routeMetric=S.metric; }
  else if(S.mode==="multi"||S.mode==="forest"){ routeMode=S.mode; }
  else { routeMode="single"; const lv=v60FixedLevel(st); if(lv) curModel=lv; }
  v60LSset("atlas_route",routeMode); v60LSset("atlas_metric",routeMetric);
  save(); renderMenu(); renderRoute(); pushCloud(); v60RefreshView();
  const rm=$("route-menu"); if(rm) rm.classList.remove("open");
}
function v60FallbackOn(){ return v60LS("atlas_fallback","1")!=="0"; }
function v60ToggleFallback(){ v60LSset("atlas_fallback",v60FallbackOn()?"0":"1"); renderRoute(); v60RefreshView(); }
function v60FallbackChain(pk){ return ["anthropic","openai","gemini","groq","deepseek","hf","other","zai","kimi","felo"].filter(p=>p!==pk&&connected(p)).slice(0,2); }

const V60_INTENTS={
  research:{es:"Investigación",en:"Research",  ic:"🔬", sample:"investigá papers sobre optimización de redes 5G"},
  code:    {es:"Código",       en:"Coding",    ic:"⌨️", sample:"escribí un script python para analizar un CSV"},
  quick:   {es:"Respuesta rápida",en:"Quick answer",ic:"⚡", sample:"qué es RAG"},
  general: {es:"General / Análisis",en:"General / Analysis",ic:"💡", sample:"diseñá y compará dos arquitecturas de red para un campus con justificación"}
};
function v60Intent(txt){
  const t=(txt||"").toLowerCase();
  let key="general";
  if(/investig|paper|arxiv|estado del arte|cient|research|scientific|state of the art|literature|survey/.test(t)) key="research";
  else if(/código|codigo|script|python|sql|debug|program|javascript|typescript|función|funcion|\bcode\b|\bbug\b|regex|html|css|java\b|c\+\+/.test(t)) key="code";
  else if(/resum|qué es|que es|rápid|rapid|defin|summar|what is|define|quick|tl;dr|brief/.test(t)) key="quick";
  const complex = t.length>600 || /analiz|compar|diseñ|arquitect|demostr|optimi|estrateg|evalu|paso a paso|justific|analy[sz]|design|architect|evaluat|step by step|trade.?off/.test(t);
  const metric = (key==="research"||key==="code") ? "calidad" : key==="quick" ? "velocidad" : complex ? "calidad" : (t.length<90 ? "velocidad" : "equilibrio");
  return {key, complex, metric};
}
function v60PickFor(intentKey, metric){
  const want = intentKey==="research"?["gemini","anthropic","openai"] : intentKey==="code"?["anthropic","openai","groq"] : intentKey==="quick"?["groq","gemini","basic"] : [];
  const pref = metric==="velocidad" ? ["groq","gemini","zai","basic","openai","anthropic","deepseek","hf","other","kimi","felo"]
             : metric==="calidad"   ? ["anthropic","openai","gemini","deepseek","hf","other","kimi","groq","zai","felo","basic"]
             :                        ["openai","gemini","anthropic","deepseek","groq","hf","other","zai","kimi","felo","basic"];
  const pk=want.concat(pref).find(connected)||"basic";
  return levelOf(pk);
}
const V60_metricName={velocidad:["velocidad","speed"],equilibrio:["equilibrio","balance"],calidad:["calidad","quality"]};
function v60MetricName(m){ const a=V60_metricName[m]||[m,m]; return v60L(a[0],a[1]); }
function v60Preview(txt, st){
  st=st||v60Strategy();
  const it=v60Intent(txt), S=V60_STRATS[st];
  if(S.mode==="smart"){ const metric=st==="auto"?it.metric:(S.metric||routeMetric); return {it, metric, lvl:v60PickFor(it.key,metric), kind:"smart"}; }
  if(S.mode==="single"){ const lvl=v60FixedLevel(st)||curModel; return {it, metric:null, lvl, kind:"fixed"}; }
  return {it, metric:null, lvl:null, kind:S.mode, n:taskCount()};
}
smartPick=function(txt){
  const st=v60Strategy();
  const p=v60Preview(txt, V60_STRATS[st].mode==="smart"?st:"balanced");
  v60RouterLog({q:(txt||"").slice(0,90), intent:p.it.key, metric:p.metric, lvl:p.lvl, st});
  return p.lvl;
};
function v60RouterLog(o){
  o.t=Date.now(); V60.rlog.unshift(o); if(V60.rlog.length>40) V60.rlog.length=40;
  v60LSset("atlas_router_log",JSON.stringify(V60.rlog));
}
function v60LvlLabel(lvl){
  const m=MODELS[lvl]; if(!m) return "—";
  return `${v60Esc(m.name)} <span class="dim">· ${v60Esc(PROVIDERS[m.prov].label)}${connected(m.prov)?" · "+v60Esc(provModel(m.prov)):""}</span>`;
}

/* send: re-evalúa estrategias fijas (Reasoning / Economy) según proveedores conectados */
const V60_send=send;
send=async function(){
  try{
    const st=v60Strategy();
    if(st==="reasoning"||st==="economy"){ const lv=v60FixedLevel(st); if(lv&&lv!==curModel){ curModel=lv; save(); renderMenu(); } }
  }catch(e){}
  return V60_send.apply(this,arguments);
};

/* askOne con FALLBACK real: si el proveedor falla, reintenta con otro conectado */
askOne=async function(c,history,baseSys,imgs){
  const m=MODELS[curModel], pk=m.prov, via=`${m.name} → ${PROVIDERS[pk].label} · ${provModel(pk)}`;
  const typing=addRow("assistant","",via); typing.querySelector(".content").innerHTML='<span class="typing"></span>'; scrollDown();
  const sys=[baseSys,m.sys].filter(Boolean).join("\n\n")||null;
  let reply=null, meta=via;
  if(!connected(pk)){
    await new Promise(r=>setTimeout(r,700)); meta=m.name+" · modo simulado"; reply=simReply(history[history.length-1].content,curModel);
  }else{
    const chain=[pk].concat(v60FallbackOn()?v60FallbackChain(pk):[]);
    const fails=[];
    for(let i=0;i<chain.length;i++){
      const p=chain[i];
      try{
        if(i>0){ const vEl=typing.querySelector(".via"); if(vEl) vEl.textContent="↪ Fallback → "+PROVIDERS[p].label+" · "+provModel(p)+"…"; }
        reply=await callProvider(p,cfg[p]||{},history,sys,imgs);
        if(i>0){
          meta="↪ Fallback: "+PROVIDERS[p].label+" · "+provModel(p)+" ("+PROVIDERS[pk].label+" "+v60L("no respondió","did not respond")+")";
          v60RouterLog({q:v60L("(fallback)","(fallback)")+" "+PROVIDERS[pk].label+" → "+PROVIDERS[p].label, intent:"fallback", metric:null, lvl:levelOf(p), st:v60Strategy(), fb:1});
        }
        break;
      }catch(e){ fails.push({p, msg:((e&&e.message)||e||"error")+""}); reply=null; }
    }
    if(reply==null){
      const emsg=fails[0].msg, hint=errHint(pk,emsg);
      const extra=fails.length>1?"\n\n↪ "+v60L("Fallback intentado con","Fallback tried with")+": "+fails.slice(1).map(f=>PROVIDERS[f.p].label+" ("+f.msg.slice(0,70)+")").join(" · "):"";
      typing.querySelector(".content").innerHTML=`<span class="err">⚠️ ${v60Esc(PROVIDERS[pk].label)}: ${v60Esc(emsg.slice(0,220))}${v60Esc(hint)}${v60Esc(extra)}</span>`;
      const vEl=typing.querySelector(".via"); if(vEl) vEl.textContent=meta; scrollDown(); return;
    }
  }
  typing.querySelector(".content").innerHTML=md(reply);
  const vEl=typing.querySelector(".via"); if(vEl) vEl.textContent=meta;
  c.msgs.push({role:"assistant",content:reply,meta}); save(); scrollDown();
};

/* Menú desplegable del Router (encabezado) */
renderRoute=function(){
  const st=v60Strategy();
  if($("route-name")) $("route-name").textContent=v60S(st,"short");
  const rm=$("route-menu"); if(!rm) return;
  let h=`<div style="padding:8px 12px 2px;font-weight:700;font-size:13px">🧭 AR.T.L.A.S. Router</div>`;
  let lastG="";
  Object.keys(V60_STRATS).forEach(k=>{
    const g=v60S(k,"grp");
    if(g!==lastG){ h+=`<div style="font-size:10.5px;letter-spacing:1px;text-transform:uppercase;color:var(--muted);font-weight:700;padding:8px 12px 2px">${g}</div>`; lastG=g; }
    h+=`<div class="m-item ${k===st?"sel":""}" onclick="v60ApplyStrategy('${k}')"><div class="info"><b>${V60_STRATS[k].ic} ${v60S(k,"n")}</b><small>${v60S(k,"d")}</small></div><span class="check">✓</span></div>`;
  });
  h+=`<div style="border-top:1px solid var(--border);margin:6px 4px 0;padding:10px 12px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
      <span class="switch ${v60FallbackOn()?"on":""}" onclick="event.stopPropagation();v60ToggleFallback()"><i></i>Fallback</span>
      <a href="#" style="font-size:12.5px;font-weight:600" onclick="event.preventDefault();$('route-menu').classList.remove('open');go('router')">${v60L("Abrir AR.T.L.A.S. Router →","Open AR.T.L.A.S. Router →")}</a></div>`;
  rm.innerHTML=h;
};
pickRoute=function(k){ const map={single:"manual",smart:"balanced",multi:"multi",forest:"forest"}; v60ApplyStrategy(map[k]||"manual"); };

const V60_renderMenu=renderMenu;
renderMenu=function(){
  V60_renderMenu.apply(this,arguments);
  try{ v60Header(); if(curView==="home"||curView==="router"||curView==="control") v60RefreshView(); }catch(e){}
};

/* pushCloud / loadCloud: respetan la opción "sincronizar keys" y fusionan por proveedor */
function v60CloudKeys(){ return v60LS("atlas_cloudkeys","1")!=="0"; }
pushCloud=async function(){
  if(!supa||!user) return;
  try{
    const sendCfg=v60CloudKeys()?cfg:v60SplitKeys(cfg).clean;
    await supa.from("atlas_profiles").upsert({id:user.id,cfg:{cfg:sendCfg,curModel,routeMode,routeMetric,strategy:v60LS("atlas_strategy","")},updated_at:new Date().toISOString()});
    if($("user-sync")) $("user-sync").textContent="☁ "+v60L("sincronizado","synced")+" "+new Date().toLocaleTimeString();
  }catch(e){}
};
loadCloud=async function(){
  if(!supa||!user) return;
  try{
    const {data}=await supa.from("atlas_profiles").select("cfg").eq("id",user.id).maybeSingle();
    if(data&&data.cfg){
      const d=data.cfg;
      if(d.cfg) Object.keys(d.cfg).forEach(pk=>{ const v=d.cfg[pk]; if(v&&typeof v==="object"&&!Array.isArray(v)) cfg[pk]={...(cfg[pk]||{}),...v}; else cfg[pk]=v; });
      if(d.curModel&&MODELS[d.curModel]) curModel=d.curModel;
      if(d.routeMode&&ROUTES[d.routeMode]) routeMode=d.routeMode;
      if(d.routeMetric) routeMetric=d.routeMetric;
      if(d.strategy&&V60_STRATS[d.strategy]) v60LSset("atlas_strategy",d.strategy);
      save(); renderMenu(); renderRoute(); v60RefreshView();
      if($("user-sync")) $("user-sync").textContent="☁ "+v60L("configuración cargada desde la nube","settings loaded from the cloud");
    } else pushCloud();
  }catch(e){}
};
