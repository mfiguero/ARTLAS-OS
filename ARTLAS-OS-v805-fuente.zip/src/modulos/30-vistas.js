
/* ==================== COMMAND CENTER ==================== */
function v60DemoBanner(){
  if(!v60Demo()) return "";
  return `<div class="v60-demo">🎁 <span style="flex:1;min-width:220px"><b>${v60L("Modo demo","Demo mode")}</b> · ${v60L("Estás explorando AR.T.L.A.S. como invitado, con modelos gratuitos y sin registro. Nada se envía a una cuenta.","You are exploring AR.T.L.A.S. as a guest, with free models and no sign-up. Nothing is sent to an account.")}</span>
    <button class="btn" onclick="v60SeedDemo()">✨ ${v60L("Cargar ejemplos","Load examples")}</button>
    <button class="btn dark" onclick="openUser()">${v60L("Crear cuenta","Create account")}</button>
    <button class="btn" onclick="v60SSset('atlas_demo',null);v60RefreshView()">✕</button></div>`;
}
function v60QuickAsk(){
  const q=$("cc-q"); if(!q) return; const t=q.value.trim(); if(!t){ q.focus(); return; }
  goChat(); newChat(); inp.value=t; send();
}
/* saludo según la hora: Buen día 6:00–12:00 · Buenas tardes 12:01–20:00 · Buenas noches 20:01–5:59 */
function v60Saludo(d){
  d=d||new Date(); const m=d.getHours()*60+d.getMinutes();
  return m>=360&&m<=720?v60L("Buen día","Good morning"):m>=721&&m<=1200?v60L("Buenas tardes","Good afternoon"):v60L("Buenas noches","Good evening");
}
function v60RenderHome(){
  const el=$("home-inner"); if(!el) return;
  const conn=v60ConnList(), st=v60Strategy();
  let nm=""; try{ if(user&&user.email) nm=", "+user.email.split("@")[0]; }catch(e){}
  const greet=v60Saludo();
  const cards=[
    ["💬",v60L("Chat IA","AI Chat"),v60L("Conversá con cualquier modelo; el Router elige el mejor.","Chat with any model; the Router picks the best one."),"go('chat')"],
    ["🤖","Agent Studio",v60L("Agentes con instrucciones, skills, documentos y web.","Agents with instructions, skills, documents and web."),"go('agents')"],
    ["⛓️","Workflows",v60L("Cadenas multi-modelo: cada paso con su LLM.","Multi-model chains: each step with its own LLM."),"go('builder')"],
    ["✨","AR.T.L.A.S. Build",v60L("Describí una app y AR.T.L.A.S. la construye.","Describe an app and AR.T.L.A.S. builds it."),"go('art')"],
    ["📈","AR.T.L.A.S. Analytics",v60L("Excel/CSV → dashboard, minería y reportes.","Excel/CSV → dashboard, mining and reports."),"go('analytics')"],
    ["📚",v60L("Knowledge & RAG","Knowledge & RAG"),v60L("Tus documentos como contexto; RAG local.","Your documents as context; local RAG."),"goMod('know')"]
  ];
  let nSkills=0; try{ nSkills=v60SkillsAll().length; }catch(e){}
  const stats=[
    [conn.length,v60L("Modelos conectados","Connected models"),"go('control')"],
    [agents.length,v60L("Agentes","Agents"),"go('agents')"],
    [nSkills,"Skills","go('agents');setTimeout(()=>{const s=$('sk-card');if(s)s.scrollIntoView({behavior:'smooth'});},80)"],
    [flows.length,"Workflows","go('builder')"],
    [kb.length,v60L("Documentos","Documents"),"goMod('know')"],
    ['<span id="cc-arts">…</span>',v60L("Artefactos","Artifacts"),"go('art')"]
  ];
  const recent=chats.slice(0,6).map(c=>`<div class="act-row" onclick="goChat();openChat('${v60Esc(c.id)}')"><span>💬</span><span class="t">${v60Esc(c.title||"—")}</span><small>${/^\d{12,}$/.test(c.id)?v60Ago(+c.id):""}</small></div>`).join("")
    || `<div class="note">${v60L("Todavía no hay conversaciones. Escribí arriba para empezar.","No conversations yet. Type above to start.")}</div>`;
  const offN=Object.keys(PROVIDERS).filter(k=>!connected(k)).length;
  const chips=conn.map(k=>`<span class="mchip on"><span class="st on"></span>${v60Esc(provShort(k))}</span>`).join("")+
    (offN?`<span class="mchip" style="cursor:pointer" onclick="openSettings()">＋ ${offN} ${v60L("por configurar","to configure")}</span>`:"");
  const u=V60.usage.tot, avg=u.req?Math.round(u.ms/u.req):0;
  el.innerHTML=`${v60DemoBanner()}
    <div class="cc-hero"><div><h2>${greet}${v60Esc(nm)} · ${v60L("¿qué querés hacer?","what would you like to do?")}</h2>
      <p>AR.T.L.A.S. · AI Orchestration Platform — ${v60L("modelos, agentes, workflows, conocimiento, apps y analítica en un único espacio.","models, agents, workflows, knowledge, apps and analytics in a single workspace.")}</p></div>
      <span class="rt-pill" onclick="go('router')"><span class="pulse"></span>AR.T.L.A.S. Intelligence Router: ${v60L("ACTIVO","ACTIVE")} · ${v60S(st,"short")}</span></div>
    <div class="cc-ask"><input id="cc-q" placeholder="${v60L("Preguntale a AR.T.L.A.S. — el Router elige el mejor modelo","Ask AR.T.L.A.S. — the Router picks the best model")}" onkeydown="if(event.key==='Enter')v60QuickAsk()"><button onclick="v60QuickAsk()" title="${v60L("Enviar","Send")}">↑</button></div>
    <div class="cc-sec">${v60L("Accesos","Shortcuts")}</div>
    <div class="cc-grid">${cards.map(c=>`<button class="cc-card" onclick="${c[3]}"><span class="cc-ico">${c[0]}</span><span><b>${c[1]}</b><small>${c[2]}</small></span></button>`).join("")}</div>
    <div class="cc-sec">${v60L("Tu plataforma","Your platform")}</div>
    <div class="cc-stats">${stats.map(s=>`<div class="stat" onclick="${s[2]}"><div class="v">${s[0]}</div><div class="l">${s[1]}</div></div>`).join("")}</div>
    <div class="cc-cols">
      <div class="card"><h4>${v60L("Actividad reciente","Recent activity")}</h4>${recent}</div>
      <div class="card"><h4>${v60L("Estado","Status")}</h4>
        <div class="chips" style="margin-bottom:12px">${chips}</div>
        <div class="kv"><span>${v60L("Estrategia de ruteo","Routing strategy")}</span><b>${V60_STRATS[st].ic} ${v60S(st,"n")}</b></div>
        <div class="kv"><span>Fallback</span><b>${v60FallbackOn()?"ON":"OFF"}</b></div>
        <div class="kv"><span>${v60L("Requests medidos","Measured requests")}</span><b>${v60Num(u.req)}</b></div>
        <div class="kv"><span>${v60L("Latencia promedio","Average latency")}</span><b>${u.req?(avg/1000).toFixed(1)+" s":"—"}</b></div>
        <div class="kv"><span>${v60L("Keys","Keys")}</span><b>${V60_KEYMODES[v60KeyMode()].ic} ${v60KM(v60KeyMode(),"n")}</b></div>
        <div style="margin-top:12px"><button class="btn" onclick="go('control')">🎛️ Control Center</button> <button class="btn" onclick="openSettings()">🔌 ${v60L("Proveedores","Providers")}</button></div>
      </div>
    </div>`;
  artStoreAll().then(a=>{ const s=$("cc-arts"); if(s) s.textContent=a.length; }).catch(()=>{ const s=$("cc-arts"); if(s) s.textContent="0"; });
}

/* ==================== AR.T.L.A.S. ROUTER (vista) ==================== */
function v60RenderRouter(){
  const el=$("router-inner"); if(!el) return;
  const st=v60Strategy(), S=V60_STRATS[st];
  const pv=k=>v60Preview(V60_INTENTS[k].sample, st);
  let branches="";
  if(S.mode==="multi"||S.mode==="forest"){
    branches=`<div class="rt-pick on" style="max-width:520px"><b>${S.ic} ${v60S(st,"n")}</b>${v60L("Consulta en paralelo a","Queries in parallel")} ${taskCount()} ${v60L("modelos","models")}${S.mode==="forest"?v60L(" y un sintetizador genera el consenso"," and a synthesiser builds the consensus"):""}</div>`;
  }else{
    branches=`<div class="rt-branches">`+Object.keys(V60_INTENTS).map(k=>{
      const p=pv(k), m=MODELS[p.lvl]||MODELS.free, on=connected(m.prov);
      return `<div class="rt-br"><div class="rt-intent">${V60_INTENTS[k].ic} ${v60L(V60_INTENTS[k].es,V60_INTENTS[k].en)}</div>
        <div class="rt-pick ${on?"on":""}"><b>${v60Esc(PROVIDERS[m.prov].label)}</b>${v60Esc(m.name)}${p.metric?`<br><span class="dim" style="font-size:11px">${v60L("métrica","metric")}: ${v60MetricName(p.metric)}</span>`:""}</div></div>`;
    }).join("")+`</div><div class="rt-merge"></div>`;
  }
  const grpOrder=[]; Object.keys(V60_STRATS).forEach(k=>{ const g=v60S(k,"grp"); if(!grpOrder.includes(g)) grpOrder.push(g); });
  const strats=Object.keys(V60_STRATS).map(k=>`<button class="strat ${k===st?"sel":""}" onclick="v60ApplyStrategy('${k}')"><span class="grp">${v60S(k,"grp")}</span><b>${V60_STRATS[k].ic} ${v60S(k,"n")}</b><small>${v60S(k,"d")}</small></button>`).join("");
  const chain=["anthropic","openai","gemini","groq","deepseek","hf","other","zai","kimi","felo"].filter(connected);
  const log=(V60.rlog||[]).slice(0,12).map(r=>`<tr><td class="dim">${new Date(r.t).toLocaleTimeString()}</td><td>${v60Esc(r.q||"")}</td><td>${r.intent==="fallback"?"↪ fallback":v60Esc(V60_INTENTS[r.intent]?v60L(V60_INTENTS[r.intent].es,V60_INTENTS[r.intent].en):r.intent)}</td><td>${r.metric?v60MetricName(r.metric):"—"}</td><td>${v60LvlLabel(r.lvl)}</td></tr>`).join("");
  el.innerHTML=`<h3>🧭 AR.T.L.A.S. Router</h3><div class="kicker">Intelligent Model Routing</div>
    <p class="sub">${v60L("Cada consulta pasa por el Router: analiza la intención, aplica la estrategia elegida y la envía al modelo óptimo entre tus proveedores conectados. Si el modelo falla, el fallback reintenta automáticamente con otro.","Every request goes through the Router: it analyses intent, applies the chosen strategy and sends it to the best model among your connected providers. If the model fails, fallback automatically retries with another one.")}</p>
    <div class="card"><div class="rt-flow">
      <div class="rt-node">👤 ${v60L("Consulta del usuario","User request")}</div><div class="rt-v"></div>
      <div class="rt-node core">🧭 AR.T.L.A.S. ROUTER<small>${v60L("Análisis de intención","Intent analysis")} · ${v60L("estrategia","strategy")}: ${S.ic} ${v60S(st,"n")}</small></div><div class="rt-v"></div>
      ${branches}<div class="rt-v"></div>
      <div class="rt-node">✅ ${v60L("Respuesta final","Final response")}<small>Fallback: ${v60FallbackOn()?"ON":"OFF"} · ${v60ConnList().length} ${v60L("modelos disponibles","models available")}</small></div>
    </div><div class="note" style="text-align:center">${v60L("Vista en vivo: muestra qué modelo elegiría hoy el Router para cada tipo de consulta, según tus proveedores conectados.","Live view: shows which model the Router would pick today for each kind of request, given your connected providers.")}</div></div>
    <div class="card mt"><h4>${v60L("Estrategia de ruteo","Routing strategy")}</h4><div class="strat-grid">${strats}</div></div>
    <div class="grid2 mt">
      <div class="card"><h4>${v60L("Probar el Router","Test the Router")}</h4>
        <div class="qbox"><textarea id="rt-q" rows="3" placeholder="${v60L("Escribí una consulta de ejemplo… (no se envía a ningún modelo)","Type a sample request… (it is not sent to any model)")}"></textarea></div>
        <button class="btn dark" onclick="v60RouterTest()">🔍 ${v60L("Analizar","Analyse")}</button>
        <div class="rt-res" id="rt-res"></div></div>
      <div class="card"><h4>${v60L("Fallback y resiliencia","Fallback & resilience")}</h4>
        <span class="switch ${v60FallbackOn()?"on":""}" onclick="v60ToggleFallback()"><i></i>${v60L("Reintentar con otro proveedor si el modelo falla","Retry with another provider if the model fails")}</span>
        <div class="kv mt"><span>${v60L("Orden de respaldo","Fallback order")}</span><b>${chain.length?chain.map(p=>v60Esc(provShort(p))).join(" → "):v60L("conectá al menos 2 proveedores","connect at least 2 providers")}</b></div>
        <div class="kv"><span>${v60L("Intentos máximos","Max attempts")}</span><b>1 + 2</b></div>
        <div class="note">${v60L("Por privacidad, el fallback no deriva tus consultas al modelo Básico comunitario (Pollinations), que no ofrece garantías sobre tus datos.","For privacy, fallback never sends your requests to the community Basic model (Pollinations), which offers no guarantees about your data.")}</div></div>
    </div>
    <div class="card mt"><h4>${v60L("Últimas decisiones del Router","Latest Router decisions")}</h4>
      ${log?`<div class="tbl-wrap"><table class="tbl"><tr><th>${v60L("Hora","Time")}</th><th>${v60L("Consulta","Request")}</th><th>${v60L("Intención","Intent")}</th><th>${v60L("Métrica","Metric")}</th><th>${v60L("Modelo elegido","Chosen model")}</th></tr>${log}</table></div>`
           :`<div class="note">${v60L("Todavía no hay decisiones. Usá una estrategia inteligente (Auto, Fast, Balanced o Best) y chateá.","No decisions yet. Use a smart strategy (Auto, Fast, Balanced or Best) and chat.")}</div>`}</div>`;
}
function v60RouterTest(){
  const q=($("rt-q")||{}).value||""; const r=$("rt-res"); if(!r) return;
  if(!q.trim()){ $("rt-q").focus(); return; }
  const st=v60Strategy(), p=v60Preview(q,st), S=V60_STRATS[st];
  const iName=v60L(V60_INTENTS[p.it.key].es,V60_INTENTS[p.it.key].en);
  let why;
  if(p.kind==="smart") why=st==="auto"
      ? v60L(`Estrategia Auto: la intención «${iName}»${p.it.complex?" con alta complejidad":""} define la métrica «${v60MetricName(p.metric)}».`,`Auto strategy: intent “${iName}”${p.it.complex?" with high complexity":""} sets the “${v60MetricName(p.metric)}” metric.`)
      : v60L(`Estrategia ${v60S(st,"n")}: métrica fija «${v60MetricName(p.metric)}», se prioriza el proveedor más apto para «${iName}».`,`${v60S(st,"n")} strategy: fixed “${v60MetricName(p.metric)}” metric, prioritising the provider best suited for “${iName}”.`);
  else if(p.kind==="fixed") why=v60L(`Estrategia ${v60S(st,"n")}: todas las consultas van al mismo modelo.`,`${v60S(st,"n")} strategy: every request goes to the same model.`);
  else why=v60L(`Estrategia ${v60S(st,"n")}: la consulta se envía en paralelo a ${p.n} modelos.`,`${v60S(st,"n")} strategy: the request is sent in parallel to ${p.n} models.`);
  r.innerHTML=`<div class="kv"><span>${v60L("Intención detectada","Detected intent")}</span><b>${V60_INTENTS[p.it.key].ic} ${iName}${p.it.complex?" · "+v60L("compleja","complex"):""}</b></div>
    <div class="kv"><span>${v60L("Estrategia","Strategy")}</span><b>${S.ic} ${v60S(st,"n")}</b></div>
    ${p.metric?`<div class="kv"><span>${v60L("Métrica aplicada","Applied metric")}</span><b>${v60MetricName(p.metric)}</b></div>`:""}
    <div class="kv"><span>${v60L("Destino","Target")}</span><b>${p.lvl?v60LvlLabel(p.lvl):p.n+" "+v60L("modelos","models")}</b></div>
    <div class="note" style="margin-top:6px">${why}</div>`;
  r.classList.add("show");
}

/* ==================== CONTROL CENTER ==================== */
function v60RenderControl(){
  const el=$("control-inner"); if(!el) return;
  const u=V60.usage, t=u.tot, avg=t.req?t.ms/t.req:0, st=v60Strategy();
  const tok=Math.round((t.inC+t.outC)/4);
  const provs=Object.keys(PROVIDERS).sort((a,b)=>(connected(b)-connected(a))||(((u.by[b]||{}).req||0)-((u.by[a]||{}).req||0)));
  const maxReq=Math.max(1,...provs.map(p=>(u.by[p]||{}).req||0));
  const rows=provs.map(p=>{ const b=u.by[p]||{req:0,fail:0,ms:0}; const on=connected(p);
    return `<tr><td><span class="st ${on?"on":"off"}"></span> <b>${v60Esc(PROVIDERS[p].label)}</b></td><td class="dim">${on?v60Esc(provModel(p)):v60L("sin configurar","not configured")}</td>
      <td class="num">${b.req}</td><td style="width:90px"><div class="bar"><i style="width:${Math.round(b.req/maxReq*100)}%"></i></div></td>
      <td class="num">${b.req?(b.ms/b.req/1000).toFixed(1)+" s":"—"}</td><td class="num">${b.req?Math.round(b.fail/b.req*100)+"%":"—"}</td></tr>`; }).join("");
  const ev=(u.ev||[]).slice(0,12).map(e=>`<tr><td class="dim">${new Date(e.t).toLocaleTimeString()}</td><td>${v60Esc((PROVIDERS[e.pk]||{}).label||e.pk)}</td><td class="dim">${v60Esc(e.model||"")}</td><td class="num">${(e.ms/1000).toFixed(1)} s</td><td class="num">≈${v60Num((e.inC+e.outC)/4)}</td><td>${e.ok?'<span style="color:var(--green)">✓ OK</span>':'<span style="color:var(--red)" title="'+v60Esc(e.err||"")+'">✗ '+v60L("error","error")+'</span>'}</td></tr>`).join("");
  let sk=0; try{ sk=v60SkillsAll().length; }catch(e){}
  el.innerHTML=`<h3>🎛️ AR.T.L.A.S. Control Center</h3><div class="kicker">Models · Router · Agents · Usage · Security</div>
    <p class="sub">${v60L("Infraestructura de IA en una sola pantalla. Las métricas se miden en este navegador sobre cada llamada real a un modelo (los tokens se estiman como caracteres ÷ 4).","AI infrastructure on a single screen. Metrics are measured in this browser on every real model call (tokens are estimated as characters ÷ 4).")}</p>
    <div class="cc-kpis">
      <div class="stat"><div class="v">${v60Num(t.req)}</div><div class="l">Requests</div></div>
      <div class="stat"><div class="v">≈${v60Num(tok)}</div><div class="l">${v60L("Tokens (estimados)","Tokens (estimated)")}</div></div>
      <div class="stat"><div class="v">${t.req?(avg/1000).toFixed(1)+" s":"—"}</div><div class="l">${v60L("Latencia promedio","Average latency")}</div></div>
      <div class="stat"><div class="v">${t.req?(t.fail/t.req*100).toFixed(1)+"%":"—"}</div><div class="l">${v60L("Tasa de fallas","Failure rate")}</div></div>
    </div>
    <div class="card"><h4>${v60L("Modelos y proveedores","Models & providers")} · ${v60ConnList().length} ${v60L("conectados","connected")}</h4>
      <div class="tbl-wrap"><table class="tbl"><tr><th>${v60L("Proveedor","Provider")}</th><th>${v60L("Modelo","Model")}</th><th style="text-align:right">Req.</th><th></th><th style="text-align:right">${v60L("Latencia","Latency")}</th><th style="text-align:right">${v60L("Fallas","Failures")}</th></tr>${rows}</table></div>
      <div style="margin-top:12px"><button class="btn dark" onclick="openSettings()">🔌 ${v60L("Configurar proveedores","Configure providers")}</button></div></div>
    <div class="grid2 mt">
      <div class="card"><h4>Router</h4>
        <div class="kv"><span>${v60L("Estrategia","Strategy")}</span><b>${V60_STRATS[st].ic} ${v60S(st,"n")}</b></div>
        <div class="kv"><span>${v60L("Modo de ruteo","Routing mode")}</span><b>${v60Esc(ROUTES[routeMode]?ROUTES[routeMode].name:routeMode)}</b></div>
        <div class="kv"><span>${v60L("Métrica","Metric")}</span><b>${st==="auto"?v60L("dinámica por consulta","dynamic per request"):V60_STRATS[st].mode==="smart"?v60MetricName(routeMetric):"—"}</b></div>
        <div class="kv"><span>Fallback</span><b><span class="switch ${v60FallbackOn()?"on":""}" onclick="v60ToggleFallback()"><i></i>${v60FallbackOn()?"ON":"OFF"}</span></b></div>
        <div class="kv"><span>${v60L("Decisiones registradas","Logged decisions")}</span><b>${(V60.rlog||[]).length}</b></div>
        <div style="margin-top:12px"><button class="btn" onclick="go('router')">🧭 ${v60L("Abrir Router","Open Router")}</button></div></div>
      <div class="card"><h4>${v60L("Agentes y automatización","Agents & automation")}</h4>
        <div class="kv"><span>${v60L("Agentes","Agents")}</span><b>${agents.length}</b></div>
        <div class="kv"><span>Skills</span><b>${sk}</b></div>
        <div class="kv"><span>Workflows</span><b>${flows.length}</b></div>
        <div class="kv"><span>${v60L("Documentos en Knowledge","Knowledge documents")}</span><b>${kb.length} (${kb.filter(d=>d.on).length} ${v60L("activos","active")})</b></div>
        <div style="margin-top:6px">${agents.slice(0,5).map(a=>`<span class="tag" style="margin:3px 4px 0 0;display:inline-block">🤖 ${v60Esc(a.name)}${(a.skills&&a.skills.length)?" · 🧩"+a.skills.length:""}</span>`).join("")}</div>
        <div style="margin-top:12px"><button class="btn" onclick="go('agents')">🤖 Agent Studio</button> <button class="btn" onclick="go('builder')">⛓️ Workflows</button></div></div>
    </div>
    <div class="card mt" id="v60-sec"><h4>🔐 ${v60L("Seguridad de credenciales","Credential security")}</h4>${v60SecurityHtml()}</div>
    <div class="card mt"><h4>${v60L("Actividad reciente de modelos","Recent model activity")}</h4>
      ${ev?`<div class="tbl-wrap"><table class="tbl"><tr><th>${v60L("Hora","Time")}</th><th>${v60L("Proveedor","Provider")}</th><th>${v60L("Modelo","Model")}</th><th style="text-align:right">${v60L("Latencia","Latency")}</th><th style="text-align:right">Tokens</th><th>${v60L("Estado","Status")}</th></tr>${ev}</table></div>`
          :`<div class="note">${v60L("Sin llamadas registradas todavía.","No calls recorded yet.")}</div>`}
      <div style="margin-top:12px"><button class="btn" onclick="v60UsageCsv()">⬇ ${v60L("Exportar CSV","Export CSV")}</button> <button class="btn" onclick="v60UsageReset()">↺ ${v60L("Reiniciar métricas","Reset metrics")}</button>
      <span class="note">${v60L("Medición desde","Measuring since")} ${new Date(u.since).toLocaleDateString()}</span></div></div>`;
}
