
/* =====================================================================
   =====================  AR.T.L.A.S. v63 — BÚSQUEDA WEB + VER CLAVE  ==
   (1) Búsqueda web real en el chat: automática (consultas de actualidad),
       forzada desde ＋ › Buscar en la web, y reintento automático cuando
       el modelo responde «no tengo información».
       Cadena de proveedores: Tavily (key) → Jina (key) → gratuito
       (DuckDuckGo · Google Noticias · Wikipedia) → DuckDuckGo Instant.
       También la usan los agentes con «Navegación Web».
   (2) Botón 👁 para ver/ocultar la clave en todos los campos de contraseña.
   Todo vive en app.js/app.html → la versión escritorio lo hereda.
   ===================================================================== */
const V63={turn:null,last:null};
const V63_W="a-z0-9áéíóúñü";
function v63Rx(s){ return new RegExp("(^|[^"+V63_W+"])("+s+")(?=$|[^"+V63_W+"])","i"); }
/* v6.5: ya no busca sola. Busca cuando el usuario lo pide; si los modelos no tienen el dato, OFRECE buscar. */
function v63AutoOn(){ return v60LS("atlas_webask","1")!=="0"; }      // = «ofrecer búsqueda»
function v63SetAuto(on){
  v60LSset("atlas_webask",on?"1":"0");
  try{ renderRoute(); if(curView==="router") v60RenderRouter(); v63SettingsCard(); }catch(e){}
}
function v63Key(k){ return ((cfg[k]&&cfg[k].key)||"").trim(); }
function v63HasProxy(){ return (location.protocol==="http:"||location.protocol==="https:") && BACKEND!==false && !window.ARTLAS_DIRECT_ONLY; }
function v63Today(){
  try{ return new Date().toLocaleDateString(atlasLang==="en"?"en-US":"es-AR",{weekday:"long",day:"numeric",month:"long",year:"numeric"}); }
  catch(e){ return new Date().toDateString(); }
}
function v63Engine(){
  if(v63Key("tavily")) return "Tavily";
  if(v63Key("jina")) return "Jina";
  return v60L("Gratuito (DuckDuckGo · Google Noticias · Wikipedia)","Free (DuckDuckGo · Google News · Wikipedia)");
}

/* ---------- ¿esta consulta necesita internet? ---------- */
const V63_RX_SKIP=v63Rx("escrib[ií]\\w*|redact[aá]\\w*|traduc[ií]\\w*|resum[ií]\\w*|corrig[ieé]\\w*|depur[aá]\\w*|compil[aá]\\w*|refactoriz\\w*|implement[aá]\\w*|poema|cuento|chiste|write|rewrite|translate|summari[sz]e|debug|refactor");
const V63_RX_ASK=v63Rx("busc[aá](me|lo|la)?( en)? (internet|la web|google|online)|en internet|en la web|googlea\\w*|search (the )?(web|internet)|look (it )?up|on the web|online");
const V63_RX_NOW=v63Rx("hoy|ayer|mañana|ahora|actualmente|actual(es)?|hoy en día|últim[oa]s?|ultim[oa]s?|reciente(s|mente)?|nuev[oa]s?|novedad(es)?|noticias?|lanz(ó|o|aron|amiento|ado|ada)|anunci(ó|aron|ado)|precio(s)?|cotizaci[oó]n|d[oó]lar|inflaci[oó]n|clima|pron[oó]stico|resultado(s)?|partido|elecci[oó]n(es)?|encuesta(s)?|esta semana|este (mes|año)|en vivo|vigente|today|yesterday|tomorrow|currently|current|latest|recent(ly)?|newest|news|released?|launch(ed)?|announced?|prices?|stock|weather|score|this (week|month|year)");
const V63_RX_YEAR=/(^|\D)20(2[5-9]|[3-9]\d)(\D|$)/;
function v63NeedsWeb(txt){
  const t=(txt||"").toLowerCase().trim();
  if(t.length<6||t.length>1500) return false;
  if(t.indexOf("```")>=0) return false;
  if(V63_RX_ASK.test(t)) return true;
  if(V63_RX_SKIP.test(t)) return false;
  return V63_RX_NOW.test(t)||V63_RX_YEAR.test(t);
}
/* v6.5: ¿el usuario PIDIÓ buscar en internet? */
const V63_RX_EXPLICIT_START=/^(por favor,?\s*)?(busc[aá](me|lo|la|los|las|nos)?|googlea\w*|investig[aá](me|lo|la)?|please search|search for|look up|google)(\s|$|[,:.!?])/i;
const V63_RX_EXPLICIT_WEB=[
  /(busc\w*|googl\w*|investig\w*|consult\w*|revis[aá]\w*|fijate|verific\w*|cheque\w*|naveg\w*)[^.?!\n]{0,40}(internet|la web|en google|online|en l[ií]nea|la red)/i,
  /(con|citando|citá|cita|incluí|incluye|agregá|agrega)\s+(las\s+|sus\s+)?fuentes/i,
  /(search|look up|browse|check)[^.?!\n]{0,40}(the web|internet|online|google)/i,
  /(google it|look it up|search it)/i
];
const V63_RX_LOCALOBJ=/```|c[oó]digo|script|texto|archivo|adjunto|documento|lista|tabla|planilla|excel|pdf|imagen|conversaci[oó]n|chat|this (code|text|file)/i;
function v63Explicit(txt){
  const t=String(txt||"").trim(); if(!t||t.length>1500) return false;
  if(V63_RX_EXPLICIT_WEB.some(r=>r.test(t))) return true;
  return V63_RX_EXPLICIT_START.test(t)&&!V63_RX_LOCALOBJ.test(t);
}
/* respuesta afirmativa corta a la oferta «¿Querés que lo busque?» */
const V63_RX_YES=/^(s[ií]|sip|dale|ok|okay|de acuerdo|por favor|claro|obvio|buscalo|busc[aá]lo|busc[aá]|busca|hacelo|yes|yep|sure|go ahead|please( do)?|search( it)?)([\s,!.]+(s[ií]|dale|por favor|gracias|buscalo|busc[aá]lo|en internet|en la web|please|thanks))*[\s!.]*$/i;
function v63IsNews(q){ return V63_RX_NOW.test(q||"")||V63_RX_YEAR.test(q||""); }
/* «no tengo información», «mi fecha de corte»… → reintentar buscando */
const V63_RX_NOINFO=/(no (tengo|dispongo de|cuento con|poseo|encuentro|hay|encontr[eé]) (ninguna |mucha |suficiente )?(informaci[oó]n|datos|registros?|referencias?)|no estoy al tanto|no tengo conocimiento|no (me )?consta|no (conozco|reconozco) (ning[uú]n|ninguna|el|la|ese|esa|este|esta)|fecha (de )?(corte|l[ií]mite)|mi (conocimiento|entrenamiento|informaci[oó]n) (llega|est[aá] limitad[oa]|se limita|tiene (un )?l[ií]mite|es hasta)|hasta mi (última |ultima )?(actualizaci[oó]n|fecha)|no puedo (navegar|acceder a internet|buscar en internet|consultar internet)|no tengo acceso (a internet|a la web|en tiempo real|a informaci[oó]n (en tiempo real|actualizada))|knowledge cut-?off|as of my (last|latest) (update|training)|i (don't|do not) have (any )?(information|access|real-time|data|details)|i'?m not aware of|i am not aware of|no (information|data) (about|on))/i;
function v63SaysNoInfo(ans){ return V63_RX_NOINFO.test(String(ans||"").slice(0,1200)); }

/* ---------- red: proxy (fullstack) → directo, con tiempo máximo ---------- */
async function v63Fetch(url,opts,ms){
  opts=opts||{}; ms=ms||9000;
  const o={method:opts.method||"GET",headers:opts.headers||{}}; if(opts.body!=null) o.body=opts.body;
  const tmo=p=>Promise.race([p,new Promise((_,rej)=>setTimeout(()=>rej(new Error("timeout")),ms))]);
  let r=null, viaProxy=v63HasProxy();
  try{ r=await tmo(apiFetch(url,o)); }catch(e){ r=null; }
  if(r&&r.ok) return r;
  if(viaProxy){ try{ const d=await tmo(fetch(url,o)); if(d.ok) return d; }catch(e){} }   // proxy viejo / sin whitelist → directo
  return r;
}
function v63Clean(s,n){ return String(s||"").replace(/<[^>]+>/g," ").replace(/&nbsp;/g," ").replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,"&").replace(/\s+/g," ").trim().slice(0,n||600); }
function v63JinaH(extra){ const h=Object.assign({},extra||{}); const k=v63Key("jina"); if(k) h["Authorization"]="Bearer "+k; return h; }

/* ---------- proveedores ---------- */
async function v63Tavily(q){
  const r=await v63Fetch("https://api.tavily.com/search",{method:"POST",
    headers:{"Content-Type":"application/json","Authorization":"Bearer "+v63Key("tavily")},
    body:JSON.stringify({api_key:v63Key("tavily"),query:q,max_results:6,search_depth:"basic",include_answer:true})},14000);
  if(!r||!r.ok) throw new Error("Tavily "+(r?r.status:"sin respuesta"));
  const j=await r.json();
  return {answer:j.answer||"",items:(j.results||[]).map(x=>({title:v63Clean(x.title,160),url:x.url,snip:v63Clean(x.content,700),date:x.published_date||"",src:"Tavily"}))};
}
async function v63Jina(q){
  const r=await v63Fetch("https://s.jina.ai/?q="+encodeURIComponent(q),{headers:v63JinaH({"Accept":"application/json","X-Respond-With":"no-content"})},14000);
  if(!r||!r.ok) throw new Error("Jina "+(r?r.status:"sin respuesta"));
  const j=await r.json();
  return {items:((j&&j.data)||[]).map(x=>({title:v63Clean(x.title,160),url:x.url,snip:v63Clean(x.description||x.content,700),date:x.date||"",src:"Jina"}))};
}
function v63ParseDdg(html){
  const out=[]; if(!html) return out;
  const doc=new DOMParser().parseFromString(html,"text/html");
  doc.querySelectorAll(".result, .web-result").forEach(el=>{
    if(el.classList.contains("result--ad")) return;
    const a=el.querySelector("a.result__a"); if(!a) return;
    let u=a.getAttribute("href")||"";
    const m=u.match(/[?&]uddg=([^&]+)/); if(m){ try{ u=decodeURIComponent(m[1]); }catch(e){} }
    if(u.indexOf("//")===0) u="https:"+u;
    if(!/^https?:\/\//i.test(u)||/duckduckgo\.com\/(y\.js|l\/)/.test(u)) return;
    const s=el.querySelector(".result__snippet");
    out.push({title:v63Clean(a.textContent,160),url:u,snip:v63Clean(s?s.textContent:"",600),src:"DuckDuckGo"});
  });
  return out;
}
async function v63Ddg(q){
  const u="https://html.duckduckgo.com/html/?q="+encodeURIComponent(q)+"&kl=wt-wt";
  let items=[];
  if(v63HasProxy()){ try{ const r=await v63Fetch(u,{headers:{"Accept":"text/html"}},9000); if(r&&r.ok) items=v63ParseDdg(await r.text()); }catch(e){} }
  if(!items.length){ try{ const r=await v63Fetch("https://r.jina.ai/"+u,{headers:v63JinaH({"X-Return-Format":"html"})},12000); if(r&&r.ok) items=v63ParseDdg(await r.text()); }catch(e){} }
  return {items};
}
function v63ParseRss(xml){
  const out=[]; if(!xml||xml.indexOf("<item")<0) return out;
  const doc=new DOMParser().parseFromString(xml,"text/xml");
  doc.querySelectorAll("item").forEach(it=>{
    const g=t=>{ const n=it.querySelector(t); return n?n.textContent:""; };
    const title=v63Clean(g("title"),200), url=g("link").trim(), src=v63Clean(g("source"),80);
    if(title&&/^https?:/.test(url)) out.push({title,url,snip:src?(v60L("Fuente: ","Source: ")+src):"",date:g("pubDate"),src:"Google News"});
  });
  return out.slice(0,6);
}
async function v63News(q){
  const en=atlasLang==="en";
  const u="https://news.google.com/rss/search?q="+encodeURIComponent(q)+(en?"&hl=en-US&gl=US&ceid=US:en":"&hl=es-419&gl=AR&ceid=AR:es-419");
  let items=[];
  if(v63HasProxy()){ try{ const r=await v63Fetch(u,{headers:{"Accept":"application/rss+xml, text/xml"}},9000); if(r&&r.ok) items=v63ParseRss(await r.text()); }catch(e){} }
  if(!items.length){ try{ const r=await v63Fetch("https://r.jina.ai/"+u,{headers:v63JinaH({"X-Return-Format":"html"})},12000); if(r&&r.ok) items=v63ParseRss(await r.text()); }catch(e){} }
  return {items};
}
async function v63Wiki(q,lang){
  lang=lang||(atlasLang==="en"?"en":"es");
  const u="https://"+lang+".wikipedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrlimit=3&gsrsearch="+encodeURIComponent(q)+"&prop=extracts%7Cinfo&inprop=url&exintro=1&explaintext=1&exchars=900&exlimit=3";
  const r=await v63Fetch(u,{headers:{"Accept":"application/json"}},9000);
  if(!r||!r.ok) return {items:[]};
  const j=await r.json(); const pages=Object.values((j&&j.query&&j.query.pages)||{}).sort((a,b)=>(a.index||0)-(b.index||0));
  return {items:pages.map(p=>({title:"Wikipedia: "+p.title,url:p.fullurl||("https://"+lang+".wikipedia.org/wiki/"+encodeURIComponent(p.title)),snip:v63Clean(p.extract,900),src:"Wikipedia"}))};
}
async function v63DdgInstant(q){
  try{
    const r=await v63Fetch("https://api.duckduckgo.com/?format=json&no_html=1&skip_disambig=1&q="+encodeURIComponent(q),{},7000);
    if(!r||!r.ok) return {items:[]};
    const j=await r.json(); const items=[];
    if(j.AbstractText) items.push({title:j.Heading||q,url:j.AbstractURL||"",snip:v63Clean(j.AbstractText,900),src:"DuckDuckGo"});
    (j.RelatedTopics||[]).slice(0,4).forEach(t=>{ if(t&&t.Text&&t.FirstURL) items.push({title:v63Clean(t.Text,120),url:t.FirstURL,snip:v63Clean(t.Text,400),src:"DuckDuckGo"}); });
    return {items};
  }catch(e){ return {items:[]}; }
}
/* lee el contenido de una página (r.jina.ai, sin key: ~20 lecturas/min) */
async function v63Read(url,n){
  try{
    const r=await v63Fetch("https://r.jina.ai/"+url,{headers:v63JinaH({"Accept":"text/plain","X-Retain-Images":"none"})},9000);
    if(!r||!r.ok) return "";
    let t=await r.text(); const i=t.indexOf("Markdown Content:"); if(i>=0) t=t.slice(i+17);
    t=t.replace(/!\[[^\]]*\]\([^)]*\)/g,"").replace(/\[([^\]]*)\]\((https?:[^)]*)\)/g,"$1").replace(/\n{3,}/g,"\n\n").trim();
    return t.slice(0,n||2600);
  }catch(e){ return ""; }
}

/* ---------- orquestador de búsqueda ---------- */
function v63Status(s){
  try{ const vs=[...document.querySelectorAll("#msgs .row.bot .via")]; const v=vs[vs.length-1];
    if(v&&/^(🔎|📄)/.test(v.textContent.trim())&&v.closest(".row").querySelector(".content .typing")) v.textContent=s; }catch(e){}
}
function v63Query(q){
  q=String(q||"").replace(/\s+/g," ").trim();
  q=q.replace(/^(por favor,?\s*)?(busc[aá](me|lo|la|los|las)?|googlea\w*|investig[aá](me|lo|la)?|search( for)?|look up|google)\s*/i,"");
  q=q.replace(/^(en\s+)?(internet|la web|google|online)\s*/i,"");
  q=q.replace(/^(informaci[oó]n|info|datos|noticias|fuentes)?\s*(sobre|acerca de|de|del|respecto (a|de)|about|on)?\s*[:,-]?\s*/i,"");
  q=q.replace(/\s*(en|por|on|in)\s+(internet|la web|google|online|the web)\s*[.?!]*$/i,"").replace(/\s*(con|citando)\s+(las\s+)?fuentes\s*[.?!]*$/i,"");
  return q.slice(0,300);
}
async function v63Search(q0){
  const q=v63Query(q0);
  const res={q,items:[],answer:"",prov:[],read:[],text:""};
  if(!q) return res;
  const add=(r,name)=>{ if(r&&r.items&&r.items.length){ r.items.forEach(x=>{ if(x.url&&!res.items.some(y=>y.url===x.url)) res.items.push(x); }); if(!res.prov.includes(name)) res.prov.push(name); } if(r&&r.answer&&!res.answer) res.answer=r.answer; };
  if(v63Key("tavily")){ v63Status("🔎 "+v60L("Buscando con Tavily…","Searching with Tavily…")); try{ add(await v63Tavily(q),"Tavily"); }catch(e){ console.warn("v63 tavily",e); } }
  if(res.items.length<3&&v63Key("jina")){ v63Status("🔎 "+v60L("Buscando con Jina…","Searching with Jina…")); try{ add(await v63Jina(q),"Jina"); }catch(e){ console.warn("v63 jina",e); } }
  if(res.items.length<3){
    v63Status("🔎 "+v60L("Buscando en la web: DuckDuckGo · Google Noticias · Wikipedia…","Searching the web: DuckDuckGo · Google News · Wikipedia…"));
    const news=v63IsNews(q);
    const [d,n,w]=await Promise.allSettled([v63Ddg(q), news?v63News(q):Promise.resolve({items:[]}), v63Wiki(q)]);
    const D=d.status==="fulfilled"?d.value:null, N=n.status==="fulfilled"?n.value:null, Wk=w.status==="fulfilled"?w.value:null;
    if(news){ add(N,"Google News"); add(D,"DuckDuckGo"); } else { add(D,"DuckDuckGo"); }
    add(Wk,"Wikipedia");
    if(!res.items.length&&!news){ try{ add(await v63News(q),"Google News"); }catch(e){} }
    if(!res.items.length&&atlasLang!=="en"){ try{ add(await v63Wiki(q,"en"),"Wikipedia"); }catch(e){} }
  }
  if(!res.items.length){ try{ add(await v63DdgInstant(q),"DuckDuckGo"); }catch(e){} }
  res.items=res.items.slice(0,8);
  /* leer las 2 primeras páginas (no Wikipedia ni redirecciones de Google Noticias) */
  const toRead=res.items.filter(x=>x.src!=="Wikipedia"&&!/news\.google\.com/.test(x.url)).slice(0,res.prov.includes("Tavily")?1:2);
  if(toRead.length){
    v63Status("📄 "+v60L("Leyendo ","Reading ")+toRead.length+v60L(" página(s)…"," page(s)…"));
    const txts=await Promise.all(toRead.map(x=>v63Read(x.url,2600)));
    txts.forEach((t,i)=>{ if(t&&t.length>200) res.read.push({n:res.items.indexOf(toRead[i])+1,text:t}); });
  }
  res.text=v63Format(res);
  V63.last=res;
  return res;
}
function v63Format(res){
  if(!res.items.length&&!res.answer) return "";
  const en=atlasLang==="en";
  let s=(en?"Today's date: ":"Fecha de hoy: ")+v63Today()+".\n"+(en?"Search engines used: ":"Buscadores consultados: ")+res.prov.join(" · ")+"\n\n";
  if(res.answer) s+=(en?"Summary from the search engine: ":"Resumen del buscador: ")+v63Clean(res.answer,900)+"\n\n";
  res.items.forEach((x,i)=>{ s+="["+(i+1)+"] "+x.title+(x.date?" ("+x.date+")":"")+"\nURL: "+x.url+"\n"+(x.snip||"")+"\n\n"; });
  res.read.forEach(r=>{ s+="--- "+(en?"Page content ":"Contenido de la página ")+"["+r.n+"] ---\n"+r.text+"\n\n"; });
  s=s.slice(0,9000);
  s+=en?"\nINSTRUCTIONS: base your answer on these real results, cite them with their number [n]. If they do not contain the answer, say so plainly — do not invent. Keep today's date in mind when talking about “the latest”."
       :"\nINSTRUCCIONES: basá tu respuesta en estos resultados reales y citalos con su número [n]. Si no contienen la respuesta, decilo con claridad — no inventes. Tené en cuenta la fecha de hoy al hablar de «lo último».";
  return s;
}
function v63Sources(res){
  if(!res||!res.items||!res.items.length) return "";
  return "\n\n🔎 **"+v60L("Fuentes","Sources")+"** ("+res.prov.join(" · ")+"):\n"+res.items.slice(0,6).map((x,i)=>"["+(i+1)+"] ["+String(x.title||x.url).replace(/[\[\]]/g,"").slice(0,110)+"]("+x.url+")").join("\n");
}

/* los agentes con «Navegación Web» y el chat usan la nueva cadena */
agentWebSearch=async function(q){
  const r=await v63Search((V63.turn&&V63.turn.query)||q);
  if(V63.turn) V63.turn.searched=true;
  return r.text;
};

/* ---------- enlaces clicables en las respuestas ---------- */
const V63_md=md;
md=function(t){
  const h=V63_md(t==null?"":String(t));
  try{
    return h.split(/(<pre>[\s\S]*?<\/pre>|<code>[\s\S]*?<\/code>)/).map((seg,i)=>{
      if(i%2) return seg;
      seg=seg.replace(/【(\d+)†([^】]*)】/g,(_,n,x)=>{ const u=(x.match(/https?:\/\/[^\s】]+/)||[])[0]; return u?`<a href="${u.replace(/"/g,"%22")}" target="_blank" rel="noopener noreferrer">[${n}]</a>`:`[${n}]`; });
      seg=seg.replace(/\[([^\]\n]{1,220})\]\((https?:\/\/[^\s)]+)\)/g,(_,a,u)=>`<a href="${u.replace(/"/g,"%22")}" target="_blank" rel="noopener noreferrer">${a}</a>`);
      seg=seg.replace(/(^|[\s(\[])(https?:\/\/[^\s<>()"\]]+[^\s<>()".,;:!?'\]])/g,(_,p,u)=>`${p}<a href="${u}" target="_blank" rel="noopener noreferrer">${u}</a>`);
      return seg;
    }).join("");
  }catch(e){ return h; }
};

/* ---------- ＋ › Buscar en la web: ahora busca de verdad ---------- */
renderMode=function(){
  const el=$("mode-row"); if(!el) return;
  el.innerHTML=webMode?`<span class="mode-chip">🔎 ${v60L("Búsqueda web activada — la próxima consulta se busca en internet y se responde con fuentes","Web search on — your next message is searched on the internet and answered with sources")} <span class="x" onclick="webMode=false;renderMode()">✕</span></span>`:"";
};

/* ---------- envío (v6.5): busca SOLO si el usuario lo pide; si el modelo no sabe, ofrece buscar ---------- */
function v63PrevUserQ(c){
  if(!c) return "";
  for(let i=c.msgs.length-1;i>=0;i--){ const m=c.msgs[i]; if(m.role==="user"){ const t=String(m.content||"").split("\n📎")[0].trim(); if(!v63Explicit(t)||v63Query(t).length>=4) return v63Query(t)||t; } }
  return "";
}
const V63_send=send;
send=async function(){
  const txt=((typeof inp!=="undefined"&&inp&&inp.value)||"").trim();
  if(busy||(!txt&&!atts.length)) return V63_send.apply(this,arguments);
  const c0=curId?cur():null;
  /* respuesta «sí / buscalo» a la oferta pendiente */
  if(V63.offer&&c0&&curId===V63.offer.cid&&txt&&!atts.length&&V63_RX_YES.test(txt)){
    inp.value=""; inp.style.height="auto";
    c0.msgs.push({role:"user",content:txt}); addRow("user",txt); save(); scrollDown();
    const o=V63.offer; v63OfferClear(); await v63Retry(c0,o.q,o.cut); return;
  }
  v63OfferClear();
  if(c0&&c0.web&&!c0.sys) c0.web=false;          // chats comunes con la marca web «pegada» (v6.3): ya no buscan solos
  const forced=!!webMode, explicit=!!txt&&v63Explicit(txt);
  const want=!!txt&&(forced||explicit);
  if(forced){ webMode=false; renderMode(); }
  let query="";
  if(want){ query=v63Query(txt); if(query.length<4) query=v63PrevUserQ(c0)||txt; }
  const agentWeb=c0?!!c0.web:!!agentWebPending;
  const idBefore=curId, lenBefore=c0?c0.msgs.length:0;
  V63.turn={want:want||agentWeb,why:forced?"manual":(explicit?"explicit":""),txt,query,searched:false};
  let restore=null;
  if(want&&!agentWeb){
    if(c0){ c0.web=true; restore=()=>{ c0.web=false; }; }
    else { agentWebPending=true; restore=()=>{ agentWebPending=false; const c=curId&&cur(); if(c&&c.id!==idBefore) c.web=false; }; }
  }
  let p;
  try{ p=V63_send.apply(this,arguments); }
  finally{ if(restore) restore(); }        // el envío original ya leyó c.web (parte sincrónica)
  const turn=V63.turn;
  try{ await p; }
  finally{
    try{
      const c=curId&&cur();
      if(c){
        const start=(c.id===idBefore?lenBefore:0)+1;
        const news=c.msgs.slice(start).filter(m=>m.role==="assistant");
        if(turn.searched&&V63.last&&news.length){ v63TagWeb(news); save(); }
        else{
          save();
          const noInfo=news.filter(m=>v63SaysNoInfo(m.content)).length;
          if(!turn.searched&&txt&&v63AutoOn()&&news.length&&(v63SaysNoInfo(news[news.length-1].content)||noInfo*2>=news.length&&noInfo>0))
            v63Offer(c,v63Query(txt)||txt,start);
        }
      }
    }catch(e){ console.error("v63 send",e); }
    V63.turn=null;
  }
};
/* oferta: «Los modelos no tienen esta información… ¿Querés que la busque en internet?» */
function v63Offer(c,q,cut){
  v63OfferClear();
  const row=addRow("assistant","","🔎 "+v60L("Búsqueda web","Web search"));
  row.classList.add("v63-offer");
  row.querySelector(".content").innerHTML=`<div class="v63-offer-box"><div>${v60L("Los modelos no tienen esta información en su conocimiento (se entrenaron hasta una fecha de corte). ¿Querés que la busque en internet?","The models don't have this information in their knowledge (they were trained up to a cutoff date). Do you want me to search the internet?")}</div>
    <div class="v63-offer-btns"><button class="btn dark sm" onclick="v63OfferYes()">🔎 ${v60L("Sí, buscar en la web","Yes, search the web")}</button><button class="btn sm" onclick="v63OfferNo()">${v60L("No, gracias","No, thanks")}</button></div></div>`;
  V63.offer={cid:c.id,q,cut,row}; scrollDown();
}
function v63OfferClear(){ try{ if(V63.offer&&V63.offer.row) V63.offer.row.remove(); }catch(e){} V63.offer=null; }
async function v63OfferYes(){
  const o=V63.offer; if(!o||busy) return;
  v63OfferClear();
  const c=chats.find(x=>x.id===o.cid); if(!c||curId!==o.cid) return;
  await v63Retry(c,o.q,o.cut);
}
function v63OfferNo(){ v63OfferClear(); try{ inp.focus(); }catch(e){} }
function v63TagWeb(news){
  const res=V63.last, rows=[...document.querySelectorAll("#msgs .row.bot")].slice(-news.length);
  news.forEach((m,i)=>{
    const last=i===news.length-1;
    if(!/🔎 web/.test(m.meta||"")) m.meta=(m.meta||"")+" · 🔎 web";
    if(last&&res.items.length&&m.content.indexOf("🔎 **"+v60L("Fuentes","Sources"))<0) m.content+=v63Sources(res);
    const row=rows[i]; if(row){ const v=row.querySelector(".via"); if(v) v.textContent=m.meta; const ct=row.querySelector(".content"); if(ct&&last) ct.innerHTML=md(m.content); }
  });
}
async function v63Retry(c,txt,cutAt){
  const row=addRow("assistant","","🔎 "+v60L("Buscando en internet…","Searching the internet…"));
  row.querySelector(".content").innerHTML='<span class="typing"></span>'; scrollDown();
  busy=true; $("send").disabled=true;
  try{
    const res=await v63Search(txt);
    if(!res.text){ row.querySelector(".via").textContent="🔎 "+v60L("Búsqueda web sin resultados","Web search returned no results"); row.querySelector(".content").innerHTML='<span class="dim">'+v60L("No encontré resultados en la web para esta consulta.","I couldn't find web results for this query.")+'</span>'; return; }
    let pk=MODELS[curModel]&&MODELS[curModel].prov;
    if(!pk||!connected(pk)||pk==="basic") pk=["anthropic","openai","gemini","groq","deepseek","hf","other","zai","kimi"].find(connected)||pk||"basic";
    const tight=["groq","webllm"].includes(pk);
    const hist=[]; let cut=c.msgs.length; if(cutAt>0&&cutAt<=c.msgs.length) cut=cutAt; else for(let i=c.msgs.length-1;i>=0;i--){ if(c.msgs[i].role==="user"){ cut=i+1; break; } }
    c.msgs.slice(0,cut).slice(tight?-6:-10).forEach(m=>hist.push({role:m.role==="assistant"?"assistant":"user",content:String(m.content||"").slice(0,tight?4000:12000)}));
    const sys=[c.sys&&c.sys.slice(0,tight?6000:30000),
      (atlasLang==="en"?"===== LIVE WEB SEARCH RESULTS for: ":"===== RESULTADOS DE BÚSQUEDA WEB EN VIVO para: ")+"\""+txt+"\" =====\n"+res.text,
      atlasLang==="en"?"Always respond in English.":""].filter(Boolean).join("\n\n");
    row.querySelector(".via").textContent="🔎 "+v60L("Respondiendo con los resultados…","Answering with the results…")+" · "+provShort(pk);
    const ans=await callProvider(pk,cfg[pk]||{},hist,sys);
    const content=String(ans||"")+v63Sources(res);
    const meta="🔎 "+v60L("Respuesta con búsqueda web","Answer with web search")+" · "+provShort(pk)+" · "+provModel(pk);
    row.remove(); addRow("assistant",content,meta); c.msgs.push({role:"assistant",content,meta}); save(); scrollDown();
  }catch(e){
    row.querySelector(".via").textContent="⚠️ "+v60L("Búsqueda web","Web search");
    row.querySelector(".content").innerHTML='<span class="err">⚠️ '+esc((e&&e.message||e)+"")+"</span>";
  }finally{ busy=false; $("send").disabled=false; }
}

/* ---------- interruptor en el menú del Router y en la vista Router ---------- */
const V63_renderRoute=renderRoute;
renderRoute=function(){
  V63_renderRoute.apply(this,arguments);
  const rm=$("route-menu"); if(!rm) return;
  const sw=`<span class="switch ${v63AutoOn()?"on":""}" title="${v60L("Si los modelos no tienen el dato, AR.T.L.A.S. te pregunta si querés buscarlo en internet","If the models don't know, AR.T.L.A.S. asks whether you want to search the internet")}" onclick="event.stopPropagation();v63SetAuto(!v63AutoOn())"><i></i>🔎 ${v60L("Ofrecer búsqueda","Offer search")}</span>`;
  const fb=rm.querySelector(":scope > div:last-child .switch");
  if(fb) fb.insertAdjacentHTML("afterend",sw); else rm.insertAdjacentHTML("beforeend",`<div class="v63-rrow">${sw}</div>`);
};
const V63_renderRouter=v60RenderRouter;
v60RenderRouter=function(){
  V63_renderRouter.apply(this,arguments);
  const el=$("router-inner"); if(!el) return;
  el.insertAdjacentHTML("beforeend",`<div class="card mt"><h4>🔎 ${v60L("Búsqueda web en el chat","Web search in chat")}</h4>
    <span class="switch ${v63AutoOn()?"on":""}" onclick="v63SetAuto(!v63AutoOn())"><i></i>${v60L("Ofrecer búsqueda web cuando los modelos no tienen el dato","Offer a web search when the models don't know")}</span>
    <div class="kv mt"><span>${v60L("Motor","Engine")}</span><b>${v60Esc(v63Engine())}</b></div>
    <div class="kv"><span>${v60L("Se activa","Triggers")}</span><b>${v60L("cuando lo pedís («buscá…», «buscalo en internet», «con fuentes») · ＋ › Buscar en la web · o si aceptás la oferta cuando los modelos no tienen el dato","when you ask for it (“search…”, “look it up”, “with sources”) · ＋ › Search the web · or when you accept the offer if the models don't know")}</b></div>
    <div class="note">${v60L("Sin claves usa DuckDuckGo, Google Noticias y Wikipedia (gratis). Para resultados más rápidos y estables, cargá una key gratuita de Tavily o Jina en Proveedores de modelos.","Without keys it uses DuckDuckGo, Google News and Wikipedia (free). For faster, more reliable results add a free Tavily or Jina key in Model Providers.")}</div>
    <div style="margin-top:10px"><button class="btn" onclick="openSettings();setTimeout(()=>{const x=$('v63-search-card');if(x)x.scrollIntoView({behavior:'smooth',block:'center'})},120)">🔑 ${v60L("Claves de búsqueda","Search keys")}</button></div></div>`);
};

/* ---------- tarjeta de claves de búsqueda en Proveedores ---------- */
function v63SettingsCard(){
  const pl=$("prov-list"); if(!pl||!$("overlay")||!$("overlay").classList.contains("open")) return;
  const old=$("v63-search-card"); const tv=old?($("key-tavily")||{}).value:null, jn=old?($("key-jina")||{}).value:null;
  if(old) old.remove();
  pl.insertAdjacentHTML("beforeend",`<div class="prov-card" id="v63-search-card"><div class="prov-head"><b>🔎 ${v60L("Búsqueda web (chat y agentes)","Web search (chat & agents)")}</b>
      <span><button class="test-btn" onclick="v63TestSearch()">${v60L("Probar búsqueda","Test search")}</button><span class="test-res" id="tr-search"></span></span></div>
    <div class="prov-grid">
      <div><label>Tavily API key (tvly-…) · ${v60L("opcional","optional")}</label><input id="key-tavily" type="password" autocomplete="new-password" spellcheck="false" data-lpignore="true" data-1p-ignore data-form-type="other" placeholder="${v60L("recomendada — 1000 búsquedas/mes gratis","recommended — 1,000 free searches/month")}"></div>
      <div><label>${v60L("Ofrecer búsqueda","Offer search")}</label><span class="switch ${v63AutoOn()?"on":""}" style="margin-top:6px" onclick="v63SetAuto(!v63AutoOn())"><i></i>${v63AutoOn()?"ON":"OFF"}</span></div>
      <div><label>Jina API key (jina_…) · ${v60L("opcional","optional")}</label><input id="key-jina" type="password" autocomplete="new-password" spellcheck="false" data-lpignore="true" data-1p-ignore data-form-type="other" placeholder="${v60L("alternativa — también acelera la lectura de páginas","alternative — also speeds up page reading")}"></div>
      <div><label>${v60L("Motor actual","Current engine")}</label><div style="font-size:12.5px;padding:8px 2px;font-weight:600;color:var(--navy)">${v60Esc(v63Engine())}</div></div>
    </div>
    <div class="prov-note">${v60L("Sin claves funciona gratis con DuckDuckGo, Google Noticias y Wikipedia. Keys gratuitas: <a href='https://app.tavily.com' target='_blank' rel='noopener'>app.tavily.com</a> · <a href='https://jina.ai/?sui=apikey' target='_blank' rel='noopener'>jina.ai</a>. Se guardan como las demás API keys (local, sesión o bóveda cifrada).","Works for free without keys using DuckDuckGo, Google News and Wikipedia. Free keys: <a href='https://app.tavily.com' target='_blank' rel='noopener'>app.tavily.com</a> · <a href='https://jina.ai/?sui=apikey' target='_blank' rel='noopener'>jina.ai</a>. Stored like your other API keys (local, session or encrypted vault).")}</div></div>`);
  $("key-tavily").value=tv!=null?tv:v63Key("tavily");
  $("key-jina").value=jn!=null?jn:v63Key("jina");
}
function v63ReadKeys(){
  const t=$("key-tavily"), j=$("key-jina"); if(!t||!j) return;
  cfg.tavily=Object.assign({},cfg.tavily||{},{key:t.value.trim()});
  cfg.jina=Object.assign({},cfg.jina||{},{key:j.value.trim()});
  if(!cfg.tavily.key) delete cfg.tavily.key;
  if(!cfg.jina.key) delete cfg.jina.key;
}
async function v63TestSearch(){
  v63ReadKeys();
  const o=$("tr-search"); if(o){ o.textContent="⏳"; o.className="test-res"; }
  const t0=Date.now();
  try{
    const r=await v63Search(v60L("noticias inteligencia artificial hoy","artificial intelligence news today"));
    if(o){ if(r.items.length){ o.textContent="✓ "+r.items.length+" "+v60L("resultados","results")+" · "+r.prov.join(" · ")+" · "+((Date.now()-t0)/1000).toFixed(1)+" s"; o.className="test-res ok"; }
           else { o.textContent="⚠ "+v60L("sin resultados","no results"); o.className="test-res bad"; } }
  }catch(e){ if(o){ o.textContent="⚠ "+(e.message||e); o.className="test-res bad"; } }
}
const V63_openSettings=openSettings;
openSettings=function(){ V63_openSettings.apply(this,arguments); try{ v63SettingsCard(); }catch(e){ console.error("v63 card",e); } };
const V63_saveSettings=saveSettings;
saveSettings=function(){ try{ v63ReadKeys(); }catch(e){} return V63_saveSettings.apply(this,arguments); };

/* ---------- 👁 ver / ocultar la clave ---------- */
const V63_EYE='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-7.5 11-7.5S23 12 23 12s-4 7.5-11 7.5S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';
const V63_EYE_OFF='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 19.5C5 19.5 1 12 1 12a18.5 18.5 0 0 1 5.06-5.94M9.9 4.74A9.12 9.12 0 0 1 12 4.5c7 0 11 7.5 11 7.5a18.5 18.5 0 0 1-2.16 3.19M14.12 14.12a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
function v63EyeSet(b,inpEl,show){
  inpEl.type=show?"text":"password";
  b.classList.toggle("on",show); b.innerHTML=show?V63_EYE_OFF:V63_EYE;
  const t=show?v60L("Ocultar clave","Hide password"):v60L("Mostrar clave","Show password");
  b.title=t; b.setAttribute("aria-label",t); b.setAttribute("aria-pressed",show?"true":"false");
}
function v63EyeOne(inpEl){
  if(!inpEl||inpEl.dataset.v63eye||!inpEl.parentNode) return;
  inpEl.dataset.v63eye="1";
  const w=document.createElement("span"); w.className="v63-pw";
  inpEl.parentNode.insertBefore(w,inpEl); w.appendChild(inpEl);
  const b=document.createElement("button"); b.type="button"; b.className="v63-eye";
  v63EyeSet(b,inpEl,false);
  b.addEventListener("mousedown",e=>e.preventDefault());          // no robar el foco del campo
  b.addEventListener("click",e=>{
    e.preventDefault(); e.stopPropagation();
    v63EyeSet(b,inpEl,inpEl.type==="password");
    try{ inpEl.focus(); const n=inpEl.value.length; inpEl.setSelectionRange(n,n); }catch(x){}
  });
  w.appendChild(b);
}
function v63EyeScan(){ try{ document.querySelectorAll('input[type="password"]:not([data-v63eye])').forEach(v63EyeOne); }catch(e){} }
function v63EyeResetAll(){
  document.querySelectorAll(".v63-pw").forEach(w=>{ const i=w.querySelector("input"), b=w.querySelector(".v63-eye"); if(i&&b&&i.type==="text") v63EyeSet(b,i,false); });
}
(function(){
  let pend=false;
  const mo=new MutationObserver(()=>{ if(pend) return; pend=true; requestAnimationFrame(()=>{ pend=false; v63EyeScan(); }); });
  try{ mo.observe(document.body,{childList:true,subtree:true}); }catch(e){}
})();
/* al abrir/cerrar los modales, la clave vuelve a quedar oculta */
v60Wrap("openUser",()=>{ v63EyeScan(); v63EyeResetAll(); });
v60Wrap("closeUser",()=>v63EyeResetAll());
v60Wrap("closeSettings",()=>v63EyeResetAll());

/* ---------- v6.5: una conversación nueva NO hereda la navegación web de un agente ---------- */
const V65_newChat=newChat;
newChat=function(){ agentWebPending=false; v63OfferClear(); return V65_newChat.apply(this,arguments); };   // agentChat() la vuelve a activar después, si el agente la tiene
v60Wrap("openChat",()=>v63OfferClear());

/* ---------- textos del menú ＋ y arranque ---------- */
function v63Decorate(){
  try{
    const it=[...document.querySelectorAll("#plus-menu .pm-item")].find(x=>/pmWeb/.test(x.getAttribute("onclick")||""));
    if(it){ const d=it.querySelector("div"); if(d) d.innerHTML=`<b>${v60L("Buscar en la web","Search the web")}</b><br><small>${v60L("Busca en internet y responde con fuentes","Searches the internet and answers with sources")}</small>`; }
  }catch(e){}
  v63EyeScan(); renderMode();
}
const V63_toggleLang=toggleLang;
toggleLang=function(){ V63_toggleLang.apply(this,arguments); try{ v63Decorate(); v63EyeScan(); }catch(e){} };
