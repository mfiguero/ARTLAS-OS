# AR.T.L.A.S. v6.7 — Versión FULLSTACK ENDURECIDA (proxy protegido)

> v60: nueva pantalla de acceso (con modo invitado/demo), Command Center, AR.T.L.A.S. Router
> (estrategias + fallback), Control Center, Skills para agentes y bóveda cifrada de API keys.
> v6.3: búsqueda web real en el chat (automática / ＋ › Buscar en la web / reintento si el modelo
> «no tiene información»), botón 👁 para ver la clave y anti-caché de app.js.
> v6.7: portada indexable por Google (index.html con contenido, robots.txt, sitemap.xml,
> vista previa para redes og-image.png y verificación de Search Console).
> Ver ARTLAS-HANDOFF-v64.md, ARTLAS-HANDOFF-v63.md, ARTLAS-HANDOFF-v62.md, ARTLAS-HANDOFF-v61.md y ARTLAS-HANDOFF-v60.md.

Igual que la fullstack, pero el proxy `/api/proxy` está blindado para que nadie
lo use como proxy abierto:

1. **Whitelist de dominios**: solo reenvía a APIs de proveedores de IA conocidos
   (OpenAI, Anthropic, Gemini, Groq, HuggingFace, OpenRouter, DeepSeek, Kimi, Z.AI,
   Together, Pollinations, Hack Club…) y, desde v6.3, a los buscadores de la búsqueda
   web (Tavily, Jina, DuckDuckGo, Google Noticias, Wikipedia). Cualquier otro dominio → 403.
2. **Límite por IP**: por defecto 60 peticiones/minuto por IP (429 si se pasa).
   Ajustable con la variable de entorno `PROXY_RATE_MAX`.
3. **Restricción de origen (opcional)**: si seteás la variable de entorno
   `ALLOWED_ORIGINS` con tu dominio (ej. `https://tu-sitio.netlify.app`), el proxy
   SOLO aceptará peticiones desde tu sitio. Si la dejás vacía, acepta cualquier origen.

## Deploy en Netlify
1. Arrastrá esta carpeta a https://app.netlify.com/drop  (o conectá el repo).
2. (Opcional, recomendado) En Netlify → Site settings → Environment variables:
   - `ALLOWED_ORIGINS` = `https://TU-SITIO.netlify.app`
   - `PROXY_RATE_MAX`  = `60`  (o el número que prefieras)
3. Re-deploy si cambiaste variables.

> **Importante al actualizar:** subí la carpeta COMPLETA (incluida `netlify/functions/proxy.js`
> y `netlify.toml`). `app.html` carga `app.js?v=6.4` y `netlify.toml` fija `Cache-Control: no-cache`,
> así el navegador no sigue usando un app.js viejo.

> Cada usuario sigue usando SUS propias API keys (no las tuyas). El proxy solo
> evita el bloqueo CORS; no comparte cuota tuya salvo que hardcodees una key.

Diseñado por el Prof. Mario M. Figueroa de la Cruz


## Supabase keep-alive (v61)
La función programada `supabase-keepalive` hace un ping cada 12 h para que el proyecto gratuito de
Supabase no se pause por inactividad (solo corre en el deploy publicado; probala con «Run now» en
Netlify → Functions). Variables opcionales: `SUPABASE_URL`, `SUPABASE_ANON_KEY`.
