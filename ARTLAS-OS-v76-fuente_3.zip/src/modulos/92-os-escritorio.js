
/* =====================================================================
   AR.T.L.A.S. · Módulo 92 · AR.T.L.A.S. OS — ESCRITORIO
   Entorno operativo de IA sobre la plataforma: escritorio, ventanas,
   barra de tareas, lanzador y registro de aplicaciones.
   No toca la base: el chat clásico sigue intacto y se abre como «AR.T.L.A.S.».
     aosOpen()            → entra al modo OS     (también app.html?os=1)
     aosClose()           → vuelve a la plataforma clásica
     aosLaunch(id,opts)   → abre una aplicación del OS en una ventana
   Las apps se registran en AOS.apps (módulos 93–96).
   ===================================================================== */
const AOS={ver:"__ARTLAS_VER__", on:false, apps:{}, wins:[], z:20, seq:0, notifs:[]};
function aosEsc(s){ return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;"); }
function aosL(es,en){ try{ return v60L(es,en); }catch(e){ return es; } }
function aosMobile(){ return window.innerWidth<760; }
function aosFmtBytes(n){ n=+n||0; const u=["B","KB","MB","GB","TB"]; let i=0; while(n>=1024&&i<u.length-1){ n/=1024; i++; } return (i?n.toFixed(n<10?1:0):n)+" "+u[i]; }
function aosFmtDate(ms){ if(!ms) return ""; try{ return new Date(ms).toLocaleString(atlasLang==="en"?"en-US":"es-AR",{day:"2-digit",month:"2-digit",year:"2-digit",hour:"2-digit",minute:"2-digit"}); }catch(e){ return ""; } }

/* ---------- íconos (trazo, sin dependencias) ---------- */
const AOS_IC={
  chat:'<path d="M4 5h16v11H9l-5 4z"/><path d="M8 9h8M8 12h5"/>',
  folder:'<path d="M3 6h6l2 2h10v11H3z"/>',
  apps:'<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
  term:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9l3 3-3 3M12 15h5"/>',
  pulse:'<path d="M3 12h4l2-5 4 10 2-5h6"/>',
  chip:'<rect x="7" y="7" width="10" height="10" rx="1"/><path d="M9 3v4M15 3v4M9 17v4M15 17v4M3 9h4M3 15h4M17 9h4M17 15h4"/>',
  gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2"/>',
  atlas:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
  file:'<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/>',
  edit:'<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  trash:'<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  grid:'<circle cx="6" cy="6" r="1.5"/><circle cx="12" cy="6" r="1.5"/><circle cx="18" cy="6" r="1.5"/><circle cx="6" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="18" cy="12" r="1.5"/><circle cx="6" cy="18" r="1.5"/><circle cx="12" cy="18" r="1.5"/><circle cx="18" cy="18" r="1.5"/>',
  plug:'<path d="M9 3v5M15 3v5M6 8h12v4a6 6 0 0 1-12 0zM12 18v3"/>',
  close:'<path d="M6 6l12 12M18 6L6 18"/>',
  min:'<path d="M6 17h12"/>',
  max:'<rect x="5" y="5" width="14" height="14" rx="1"/>',
  up:'<path d="M12 19V5M6 11l6-6 6 6"/>',
  search:'<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/>',
  send:'<path d="M4 12l16-8-6 16-2-6z"/>',
  exit:'<path d="M14 4h6v16h-6M10 8l-4 4 4 4M6 12h10"/>',
  log:'<path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h5"/>'
};
function aosIcon(k,sz){ sz=sz||18; return `<svg class="aos-ic" width="${sz}" height="${sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${AOS_IC[k]||AOS_IC.file}</svg>`; }

/* ---------- estilos (todo bajo #aos) ---------- */
function aosCss(){
  if($("aos-css")) return;
  const grid=encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800" fill="none" stroke="#4f9cf9" stroke-opacity=".10" stroke-width="1"><ellipse cx="600" cy="400" rx="560" ry="340"/><ellipse cx="600" cy="400" rx="420" ry="340"/><ellipse cx="600" cy="400" rx="260" ry="340"/><ellipse cx="600" cy="400" rx="90" ry="340"/><path d="M40 400h1120M80 230h1040M80 570h1040M190 110h820M190 690h820"/></svg>');
  const s=document.createElement("style"); s.id="aos-css";
  s.textContent=`
#aos{position:fixed;inset:0;z-index:280;display:flex;flex-direction:column;color:#0d0d0d;font-size:13px;
  background:url("data:image/svg+xml,${grid}") center/cover no-repeat,radial-gradient(ellipse 58% 68% at 50% 46%,#0c55b4 0%,#0a3f8f 30%,#062b6a 58%,#031a46 82%,#02112f 100%);background-color:#031a46;user-select:none;-webkit-user-select:none;font-family:inherit}
#aos .aos-ic{flex:none}
body.aos-on #overlay{z-index:9700}
#aos-top{height:40px;display:flex;align-items:center;gap:0;padding:0 16px;background:linear-gradient(180deg,rgba(3,14,40,.92),rgba(4,20,52,.82));border-bottom:1px solid rgba(56,170,255,.22);color:#dbe6f3;font-size:13px;backdrop-filter:blur(8px);position:relative;z-index:2}
#aos-top .brand{display:flex;align-items:center;gap:9px;font-weight:700;letter-spacing:4px;color:#fff;white-space:nowrap;font-size:14.5px}
#aos-top .brand .lg{height:28px;width:auto;filter:drop-shadow(0 0 6px rgba(56,200,255,.45))}
#aos-top .brand small{font-weight:500;letter-spacing:.5px;color:#38c8ff;margin-left:2px;font-size:12.5px}
#aos-top>.aos-st,#aos-top>#aos-clock{padding:3px 14px;border-left:1px solid rgba(120,180,255,.28);border-radius:0}
#aos-top>#aos-st-ia{border-left:none}
#aos-top .aos-exit{display:flex;align-items:center;gap:0;position:relative}
#aos-top .aos-exit img{height:26px;width:auto;filter:drop-shadow(0 0 5px rgba(56,200,255,.5))}
#aos-top .aos-exit .lbx{color:#38c8ff;font-weight:600;font-size:12.5px;margin-left:-6px;text-shadow:0 0 6px rgba(0,0,0,.6)}
#aos-top .sp{flex:1}
#aos-top .aos-st{display:flex;align-items:center;gap:6px;cursor:pointer;padding:3px 8px;border-radius:6px;white-space:nowrap;flex:none}
#aos-top #aos-lb-ia{display:block;max-width:280px;overflow:hidden;text-overflow:ellipsis}
#aos-clock{white-space:nowrap}
#aos-top .aos-st:hover{background:rgba(255,255,255,.07)}
#aos-top .dot{width:7px;height:7px;border-radius:50%;background:#8f8f8f}
#aos-top .dot.ok{background:#22d36b;box-shadow:0 0 0 3px rgba(34,211,107,.18),0 0 8px rgba(34,211,107,.7)} #aos-top .dot.warn{background:#e8a13c}
#aos-desk{flex:1;position:relative;overflow:hidden}
#aos-desk::after{content:"";position:absolute;left:18%;right:18%;bottom:-38px;height:90px;pointer-events:none;background:radial-gradient(ellipse 50% 50% at 50% 50%,rgba(64,190,255,.55),rgba(30,120,255,.18) 45%,transparent 72%);z-index:0}
#aos-hero{position:absolute;left:50%;top:47%;transform:translate(-50%,-50%);display:flex;flex-direction:column;align-items:center;pointer-events:none;z-index:0;text-align:center;width:min(640px,90%)}
#aos-hero img{width:clamp(130px,min(19vw,30vh),290px);height:auto;filter:drop-shadow(0 0 22px rgba(30,160,255,.45))}
#aos-hero .t{margin-top:clamp(10px,2.2vh,24px);font-size:clamp(22px,min(2.9vw,5.4vh),44px);font-weight:800;letter-spacing:.32em;color:#f4f9ff;white-space:nowrap;text-shadow:0 0 18px rgba(80,170,255,.35);padding-left:.32em}
#aos-hero .t b{color:#22c4ff;font-weight:800;text-shadow:0 0 16px rgba(34,196,255,.55)}
#aos-hero .s{margin-top:10px;font-size:clamp(11px,1.05vw,15px);letter-spacing:.22em;color:#8fd3ff;font-weight:500;white-space:nowrap}
#aos{--ti:clamp(40px,min(4vw,8.6vh),80px);--ih:calc(var(--ti) * 1.5 + 12px)}
#aos-icons{position:absolute;top:calc(var(--ti) * .3);left:calc(var(--ti) * .32);display:grid;grid-auto-flow:column;grid-template-rows:repeat(auto-fill,var(--ih));column-gap:calc(var(--ti) * .14);row-gap:calc(var(--ti) * .08);max-height:calc(100% - 20px);z-index:1}
.aos-dicon{width:calc(var(--ti) * 1.72);height:var(--ih);display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding-top:calc(var(--ti) * .06);gap:calc(var(--ti) * .1);color:#f2f7ff;border-radius:12px;cursor:pointer;font-size:clamp(11px,calc(var(--ti) * .19),14px);font-weight:500;text-align:center;line-height:1.2;border:1px solid transparent;background:none;text-shadow:0 1px 4px rgba(0,0,0,.55)}
.aos-dicon .ib{width:var(--ti);height:var(--ti);border-radius:calc(var(--ti) * .23);display:flex;align-items:center;justify-content:center;background:linear-gradient(180deg,#0b3c8c,#061f52);color:#7fd8ff;border:1px solid rgba(80,170,255,.4);box-shadow:0 6px 16px rgba(0,8,30,.45);transition:transform .15s ease,filter .15s ease}
.aos-dicon img.ib{background:none;border:none;object-fit:contain}
.aos-dicon:hover .ib,.aos-dicon:focus-visible .ib{transform:translateY(-2px);filter:brightness(1.15) drop-shadow(0 0 10px rgba(56,190,255,.55))}
.aos-dicon:hover,.aos-dicon:focus-visible{background:rgba(120,190,255,.07);border-color:rgba(120,190,255,.16);outline:none}
.aos-dicon.main .ib{filter:drop-shadow(0 0 12px rgba(40,190,255,.6))}
.aos-dicon.main>span:last-child{box-shadow:0 2px 0 #38c8ff;padding-bottom:2px}
@media (min-width:760px) and (min-height:520px){ #aos-icons{grid-template-rows:repeat(4,var(--ih))} }
@media (min-width:1500px){ #aos-top{font-size:14px} #aos-top .brand{font-size:16px} }
.aos-win{position:absolute;display:flex;flex-direction:column;background:#fff;border-radius:10px;overflow:hidden;min-width:300px;min-height:200px;
  box-shadow:0 18px 50px rgba(3,14,36,.45),0 0 0 1px rgba(13,43,94,.25);user-select:text;-webkit-user-select:text}
.aos-win.max{left:0!important;top:0!important;width:100%!important;height:100%!important;border-radius:0}
.aos-win.min{display:none}
.aos-win.focus{box-shadow:0 22px 60px rgba(3,14,36,.55),0 0 0 1px #4f9cf9}
.aos-tb{height:36px;flex:none;display:flex;align-items:center;gap:8px;padding:0 6px 0 12px;background:#f4f8fd;border-bottom:1px solid #dbe6f3;color:#0d2b5e;font-weight:600;font-size:12.5px;cursor:default;user-select:none}
.aos-tb .t{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.aos-tb button{width:28px;height:26px;border:none;background:none;border-radius:6px;color:#0d2b5e;display:flex;align-items:center;justify-content:center}
.aos-tb button:hover{background:#e3edf9} .aos-tb button.x:hover{background:#ef4146;color:#fff}
.aos-body{flex:1;overflow:auto;position:relative;display:flex;flex-direction:column}
.aos-rs{position:absolute;right:0;bottom:0;width:16px;height:16px;cursor:nwse-resize;z-index:2}
#aos-bar{height:66px;flex:none;display:flex;align-items:center;gap:16px;padding:0 20px;background:linear-gradient(180deg,rgba(4,20,52,.86),rgba(3,14,40,.94));backdrop-filter:blur(10px);border-top:1px solid rgba(56,170,255,.2);position:relative;z-index:2}
#aos-bar .lb{flex:none;width:50px;height:46px;border-radius:10px;border:none;background:linear-gradient(180deg,#2aa3ff,#1565e0);color:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 14px rgba(21,120,255,.45),inset 0 1px 0 rgba(255,255,255,.25)}
#aos-bar .lb:hover{filter:brightness(1.12)}
#aos-ask{flex:0 1 560px;display:flex;align-items:center;gap:10px;background:rgba(8,32,78,.72);border:1px solid rgba(70,150,255,.38);border-radius:10px;padding:0 8px 0 14px;height:46px;color:#fff}
#aos-ask .mg{color:#5cc8ff;display:flex;flex:none}
#aos-ask input{flex:1;min-width:0;background:none;border:none;outline:none;color:#fff;font-size:14.5px;font-family:inherit}
#aos-ask input::placeholder{color:#a9c3e6}
#aos-ask button{border:none;background:none;color:#cfe0f7;width:28px;height:28px;border-radius:7px;display:flex;align-items:center;justify-content:center}
#aos-ask button:hover{background:rgba(255,255,255,.12)}
#aos-tasks{flex:1;display:flex;gap:6px;overflow-x:auto;min-width:0}
.aos-task{display:flex;align-items:center;gap:7px;max-width:180px;height:36px;padding:0 10px;border-radius:9px;border:1px solid transparent;background:rgba(255,255,255,.06);color:#dbe6f3;font-size:12px;white-space:nowrap;overflow:hidden}
.aos-task span{overflow:hidden;text-overflow:ellipsis}
.aos-task.on{background:rgba(79,156,249,.22);border-color:rgba(79,156,249,.5);color:#fff}
.aos-task:hover{background:rgba(255,255,255,.14)}
#aos-start{position:absolute;left:20px;bottom:10px;width:min(440px,calc(100vw - 24px));max-height:70vh;background:#fff;border-radius:14px;box-shadow:0 20px 60px rgba(3,14,36,.5);display:none;flex-direction:column;overflow:hidden;z-index:9000}
#aos-start.on{display:flex}
#aos-start .sh{padding:14px 14px 10px;border-bottom:1px solid #e5e5e5}
#aos-start .sh input{width:100%;border:1px solid #d9d9d9;border-radius:9px;padding:9px 12px;font-size:13.5px;outline:none;font-family:inherit}
#aos-start .sh input:focus{border-color:#1976d2;box-shadow:0 0 0 3px rgba(25,118,210,.12)}
#aos-start .sl{overflow:auto;padding:8px}
#aos-start .grp{font-size:11px;color:#8f8f8f;padding:8px 8px 4px;font-weight:600}
.aos-row{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;cursor:pointer;color:#0d0d0d;width:100%;border:none;background:none;text-align:left;font-size:13px}
.aos-row:hover{background:#e3f1ff;color:#0d2b5e} .aos-row.sel{background:#cfe5ff;color:#0d2b5e;box-shadow:inset 3px 0 0 #1976d2} .aos-row .ib{color:#1976d2;display:flex} .aos-row:hover .ib{color:#0ea5e9}
.aos-row small{color:#8f8f8f;margin-left:auto;font-size:11px;max-width:45%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#aos-toasts{position:absolute;right:14px;bottom:62px;display:flex;flex-direction:column;gap:8px;z-index:9500;pointer-events:none}
.aos-toast{background:#fff;border-radius:10px;padding:10px 14px;box-shadow:0 10px 30px rgba(3,14,36,.35);font-size:12.5px;max-width:340px;border-left:4px solid #1976d2;pointer-events:auto}
.aos-toast.err{border-left-color:#ef4146} .aos-toast.ok{border-left-color:#10a37f} .aos-toast.warn{border-left-color:#e8a13c}
/* piezas comunes de las apps */
.aos-pad{padding:14px 16px}
.aos-h{font-size:15px;font-weight:700;color:#0d2b5e;margin:0 0 4px}
.aos-sub{color:#6b7a90;font-size:12.5px;margin:0 0 12px;line-height:1.5}
.aos-btn{display:inline-flex;align-items:center;gap:6px;border:1px solid #d9d9d9;background:#fff;border-radius:8px;padding:6px 11px;font-size:12.5px;color:#0d2b5e;font-family:inherit}
.aos-btn:hover{border-color:#b9cde6;background:#f4f8fd}
.aos-btn.pri{background:#1976d2;border-color:#1976d2;color:#fff} .aos-btn.pri:hover{background:#0d2b5e}
.aos-btn.dan{color:#c0272d;border-color:#f3c2c4} .aos-btn.dan:hover{background:#fdeeee}
.aos-btn.sm{padding:3px 8px;font-size:11.5px}
.aos-in{border:1px solid #d9d9d9;border-radius:8px;padding:7px 10px;font-size:13px;font-family:inherit;outline:none;background:#fff;color:#0d0d0d}
.aos-in:focus{border-color:#1976d2;box-shadow:0 0 0 3px rgba(25,118,210,.12)}
.aos-tbar{display:flex;align-items:center;gap:6px;padding:8px 10px;border-bottom:1px solid #e5e5e5;background:#fff;flex-wrap:wrap}
.aos-card{border:1px solid #e5e5e5;border-radius:10px;padding:12px 14px;background:#fff}
.aos-kv{display:grid;grid-template-columns:auto 1fr;gap:4px 14px;font-size:12.5px} .aos-kv b{color:#6b7a90;font-weight:600}
.aos-pill{display:inline-flex;align-items:center;gap:5px;font-size:11px;border-radius:20px;padding:2px 9px;background:#f4f8fd;color:#0d2b5e;border:1px solid #dbe6f3}
.aos-pill.ok{background:#eefaf5;color:#0b6e56;border-color:#bfe6d8} .aos-pill.warn{background:#fdf6ea;color:#7a4a05;border-color:#f1d6a8} .aos-pill.off{background:#f4f4f4;color:#6b6b6b;border-color:#e5e5e5}
.aos-empty{color:#8f8f8f;text-align:center;padding:30px 16px;font-size:12.5px;line-height:1.6}
.aos-bar-meter{height:7px;border-radius:5px;background:#e9eef6;overflow:hidden} .aos-bar-meter i{display:block;height:100%;background:#1976d2;border-radius:5px}
.aos-bar-meter i.hi{background:#e8a13c} .aos-bar-meter i.crit{background:#ef4146}
.aos-tbl{width:100%;border-collapse:collapse;font-size:12.5px} .aos-tbl th{text-align:left;color:#6b7a90;font-weight:600;padding:6px 8px;border-bottom:1px solid #e5e5e5;position:sticky;top:0;background:#fff}
.aos-tbl td{padding:5px 8px;border-bottom:1px solid #f0f0f0;transition:background .08s} .aos-tbl tr:hover td{background:#f9fbfe}
.aosf-list tr[data-i]:hover td{background:#e3f1ff;color:#0d2b5e} .aosf-list tr[data-i]:hover td:first-child{box-shadow:inset 3px 0 0 #22c4ff}
.aosf-list tr[data-i].sel td{background:#cfe5ff;color:#0d2b5e} .aosf-list tr[data-i].sel td:first-child{box-shadow:inset 3px 0 0 #1976d2;font-weight:600}
@media (max-width:759px){ #aos-icons{grid-auto-flow:row;grid-template-columns:repeat(auto-fill,84px);grid-template-rows:none;right:14px;left:14px;top:14px;column-gap:4px;row-gap:6px} #aos{--ti:50px;--ih:96px} .aos-dicon{width:84px} #aos-hero{top:auto;bottom:16px;transform:translateX(-50%)} #aos-hero img{width:120px} #aos-hero .t{font-size:22px;margin-top:8px} #aos-hero .s{font-size:10px;letter-spacing:.14em} #aos-top{height:40px} #aos-top .brand .lg{height:22px} #aos-top>.aos-st,#aos-top>#aos-clock{padding:3px 8px} #aos-bar{height:58px;gap:10px;padding:0 10px} #aos-top .aos-exit .lbx{display:none} #aos-top .brand{letter-spacing:2px;font-size:13px;gap:6px} #aos-top{padding:0 8px} #aos-bar .lb{width:44px;height:42px} #aos-ask{height:42px} #aos-tasks .aos-task span{display:none} #aos-top .hide-m{display:none} #aos-top{gap:8px;padding:0 10px} #aos-top .brand{letter-spacing:1px;font-size:12px} #aos-top .brand small{display:none} #aos-clock{font-size:11.5px} }
@media (prefers-reduced-motion:no-preference){ .aos-win.opening{animation:aosIn .16s ease-out} @keyframes aosIn{from{opacity:0;transform:translateY(8px) scale(.985)}to{opacity:1;transform:none}} }
`;
  document.head.appendChild(s);
}

/* ---------- registro de apps ---------- */
function aosRegister(id,def){ AOS.apps[id]=Object.assign({id,icon:"file",desk:false,single:true,w:760,h:520},def); }

/* ---------- entrar / salir ---------- */
function aosOpen(){
  aosCss();
  let el=$("aos");
  if(!el){
    el=document.createElement("div"); el.id="aos";
    el.innerHTML=`
<div id="aos-top"><span class="brand"><img class="lg aos-logo" alt="" hidden>AR.T.L.A.S. OS<small>${AOS.ver}</small></span><span class="sp"></span>
  <span class="aos-st hide-m" id="aos-st-ia" onclick="aosLaunch('modelos')" title="${aosEsc(aosL("Motor del asistente","Assistant engine"))}"><span class="dot" id="aos-dot-ia"></span><span id="aos-lb-ia">IA</span></span>
  <span class="aos-st" id="aos-st-nuc" onclick="aosNucStClick()" title="${aosEsc(aosL("Núcleo local","Local core"))}"><span class="dot" id="aos-dot-nuc"></span><span id="aos-lb-nuc" class="hide-m">${aosL("Núcleo local","Local core")}</span></span>
  <span id="aos-clock"></span>
  <span class="aos-st aos-exit" onclick="aosExitClick(event)" title="${aosEsc(aosL("Volver a la plataforma","Back to the platform"))}"><img class="aos-logo" alt="" hidden><span class="aos-exit-ic">${aosIcon("exit",16)}</span><span class="lbx">${aosL("Salir","Exit")}</span></span></div>
<div id="aos-desk"><div id="aos-hero" aria-hidden="true"><img alt="" hidden><div class="t">AR.T.L.A.S. <b>OS</b></div><div class="s">${aosL("INTELIGENCIA · DATOS · CONECTIVIDAD","INTELLIGENCE · DATA · CONNECTIVITY")}</div></div><div id="aos-icons"></div><div id="aos-toasts"></div>
  <div id="aos-start"><div class="sh"><input id="aos-start-q" placeholder="${aosEsc(aosL("Buscá apps, archivos o pedile algo a AR.T.L.A.S.","Search apps, files, or ask AR.T.L.A.S."))}" autocomplete="off"></div><div class="sl" id="aos-start-l"></div></div></div>
<div id="aos-bar"><button class="lb" onclick="aosStart()" aria-label="${aosEsc(aosL("Inicio","Start"))}">${aosIcon("grid",24)}</button>
  <form id="aos-ask" onsubmit="event.preventDefault();aosAskBar()"><span class="mg">${aosIcon("search",20)}</span><input id="aos-ask-in" placeholder="${aosEsc(aosL("Pedile algo a AR.T.L.A.S.…","Ask AR.T.L.A.S. anything…"))}" autocomplete="off"><button type="submit" aria-label="${aosEsc(aosL("Enviar","Send"))}">${aosIcon("send",20)}</button></form>
  <div id="aos-tasks"></div></div>`;
    document.body.appendChild(el);
    const q=$("aos-start-q"); q.addEventListener("input",()=>aosStartList(q.value)); q.addEventListener("keydown",aosStartKey);
    $("aos-desk").addEventListener("pointerdown",e=>{ if(!e.target.closest("#aos-start")&&!e.target.closest(".lb")) aosStart(false); });
    document.addEventListener("keydown",aosKeys);
  }
  el.style.display="flex"; AOS.on=true; document.body.classList.add("aos-on"); aosRelabel(false);
  try{ document.body.style.overflow="hidden"; }catch(e){}
  aosIcons(); aosArt(); aosClock(); aosStatus();
  if(!AOS._clock) AOS._clock=setInterval(()=>{ if(AOS.on){ aosClock(); } },15000);
  if(!AOS._stat) AOS._stat=setInterval(()=>{ if(AOS.on) aosStatus(); },20000);
  try{ v60LSset("atlas_os_last","1"); }catch(e){}
  if(!AOS.wins.length&&!aosMobile()) aosLaunch("asistente");
}
function aosClose(){ const el=$("aos"); if(el) el.style.display="none"; AOS.on=false; document.body.classList.remove("aos-on"); aosStart(false); try{ document.body.style.overflow=""; }catch(e){} }
function aosKeys(e){
  if(!AOS.on) return;
  if(e.key==="Escape"){ if($("aos-start")&&$("aos-start").classList.contains("on")){ aosStart(false); e.preventDefault(); } }
  if((e.ctrlKey||e.metaKey)&&e.code==="Space"){ e.preventDefault(); aosStart(); }
}
function aosClock(){ const c=$("aos-clock"); if(!c) return; const d=new Date(); c.textContent=d.toLocaleTimeString(atlasLang==="en"?"en-US":"es-AR",{hour:"2-digit",minute:"2-digit"})+(aosMobile()?"":" · "+d.toLocaleDateString(atlasLang==="en"?"en-US":"es-AR",{weekday:"short",day:"numeric",month:"short"})); }
function aosStatus(){
  try{ if(typeof aosNucPing==="function") aosNucPing().then(aosPaintStatus).catch(()=>aosPaintStatus()); else aosPaintStatus(); }catch(e){}
}
function aosPaintStatus(){
  const nd=$("aos-dot-nuc"), nl=$("aos-lb-nuc");
  if(nd){ const st=(typeof AOSN!=="undefined")?AOSN.state:"off"; nd.className="dot "+(st==="ok"?"ok":st==="pair"?"warn":""); if(nl) nl.textContent=st==="ok"?(AOSN.equipo||aosL("Núcleo local","Local core")):st==="pair"?aosL("Núcleo: emparejar","Core: pair"):aosL("Sin núcleo","No core"); }
  const id=$("aos-dot-ia"), il=$("aos-lb-ia");
  if(id&&typeof aosMotorInfo==="function"){ const m=aosMotorInfo(); id.className="dot "+(m.local?"ok":m.pk?"":"warn"); il.textContent=m.label; }
}

/* ---------- íconos del escritorio ---------- */
/* imágenes del tema (app-recursos.js → ARTLAS_OS_IMG); sin ellas, íconos de trazo */
function aosImg(k){ try{ return (window.ARTLAS_OS_IMG||{})[k]||""; }catch(e){ return ""; } }
function aosAppIcon(a,sz,cls){ const im=aosImg(a.id); return im?`<img class="${cls||""}" src="${im}" width="${sz}" height="${sz}" alt="" draggable="false">`:(cls?`<span class="${cls}">${aosIcon(a.icon,Math.round(sz*.5))}</span>`:aosIcon(a.icon,sz)); }
function aosArt(){
  if(!window.ARTLAS_OS_IMG){ AOS._artTry=(AOS._artTry||0)+1; if(AOS._artTry<40) setTimeout(()=>{ if(window.ARTLAS_OS_IMG){ aosIcons(); aosTasks(); } aosArt(); },500); return; }
  const lg=aosImg("logo"), he=aosImg("hero");
  document.querySelectorAll("#aos .aos-logo").forEach(i=>{ if(lg){ i.src=lg; i.hidden=false; } });
  const ex=document.querySelector("#aos .aos-exit-ic"); if(ex&&lg) ex.style.display="none";
  const h=document.querySelector("#aos-hero img"); if(h&&he){ h.src=he; h.hidden=false; }
}
function aosIcons(){
  const box=$("aos-icons"); if(!box) return;
  box.innerHTML=Object.values(AOS.apps).filter(a=>a.desk).sort((a,b)=>(a.order||50)-(b.order||50)).map(a=>
    `<button class="aos-dicon ${a.id==="asistente"?"main":""}" ondblclick="aosLaunch('${a.id}')" onclick="if(aosMobile()||event.detail===0)aosLaunch('${a.id}')" onkeydown="if(event.key==='Enter')aosLaunch('${a.id}')">${aosAppIcon(a,74,"ib")}<span>${aosEsc(a.title())}</span></button>`).join("");
}

/* ---------- ventanas ---------- */
function aosLaunch(id,opts){
  opts=opts||{}; const app=AOS.apps[id]; if(!app){ aosToast(aosL("Aplicación desconocida: ","Unknown app: ")+id,"err"); return null; }
  aosStart(false);
  if(app.single&&!opts.nuevo){ const w=AOS.wins.find(x=>x.app===id); if(w){ aosFocus(w.id,true); if(app.reopen) try{ app.reopen(w,opts); }catch(e){ console.error(e); } return w; } }
  const desk=$("aos-desk"); if(!desk){ aosOpen(); return aosLaunch(id,opts); }
  const n=AOS.wins.length, W=desk.clientWidth, H=desk.clientHeight;
  const w=Math.min(opts.w||app.w,W-40), h=Math.min(opts.h||app.h,H-30);
  const x=Math.max(10,Math.min(W-w-10,Math.round((W-w)/2)+((n%6)-2)*28)), y=Math.max(8,Math.min(H-h-8,Math.round((H-h)/2.4)+((n%6)-2)*24));
  const wid="aw"+(++AOS.seq);
  const el=document.createElement("div"); el.className="aos-win opening"; el.id=wid;
  el.style.cssText=`left:${x}px;top:${y}px;width:${w}px;height:${h}px;z-index:${++AOS.z}`;
  el.innerHTML=`<div class="aos-tb">${aosAppIcon(app,18)}<span class="t"></span>
    <button onclick="aosMin('${wid}')" aria-label="${aosEsc(aosL("Minimizar","Minimize"))}">${aosIcon("min",15)}</button>
    <button onclick="aosMax('${wid}')" aria-label="${aosEsc(aosL("Maximizar","Maximize"))}">${aosIcon("max",13)}</button>
    <button class="x" onclick="aosCloseWin('${wid}')" aria-label="${aosEsc(aosL("Cerrar","Close"))}">${aosIcon("close",15)}</button></div>
    <div class="aos-body"></div><div class="aos-rs"></div>`;
  desk.appendChild(el);
  const win={id:wid,app:id,el,body:el.querySelector(".aos-body"),title:app.title(),state:{}};
  AOS.wins.push(win); aosTitle(win,opts.title||app.title());
  if(aosMobile()||opts.max) el.classList.add("max");
  aosDrag(win); el.addEventListener("pointerdown",()=>aosFocus(wid));
  setTimeout(()=>el.classList.remove("opening"),220);
  try{ app.render(win,opts); }catch(e){ console.error("aos app",id,e); win.body.innerHTML=`<div class="aos-empty">${aosEsc(aosL("No se pudo abrir: ","Could not open: ")+(e.message||e))}</div>`; }
  aosFocus(wid); return win;
}
function aosWin(wid){ return AOS.wins.find(w=>w.id===wid); }
function aosTitle(win,t){ win.title=t; const s=win.el.querySelector(".aos-tb .t"); if(s) s.textContent=t; aosTasks(); }
function aosFocus(wid,restore){
  const w=aosWin(wid); if(!w) return;
  if(restore) w.el.classList.remove("min");
  if(!w.el.classList.contains("focus")){ AOS.wins.forEach(x=>x.el.classList.remove("focus")); w.el.classList.add("focus"); w.el.style.zIndex=++AOS.z; }
  AOS.focus=wid; aosTasks();
}
function aosMin(wid){ const w=aosWin(wid); if(!w) return; w.el.classList.add("min"); w.el.classList.remove("focus"); AOS.focus=null; aosTasks(); }
function aosMax(wid){ const w=aosWin(wid); if(!w||aosMobile()) return; w.el.classList.toggle("max"); }
function aosCloseWin(wid){
  const w=aosWin(wid); if(!w) return; const app=AOS.apps[w.app];
  if(app&&app.beforeClose&&app.beforeClose(w)===false) return;
  try{ if(app&&app.onClose) app.onClose(w); }catch(e){}
  w.el.remove(); AOS.wins=AOS.wins.filter(x=>x!==w); aosTasks();
}
function aosTasks(){
  const t=$("aos-tasks"); if(!t) return;
  t.innerHTML=AOS.wins.map(w=>{ const a=AOS.apps[w.app]; const on=AOS.focus===w.id&&!w.el.classList.contains("min");
    return `<button class="aos-task ${on?"on":""}" title="${aosEsc(w.title)}" onclick="aosTaskClick('${w.id}')">${a?aosAppIcon(a,18):aosIcon("file",15)}<span>${aosEsc(w.title)}</span></button>`; }).join("");
}
function aosTaskClick(wid){ const w=aosWin(wid); if(!w) return; if(AOS.focus===wid&&!w.el.classList.contains("min")) aosMin(wid); else aosFocus(wid,true); }
function aosDrag(win){
  const tb=win.el.querySelector(".aos-tb"), rs=win.el.querySelector(".aos-rs");
  const drag=(e,mode)=>{
    if(e.button!==0||aosMobile()||win.el.classList.contains("max")) return;
    if(mode==="move"&&e.target.closest("button")) return;
    e.preventDefault(); const sx=e.clientX, sy=e.clientY, r={x:win.el.offsetLeft,y:win.el.offsetTop,w:win.el.offsetWidth,h:win.el.offsetHeight};
    const D=$("aos-desk"); const mv=ev=>{
      const dx=ev.clientX-sx, dy=ev.clientY-sy;
      if(mode==="move"){ win.el.style.left=Math.max(-r.w+80,Math.min(D.clientWidth-80,r.x+dx))+"px"; win.el.style.top=Math.max(0,Math.min(D.clientHeight-36,r.y+dy))+"px"; }
      else { win.el.style.width=Math.max(300,r.w+dx)+"px"; win.el.style.height=Math.max(200,r.h+dy)+"px"; }
    };
    const up=()=>{ document.removeEventListener("pointermove",mv); document.removeEventListener("pointerup",up); };
    document.addEventListener("pointermove",mv); document.addEventListener("pointerup",up);
  };
  tb.addEventListener("pointerdown",e=>drag(e,"move")); tb.addEventListener("dblclick",e=>{ if(!e.target.closest("button")) aosMax(win.id); });
  rs.addEventListener("pointerdown",e=>drag(e,"size"));
}

/* ---------- notificaciones ---------- */
function aosToast(msg,kind,ms){
  const box=$("aos-toasts"); if(!box){ return; }
  const t=document.createElement("div"); t.className="aos-toast "+(kind||""); t.textContent=msg; box.appendChild(t);
  setTimeout(()=>{ t.style.transition="opacity .3s"; t.style.opacity="0"; setTimeout(()=>t.remove(),320); },ms||4200);
}

/* ---------- lanzador (inicio) ---------- */
function aosStart(force){
  const s=$("aos-start"); if(!s) return;
  const on=force===undefined?!s.classList.contains("on"):!!force;
  s.classList.toggle("on",on);
  if(on){ const q=$("aos-start-q"); q.value=""; aosStartList(""); setTimeout(()=>q.focus(),30); }
}
let AOS_START_T=null;
function aosStartList(q){
  const L=$("aos-start-l"); if(!L) return; q=String(q||"").trim(); const ql=q.toLowerCase();
  const apps=Object.values(AOS.apps).filter(a=>!a.hidden&&(!ql||a.title().toLowerCase().includes(ql)||(a.kw||"").includes(ql)));
  let h=`<div class="grp">${aosL("Aplicaciones de AR.T.L.A.S. OS","AR.T.L.A.S. OS apps")}</div>`+apps.map(a=>`<button class="aos-row" onclick="aosLaunch('${a.id}')"><span class="ib">${aosAppIcon(a,22)}</span>${aosEsc(a.title())}<small>${aosEsc(a.sub?a.sub():"")}</small></button>`).join("");
  if(q) h+=`<div class="grp">AR.T.L.A.S.</div><button class="aos-row" onclick="aosAskAtlas(${aosEsc(JSON.stringify(q))})"><span class="ib">${aosIcon("chat",18)}</span>${aosL("Preguntar: ","Ask: ")}«${aosEsc(q.slice(0,60))}»</button><div id="aos-start-x"></div>`;
  L.innerHTML=h;
  const first=L.querySelector(".aos-row"); if(first) first.classList.add("sel");
  clearTimeout(AOS_START_T);
  if(q.length>=2&&typeof aosStartExtra==="function") AOS_START_T=setTimeout(()=>aosStartExtra(q),260);
}
function aosStartKey(e){
  const rows=[...document.querySelectorAll("#aos-start-l .aos-row")]; let i=rows.findIndex(r=>r.classList.contains("sel"));
  if(e.key==="ArrowDown"||e.key==="ArrowUp"){ e.preventDefault(); if(rows[i]) rows[i].classList.remove("sel"); i=e.key==="ArrowDown"?Math.min(rows.length-1,i+1):Math.max(0,i-1); if(rows[i]){ rows[i].classList.add("sel"); rows[i].scrollIntoView({block:"nearest"}); } }
  if(e.key==="Enter"){ e.preventDefault(); const q=e.target.value.trim(); const apps=rows.filter(r=>!r.closest("#aos-start-x")); if(rows[i]&&(i>0||apps.length>1||!q)) rows[i].click(); else if(q) aosAskAtlas(q); else if(rows[i]) rows[i].click(); }
}
function aosAskBar(){ const i=$("aos-ask-in"); const q=(i.value||"").trim(); if(!q) return; i.value=""; aosAskAtlas(q); }
function aosAskAtlas(q){ aosStart(false); const w=aosLaunch("asistente"); if(w&&typeof aosAgentAsk==="function") aosAgentAsk(w,q); }

/* ---------- apps básicas: AR.T.L.A.S. clásico ---------- */
aosRegister("clasico",{title:()=>aosL("Plataforma","Platform"),sub:()=>aosL("Plataforma completa","Full platform"),icon:"atlas",desk:true,order:90,hidden:false,
  render(win){ aosCloseWin(win.id); aosClose(); try{ go("chat"); }catch(e){} }});

/* ---------- integración con la plataforma ---------- */
const V92_renderNav=renderNav;
renderNav=function(){
  V92_renderNav.apply(this,arguments);
  try{
    const el=$("nav-v60"); if(!el||el.querySelector(".v92-nav")) return;
    const b=`<button class="side-btn v92-nav" onclick="aosOpen()" title="${aosEsc(aosL("Escritorio de IA: carpetas, aplicaciones y sistema","AI desktop: folders, apps and system"))}">🖥️&nbsp; AR.T.L.A.S. OS<span class="v92-new">${aosL("NUEVO","NEW")}</span></button>`;
    const home=el.querySelector(".home-btn"); if(home) home.insertAdjacentHTML("afterend",b); else el.insertAdjacentHTML("afterbegin",b);
  }catch(e){ console.error("v92 nav",e); }
};
(function(){ try{ const s=document.createElement("style"); s.textContent=".v92-new{margin-left:auto;font-size:9.5px;font-weight:700;letter-spacing:.5px;background:#1976d2;color:#fff;border-radius:8px;padding:1px 6px}"; document.head.appendChild(s); }catch(e){} })();
function aosBoot(){
  try{ renderNav(); }catch(e){}
  try{
    const u=new URLSearchParams(location.search);
    if(u.get("os")==="1"){
      const tryOpen=()=>{ if(typeof v61GateVisible==="function"&&v61GateVisible()){ setTimeout(tryOpen,600); return; } aosOpen(); };
      setTimeout(tryOpen,400);
    }
  }catch(e){}
}

/* ---------- idioma: los textos fijos del OS siguen al botón ES/EN de la plataforma ---------- */
function aosRelabel(full){
  const set=(id,f)=>{ const e=$(id); if(e) f(e); };
  set("aos-ask-in",e=>e.placeholder=aosL("Pedile algo a AR.T.L.A.S.…","Ask AR.T.L.A.S. anything…"));
  set("aos-start-q",e=>e.placeholder=aosL("Buscá apps, archivos o pedile algo a AR.T.L.A.S.","Search apps, files, or ask AR.T.L.A.S."));
  document.querySelectorAll("#aos .aos-exit").forEach(e=>{ e.title=aosL("Volver a la plataforma","Back to the platform"); const l=e.querySelector(".lbx"); if(l) l.textContent=aosL("Salir","Exit"); });
  const hs=document.querySelector("#aos-hero .s"); if(hs) hs.textContent=aosL("INTELIGENCIA · DATOS · CONECTIVIDAD","INTELLIGENCE · DATA · CONNECTIVITY");
  try{ aosIcons(); aosClock(); aosPaintStatus(); }catch(e){}
  if(full!==false) try{ AOS.wins.forEach(w=>{ const a=AOS.apps[w.app]; if(a&&a.reopen&&a.single!==false&&w.app!=="asistente") a.reopen(w,{}); }); }catch(e){}
}
const V92_toggleLang=toggleLang;
toggleLang=function(){ const r=V92_toggleLang.apply(this,arguments); try{ if($("aos")) aosRelabel(); }catch(e){} return r; };
