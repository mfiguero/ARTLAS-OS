#!/bin/bash
# AR.T.L.A.S. OS · construye la ISO amd64. En Debian 13 corre live-build directo; en otro sistema usa Docker.
# Uso: sudo imagen/iso/construir.sh       (resultado en imagen/salida/)
set -euo pipefail
R=$(cd "$(dirname "$0")/../.." && pwd); SAL=${ARTLAS_SALIDA:-$R/imagen/salida}; mkdir -p "$SAL"
[ -f "$R/dist/nucleo/artlas-nucleo.mjs" ] || (cd "$R" && node build.mjs)
VER=$(node -p "require('$R/artlas.config.json').ver" 2>/dev/null || echo v7)
W=$(mktemp -d /tmp/artlas-iso.XXXX); cp -a "$R/imagen/iso/." "$W/"
INC="$W/config/includes.chroot"; mkdir -p "$INC/opt/artlas"
cp -a "$R/dist/web-only" "$INC/opt/artlas/app"; cp -a "$R/dist/nucleo" "$INC/opt/artlas/nucleo"; cp -a "$R/dist/rag" "$INC/opt/artlas/rag"
cp -a "$R/imagen/comun/raiz/." "$INC/"; cp "$R/imagen/comun/instalar-artlas.sh" "$INC/opt/artlas/"
grep -hv '^\s*#' "$R/imagen/comun/paquetes.txt" "$W/config/package-lists/amd64.list" | grep -v '^\s*$' > "$W/config/package-lists/artlas.list.chroot"
rm -f "$W/config/package-lists/amd64.list"
EN_DEBIAN=0; grep -q 'VERSION_CODENAME=trixie' /etc/os-release 2>/dev/null && command -v lb >/dev/null && EN_DEBIAN=1
if [ "$EN_DEBIAN" = 1 ]; then (cd "$W" && lb clean && ./auto/config && ./auto/build)
else docker run --rm --privileged -v "$W:/w" -w /w debian:trixie bash -c "apt-get update -q && apt-get install -y -q live-build && lb clean && ./auto/config && ./auto/build"; fi
ISO=$(ls "$W"/*.iso | head -1); cp "$ISO" "$SAL/ARTLAS-OS-$VER-amd64.iso"
(cd "$SAL" && sha256sum "ARTLAS-OS-$VER-amd64.iso" > "ARTLAS-OS-$VER-amd64.iso.sha256")
echo "Listo: $SAL/ARTLAS-OS-$VER-amd64.iso"
