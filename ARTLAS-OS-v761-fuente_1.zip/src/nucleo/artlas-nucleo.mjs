#!/usr/bin/env node
/* =====================================================================
   AR.T.L.A.S. OS · Núcleo local  (__ARTLAS_VER__)
   © MMFC · AI-TECH · Prof. Mario M. Figueroa de la Cruz. Uso según la Licencia AR.T.L.A.S.

   Servicio pequeño que corre en TU computadora (solo 127.0.0.1) y le da a
   AR.T.L.A.S. OS lo que un navegador no puede hacer: carpetas del disco,
   aplicaciones, procesos, estado del sistema, terminal con lista blanca y
   modelos locales (Ollama) y ofimática con LibreOffice / OpenOffice.
   Node 18 o superior, sin dependencias.

     node artlas-nucleo.mjs                       → inicia con las raíces por defecto
     node artlas-nucleo.mjs --raiz "D:\Proyectos" → agrega una raíz permitida
     node artlas-nucleo.mjs --puerto 8770

   Seguridad:
     · escucha solo en 127.0.0.1; acepta solo los orígenes de AR.T.L.A.S.
     · cada navegador se empareja con un código que se muestra en esta consola
     · las raíces y los permisos se cambian SOLO acá (config.json), nunca desde la web
     · borrar = mover a la papelera del núcleo (restaurable); sobrescribir guarda copia
     · sin elevación de administrador; todo queda en registro.jsonl
   ===================================================================== */
import http from "node:http";
import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import crypto from "node:crypto";
import { execFile, spawn } from "node:child_process";
import dns from "node:dns/promises";
import net from "node:net";

const VER = "__ARTLAS_VER__";
const WIN = process.platform === "win32", MAC = process.platform === "darwin";
const argv = process.argv.slice(2);
const argVal = (k) => { const out = []; argv.forEach((a, i) => { if (a === k && argv[i + 1]) out.push(argv[i + 1]); }); return out; };
const PORT = +(argVal("--puerto")[0] || process.env.ARTLAS_NUCLEO_PORT || 8770);
const HOME = os.homedir();
const DIR = process.env.ARTLAS_NUCLEO_DIR || path.join(HOME, ".artlas-nucleo");
const CFG_F = path.join(DIR, "config.json"), LOG_F = path.join(DIR, "registro.jsonl");
const TRASH = path.join(DIR, "papelera"), TRASH_F = path.join(DIR, "papelera.json");
fs.mkdirSync(TRASH, { recursive: true });

/* ---------------- configuración ---------------- */
const MEDIA_DIRS = ["Pictures", "Imágenes", "Imagenes", "Music", "Música", "Musica", "Videos", "Vídeos"];
function defRoots(solo) {
  const c = [];
  for (const b of [HOME, path.join(HOME, "OneDrive")]) for (const n of solo || ["Desktop", "Escritorio", "Documents", "Documentos", "Downloads", "Descargas", ...MEDIA_DIRS]) c.push(path.join(b, n));
  return c.filter(p => { try { return fs.statSync(p).isDirectory(); } catch (e) { return false; } });
}
const DEF = {
  raices: null,
  permisos: { lectura: true, escritura: true, apps: true, procesos: true, terminal: true, terminal_libre: false, web: true },
  ollama: "http://127.0.0.1:11434",
  origenes_extra: [],
  tokens: []
};
let cfg = {};
try { cfg = JSON.parse(fs.readFileSync(CFG_F, "utf8")); } catch (e) { cfg = {}; }
cfg = { ...DEF, ...cfg, permisos: { ...DEF.permisos, ...(cfg.permisos || {}) } };
if (!Array.isArray(cfg.raices) || !cfg.raices.length) cfg.raices = defRoots();
for (const r of argVal("--raiz")) { const a = path.resolve(r); if (!cfg.raices.some(x => same(x, a))) cfg.raices.push(a); }
if (!cfg.raices.length) cfg.raices = [HOME];
// v6.9.4: Imágenes, Música y Videos se suman una vez a las carpetas permitidas (también en configuraciones existentes)
if ((cfg.raices_v || 1) < 2) { for (const r of defRoots(MEDIA_DIRS)) if (!cfg.raices.some(x => same(x, r))) cfg.raices.push(r); cfg.raices_v = 2; }
const saveCfg = () => fs.writeFileSync(CFG_F, JSON.stringify(cfg, null, 2));
saveCfg();

function same(a, b) { a = path.resolve(a); b = path.resolve(b); return WIN ? a.toLowerCase() === b.toLowerCase() : a === b; }
function inside(child, parent) {
  const rel = path.relative(parent, child);
  if (WIN && /^[a-z]:/i.test(rel)) return false;
  return rel === "" || (!rel.startsWith("..") && !path.isAbsolute(rel));
}
const realRoots = () => cfg.raices.map(r => { try { return fs.realpathSync(r); } catch (e) { return path.resolve(r); } });

/* ---------------- emparejamiento ---------------- */
let PAIR = { code: null, until: 0, fails: 0 };
function newCode() {
  PAIR = { code: String(crypto.randomInt(100000, 999999)), until: Date.now() + 10 * 60 * 1000, fails: 0 };
  console.log(`\n  🔑 Código de emparejamiento: ${PAIR.code}  (válido 10 minutos)\n     Pegalo en AR.T.L.A.S. OS → Configuración → Núcleo local.\n`);
}
const tokOk = (t) => !!t && cfg.tokens.some(x => x.t.length === t.length && crypto.timingSafeEqual(Buffer.from(x.t), Buffer.from(t)));

/* ---------------- orígenes permitidos ---------------- */
// sitios de AR.T.L.A.S. que pueden hablar con el núcleo: la compilación pone acá la misma lista de dominios autorizados
// de la app (artlas.config.json → dominios), así un sitio oficial nuevo no requiere tocar este archivo
const ORIG_B = "__ARTLAS_DOMINIOS__";
const ORIG = ORIG_B.startsWith("__") ? ["artlas.ar", "*.artlas.ar", "artlas.netlify.app", "*--artlas.netlify.app", "artlas-ai-arg.netlify.app", "*--artlas-ai-arg.netlify.app", "artlas-os.netlify.app", "*--artlas-os.netlify.app", "artlas-ucasal.netlify.app", "*--artlas-ucasal.netlify.app", "localhost", "127.0.0.1"] : ORIG_B.split(",").map(x => x.trim()).filter(Boolean);
function originOk(o) {
  if (!o) return false;
  if (o === "null") return true;                 // file:// (Escritorio, Web only desde el disco)
  let h; try { h = new URL(o).hostname.toLowerCase(); } catch (e) { return false; }
  return ORIG.concat(cfg.origenes_extra || []).some(p => {
    p = String(p).toLowerCase();
    if (p.startsWith("*.")) return h === p.slice(2) || h.endsWith(p.slice(1));
    if (p.includes("*")) return new RegExp("^" + p.replace(/[.]/g, "\\.").replace(/\*/g, "[^.]+") + "$").test(h);
    return h === p;
  });
}

/* ---------------- registro de actividad ---------------- */
function log(e) { try { fs.appendFileSync(LOG_F, JSON.stringify({ t: new Date().toISOString(), ...e }) + "\n"); } catch (x) {} }
function logTail(n) {
  try { const L = fs.readFileSync(LOG_F, "utf8").trim().split("\n"); return L.slice(-n).map(l => { try { return JSON.parse(l); } catch (e) { return null; } }).filter(Boolean).reverse(); }
  catch (e) { return []; }
}

/* ---------------- rutas seguras ---------------- */
function expand(p) { p = String(p || "").trim(); if (p === "~") return HOME; if (p.startsWith("~/") || p.startsWith("~\\")) return path.join(HOME, p.slice(2)); return p; }
function safe(p, mustExist = false) {
  if (!p) throw new Error("Falta la ruta");
  const abs = path.resolve(expand(p));
  // resolver enlaces del tramo existente más largo
  let cur = abs, tail = [];
  while (!fs.existsSync(cur)) { const up = path.dirname(cur); if (up === cur) break; tail.unshift(path.basename(cur)); cur = up; }
  let real = cur; try { real = fs.realpathSync(cur); } catch (e) {}
  const full = tail.length ? path.join(real, ...tail) : real;
  if (mustExist && tail.length) throw new Error("No existe: " + abs);
  if (!realRoots().some(r => inside(full, r))) throw new Error("Fuera de las carpetas permitidas: " + abs);
  return full;
}
function need(k) { if (!cfg.permisos[k]) throw new Error(`Permiso «${k}» desactivado en el núcleo (config.json)`); }

/* ---------------- utilidades ---------------- */
const ext = n => (path.extname(n).slice(1) || "").toLowerCase();
function isText(buf) { const n = Math.min(buf.length, 8192); for (let i = 0; i < n; i++) if (buf[i] === 0) return false; return true; }
function decodeOut(buf) {
  const u = buf.toString("utf8");
  if (!WIN || !u.includes("\uFFFD")) return u;
  try { return new TextDecoder("ibm850").decode(buf); } catch (e) { return buf.toString("latin1"); }
}
function run(cmd, args, opt = {}) {
  return new Promise((res) => {
    execFile(cmd, args, { timeout: opt.timeout || 30000, maxBuffer: 2 * 1024 * 1024, windowsHide: true, encoding: "buffer", shell: !!opt.shell }, (err, so, se) => {
      res({ code: err ? (err.code ?? 1) : 0, salida: decodeOut(so || Buffer.alloc(0)), error: decodeOut(se || Buffer.alloc(0)) || (err && !so?.length ? String(err.message || err) : ""), timeout: !!(err && err.killed) });
    });
  });
}
function detached(cmd, args) { const c = spawn(cmd, args, { detached: true, stdio: "ignore", windowsHide: false }); c.on("error", () => {}); c.unref(); }
function openWithDefault(p) { if (WIN) detached("explorer.exe", [p]); else if (MAC) detached("open", [p]); else detached("xdg-open", [p]); }
function trashDb() { try { return JSON.parse(fs.readFileSync(TRASH_F, "utf8")); } catch (e) { return []; } }
async function moveAny(a, b) {
  try { await fsp.rename(a, b); }
  catch (e) { if (e.code !== "EXDEV") throw e; await fsp.cp(a, b, { recursive: true }); await fsp.rm(a, { recursive: true, force: true }); }
}
async function toTrash(p, motivo) {
  const id = Date.now().toString(36) + crypto.randomBytes(3).toString("hex");
  const dst = path.join(TRASH, id); await fsp.mkdir(dst, { recursive: true });
  const st = await fsp.stat(p);
  if (motivo === "copia") await fsp.cp(p, path.join(dst, path.basename(p)), { recursive: true });
  else await moveAny(p, path.join(dst, path.basename(p)));
  const db = trashDb(); db.unshift({ id, original: p, nombre: path.basename(p), tipo: st.isDirectory() ? "dir" : "archivo", tam: st.size, t: new Date().toISOString(), motivo: motivo || "borrado" });
  fs.writeFileSync(TRASH_F, JSON.stringify(db.slice(0, 500), null, 1));
  return id;
}

/* ---------------- CPU (uso por muestreo) ---------------- */
let cpuPrev = os.cpus().map(c => c.times);
function cpuUse() {
  const now = os.cpus().map(c => c.times); let idle = 0, tot = 0;
  now.forEach((t, i) => { const p = cpuPrev[i] || t; const d = k => t[k] - p[k]; const all = d("user") + d("nice") + d("sys") + d("idle") + d("irq"); tot += all; idle += d("idle"); });
  cpuPrev = now; return tot > 0 ? Math.round(100 * (1 - idle / tot)) : 0;
}
async function disk(p) { try { const s = await fsp.statfs(p); return { total: s.blocks * s.bsize, libre: s.bavail * s.bsize }; } catch (e) { return null; } }

/* ---------------- aplicaciones instaladas ---------------- */
let APPS = null, APPS_T = 0;
async function walk(dir, depth, fn) {
  if (depth < 0) return; let es; try { es = await fsp.readdir(dir, { withFileTypes: true }); } catch (e) { return; }
  for (const e of es) { const p = path.join(dir, e.name); if (e.isDirectory()) { if (MAC && e.name.endsWith(".app")) fn(p, e); else await walk(p, depth - 1, fn); } else fn(p, e); }
}
async function listApps(force) {
  if (APPS && !force && Date.now() - APPS_T < 5 * 60 * 1000) return APPS;
  const out = [], seen = new Set();
  const add = (nombre, ruta, extra = {}) => { const k = nombre.toLowerCase(); if (seen.has(k)) return; seen.add(k); out.push({ id: crypto.createHash("sha1").update(ruta).digest("hex").slice(0, 12), nombre, ruta, ...extra }); };
  if (WIN) {
    const dirs = [path.join(process.env.ProgramData || "C:\\ProgramData", "Microsoft", "Windows", "Start Menu", "Programs"),
                  path.join(process.env.APPDATA || path.join(HOME, "AppData", "Roaming"), "Microsoft", "Windows", "Start Menu", "Programs")];
    for (const d of dirs) await walk(d, 4, (p) => { if (/\.(lnk|url)$/i.test(p)) { const n = path.basename(p).replace(/\.(lnk|url)$/i, ""); if (!/uninstall|desinstal|readme|léame|help|ayuda|website|sitio web/i.test(n)) add(n, p, { carpeta: path.basename(path.dirname(p)) }); } });
  } else if (MAC) {
    for (const d of ["/Applications", "/System/Applications", path.join(HOME, "Applications")]) await walk(d, 1, (p) => { if (p.endsWith(".app")) add(path.basename(p, ".app"), p); });
  } else {
    for (const d of ["/usr/share/applications", "/var/lib/flatpak/exports/share/applications", path.join(HOME, ".local/share/applications")]) await walk(d, 1, (p) => {
      if (!p.endsWith(".desktop")) return;
      try { const t = fs.readFileSync(p, "utf8"); if (/^NoDisplay=true/m.test(t)) return; const n = (t.match(/^Name=(.+)$/m) || [])[1]; if (n) add(n.trim(), p, { exec: ((t.match(/^Exec=(.+)$/m) || [])[1] || "").replace(/%[a-zA-Z]/g, "").trim(), icono: ((t.match(/^Icon=(.+)$/m) || [])[1] || "").trim() }); } catch (e) {}
    });
  }
  out.sort((a, b) => a.nombre.localeCompare(b.nombre, "es"));
  APPS = out; APPS_T = Date.now(); return out;
}
function findApp(list, q) {
  if (!q) return null; const s = String(q).toLowerCase().trim();
  return list.find(a => a.id === q) || list.find(a => a.nombre.toLowerCase() === s) || list.find(a => a.nombre.toLowerCase().startsWith(s)) || list.find(a => a.nombre.toLowerCase().includes(s)) || null;
}

/* ---------------- procesos ---------------- */
const PROTECTED = /^(system|system idle process|idle|registry|smss|csrss|wininit|winlogon|services|lsass|lsaiso|svchost|fontdrvhost|dwm|memory compression|secure system|explorer|launchd|kernel_task|windowserver|loginwindow|systemd|init|kthreadd)(\.exe)?$/i;
async function listProcs() {
  if (WIN) {
    const r = await run("tasklist", ["/fo", "csv", "/nh"]);
    return r.salida.split(/\r?\n/).filter(Boolean).map(l => { const c = l.match(/"([^"]*)"/g)?.map(x => x.slice(1, -1)) || []; return { nombre: c[0], pid: +c[1], memoria: parseInt((c[4] || "0").replace(/[^\d]/g, ""), 10) * 1024 }; }).filter(p => p.nombre && p.pid);
  }
  const r = await run("ps", ["-eo", "pid=,pcpu=,rss=,comm="]);
  return r.salida.split("\n").filter(Boolean).map(l => { const m = l.trim().match(/^(\d+)\s+([\d.]+)\s+(\d+)\s+(.+)$/); return m ? { pid: +m[1], cpu: +m[2], memoria: +m[3] * 1024, nombre: path.basename(m[4]) } : null; }).filter(Boolean);
}

/* ---------------- terminal con lista blanca ---------------- */
const ALLOW_ALL = { ping: 1, nslookup: 1, hostname: 1, whoami: 1, node: 1, python: 1, python3: 1, py: 1, pip: 1, git: 1, ollama: 1, curl: 1 };
const ALLOW_WIN = { ipconfig: 1, tracert: 1, netstat: 1, systeminfo: 1, getmac: 1, arp: 1, route: 1, where: 1, tasklist: 1, pathping: 1, nbtstat: 1 };
const ALLOW_NIX = { ifconfig: 1, ip: 1, traceroute: 1, netstat: 1, ss: 1, uname: 1, df: 1, uptime: 1, ls: 1, arp: 1, which: 1, dig: 1, free: 1 };
const SUB = { git: /^(status|log|branch|diff|remote|--version|show)$/, pip: /^(list|show|--version|freeze)$/, ollama: /^(list|ps|show|--version)$/, route: /^(print|-n|get)$/, ip: /^(a|addr|address|r|route|link|-br|-4|-6)$/ };
// estos comandos podrían ejecutar código o escribir archivos con ciertos argumentos: se valida CADA argumento
const ALL_ARGS = { curl: /^(-I|--head|-s|-S|-L|-v|--max-time|\d{1,3}|https?:\/\/[^\s"'<>|&;]+)$/, node: /^(--version|-v)$/, python: /^(--version|-V)$/, python3: /^(--version|-V)$/, py: /^(--version|-V|-0)$/ };
const NO_ARG = /^(--output|-o$|--exec|--upload-pack|--receive-pack|-c$|--config|--git-dir|--work-tree|--ext-diff|--textconv)/i;
function allowed(cmd) { const c = cmd.toLowerCase().replace(/\.exe$/, ""); return !!(ALLOW_ALL[c] || (WIN ? ALLOW_WIN[c] : ALLOW_NIX[c])); }
async function shell(a) {
  need("terminal");
  let cmd = String(a.cmd || "").trim(), args = Array.isArray(a.args) ? a.args.map(String) : [];
  if (!cmd) throw new Error("Falta el comando");
  if (!a.args && /\s/.test(cmd)) { const parts = cmd.match(/"[^"]*"|\S+/g) || []; cmd = parts.shift(); args = parts.map(x => x.replace(/^"|"$/g, "")); }
  const base = path.basename(cmd).toLowerCase().replace(/\.exe$/, "");
  if (allowed(base)) {
    if (SUB[base] && args[0] && !SUB[base].test(args[0])) throw new Error(`«${base} ${args[0]}» no está en la lista blanca`);
    if (ALL_ARGS[base]) { const bad = args.find(x => !ALL_ARGS[base].test(x)); if (bad) throw new Error(`«${base} ${bad}» no está en la lista blanca (para eso activá la terminal libre)`); }
    if ((base === "git" || base === "pip") && args.some(x => NO_ARG.test(x))) throw new Error(`Opción no permitida en «${base}»`);
    if (["ip", "route", "arp", "netsh"].includes(base) && args.some(x => /^(add|del|delete|flush|set|change|replace|-d|-s|-f)$/i.test(x))) throw new Error(`«${base}» solo se permite para consultar, no para modificar`);
    if (args.some(x => /[\r\n]/.test(x))) throw new Error("Argumentos inválidos");
    if (base === "ping" && !args.some(x => /^-(n|c)$/i.test(x))) args.unshift(WIN ? "-n" : "-c", "4");
    const r = await run(base, args, { timeout: 45000 });
    return { ...r, comando: [base, ...args].join(" "), modo: "lista blanca" };
  }
  if (!cfg.permisos.terminal_libre) throw new Error(`«${base}» no está en la lista blanca. Para habilitar cualquier comando, activá permisos.terminal_libre en ${CFG_F}`);
  if (!a.confirmado) throw new Error(`«${base}» no está en la lista blanca: requiere confirmación en AR.T.L.A.S.`);
  const line = [cmd, ...args].join(" ");
  const r = WIN ? await run("cmd.exe", ["/d", "/s", "/c", line], { timeout: 60000 }) : await run("/bin/sh", ["-c", line], { timeout: 60000 });
  return { ...r, comando: line, modo: "libre" };
}

/* ---------------- Ollama (modelos locales) ---------------- */
const OLL = () => String(cfg.ollama || "http://127.0.0.1:11434").replace(/\/$/, "");
const JOBS = new Map();
async function ollamaEstado() {
  try {
    const [v, t, ps] = await Promise.all([fetch(OLL() + "/api/version", { signal: AbortSignal.timeout(2500) }).then(r => r.json()),
      fetch(OLL() + "/api/tags", { signal: AbortSignal.timeout(4000) }).then(r => r.json()),
      fetch(OLL() + "/api/ps", { signal: AbortSignal.timeout(4000) }).then(r => r.json()).catch(() => ({ models: [] }))]);
    return { activo: true, version: v.version, modelos: (t.models || []).map(m => ({ nombre: m.name, tam: m.size, familia: m.details?.family, parametros: m.details?.parameter_size, cuant: m.details?.quantization_level })), cargados: (ps.models || []).map(m => m.name) };
  } catch (e) { return { activo: false, error: "Ollama no responde en " + OLL() + ". Instalalo desde ollama.com y abrilo." }; }
}
function ollamaPull(modelo) {
  if (!/^[\w.\-:\/]+$/.test(modelo || "")) throw new Error("Nombre de modelo inválido");
  const id = "j" + Date.now().toString(36); const job = { id, modelo, estado: "iniciando", completado: 0, total: 0, error: null }; JOBS.set(id, job);
  (async () => {
    try {
      const r = await fetch(OLL() + "/api/pull", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model: modelo, stream: true }) });
      if (!r.ok || !r.body) throw new Error("Ollama respondió " + r.status);
      const dec = new TextDecoder(); let buf = "";
      for await (const ch of r.body) {
        buf += dec.decode(ch, { stream: true }); let i;
        while ((i = buf.indexOf("\n")) >= 0) { const l = buf.slice(0, i); buf = buf.slice(i + 1); if (!l.trim()) continue; const j = JSON.parse(l); if (j.error) throw new Error(j.error); job.estado = j.status || job.estado; if (j.total) { job.total = j.total; job.completado = j.completed || 0; } }
      }
      job.estado = "listo"; log({ op: "ia.descargar", modelo, ok: true });
    } catch (e) { job.estado = "error"; job.error = String(e.message || e); }
  })();
  return { job: id };
}

/* ---------------- ofimática: LibreOffice / Apache OpenOffice ---------------- */
// Se usa el soffice instalado en la PC, en modo sin ventana para crear y convertir.
// Perfil propio (no choca con un LibreOffice que el usuario tenga abierto).
let OFFICE = null;
function officeCands() {
  if (cfg.office) return [cfg.office];
  if (WIN) { const pf = [process.env.ProgramFiles || "C:\\Program Files", process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)"]; const c = [];
    for (const b of pf) c.push(path.join(b, "LibreOffice", "program", "soffice.exe"), path.join(b, "OpenOffice 4", "program", "soffice.exe"), path.join(b, "OpenOffice.org 3", "program", "soffice.exe"));
    if (process.env.LOCALAPPDATA) c.push(path.join(process.env.LOCALAPPDATA, "Programs", "LibreOffice", "program", "soffice.exe"));
    for (const d of ["C", "D", "E"]) c.push(d + ":\\LibreOffice\\program\\soffice.exe", d + ":\\Program Files\\LibreOffice\\program\\soffice.exe", d + ":\\PortableApps\\LibreOfficePortable\\App\\libreoffice\\program\\soffice.exe");
    return c; }
  if (MAC) return ["/Applications/LibreOffice.app/Contents/MacOS/soffice", "/Applications/OpenOffice.app/Contents/MacOS/soffice"];
  return ["/usr/bin/soffice", "/usr/bin/libreoffice", "/usr/local/bin/soffice", "/snap/bin/libreoffice", "/opt/libreoffice/program/soffice", "/usr/bin/openoffice4"];
}
async function officeFind(force) {
  if (OFFICE && !force) return OFFICE;
  let ruta = officeCands().find(p => { try { return fs.statSync(p).isFile(); } catch (e) { return false; } });
  if (!ruta && !cfg.office) {   // última opción: soffice en el PATH
    const r = await run(WIN ? "where" : "which", [WIN ? "soffice.exe" : "soffice"], { timeout: 8000 }); const p = (r.salida || "").split(/\r?\n/).map(x => x.trim()).find(Boolean);
    if (p && fs.existsSync(p)) ruta = p;
  }
  if (!ruta) return (OFFICE = { disponible: false });
  const suite = /openoffice/i.test(ruta) ? "Apache OpenOffice" : "LibreOffice";
  let version = "";
  if (!WIN) { const r = await run(ruta, ["--version"], { timeout: 20000 }); version = (r.salida.match(/\d+\.\d+(\.\d+)*/) || [""])[0]; }
  return (OFFICE = { disponible: true, suite, ruta, version });
}
const OFFICE_FMT = { pdf: 1, docx: 1, odt: 1, doc: 1, rtf: 1, txt: 1, html: 1, xlsx: 1, ods: 1, xls: 1, csv: 1, pptx: 1, odp: 1, ppt: 1, png: 1 };
const OFFICE_PROFILE = () => "-env:UserInstallation=" + new URL("file://" + (WIN ? "/" : "") + path.join(DIR, "office-perfil").replace(/\\/g, "/")).href;
async function officeConvert(src, fmt, outdir) {
  const o = await officeFind(); if (!o.disponible) throw new Error("No encuentro LibreOffice ni OpenOffice en esta PC. Instalá LibreOffice (libreoffice.org) o indicá la ruta de soffice en " + CFG_F + " (\"office\").");
  if (o.suite !== "LibreOffice") throw new Error("Apache OpenOffice no permite crear ni convertir documentos de forma automática: puede abrirlos, pero para crear y convertir instalá LibreOffice (gratis, libreoffice.org). Pueden convivir.");
  fmt = String(fmt || "").toLowerCase().replace(/^\./, ""); if (!OFFICE_FMT[fmt]) throw new Error("Formato no admitido: " + fmt);
  const tmp = path.join(DIR, "office-salida", Date.now().toString(36)); await fsp.mkdir(tmp, { recursive: true });
  const filtro = fmt === "csv" ? "csv:Text - txt - csv (StarCalc):44,34,76,1" : fmt === "txt" ? "txt:Text (encoded):UTF8" : fmt === "docx" && /\.html?$/i.test(src) ? "docx:MS Word 2007 XML" : fmt === "pdf" && /\.html?$/i.test(src) ? "pdf:writer_pdf_Export" : fmt;
  // HTML → Writer (si no, abre en Writer/Web, que no exporta a Word). CSV: UTF-8, punto decimal (en-US) y fórmulas que empiezan con «=» evaluadas
  const inf = /\.html?$/i.test(src) ? ["--infilter=HTML (StarWriter)"] : /\.csv$/i.test(src) ? ["--infilter=Text - txt - csv (StarCalc):44,34,76,1,,1033,false,true,false,false,false,false,true"] : [];
  const r = await run(o.ruta, [OFFICE_PROFILE(), "--headless", "--invisible", "--norestore", "--nolockcheck", ...inf, "--convert-to", filtro, "--outdir", tmp, src], { timeout: 180000 });
  const out = (await fsp.readdir(tmp)).find(f => f.toLowerCase().endsWith("." + fmt));
  if (!out) { await fsp.rm(tmp, { recursive: true, force: true }); throw new Error("La conversión no generó el archivo. " + (r.error || r.salida || "").trim().slice(0, 300)); }
  return path.join(tmp, out);
}
async function officePlace(tmpFile, dst, sobrescribir) {
  let respaldo = null;
  if (fs.existsSync(dst)) { if (!sobrescribir) { await fsp.rm(path.dirname(tmpFile), { recursive: true, force: true }); throw new Error("Ya existe: " + dst + " (pedí sobrescribir)"); } respaldo = await toTrash(dst, "copia"); }
  await fsp.mkdir(path.dirname(dst), { recursive: true }); await moveAny(tmpFile, dst); await fsp.rm(path.dirname(tmpFile), { recursive: true, force: true });
  return respaldo;
}
const ENTRADA = { html: "html", markdown: "html", texto: "txt", txt: "txt", csv: "csv" };

async function copiaPath(id) {
  if (!/^[a-z0-9]{6,30}$/.test(String(id || ""))) throw new Error("Copia inválida");
  const d = path.join(DIR, "abiertos", String(id)); const f = (await fsp.readdir(d)).filter(n => !n.startsWith(".~lock") && !n.startsWith("~$"))[0];
  if (!f) throw new Error("La copia ya no existe"); return path.join(d, f);
}
async function limpiarCopias() {   // las copias abiertas se borran a los 7 días
  try { const d = path.join(DIR, "abiertos"); for (const n of await fsp.readdir(d)) { const st = await fsp.stat(path.join(d, n)); if (Date.now() - st.mtimeMs > 7 * 864e5) await fsp.rm(path.join(d, n), { recursive: true, force: true }); } } catch (e) {}
}
/* ---------------- web: leer páginas para el Navegador y el asistente ----------------
   Solo http/https públicos: se rechazan 127.x, 10.x, 192.168.x, 172.16-31.x, 169.254.x, ::1, fc00::/7 y similares
   (también tras cada redirección), salvo "web_red_local": true en config.json. Máx. 4 MB y 15 s. */
function ipPrivada(ip) {
  if (net.isIPv4(ip)) { const [a, b] = ip.split(".").map(Number); return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224; }
  const l = ip.toLowerCase(); return l === "::1" || l === "::" || l.startsWith("fc") || l.startsWith("fd") || l.startsWith("fe80") || (l.startsWith("::ffff:") && ipPrivada(l.slice(7)));
}
async function urlSegura(u) {
  let url; try { url = new URL(String(u || "")); } catch (e) { throw new Error("Dirección inválida"); }
  if (!/^https?:$/.test(url.protocol)) throw new Error("Solo se admiten direcciones http y https");
  if (cfg.web_red_local) return url;
  const host = url.hostname.replace(/^\[|\]$/g, "");
  const ips = net.isIP(host) ? [host] : (await dns.lookup(host, { all: true }).catch(() => [])).map(x => x.address);
  if (!ips.length) throw new Error("No se encontró el sitio: " + host);
  if (ips.some(ipPrivada)) throw new Error("Por seguridad, el núcleo no lee direcciones de la red local");
  return url;
}
async function webGet(u) {
  let url = await urlSegura(u);
  for (let i = 0; i < 6; i++) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
    let r; try { r = await fetch(url, { redirect: "manual", signal: ctl.signal, headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 ARTLAS-OS", "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.5", "Accept-Language": "es-AR,es;q=0.9,en;q=0.8" } }); }
    catch (e) { clearTimeout(t); throw new Error(e.name === "AbortError" ? "La página tardó demasiado" : "No se pudo conectar: " + (e.cause && e.cause.code || e.message)); }
    if (r.status >= 300 && r.status < 400 && r.headers.get("location")) { clearTimeout(t); url = await urlSegura(new URL(r.headers.get("location"), url).href); continue; }
    const tipo = r.headers.get("content-type") || ""; const chunks = []; let n = 0;
    try { for await (const c of r.body) { n += c.length; if (n > 4 * 1024 * 1024) break; chunks.push(c); } } finally { clearTimeout(t); }
    const buf = Buffer.concat(chunks); let cs = (tipo.match(/charset=([\w-]+)/i) || [])[1];
    if (!cs && /html/i.test(tipo)) cs = (buf.slice(0, 4096).toString("latin1").match(/<meta[^>]+charset=["']?([\w-]+)/i) || [])[1];
    let texto; try { texto = new TextDecoder(cs || "utf-8").decode(buf); } catch (e) { texto = buf.toString("utf8"); }
    return { url: url.href, estado: r.status, tipo, texto };
  }
  throw new Error("Demasiadas redirecciones");
}
const ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " ", laquo: "«", raquo: "»", ndash: "–", mdash: "—", hellip: "…", aacute: "á", eacute: "é", iacute: "í", oacute: "ó", uacute: "ú", ntilde: "ñ", Aacute: "Á", Eacute: "É", Iacute: "Í", Oacute: "Ó", Uacute: "Ú", Ntilde: "Ñ", uuml: "ü", iexcl: "¡", iquest: "¿", copy: "©", reg: "®", deg: "°", middot: "·" };
const deco = t => t.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) => e[0] === "#" ? String.fromCodePoint(e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : +e.slice(1)) : (ENT[e] ?? m));
const sinTags = t => t.replace(/<[^>]+>/g, " ");
function html2md(html, base) {
  let h = String(html).replace(/<!--[\s\S]*?-->/g, "").replace(/<(script|style|noscript|svg|iframe|template|form|nav|footer|aside|button|select)\b[\s\S]*?<\/\1>/gi, " ");
  const titulo = deco(sinTags((h.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || "")).replace(/\s+/g, " ").trim();
  const m = h.match(/<(article|main)\b[\s\S]*?<\/\1>/i); if (m && sinTags(m[0]).replace(/\s+/g, "").length > 400) h = m[0]; else { const b = h.match(/<body\b[\s\S]*<\/body>/i); if (b) h = b[0]; }
  h = h.replace(/<header\b[\s\S]*?<\/header>/gi, (x) => /<h1/i.test(x) ? x : " ");
  h = h.replace(/<a\s[^>]*href\s*=\s*["']([^"'#][^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi, (_, href, t) => { t = deco(sinTags(t)).replace(/\s+/g, " ").trim(); if (!t) return " "; let u; try { u = new URL(deco(href), base).href; } catch (e) { return t; } return /^https?:/.test(u) ? `[${t.replace(/[\[\]]/g, "")}](${u.replace(/\)/g, "%29")})` : t; });
  h = h.replace(/<h([1-4])\b[^>]*>([\s\S]*?)<\/h\1>/gi, (_, n, t) => "\n\n" + "#".repeat(+n) + " " + sinTags(t).replace(/\s+/g, " ").trim() + "\n\n");
  h = h.replace(/<li\b[^>]*>/gi, "\n- ").replace(/<(td|th)\b[^>]*>/gi, " · ").replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|div|section|tr|ul|ol|table|blockquote|li|dd|dt|figure|pre)>/gi, "\n").replace(/<(p|div|section|blockquote|pre|tr)\b[^>]*>/gi, "\n");
  h = h.replace(/<(b|strong)\b[^>]*>([\s\S]*?)<\/\1>/gi, (_, x, t) => { t = sinTags(t).replace(/\s+/g, " ").trim(); return t ? " **" + t + "** " : " "; });
  let t = deco(sinTags(h)).replace(/[ \t\u00a0]+/g, " ").split("\n").map(x => x.trim()).filter((x, i, a) => x || (a[i - 1] && a[i - 1].trim())).join("\n").replace(/\n{3,}/g, "\n\n").trim();
  for (let k = 0; k < 3; k++) t = t.replace(/(^|\n)(- [^\n]*)\n\n(?=- )/g, "$1$2\n");
  return { titulo, texto: t };
}


/* ---------------- íconos de aplicaciones (v6.9.4) ----------------
   Windows: PowerShell + System.Drawing (destino o IconLocation del acceso directo). Linux: Icon= del .desktop.
   macOS: .icns del paquete con sips. Se guardan en ~/.artlas-nucleo/iconos/ y se devuelven como data URL. */
const ICO_DIR = () => path.join(DIR, "iconos");
const icoKey = (ruta) => crypto.createHash("sha1").update(String(ruta)).digest("hex").slice(0, 16);
async function icoCached(k) { for (const e of ["png", "svg"]) { const f = path.join(ICO_DIR(), k + "." + e); try { const b = await fsp.readFile(f); if (!b.length) return ""; return "data:image/" + (e === "svg" ? "svg+xml" : "png") + ";base64," + b.toString("base64"); } catch (e) {} } return null; }
function linuxIcon(name) {
  if (!name) return null; if (path.isAbsolute(name) && fs.existsSync(name)) return name;
  const bases = ["/usr/share/icons/hicolor", "/usr/share/icons/Adwaita", path.join(HOME, ".local/share/icons/hicolor")];
  for (const b of bases) for (const sz of ["48x48", "64x64", "128x128", "256x256", "32x32", "scalable"]) for (const e of ["png", "svg"]) { const f = path.join(b, sz, "apps", name + "." + e); if (fs.existsSync(f)) return f; }
  for (const e of ["png", "svg"]) { const f = path.join("/usr/share/pixmaps", name + "." + e); if (fs.existsSync(f)) return f; }
  return null;
}
async function iconos(items) {   // items: [{k, ruta, icon?}] → { k: dataURL | "" }
  await fsp.mkdir(ICO_DIR(), { recursive: true }); const out = {}, falta = [];
  for (const it of items) { const c = await icoCached(icoKey(it.ruta)); if (c !== null) out[it.k] = c; else falta.push(it); }
  if (!falta.length) return out;
  if (WIN) {
    const ps = path.join(ICO_DIR(), "extraer.ps1"), lista = path.join(ICO_DIR(), "lista-" + Date.now() + ".json");
    await fsp.writeFile(ps, `param([string]$Lista)
Add-Type -AssemblyName System.Drawing
$sh = New-Object -ComObject WScript.Shell
$items = Get-Content -Raw -Encoding UTF8 -LiteralPath $Lista | ConvertFrom-Json
foreach ($it in $items) {
  try {
    $src = $it.ruta; $ico = $null
    if ($src -like '*.lnk') { $l = $sh.CreateShortcut($src); $loc = $l.IconLocation
      if ($loc -and -not $loc.StartsWith(',')) { $p = [Environment]::ExpandEnvironmentVariables(($loc -split ',')[0]); if (Test-Path -LiteralPath $p) { $ico = $p } }
      if (-not $ico) { $t = $l.TargetPath; if ($t -and (Test-Path -LiteralPath $t)) { $ico = $t } } }
    if ($src -like '*.url') { $m = Select-String -LiteralPath $src -Pattern '^IconFile=(.+)$' | Select-Object -First 1; if ($m) { $p = [Environment]::ExpandEnvironmentVariables($m.Matches[0].Groups[1].Value.Trim()); if (Test-Path -LiteralPath $p) { $ico = $p } } }
    if (-not $ico) { $ico = $src }
    if ($ico -like '*.ico') { $i = New-Object System.Drawing.Icon($ico, 48, 48) } else { $i = [System.Drawing.Icon]::ExtractAssociatedIcon($ico) }
    $b = $i.ToBitmap(); $b.Save($it.out, [System.Drawing.Imaging.ImageFormat]::Png); $b.Dispose(); $i.Dispose()
  } catch { }
}
`, "utf8");
    await fsp.writeFile(lista, JSON.stringify(falta.map(it => ({ ruta: it.ruta, out: path.join(ICO_DIR(), icoKey(it.ruta) + ".png") }))), "utf8");
    await run("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ps, "-Lista", lista], { timeout: 60000 });
    await fsp.rm(lista, { force: true });
  } else {
    for (const it of falta) {
      const k = icoKey(it.ruta); let f = null;
      try {
        if (MAC) { const pl = path.join(it.ruta, "Contents", "Info.plist"); const t = fs.existsSync(pl) ? fs.readFileSync(pl, "utf8") : ""; let n = (t.match(/<key>CFBundleIconFile<\/key>\s*<string>([^<]+)<\/string>/) || [])[1]; if (n) { if (!/\.icns$/.test(n)) n += ".icns"; const icns = path.join(it.ruta, "Contents", "Resources", n); if (fs.existsSync(icns)) await run("sips", ["-s", "format", "png", "-Z", "64", icns, "--out", path.join(ICO_DIR(), k + ".png")], { timeout: 15000 }); } }
        else { f = linuxIcon(it.icon); if (f) await fsp.copyFile(f, path.join(ICO_DIR(), k + (f.endsWith(".svg") ? ".svg" : ".png"))); }
      } catch (e) {}
    }
  }
  for (const it of falta) { const k = icoKey(it.ruta); const c = await icoCached(k); if (c === null) { try { await fsp.writeFile(path.join(ICO_DIR(), k + ".png"), ""); } catch (e) {} out[it.k] = ""; } else out[it.k] = c; }   // vacío = sin ícono (no se reintenta)
  return out;
}
function officeModulos(o) {
  if (!o || !o.disponible) return null; const d = path.dirname(o.ruta);
  if (WIN) return { writer: path.join(d, "swriter.exe"), calc: path.join(d, "scalc.exe"), impress: path.join(d, "simpress.exe") };
  if (MAC) return { writer: path.dirname(path.dirname(o.ruta)), calc: path.dirname(path.dirname(o.ruta)), impress: path.dirname(path.dirname(o.ruta)) };
  return { writer: "libreoffice-writer", calc: "libreoffice-calc", impress: "libreoffice-impress" };
}


/* ---------------- inicio desde AR.T.L.A.S. OS (v7.3) ----------------
   Registra el protocolo artlas-nucleo:// para el usuario actual (sin permisos de administrador), así el botón
   «Iniciar el núcleo» del OS (web o Escritorio) puede abrirlo cuando ya fue emparejado. Opcional: inicio automático
   con la sesión del sistema. Se desactiva con "protocolo": false en config.json. */
const SCRIPT = (() => { try { return decodeURIComponent(new URL(import.meta.url).pathname).replace(/^\/([A-Za-z]:)/, "$1"); } catch (e) { return process.argv[1]; } })();
const LAUNCH_VBS = () => path.join(DIR, "iniciar-nucleo.vbs");
const STARTUP_DIR = () => WIN ? path.join(process.env.APPDATA || path.join(HOME, "AppData", "Roaming"), "Microsoft", "Windows", "Start Menu", "Programs", "Startup") : path.join(HOME, ".config", "autostart");
const STARTUP_FILE = () => path.join(STARTUP_DIR(), WIN ? "ARTLAS-Nucleo.vbs" : "artlas-nucleo.desktop");
function lanzadorVbs() {   // ventana minimizada (se ve en la barra de tareas y se puede cerrar)
  const q = s => '""' + String(s).replace(/"/g, '') + '""';
  const args = [q(process.execPath), q(SCRIPT), ...argv.map(a => q(a))].join(" ");
  return `' AR.T.L.A.S. OS · inicia el núcleo local (generado automáticamente)\r\nSet sh = CreateObject("WScript.Shell")\r\nsh.CurrentDirectory = "${path.dirname(SCRIPT).replace(/"/g, "")}"\r\nsh.Run "${args}", 7, False\r\n`;
}
function desktopFile(extra) {
  const ex = [process.execPath, SCRIPT, ...argv].map(a => '"' + String(a).replace(/"/g, "") + '"').join(" ");
  return `[Desktop Entry]\nType=Application\nName=AR.T.L.A.S. Núcleo\nExec=${ex}${extra || ""}\nTerminal=false\nNoDisplay=true\n`;
}
let PROTO = false;
async function registrarProtocolo() {
  if (cfg.protocolo === false) return false;
  try {
    if (WIN) {
      await fsp.writeFile(LAUNCH_VBS(), Buffer.from("\ufeff" + lanzadorVbs(), "utf16le"));   // UTF-16 con BOM: wscript lee bien rutas con acentos
      const k = "HKCU\\Software\\Classes\\artlas-nucleo";
      const cmd = `"${path.join(process.env.SystemRoot || "C:\\Windows", "System32", "wscript.exe")}" "${LAUNCH_VBS()}" "%1"`;
      for (const a of [[k, "/ve", "/d", "URL:AR.T.L.A.S. Nucleo"], [k, "/v", "URL Protocol", "/d", ""], [k + "\\shell\\open\\command", "/ve", "/d", cmd]]) {
        const r = await run("reg", ["add", ...a, "/f"], { timeout: 10000 }); if (r.code !== 0) throw new Error(r.error || r.salida);
      }
      return (PROTO = true);
    }
    if (!MAC) {
      const d = path.join(HOME, ".local", "share", "applications"); await fsp.mkdir(d, { recursive: true });
      await fsp.writeFile(path.join(d, "artlas-nucleo.desktop"), desktopFile(" %u") + "MimeType=x-scheme-handler/artlas-nucleo;\n", "utf8");
      const r = await run("xdg-mime", ["default", "artlas-nucleo.desktop", "x-scheme-handler/artlas-nucleo"], { timeout: 10000 });
      return (PROTO = r.code === 0);
    }
  } catch (e) { console.log("  (No se pudo registrar el inicio desde el navegador: " + (e.message || e) + ")"); }
  return false;
}
function autoinicioActivo() { try { return fs.existsSync(STARTUP_FILE()); } catch (e) { return false; } }


/* ---------------- modo appliance (AR.T.L.A.S. OS como sistema propio, v7.6) ----------------
   Con "appliance": true el núcleo (1) sirve la app desde "app_dir" en http://127.0.0.1:<puerto>/app/,
   (2) le entrega el token a esa misma app (mismo origen, sin código de 6 dígitos) y (3) habilita las
   operaciones de sistema (Wi-Fi, volumen, zona horaria, apagar, instalar LibreOffice) a través del
   ayudante "sistema_cmd" (por defecto /usr/local/sbin/artlas-sistema, vía sudo -n). */
const APPL = () => !!cfg.appliance;
const MIME = { html: "text/html; charset=utf-8", js: "text/javascript; charset=utf-8", mjs: "text/javascript; charset=utf-8", css: "text/css; charset=utf-8", json: "application/json", webmanifest: "application/manifest+json", png: "image/png", webp: "image/webp", jpg: "image/jpeg", svg: "image/svg+xml", ico: "image/x-icon", pdf: "application/pdf", txt: "text/plain; charset=utf-8", wasm: "application/wasm", woff2: "font/woff2" };
async function serveApp(req, res, rel) {
  const base = path.resolve(cfg.app_dir || ""); if (!cfg.app_dir) return send(res, 404, { error: "Sin app_dir" });
  let p = path.resolve(base, "." + decodeURIComponent(rel || "/")); if (!(p === base || p.startsWith(base + path.sep))) return send(res, 403, { error: "Ruta no permitida" });
  try { if ((await fsp.stat(p)).isDirectory()) p = path.join(p, "app.html"); const b = await fsp.readFile(p);
    res.writeHead(200, { "Content-Type": MIME[ext(p)] || "application/octet-stream", "Cache-Control": /\.(html|js)$/.test(p) ? "no-cache" : "max-age=86400", "X-Content-Type-Options": "nosniff" }); res.end(b);
  } catch (e) { send(res, 404, { error: "No encontrado" }); }
}
async function sistema(args, timeout) {   // ayudante con lista cerrada de subcomandos; el núcleo nunca arma comandos libres
  const cmd = cfg.sistema_cmd || "/usr/local/sbin/artlas-sistema";
  const r = cfg.sistema_sin_sudo ? await run(cmd, args, { timeout: timeout || 60000 }) : await run("sudo", ["-n", cmd, ...args], { timeout: timeout || 60000 });
  if (r.code !== 0) throw new Error((r.error || r.salida || "Error del sistema").trim().slice(0, 400)); return r.salida.trim();
}
const SJOBS = new Map();
function needAppl() { if (!APPL()) throw new Error("Solo disponible en AR.T.L.A.S. OS instalado como sistema (modo appliance)."); }
/* RAG local (AR.T.L.A.S. RAG, Flask + llama.cpp en 127.0.0.1:8760) */
const RAG_PORT = () => +(cfg.rag_puerto || 8760);
async function ragVivo() { try { const r = await fetch(`http://127.0.0.1:${RAG_PORT()}/`, { signal: AbortSignal.timeout(1500) }); return r.status < 500; } catch (e) { return false; } }

/* ---------------- operaciones ---------------- */
const OPS = {
  "nucleo.info": async () => ({ ver: VER, raices: cfg.raices, permisos: cfg.permisos, plataforma: process.platform, config: CFG_F }),
  // v7.4 · sumar una carpeta a las permitidas: la elige el usuario EN SU PC, con el diálogo nativo del sistema
  // (la web no puede indicar la ruta). Útil para carpetas conectadas en el navegador donde Chrome bloquea cambios.
  "fs.agregarRaiz": async (a) => {
    need("lectura"); let ruta = ""; const titulo = "AR.T.L.A.S. OS · Elegí la carpeta que el núcleo podrá usar" + (a.sugerida ? " («" + String(a.sugerida).replace(/["'`$]/g, "").slice(0, 80) + "»)" : "");
    if (WIN) {
      const ps = `[Console]::OutputEncoding=[Text.Encoding]::UTF8; Add-Type -AssemblyName System.Windows.Forms; $f=New-Object System.Windows.Forms.Form; $f.TopMost=$true; $f.ShowInTaskbar=$false; $f.Opacity=0; $f.Show(); $d=New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description='${titulo.replace(/'/g, "")}'; $d.ShowNewFolderButton=$false; if($d.ShowDialog($f) -eq 'OK'){ Write-Output $d.SelectedPath }; $f.Close()`;
      const r = await run("powershell.exe", ["-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", ps], { timeout: 600000 }); ruta = (r.salida || "").trim();
    } else if (MAC) {
      const r = await run("osascript", ["-e", `POSIX path of (choose folder with prompt "${titulo.replace(/"/g, "")}")`], { timeout: 600000 }); ruta = (r.salida || "").trim().replace(/\/$/, "");
    } else {
      const r = await run("zenity", ["--file-selection", "--directory", "--title=" + titulo], { timeout: 600000 }); ruta = (r.salida || "").trim();
      if (!ruta && r.error && /ENOENT/.test(r.error)) throw new Error("Falta zenity para mostrar el selector de carpetas. Agregala con: Iniciar-Nucleo --raiz \"/ruta\"");
    }
    if (!ruta) throw new Error("No se eligió ninguna carpeta.");
    ruta = path.resolve(ruta); let st; try { st = fs.statSync(ruta); } catch (e) { throw new Error("No existe: " + ruta); }
    if (!st.isDirectory()) throw new Error("No es una carpeta: " + ruta);
    if (path.parse(ruta).root === ruta || /^[A-Za-z]:\\(Windows|Program Files( \(x86\))?|ProgramData)(\\|$)/i.test(ruta) || /^\/(etc|bin|sbin|usr|boot|proc|sys|dev|var|System|Library)(\/|$)/.test(ruta)) throw new Error("Por seguridad no se permite esa carpeta del sistema: " + ruta);
    if (!cfg.raices.some(x => same(x, ruta))) { cfg.raices.push(ruta); saveCfg(); }
    return { ruta, nombre: path.basename(ruta), raices: cfg.raices };
  },
  "fs.raices": async () => { need("lectura"); return Promise.all(cfg.raices.map(async r => ({ nombre: path.basename(r) || r, ruta: r, disco: await disk(r) }))); },
  "fs.listar": async (a) => {
    need("lectura"); const p = safe(a.ruta, true);
    const es = await fsp.readdir(p, { withFileTypes: true }); const out = [];
    for (const e of es) {
      if (!a.ocultos && (e.name.startsWith(".") || /^(desktop\.ini|thumbs\.db|\$recycle\.bin|ntuser\..*)$/i.test(e.name))) continue;
      let st = null; try { st = await fsp.stat(path.join(p, e.name)); } catch (x) { continue; }
      out.push({ nombre: e.name, tipo: st.isDirectory() ? "dir" : "archivo", tam: st.size, mod: st.mtimeMs, ext: st.isDirectory() ? "" : ext(e.name) });
      if (out.length >= 3000) break;
    }
    out.sort((x, y) => (x.tipo === y.tipo ? x.nombre.localeCompare(y.nombre, "es", { numeric: true }) : x.tipo === "dir" ? -1 : 1));
    return { ruta: p, padre: realRoots().some(r => same(r, p)) ? null : path.dirname(p), entradas: out };
  },
  "fs.info": async (a) => { need("lectura"); const p = safe(a.ruta, true); const st = await fsp.stat(p); return { ruta: p, nombre: path.basename(p), tipo: st.isDirectory() ? "dir" : "archivo", tam: st.size, mod: st.mtimeMs, creado: st.birthtimeMs }; },
  "fs.leer": async (a) => {
    need("lectura"); const p = safe(a.ruta, true); const st = await fsp.stat(p);
    if (st.isDirectory()) throw new Error("Es una carpeta");
    const max = Math.min(+a.max || 2 * 1024 * 1024, 25 * 1024 * 1024);
    const fh = await fsp.open(p, "r"); const len = Math.min(st.size, max); const buf = Buffer.alloc(len); await fh.read(buf, 0, len, 0); await fh.close();
    if (a.modo !== "base64" && isText(buf)) return { ruta: p, texto: buf.toString("utf8"), tam: st.size, truncado: st.size > len };
    if (st.size > max) throw new Error("Archivo binario demasiado grande para leer (" + Math.round(st.size / 1048576) + " MB)");
    return { ruta: p, base64: buf.toString("base64"), tam: st.size, ext: ext(p) };
  },
  "fs.escribir": async (a) => {
    need("escritura"); const p = safe(a.ruta); let respaldo = null;
    if (fs.existsSync(p)) { if (!a.sobrescribir) throw new Error("Ya existe: " + p + " (pedí sobrescribir)"); respaldo = await toTrash(p, "copia"); }
    await fsp.mkdir(path.dirname(p), { recursive: true });
    await fsp.writeFile(p, a.base64 != null ? Buffer.from(a.base64, "base64") : String(a.texto ?? ""));
    return { ruta: p, respaldo };
  },
  "fs.crearCarpeta": async (a) => { need("escritura"); const p = safe(a.ruta); await fsp.mkdir(p, { recursive: true }); return { ruta: p }; },
  "fs.mover": async (a) => {
    need("escritura"); const de = safe(a.de, true); let dst = safe(a.a);
    if (fs.existsSync(dst) && fs.statSync(dst).isDirectory() && !same(path.dirname(de), dst)) dst = safe(path.join(dst, path.basename(de)));
    if (fs.existsSync(dst)) throw new Error("El destino ya existe: " + dst);
    await fsp.mkdir(path.dirname(dst), { recursive: true }); await moveAny(de, dst); return { de, a: dst };
  },
  "fs.copiar": async (a) => {
    need("escritura"); const de = safe(a.de, true); let dst = safe(a.a);
    if (fs.existsSync(dst) && fs.statSync(dst).isDirectory()) dst = safe(path.join(dst, path.basename(de)));
    if (fs.existsSync(dst)) throw new Error("El destino ya existe: " + dst);
    await fsp.cp(de, dst, { recursive: true, errorOnExist: true }); return { de, a: dst };
  },
  "fs.papelera": async (a) => { need("escritura"); const p = safe(a.ruta, true); if (realRoots().some(r => same(r, p))) throw new Error("No se puede borrar una raíz"); return { id: await toTrash(p), ruta: p }; },
  "fs.verPapelera": async () => trashDb(),
  "fs.restaurar": async (a) => {
    need("escritura"); const db = trashDb(); const e = db.find(x => x.id === a.id); if (!e) throw new Error("No está en la papelera");
    const dst = safe(e.original); if (fs.existsSync(dst)) throw new Error("Ya existe un elemento en " + dst);
    await fsp.mkdir(path.dirname(dst), { recursive: true }); await moveAny(path.join(TRASH, e.id, e.nombre), dst);
    await fsp.rm(path.join(TRASH, e.id), { recursive: true, force: true });
    fs.writeFileSync(TRASH_F, JSON.stringify(db.filter(x => x.id !== a.id), null, 1)); return { ruta: dst };
  },
  "fs.buscar": async (a) => {
    need("lectura"); const base = a.ruta ? safe(a.ruta, true) : null; const q = String(a.patron || "").toLowerCase().trim(); if (!q) throw new Error("Falta el patrón");
    const rx = q.includes("*") || q.includes("?") ? new RegExp("^" + q.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$") : null;
    const txt = a.texto ? String(a.texto).toLowerCase() : null; const max = Math.min(+a.max || 200, 1000); const out = []; const t0 = Date.now();
    async function go(d, depth) {
      if (out.length >= max || depth < 0 || Date.now() - t0 > 15000) return; let es; try { es = await fsp.readdir(d, { withFileTypes: true }); } catch (e) { return; }
      for (const e of es) {
        if (out.length >= max) return; if (e.name.startsWith(".") || /^(node_modules|\$recycle\.bin|appdata|__pycache__)$/i.test(e.name)) continue;
        const p = path.join(d, e.name); const n = e.name.toLowerCase();
        let hit = rx ? rx.test(n) : n.includes(q);
        if (hit && txt && e.isFile()) { try { const st = await fsp.stat(p); hit = st.size < 1048576 && (await fsp.readFile(p, "utf8")).toLowerCase().includes(txt); } catch (x) { hit = false; } }
        if (hit) out.push({ ruta: p, nombre: e.name, tipo: e.isDirectory() ? "dir" : "archivo" });
        if (e.isDirectory()) await go(p, depth - 1);
      }
    }
    for (const r of base ? [base] : realRoots()) await go(r, Math.min(+a.profundidad || 6, 10));
    return { resultados: out, truncado: out.length >= max };
  },
  "fs.abrir": async (a) => { need("apps"); const p = safe(a.ruta, true); openWithDefault(p); return { ruta: p }; },
  "fs.revelar": async (a) => { need("lectura"); const p = safe(a.ruta, true); if (WIN) detached("explorer.exe", ["/select," + p]); else if (MAC) detached("open", ["-R", p]); else detached("xdg-open", [path.dirname(p)]); return { ruta: p }; },

  // Documentos que el navegador tiene pero el núcleo no ve (carpetas conectadas en el navegador): se abre una COPIA
  // en ~/.artlas-nucleo/abiertos/<id>/ y la app puede traer de vuelta los cambios que el usuario guarde ahí.
  "fs.abrirCopia": async (a) => {
    need("apps"); const nombre = path.basename(String(a.nombre || "documento")).replace(/[<>:"/\\|?*\x00-\x1f]/g, "_").slice(0, 150) || "documento";
    if (!a.base64) throw new Error("Falta el contenido del archivo");
    const id = Date.now().toString(36) + crypto.randomBytes(3).toString("hex"); const dir = path.join(DIR, "abiertos", id);
    await fsp.mkdir(dir, { recursive: true }); const f = path.join(dir, nombre); await fsp.writeFile(f, Buffer.from(String(a.base64), "base64"));
    const st = await fsp.stat(f); let con = "sistema";
    if (a.con !== "sistema") { const o = await officeFind(); if (o.disponible) { detached(o.ruta, ["--norestore", f]); con = o.suite; } }
    if (con === "sistema") openWithDefault(f);
    return { id, mod: st.mtimeMs, con };
  },
  "fs.estadoCopia": async (a) => { need("lectura"); const f = await copiaPath(a.id); const st = await fsp.stat(f); return { mod: st.mtimeMs, tam: st.size }; },
  "fs.leerCopia": async (a) => { need("lectura"); const f = await copiaPath(a.id); const st = await fsp.stat(f); if (st.size > 60 * 1024 * 1024) throw new Error("Archivo demasiado grande"); return { base64: (await fsp.readFile(f)).toString("base64"), mod: st.mtimeMs }; },
  "web.leer": async (a) => {
    need("web"); const r = await webGet(a.url); const max = Math.min(+a.max || 60000, 200000);
    if (/html|xml/i.test(r.tipo) || /^\s*</.test(r.texto)) { const d = html2md(r.texto, r.url); return { url: r.url, estado: r.estado, titulo: d.titulo, texto: d.texto.slice(0, max), truncado: d.texto.length > max }; }
    if (/^text\/|json/i.test(r.tipo)) return { url: r.url, estado: r.estado, titulo: "", texto: r.texto.slice(0, max), truncado: r.texto.length > max };
    throw new Error("No es una página de texto (" + (r.tipo || "tipo desconocido") + "). Abrila en el navegador de la PC.");
  },
  "web.abrir": async (a) => { need("apps"); const u = await urlSegura(a.url); openWithDefault(u.href); return { url: u.href }; },
  "nucleo.estado": async () => ({ protocolo: PROTO, autoinicio: autoinicioActivo(), plataforma: process.platform, script: SCRIPT, puerto: PORT }),
  "nucleo.autoinicio": async (a) => {
    need("apps"); if (MAC) throw new Error("En macOS agregalo a mano en Ajustes → General → Ítems de inicio.");
    const f = STARTUP_FILE();
    if (a.activar) { await fsp.mkdir(path.dirname(f), { recursive: true }); await fsp.writeFile(f, WIN ? Buffer.from("\ufeff" + lanzadorVbs(), "utf16le") : desktopFile() + "X-GNOME-Autostart-enabled=true\n"); }
    else await fsp.rm(f, { force: true });
    return { autoinicio: autoinicioActivo() };
  },
  "nucleo.detener": async () => { setTimeout(() => { console.log("\n  Núcleo detenido desde AR.T.L.A.S. OS.\n"); process.exit(0); }, 400); return { detenido: true }; },
  "sistema.estado": async () => {
    const o = { appliance: APPL(), equipo: os.hostname(), zona: Intl.DateTimeFormat().resolvedOptions().timeZone };
    if (!APPL()) return o;
    try { o.wifi = (await sistema(["wifi-actual"], 15000)) || ""; } catch (e) { o.wifi = ""; }
    try { o.volumen = +(await sistema(["volumen-actual"], 10000)) || 0; } catch (e) {}
    return o;
  },
  "sistema.wifi": async (a) => {
    needAppl();
    if (a.accion === "conectar") { if (!a.ssid) throw new Error("Falta la red"); return { salida: await sistema(["wifi-conectar", String(a.ssid).slice(0, 64), String(a.clave || "").slice(0, 128)], 45000) }; }
    const out = await sistema(["wifi-listar"], 30000);
    return { redes: out.split("\n").filter(Boolean).map(l => { const [ssid, senal, seg, uso] = l.split("\t"); return { ssid, senal: +senal || 0, segura: !!seg && seg !== "--", activa: uso === "*" }; }).filter(x => x.ssid) };
  },
  "sistema.volumen": async (a) => { needAppl(); const v = Math.max(0, Math.min(100, Math.round(+a.valor || 0))); await sistema(["volumen", String(v)]); return { volumen: v }; },
  "sistema.zona": async (a) => { needAppl(); if (!/^[A-Za-z_]+(\/[A-Za-z_\-+0-9]+){0,2}$/.test(String(a.zona || ""))) throw new Error("Zona horaria inválida"); await sistema(["zona", a.zona]); return { zona: a.zona }; },
  "sistema.energia": async (a) => { needAppl(); const acc = a.accion === "reiniciar" ? "reiniciar" : "apagar"; setTimeout(() => sistema([acc]).catch(() => {}), 600); return { accion: acc }; },
  "sistema.instalar": async (a) => {
    needAppl(); const paq = String(a.paquete || ""); if (!/^(libreoffice)$/.test(paq)) throw new Error("Paquete no disponible para instalar desde AR.T.L.A.S. OS");
    for (const j of SJOBS.values()) if (j.paquete === paq && j.estado === "instalando") return { job: j.id };
    const id = "s" + Date.now().toString(36); const j = { id, paquete: paq, estado: "instalando", inicio: Date.now(), log: "" }; SJOBS.set(id, j);
    sistema(["instalar", paq], 1800000).then(o => { j.estado = "listo"; j.log = o.slice(-2000); OFFICE = null; }).catch(e => { j.estado = "error"; j.error = e.message; });
    return { job: id };
  },
  "sistema.trabajo": async (a) => { const j = SJOBS.get(a.job); if (!j) return { estado: "desconocido" }; return { estado: j.estado, paquete: j.paquete, error: j.error, segundos: Math.round((Date.now() - j.inicio) / 1000) }; },
  "rag.estado": async () => ({ instalado: !!(cfg.rag_dir && fs.existsSync(path.join(cfg.rag_dir, "rag_local.py"))), activo: await ragVivo(), puerto: RAG_PORT(), url: `http://127.0.0.1:${RAG_PORT()}/` }),
  "rag.iniciar": async () => {
    need("apps"); if (await ragVivo()) return { activo: true };
    const dir = cfg.rag_dir; if (!dir || !fs.existsSync(path.join(dir, "rag_local.py"))) throw new Error("AR.T.L.A.S. RAG no está instalado en este equipo.");
    const py = cfg.rag_python || [path.join(dir, "venv", "bin", "python3"), path.join(dir, "venv", "Scripts", "python.exe")].find(p => fs.existsSync(p)) || (WIN ? "python" : "python3");
    const ch = spawn(py, ["rag_local.py"], { cwd: dir, detached: true, stdio: "ignore", windowsHide: true, env: { ...process.env, RAG_PORT: String(RAG_PORT()), RAG_AUTOLOAD: "0", BROWSER: WIN ? "" : "true" } }); ch.unref();
    for (let i = 0; i < 40; i++) { await new Promise(r => setTimeout(r, 500)); if (await ragVivo()) return { activo: true }; }
    return { activo: false, iniciando: true };
  },
  "office.estado": async (a) => officeFind(!!a.actualizar),
  "office.convertir": async (a) => {
    need("escritura"); const src = safe(a.ruta, true); const fmt = String(a.formato || "pdf").toLowerCase().replace(/^\./, "");
    const dst = safe(a.destino || path.join(path.dirname(src), path.basename(src, path.extname(src)) + "." + fmt));
    const tmp = await officeConvert(src, fmt); const respaldo = await officePlace(tmp, dst, a.sobrescribir); return { ruta: dst, respaldo };
  },
  "office.crear": async (a) => {
    need("escritura"); const dst = safe(a.ruta); const fmt = ext(dst); if (!OFFICE_FMT[fmt]) throw new Error("Extensión no admitida: ." + fmt); if (/^(pptx|odp|ppt|png)$/.test(fmt)) throw new Error("Las presentaciones no se generan automáticamente: abrí Impress o convertí un archivo existente.");
    const tipo = ENTRADA[String(a.origen || (fmt.match(/^(xlsx|ods|xls|csv)$/) ? "csv" : "html")).toLowerCase()] || "html";
    const work = path.join(DIR, "office-entrada"); await fsp.mkdir(work, { recursive: true });
    const base = path.join(work, path.basename(dst, path.extname(dst)).replace(/[^\w\-áéíóúñÁÉÍÓÚÑ ]/g, "_").slice(0, 60) || "documento");
    const src = base + "." + tipo; const txt = String(a.contenido ?? a.texto ?? "");
    await fsp.writeFile(src, tipo === "csv" || tipo === "txt" ? "\ufeff" + txt : txt, "utf8");
    try {
      if (fmt === tipo) { const t = path.join(DIR, "office-salida", Date.now().toString(36)); await fsp.mkdir(t, { recursive: true }); const f = path.join(t, path.basename(src)); await fsp.copyFile(src, f); return { ruta: dst, respaldo: await officePlace(f, dst, a.sobrescribir) }; }
      const tmp = await officeConvert(src, fmt); return { ruta: dst, respaldo: await officePlace(tmp, dst, a.sobrescribir) };
    } finally { await fsp.rm(src, { force: true }); }
  },
  "office.abrir": async (a) => {
    need("apps"); const o = await officeFind(); if (!o.disponible) throw new Error("No encuentro LibreOffice ni OpenOffice en esta PC.");
    if (a.ruta) { const p = safe(a.ruta, true); detached(o.ruta, ["--norestore", p]); return { abierto: p, suite: o.suite }; }
    const mod = { writer: "--writer", texto: "--writer", calc: "--calc", hoja: "--calc", impress: "--impress", presentacion: "--impress", draw: "--draw", math: "--math" }[String(a.app || "writer").toLowerCase()] || "--writer";
    detached(o.ruta, ["--norestore", mod]); return { abierto: mod.slice(2), suite: o.suite };
  },
  "app.iconos": async (a) => {
    need("apps"); const list = await listApps(); const ids = (Array.isArray(a.ids) ? a.ids : []).slice(0, 80);
    const items = ids.map(id => list.find(x => x.id === id)).filter(Boolean).map(x => ({ k: x.id, ruta: x.ruta, icon: x.icono }));
    return { iconos: await iconos(items) };
  },
  "office.iconos": async () => {
    const o = await officeFind(); const m = officeModulos(o); if (!m) return { iconos: {} };
    const items = Object.entries(m).map(([k, r]) => WIN || MAC ? ({ k, ruta: r }) : ({ k, ruta: "lo:" + r, icon: r })).filter(it => WIN || MAC ? fs.existsSync(it.ruta) : true);
    return { iconos: await iconos(items) };
  },
  "app.listar": async (a) => { need("apps"); return listApps(a.actualizar); },
  "app.abrir": async (a) => {
    need("apps"); const list = await listApps(); const app = findApp(list, a.id || a.nombre); if (!app) throw new Error("No encuentro la aplicación «" + (a.nombre || a.id) + "»");
    if (WIN) detached("explorer.exe", [app.ruta]); else if (MAC) detached("open", ["-a", app.ruta]); else if (app.exec) detached("/bin/sh", ["-c", app.exec]); else detached("gtk-launch", [path.basename(app.ruta, ".desktop")]);
    return { abierta: app.nombre };
  },
  "proc.listar": async () => { need("procesos"); return listProcs(); },
  "proc.cerrar": async (a) => {
    need("procesos"); const pid = +a.pid; if (!pid || pid <= 4 || pid === process.pid || pid === process.ppid) throw new Error("PID protegido o inválido");
    const p = (await listProcs()).find(x => x.pid === pid); if (!p) throw new Error("No existe el proceso " + pid);
    if (PROTECTED.test(p.nombre)) throw new Error("«" + p.nombre + "» es un proceso del sistema: no se cierra desde AR.T.L.A.S.");
    if (WIN) { const r = await run("taskkill", ["/PID", String(pid), ...(a.forzar ? ["/F"] : [])]); if (r.code) throw new Error(r.error || r.salida); }
    else process.kill(pid, a.forzar ? "SIGKILL" : "SIGTERM");
    return { cerrado: p.nombre, pid };
  },
  "sys.info": async () => {
    const drives = [];
    if (WIN) { for (const L of "CDEFGHIJKLMNOPQRSTUVWXYZ") { const r = L + ":\\"; if (fs.existsSync(r)) { const d = await disk(r); if (d) drives.push({ unidad: L + ":", ...d }); } } }
    else { const d = await disk("/"); if (d) drives.push({ unidad: "/", ...d }); }
    const nets = []; for (const [n, arr] of Object.entries(os.networkInterfaces())) for (const x of arr || []) if (x.family === "IPv4" && !x.internal) nets.push({ interfaz: n, ip: x.address, mac: x.mac });
    return { equipo: os.hostname(), usuario: os.userInfo().username, so: `${os.type()} ${os.release()}`, plataforma: process.platform, arquitectura: os.arch(), cpu: os.cpus()[0]?.model, nucleos: os.cpus().length, cpuUso: cpuUse(),
      memoria: { total: os.totalmem(), libre: os.freemem() }, encendido: os.uptime(), discos: drives, red: nets, node: process.version, nucleoVer: VER };
  },
  "shell.ejecutar": shell,
  "ia.estado": async () => ollamaEstado(),
  "ia.descargar": async (a) => ollamaPull(a.modelo),
  "ia.progreso": async (a) => JOBS.get(a.job) || { estado: "desconocido" },
  "ia.borrar": async (a) => { const r = await fetch(OLL() + "/api/delete", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model: a.modelo }) }); if (!r.ok) throw new Error("Ollama respondió " + r.status); return { borrado: a.modelo }; },
  "registro.ver": async (a) => logTail(Math.min(+a.n || 100, 500))
};
const MUTA = /^(sistema\.(wifi|volumen|zona|energia|instalar)|rag\.iniciar|nucleo\.(autoinicio|detener)|fs\.(agregarRaiz|escribir|crearCarpeta|mover|copiar|papelera|restaurar|abrir|abrirCopia)|office\.(crear|convertir|abrir)|app\.abrir|proc\.cerrar|shell\.ejecutar|ia\.(descargar|borrar))$/;
function brief(a) { const o = {}; for (const [k, v] of Object.entries(a || {})) o[k] = (k === "texto" || k === "base64") ? `(${String(v).length} car.)` : v; return o; }

/* ---------------- servidor HTTP ---------------- */
function cors(req, res) {
  const o = req.headers.origin;
  if (o && originOk(o)) {
    res.setHeader("Access-Control-Allow-Origin", o); res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Artlas-Token");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Private-Network", "true");
    res.setHeader("Access-Control-Max-Age", "600");
  }
  return !o || originOk(o);
}
function send(res, code, obj) { res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }); res.end(JSON.stringify(obj)); }
function body(req, limit = 60 * 1024 * 1024) {
  return new Promise((ok, ko) => { let n = 0; const ch = []; req.on("data", d => { n += d.length; if (n > limit) { ko(new Error("Pedido demasiado grande")); req.destroy(); } else ch.push(d); }); req.on("end", () => { try { ok(ch.length ? JSON.parse(Buffer.concat(ch).toString("utf8")) : {}); } catch (e) { ko(new Error("JSON inválido")); } }); req.on("error", ko); });
}
const bearer = (req) => (req.headers.authorization || "").replace(/^Bearer\s+/i, "") || req.headers["x-artlas-token"] || "";

const server = http.createServer(async (req, res) => {
  const okOrigin = cors(req, res);
  if (req.method === "OPTIONS") { res.writeHead(okOrigin ? 204 : 403); return res.end(); }
  if (!okOrigin) return send(res, 403, { error: "Origen no autorizado" });
  const host = (req.headers.host || "").split(":")[0];
  if (!["127.0.0.1", "localhost", "[::1]"].includes(host)) return send(res, 403, { error: "Host no permitido" });   // anti DNS-rebinding
  const url = new URL(req.url, "http://127.0.0.1");
  try {
    if (APPL() && req.method === "GET" && (url.pathname === "/" || url.pathname === "/app" || url.pathname.startsWith("/app/"))) {
      if (url.pathname === "/" || url.pathname === "/app") { res.writeHead(302, { Location: "/app/app.html?os=1&appliance=1" }); return res.end(); }
      return serveApp(req, res, url.pathname.slice(4));
    }
    if (url.pathname === "/appliance/token" && req.method === "POST") {   // solo la app servida por este mismo núcleo
      if (!APPL() || req.headers.origin !== `http://127.0.0.1:${PORT}`) return send(res, 403, { error: "No disponible" });
      let t = (cfg.tokens.find(x => x.nombre === "appliance") || {}).t;
      if (!t) { t = crypto.randomBytes(24).toString("base64url"); cfg.tokens.push({ t, origen: req.headers.origin, nombre: "appliance", fecha: new Date().toISOString() }); saveCfg(); }
      return send(res, 200, { token: t });
    }
    if (url.pathname === "/estado" && req.method === "GET") {
      return send(res, 200, { ok: true, nombre: "AR.T.L.A.S. Núcleo", ver: VER, plataforma: process.platform, equipo: os.hostname(), emparejado: tokOk(bearer(req)), permisos: cfg.permisos, appliance: APPL() });
    }
    if (url.pathname === "/emparejar" && req.method === "POST") {
      const b = await body(req, 4096);
      if (!PAIR.code || Date.now() > PAIR.until) { newCode(); return send(res, 410, { error: "El código venció. Mirá el nuevo en la consola del núcleo." }); }
      if (String(b.codigo || "").trim() !== PAIR.code) { if (++PAIR.fails >= 5) newCode(); return send(res, 401, { error: "Código incorrecto" }); }
      const t = crypto.randomBytes(24).toString("base64url");
      cfg.tokens.push({ t, origen: req.headers.origin || "", nombre: String(b.nombre || "").slice(0, 60), fecha: new Date().toISOString() }); saveCfg();
      log({ op: "emparejar", origen: req.headers.origin, ok: true }); newCode();
      return send(res, 200, { token: t, equipo: os.hostname() });
    }
    const om = url.pathname.match(/^\/ollama\/([\w-]+)(\/.*)$/);
    if (om) {     // puente a Ollama (resuelve CORS); el token va en la ruta porque el cliente de Ollama no manda encabezados
      if (!tokOk(om[1])) return send(res, 401, { error: "Núcleo no emparejado" });
      const b = req.method === "POST" ? await new Promise(r => { const c = []; req.on("data", d => c.push(d)); req.on("end", () => r(Buffer.concat(c))); }) : undefined;
      const r = await fetch(OLL() + om[2] + url.search, { method: req.method, headers: { "Content-Type": "application/json" }, body: b });
      res.writeHead(r.status, { "Content-Type": r.headers.get("content-type") || "application/json" });
      if (r.body) for await (const ch of r.body) res.write(ch);
      return res.end();
    }
    if (url.pathname === "/rpc" && req.method === "POST") {
      if (!tokOk(bearer(req))) return send(res, 401, { error: "Núcleo no emparejado" });
      const b = await body(req); const f = OPS[b.op]; if (!f) return send(res, 404, { error: "Operación desconocida: " + b.op });
      try { const out = await f(b.args || {}); if (MUTA.test(b.op)) log({ op: b.op, args: brief(b.args), ok: true }); return send(res, 200, { ok: true, r: out }); }
      catch (e) { if (MUTA.test(b.op)) log({ op: b.op, args: brief(b.args), ok: false, error: String(e.message || e) }); return send(res, 200, { ok: false, error: String(e.message || e) }); }
    }
    send(res, 404, { error: "No encontrado" });
  } catch (e) { send(res, 500, { error: String(e.message || e) }); }
});
server.on("error", (e) => { console.error(e.code === "EADDRINUSE" ? `\n  ✗ El puerto ${PORT} está ocupado: ¿el núcleo ya está abierto?\n` : e); process.exit(1); });
limpiarCopias();
server.listen(PORT, "127.0.0.1", async () => {
  if (await registrarProtocolo()) console.log("  Botón «Iniciar el núcleo» habilitado en AR.T.L.A.S. OS (protocolo artlas-nucleo://).");
  console.log(`\n  AR.T.L.A.S. OS · Núcleo local ${VER}   http://127.0.0.1:${PORT}\n  Carpetas permitidas:`);
  cfg.raices.forEach(r => console.log("    · " + r));
  console.log(`  Permisos y raíces: ${CFG_F}\n  Dejá esta ventana abierta mientras uses AR.T.L.A.S. OS. Ctrl+C para cerrar.`);
  newCode();
});
