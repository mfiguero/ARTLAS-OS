#!/bin/sh
# Ayudante de sistema FALSO para las pruebas del modo appliance (no toca el equipo).
LOG="${ARTLAS_PRUEBA_LOG:-/tmp/artlas-sistema-prueba.log}"
echo "$*" >> "$LOG"
case "$1" in
  wifi-listar) printf 'Casa\t80\tWPA2\t*\nVecino\t40\t--\t\n' ;;
  wifi-actual) echo "Casa" ;;
  wifi-conectar) echo "conectado a $2" ;;
  volumen-actual) echo 55 ;;
  volumen|zona) echo ok ;;
  instalar) sleep 1; echo "instalado $2" ;;
  apagar|reiniciar) echo ok ;;
  *) echo "subcomando desconocido" >&2; exit 2 ;;
esac
