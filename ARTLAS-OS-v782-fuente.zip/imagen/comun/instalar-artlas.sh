#!/bin/bash
# AR.T.L.A.S. OS · se ejecuta DENTRO del sistema que se está construyendo (chroot), en la ISO y en la Raspberry Pi.
# Requiere que ya estén copiados /opt/artlas/{app,nucleo,rag} y los archivos de imagen/comun/raiz.
set -euo pipefail
echo "== AR.T.L.A.S. OS: configurando el sistema =="
chmod 0440 /etc/sudoers.d/artlas
chmod 0755 /usr/local/sbin/artlas-sistema /usr/local/sbin/artlas-primer-arranque /usr/local/bin/artlas-kiosco
sed -i 's/^# *\(es_AR.UTF-8\)/\1/; s/^# *\(en_US.UTF-8\)/\1/' /etc/locale.gen || true
locale-gen || true
update-locale LANG=es_AR.UTF-8 || true
ln -sf /usr/share/zoneinfo/America/Argentina/Buenos_Aires /etc/localtime || true
systemctl enable artlas-primer-arranque.service artlas-nucleo.service NetworkManager.service || true
# v7.8.2: arranque más rápido (no esperar la red para mostrar la interfaz) y memoria comprimida (zram) para 4 GB
systemctl disable NetworkManager-wait-online.service systemd-networkd-wait-online.service 2>/dev/null || true
systemctl mask NetworkManager-wait-online.service 2>/dev/null || true
printf 'ALGO=zstd\nPERCENT=60\nPRIORITY=100\n' > /etc/default/zramswap; systemctl enable zramswap.service 2>/dev/null || true
[ -f /etc/default/grub ] && sed -i 's/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT=1/' /etc/default/grub || true
chmod 0755 /usr/local/bin/artlas-portapapeles 2>/dev/null || true

echo "== Software adicional: Flathub (VS Code, GIMP, VLC…) =="
flatpak remote-add --system --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo || echo "AVISO: no se pudo agregar Flathub"
chmod 0755 /usr/local/bin/artlas-sesion 2>/dev/null || true

echo "== Ollama (modelos de IA locales; se descargan desde Modelos IA) =="
if [ "${ARTLAS_CON_OLLAMA:-0}" = "1" ]; then   # v7.8: el motor local es el propio (llama.cpp); Ollama queda opcional
  if curl -fsSL https://ollama.com/install.sh -o /tmp/ollama-install.sh; then
    sh /tmp/ollama-install.sh || echo "AVISO: no se pudo instalar Ollama"
    systemctl enable ollama.service 2>/dev/null || true
  else echo "AVISO: sin acceso a ollama.com"; fi
fi

echo "== AR.T.L.A.S. RAG (entorno Python con llama.cpp) =="
if [ -f /opt/artlas/rag/rag_local.py ]; then
  python3 -m venv /opt/artlas/rag/venv
  /opt/artlas/rag/venv/bin/pip install --no-cache-dir --upgrade pip
  /opt/artlas/rag/venv/bin/pip install --no-cache-dir flask huggingface_hub pypdf python-docx openpyxl
  /opt/artlas/rag/venv/bin/pip install --no-cache-dir --prefer-binary llama-cpp-python \
      --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu \
    || CMAKE_ARGS="-DGGML_NATIVE=OFF" /opt/artlas/rag/venv/bin/pip install --no-cache-dir llama-cpp-python \
    || echo "AVISO: llama-cpp-python no se pudo instalar; RAG pedirá instalarlo"
  # servidor compatible con OpenAI de llama.cpp: el motor de IA local de AR.T.L.A.S. OS (sin Ollama ni GPU)
  /opt/artlas/rag/venv/bin/pip install --no-cache-dir fastapi uvicorn sse-starlette starlette-context pydantic-settings || echo "AVISO: faltan dependencias del servidor llama.cpp"
  if /opt/artlas/rag/venv/bin/python3 -c "import llama_cpp" 2>/dev/null; then echo "OK: llama_cpp disponible para el motor de IA local"
  else echo "::warning::llama_cpp NO se pudo importar: el motor de IA local no va a funcionar"; fi
  rm -f /opt/artlas/rag/*.bat /opt/artlas/rag/*.ico
fi
apt-get clean
rm -rf /var/lib/apt/lists/* /tmp/* 2>/dev/null || true
echo "== AR.T.L.A.S. OS listo =="
