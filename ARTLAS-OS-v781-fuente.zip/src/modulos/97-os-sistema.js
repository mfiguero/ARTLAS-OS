
/* =====================================================================
   AR.T.L.A.S. · Módulo 97 · AR.T.L.A.S. OS — SISTEMA
   Apps del sistema: Configuración (núcleo local, carpetas, inicio),
   Terminal, Monitor del sistema y Aplicaciones de la PC.
   Router: los modelos locales (navegador u Ollama) se suman al ruteo de
   la plataforma — Simultáneo, Consenso e Inteligente — y a la estrategia
   nueva «Local primero» (métrica privacidad). Reemplazan al Básico gratis
   cuando están cargados y, sin internet, el router pasa solo al local.
   Descarga del núcleo: solo usuarios registrados que aceptaron la licencia.
   ===================================================================== */

/* ---------- router: modelos locales junto a las APIs ---------- */
function aosLocalLevel(pk){ return pk==="webllm"?"locallm":pk==="ollama"?"local":null; }
const V97_connectedProviders=connectedProviders;
connectedProviders=function(){
  const L=V97_connectedProviders.apply(this,arguments);
  try{ if(connected("ollama")&&!L.includes("ollama")){ const i=L.indexOf("webllm"); if(i>=0) L.splice(i,0,"ollama"); else { const b=L.indexOf("basic"); if(b>=0) L.splice(b,0,"ollama"); else L.push("ollama"); } } }catch(e){}
  return L;
};
// el router elige el modelo local con la métrica «privacidad», en lugar del Básico gratis (servicio comunitario) y sin internet
const V97_pickFor=v60PickFor;
v60PickFor=function(intentKey,metric){
  const lvl=V97_pickFor.apply(this,arguments);
  try{
    const loc=aosLocalPk(); if(!loc) return lvl;
    const pk=(MODELS[lvl]&&MODELS[lvl].prov)||"basic";
    if(metric==="privacidad"||pk==="basic"||!connected(pk)||navigator.onLine===false) return aosLocalLevel(loc);
  }catch(e){}
  return lvl;
};
const V97_smartPick=smartPick;
smartPick=function(txt){
  const lvl=V97_smartPick.apply(this,arguments);
  try{ const loc=aosLocalPk(); if(loc&&navigator.onLine===false) return aosLocalLevel(loc); }catch(e){}
  return lvl;
};
/* estrategia nueva en AR.T.L.A.S. Router: «Local primero» (métrica privacidad) */
try{
  V60_STRATS.local={grp:["Inteligente","Smart"], ic:"🔒", n:["Local primero","Local first"], short:"Local", mode:"smart", metric:"privacidad",
    d:["Usa el modelo que corre en tu equipo (navegador u Ollama): privado y sin internet. Si no hay uno cargado, elige como Balanced.","Uses the model running on your device (browser or Ollama): private and offline. If none is loaded, picks like Balanced."]};
  V60_metricName.privacidad=["privacidad (local)","privacy (local)"];
  const E=Object.entries(V60_STRATS), loc=E.find(x=>x[0]==="local"), rest=E.filter(x=>x[0]!=="local"), at=rest.findIndex(x=>x[0]==="best")+1;
  rest.splice(at>0?at:rest.length,0,loc); Object.keys(V60_STRATS).forEach(k=>delete V60_STRATS[k]); rest.forEach(([k,v])=>V60_STRATS[k]=v);
}catch(e){ console.error("v97 router",e); }

/* ---------- Configuración ---------- */
aosRegister("config",{title:()=>aosL("Configuración","Settings"),sub:()=>aosL("Núcleo local, carpetas e inicio","Local core, folders and startup"),icon:"gear",desk:true,order:80,w:720,h:600,kw:"configuracion ajustes nucleo emparejar settings",
  render(win){ win.body.innerHTML=`<div class="aos-pad aosc"></div>`; aoscPaint(win); },
  reopen(win){ aoscPaint(win); }
});
async function aoscPaint(win){
  const B=win.body.querySelector(".aosc"); if(!B) return;
  try{ await aosNucPing(); }catch(e){}
  const st=AOSN.state, logged=(typeof v61Logged==="function")&&v61Logged();
  const pill=st==="ok"?`<span class="aos-pill ok">${aosL("Conectado","Connected")} · ${aosEsc(AOSN.equipo)} · ${aosEsc(AOSN.ver||"")}</span>`:st==="pair"?`<span class="aos-pill warn">${aosL("Abierto, falta emparejar","Running, needs pairing")}</span>`:`<span class="aos-pill off">${aosL("No detectado","Not detected")}</span>`;
  const perms=AOSN.permisos?Object.entries(AOSN.permisos).map(([k,v])=>`<span class="aos-pill ${v?"ok":"off"}">${aosEsc(k.replace("_"," "))}</span>`).join(" "):"";
  const fsa=Object.keys(AOSF.handles);
  B.innerHTML=`<div class="aos-h">${aosL("Núcleo local","Local core")}</div>
  <p class="aos-sub">${aosL("Un servicio pequeño en tu PC (solo 127.0.0.1) que le da a AR.T.L.A.S. OS acceso al disco, a las aplicaciones, a los procesos, a una terminal segura y a Ollama. Las carpetas permitidas y los permisos se eligen en tu equipo, nunca desde la web.","A small service on your PC (127.0.0.1 only) that gives AR.T.L.A.S. OS access to the disk, apps, processes, a safe terminal and Ollama. Allowed folders and permissions are set on your computer, never from the web.")}</p>
  <div class="aos-card" style="margin-bottom:10px"><div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px">${pill}<span style="flex:1"></span><button class="aos-btn sm" data-k="ping">${aosL("Volver a comprobar","Check again")}</button></div>
    ${st==="ok"?`<div style="margin-bottom:8px">${perms}</div><div style="display:flex;gap:6px;flex-wrap:wrap"><button class="aos-btn sm" data-k="log">${aosIcon("log",13)} ${aosL("Registro de actividad","Activity log")}</button><button class="aos-btn sm ${aosNucOld()?"pri":""}" data-k="dl">${aosIcon("up",13)} ${aosNucOld()?aosL("Actualizar el núcleo (hay versión nueva)","Update the core (new version)"):aosL("Descargar el núcleo de nuevo","Download the core again")}</button><button class="aos-btn sm dan" data-k="forget">${aosL("Olvidar este equipo","Forget this computer")}</button></div>`
    :st==="pair"?`<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap"><input class="aos-in aosc-code" inputmode="numeric" maxlength="6" placeholder="${aosEsc(aosL("Código de 6 dígitos","6-digit code"))}" style="width:170px;letter-spacing:3px;font-weight:600"><button class="aos-btn pri" data-k="pair">${aosL("Emparejar","Pair")}</button></div><div style="font-size:12px;color:#6b7a90;margin-top:6px">${aosL("El código aparece en la ventana del núcleo y vale 10 minutos.","The code shows in the core window and lasts 10 minutes.")}</div>`
    :`<ol style="margin:0 0 8px 18px;padding:0;font-size:12.5px;line-height:1.7;color:#33445c"><li>${aosL("Instalá Node.js 18 o superior (nodejs.org, versión LTS).","Install Node.js 18 or newer (nodejs.org, LTS).")}</li><li>${aosL("Descargá el núcleo, descomprimilo y abrí <b>Iniciar-Nucleo.bat</b> (en macOS o Linux, <b>iniciar-nucleo.sh</b>).","Download the core, unzip it and run <b>Iniciar-Nucleo.bat</b> (macOS or Linux: <b>iniciar-nucleo.sh</b>).")}</li><li>${aosL("Volvé acá y pegá el código de 6 dígitos que muestra la ventana.","Come back and paste the 6-digit code shown in the window.")}</li></ol>
      <div style="display:flex;gap:6px;flex-wrap:wrap"><button class="aos-btn ${logged?"pri":""}" data-k="dl">${aosIcon("up",13)} ${aosL("Descargar el núcleo local","Download the local core")}</button>${logged?"":`<span style="font-size:12px;color:#7a4a05;align-self:center">🔒 ${aosL("Para usuarios registrados","For registered users")}</span>`}</div>`}
    <details style="margin-top:10px;font-size:12px;color:#6b7a90"><summary style="cursor:pointer">${aosL("Avanzado","Advanced")}</summary><div style="display:flex;gap:6px;align-items:center;margin-top:6px"><span>URL</span><input class="aos-in aosc-url" value="${aosEsc(aosNucUrl())}" style="flex:1;font-size:12px;padding:4px 8px"><button class="aos-btn sm" data-k="url">${aosL("Guardar","Save")}</button></div></details>
  </div>
  <div class="aos-h" style="margin-top:16px">${aosL("Carpetas conectadas en el navegador","Folders connected in the browser")}</div>
  <p class="aos-sub">${aosL("Sin instalar nada: en Chrome o Edge podés darle permiso a AR.T.L.A.S. OS para trabajar en carpetas puntuales.","Nothing to install: in Chrome or Edge you can grant AR.T.L.A.S. OS access to specific folders.")}</p>
  <div style="display:flex;flex-direction:column;gap:5px;margin-bottom:6px">${fsa.length?fsa.map(n=>`<div class="aos-card" style="display:flex;align-items:center;gap:8px;padding:7px 12px">${aosIcon("folder",16)}<span style="flex:1">${aosEsc(n)}</span><span class="aos-pill ${AOSF.perm[n]==="granted"?"ok":"warn"}">${AOSF.perm[n]==="granted"?aosL("con permiso","granted"):aosL("pedir permiso","needs permission")}</span><button class="aos-btn sm dan" data-f="${aosEsc(n)}">${aosL("Quitar","Remove")}</button></div>`).join(""):`<div style="font-size:12.5px;color:#8f8f8f">${aosL("Ninguna todavía.","None yet.")}</div>`}</div>
  <button class="aos-btn sm" data-k="fsa">${aosIcon("plug",13)} ${aosL("Conectar carpeta…","Connect folder…")}</button>
  <div class="aos-h" style="margin-top:18px">${aosL("Inicio","Startup")}</div>
  <label style="display:flex;gap:8px;align-items:center;font-size:12.5px;color:#0d2b5e"><input type="checkbox" class="aosc-auto" ${v60LS("atlas_os_auto","0")==="1"?"checked":""}> ${aosL("Abrir AR.T.L.A.S. OS al ingresar a la plataforma","Open AR.T.L.A.S. OS when entering the platform")}</label>
  <div style="font-size:12px;color:#6b7a90;margin-top:4px">${aosL("También podés entrar directo con app.html?os=1. Atajo: Ctrl + Espacio abre el inicio.","You can also go straight in with app.html?os=1. Shortcut: Ctrl + Space opens Start.")}</div>`;
  const k=s=>B.querySelector(`[data-k="${s}"]`);
  if(k("ping")) k("ping").onclick=()=>aoscPaint(win);
  if(k("pair")){ const go=async()=>{ const c=B.querySelector(".aosc-code").value; try{ await aosNucPair(c); aosToast(aosL("Núcleo emparejado","Core paired"),"ok"); aosPaintStatus(); aoscPaint(win); AOS.wins.filter(w=>w.app==="archivos").forEach(w=>aosfSide(w)); }catch(e){ aosToast(e.message,"err"); } }; k("pair").onclick=go; B.querySelector(".aosc-code").onkeydown=e=>{ if(e.key==="Enter") go(); }; setTimeout(()=>{ const i=B.querySelector(".aosc-code"); if(i) i.focus(); },50); }
  if(k("forget")) k("forget").onclick=()=>{ if(!confirm(aosL("¿Olvidar el emparejamiento con este equipo?","Forget the pairing with this computer?"))) return; aosNucForget(); aosPaintStatus(); aoscPaint(win); };
  if(k("log")) k("log").onclick=()=>aoscLog(win);
  if(k("dl")) k("dl").onclick=()=>aosNucDownload();
  if(k("url")) k("url").onclick=()=>{ const v=B.querySelector(".aosc-url").value.trim(); if(v&&!/^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?\/?$/i.test(v)){ aosToast(aosL("El núcleo solo puede estar en 127.0.0.1 o localhost","The core can only live on 127.0.0.1 or localhost"),"err"); return; } v60LSset("atlas_os_nuc_url",v.replace(/\/$/,"")); aoscPaint(win); };
  k("fsa").onclick=async()=>{ try{ await aosFsaConnect(); aoscPaint(win); }catch(e){ if(e&&e.name!=="AbortError") aosToast(e.message||String(e),"err"); } };
  B.querySelectorAll("[data-f]").forEach(b=>b.onclick=async()=>{ await aosFsaForget(b.dataset.f); aoscPaint(win); });
  B.querySelector(".aosc-auto").onchange=e=>v60LSset("atlas_os_auto",e.target.checked?"1":"0");
}
async function aoscLog(win){
  const B=win.body.querySelector(".aosc"); let L=[];
  try{ L=await aosNuc("registro.ver",{n:150}); }catch(e){ aosToast(e.message,"err"); return; }
  B.innerHTML=`<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px"><button class="aos-btn sm" data-b="1">← ${aosL("Volver","Back")}</button><div class="aos-h" style="margin:0">${aosL("Registro de actividad del núcleo","Core activity log")}</div></div>
  ${L.length?`<table class="aos-tbl"><thead><tr><th>${aosL("Fecha","Date")}</th><th>${aosL("Operación","Operation")}</th><th>${aosL("Detalle","Detail")}</th></tr></thead><tbody>${L.map(x=>`<tr><td style="white-space:nowrap">${aosFmtDate(Date.parse(x.t))}</td><td>${x.ok===false?"✗ ":"✓ "}${aosEsc(x.op)}</td><td style="font-size:11.5px;color:#6b7a90;word-break:break-all">${aosEsc(x.error||JSON.stringify(x.args||{modelo:x.modelo,origen:x.origen}).slice(0,180))}</td></tr>`).join("")}</tbody></table>`:`<div class="aos-empty">${aosL("Todavía no hay actividad registrada.","No activity yet.")}</div>`}`;
  B.querySelector("[data-b]").onclick=()=>aoscPaint(win);
}

/* ---------- descarga del núcleo (registrados + licencia aceptada) ---------- */
async function aosNucDownload(){
  if(typeof v61Logged==="function"&&!v61Logged()){ alert(aosL("El núcleo local de AR.T.L.A.S. OS es para usuarios registrados. Creá tu cuenta gratuita o iniciá sesión.","The AR.T.L.A.S. OS local core is for registered users. Create your free account or sign in.")); try{ v61GateLogin(true); }catch(e){} return; }
  if(typeof v69Need==="function"&&v69Need("descarga-nucleo",()=>aosNucDownload())) return;
  const F=window.ARTLAS_NUCLEO; if(!F){ aosToast(aosL("El paquete del núcleo no está disponible en esta copia.","The core package isn't available in this copy."),"err"); return; }
  if(typeof JSZip==="undefined"){ aosToast(aosL("No se pudo cargar el empaquetador. Recargá la página.","Couldn't load the packager. Reload the page."),"err"); return; }
  try{
    const z=new JSZip(), d=z.folder("ARTLAS-OS-Nucleo");
    Object.entries(F).forEach(([n,t])=>d.file(n,t,n.endsWith(".sh")?{unixPermissions:"755"}:{}));
    try{ if(location.protocol!=="file:"&&typeof V69!=="undefined"){ const r=await fetch(V69.pdf); if(r.ok) d.file("LICENCIA-AR.T.L.A.S.pdf",await r.arrayBuffer()); } }catch(e){}
    const blob=await z.generateAsync({type:"blob",platform:"UNIX"});
    const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="ARTLAS-OS-Nucleo.zip"; document.body.appendChild(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); },4000);
    aosToast(aosL("Descargado. Descomprimilo y abrí Iniciar-Nucleo.","Downloaded. Unzip it and run Iniciar-Nucleo."),"ok",6000);
  }catch(e){ aosToast(e.message||String(e),"err"); }
}

/* ---------- Terminal ---------- */
aosRegister("terminal",{title:()=>aosL("Terminal","Terminal"),sub:()=>aosL("Diagnóstico de red y sistema","Network and system diagnostics"),icon:"term",desk:true,order:40,w:760,h:460,kw:"terminal consola cmd shell ping ipconfig",
  render(win){
    win.state={h:[],i:-1};
    win.body.style.background="#0a1a38";
    win.body.innerHTML=`<pre class="aost-o" style="flex:1;margin:0;overflow:auto;padding:12px 14px;color:#dbe6f3;font:12.5px/1.5 Consolas,'Cascadia Mono',Menlo,monospace;white-space:pre-wrap;word-break:break-word"></pre>
      <form class="aost-f" style="display:flex;align-items:center;gap:8px;padding:8px 12px;border-top:1px solid rgba(79,156,249,.25);font:12.5px Consolas,Menlo,monospace;color:#4f9cf9"><span class="aost-p"></span><input class="aost-i" autocomplete="off" spellcheck="false" style="flex:1;background:none;border:none;outline:none;color:#fff;font:inherit"></form>`;
    const o=win.body.querySelector(".aost-o"), i=win.body.querySelector(".aost-i");
    win.body.querySelector(".aost-p").textContent=(AOSN.equipo||"artlas")+" ›";
    aostOut(win,aosL("AR.T.L.A.S. OS · Terminal. Escribí «ayuda» para ver qué podés hacer.\n","AR.T.L.A.S. OS · Terminal. Type «help» to see what you can do.\n"),"#8fb6e8");
    win.body.querySelector(".aost-f").onsubmit=e=>{ e.preventDefault(); const c=i.value.trim(); i.value=""; if(c){ win.state.h.unshift(c); win.state.i=-1; aostRun(win,c); } };
    i.onkeydown=e=>{ const H=win.state.h; if(e.key==="ArrowUp"&&H.length){ e.preventDefault(); win.state.i=Math.min(H.length-1,win.state.i+1); i.value=H[win.state.i]; } if(e.key==="ArrowDown"){ e.preventDefault(); win.state.i=Math.max(-1,win.state.i-1); i.value=win.state.i<0?"":H[win.state.i]; } };
    o.onclick=()=>i.focus(); setTimeout(()=>i.focus(),60);
  }
});
function aostOut(win,t,color){ const o=win.body.querySelector(".aost-o"); if(!o) return; const s=document.createElement("span"); if(color) s.style.color=color; s.textContent=t; o.appendChild(s); o.scrollTop=o.scrollHeight; }
async function aostRun(win,c){
  aostOut(win,"› "+c+"\n","#4f9cf9");
  const lc=c.toLowerCase();
  if(lc==="ayuda"||lc==="help"){ aostOut(win,aosL(
`Comandos internos:
  ayuda · limpiar · sistema · apps [filtro] · abrir <app> · procesos [filtro]
  artlas <pedido>   → se lo pasa al asistente
Del sistema (con el núcleo local), lista blanca de diagnóstico:
  ping · ipconfig · tracert · nslookup · netstat · arp · route print · systeminfo · getmac
  hostname · whoami · git status/log · pip list · ollama list/ps · node -v · python --version
`,`Built-in: help · clear · system · apps [filter] · open <app> · processes [filter]
  artlas <request>  → sends it to the assistant
System (with the local core), diagnostics allowlist:
  ping · ipconfig · tracert · nslookup · netstat · arp · route print · systeminfo · getmac
  hostname · whoami · git status/log · pip list · ollama list/ps · node -v · python --version
`)); return; }
  if(lc==="limpiar"||lc==="clear"||lc==="cls"){ win.body.querySelector(".aost-o").textContent=""; return; }
  if(/^artlas\s+/i.test(c)){ aosAskAtlas(c.replace(/^artlas\s+/i,"")); return; }
  try{
    if(lc==="sistema"||lc==="system"){ aostOut(win,aosSysText(await aosNuc("sys.info"))+"\n"); return; }
    if(/^(apps|aplicaciones)\b/.test(lc)){ const f=c.split(/\s+/).slice(1).join(" ").toLowerCase(); const L=(await aosNuc("app.listar",{})).filter(a=>!f||a.nombre.toLowerCase().includes(f)); aostOut(win,L.slice(0,200).map(a=>"  "+a.nombre).join("\n")+"\n("+L.length+")\n"); return; }
    if(/^(abrir|open)\s+/.test(lc)){ const r=await aosNuc("app.abrir",{nombre:c.replace(/^\S+\s+/,"")}); aostOut(win,"✓ "+r.abierta+"\n","#10a37f"); return; }
    if(/^(procesos|processes|ps)\b/.test(lc)){ const f=c.split(/\s+/).slice(1).join(" ").toLowerCase(); const L=(await aosNuc("proc.listar")).filter(p=>!f||String(p.nombre).toLowerCase().includes(f)).sort((a,b)=>(b.memoria||0)-(a.memoria||0)).slice(0,60); aostOut(win,L.map(p=>String(p.pid).padStart(7)+"  "+aosFmtBytes(p.memoria).padStart(8)+"  "+p.nombre).join("\n")+"\n"); return; }
    let r;
    try{ r=await aosNuc("shell.ejecutar",{cmd:c}); }
    catch(e){
      if(/requiere confirmación/i.test(e.message)&&AOSN.permisos&&AOSN.permisos.terminal_libre&&confirm(aosL("«"+c+"» no es un comando de diagnóstico. ¿Ejecutarlo igual en tu PC?","«"+c+"» isn't a diagnostics command. Run it anyway on your PC?"))) r=await aosNuc("shell.ejecutar",{cmd:c,confirmado:true});
      else throw e;
    }
    aostOut(win,(r.salida||"")+(r.error?(r.salida?"\n":"")+r.error:"")+(r.timeout?"\n"+aosL("(tiempo agotado)","(timed out)"):"")+"\n",r.code?"#f5a3a6":null);
  }catch(e){ aostOut(win,"✗ "+e.message+"\n","#f5a3a6"); }
}

/* ---------- Monitor del sistema ---------- */
aosRegister("monitor",{title:()=>aosL("Monitor del sistema","System monitor"),sub:()=>aosL("CPU, memoria, discos y procesos","CPU, memory, disks and processes"),icon:"pulse",desk:true,order:50,w:820,h:600,kw:"monitor sistema procesos memoria cpu disco tareas",
  render(win){ win.state={f:"",hist:[]}; win.body.innerHTML=`<div class="aos-pad aosmo" style="display:flex;flex-direction:column;gap:12px"></div>`; aosmoTick(win); win.state.t=setInterval(()=>{ if(aosWin(win.id)&&!win.el.classList.contains("min")) aosmoTick(win); },4000); },
  onClose(win){ clearInterval(win.state.t); }
});
function aosMeter(p){ p=Math.max(0,Math.min(100,Math.round(p||0))); return `<div class="aos-bar-meter"><i class="${p>90?"crit":p>75?"hi":""}" style="width:${p}%"></i></div>`; }
async function aosmoTick(win){
  const B=win.body.querySelector(".aosmo"); if(!B) return;
  if(!aosNucOk()){
    let est=null; try{ est=navigator.storage&&await navigator.storage.estimate(); }catch(e){}
    B.innerHTML=`<div class="aos-card"><div class="aos-h">${aosL("Este navegador","This browser")}</div><div class="aos-kv"><b>${aosL("Núcleos lógicos","Logical cores")}</b><span>${navigator.hardwareConcurrency||"—"}</span><b>${aosL("Memoria aprox.","Approx. memory")}</b><span>${navigator.deviceMemory?navigator.deviceMemory+" GB":"—"}</span><b>WebGPU</b><span>${"gpu" in navigator?aosL("disponible","available"):aosL("no disponible","unavailable")}</span><b>${aosL("Conexión","Connection")}</b><span>${navigator.onLine?aosL("en línea","online"):aosL("sin conexión","offline")}${navigator.connection&&navigator.connection.effectiveType?" · "+navigator.connection.effectiveType:""}</span>${est?`<b>${aosL("Espacio del navegador","Browser storage")}</b><span>${aosFmtBytes(est.usage)} / ${aosFmtBytes(est.quota)}</span>`:""}</div></div>
    <div class="aos-empty">${aosL("Para ver CPU, memoria, discos y procesos de la PC, conectá el núcleo local.","Connect the local core to see the PC's CPU, memory, disks and processes.")}<br><button class="aos-btn" style="margin-top:8px" onclick="aosLaunch('config')">${aosL("Configurar el núcleo","Set up the core")}</button></div>`; return;
  }
  let s,P; try{ [s,P]=await Promise.all([aosNuc("sys.info"),aosNuc("proc.listar")]); }catch(e){ B.innerHTML=`<div class="aos-empty">${aosEsc(e.message)}</div>`; return; }
  const mem=100*(1-s.memoria.libre/s.memoria.total);
  win.state.hist.push(s.cpuUso); if(win.state.hist.length>40) win.state.hist.shift();
  const H=win.state.hist, spark=`<svg viewBox="0 0 200 40" preserveAspectRatio="none" style="width:100%;height:40px;display:block"><polyline fill="none" stroke="#1976d2" stroke-width="1.6" points="${H.map((v,i)=>(i*200/39).toFixed(1)+","+(40-v*0.38).toFixed(1)).join(" ")}"/></svg>`;
  const g={}; P.forEach(p=>{ const k=p.nombre; g[k]=g[k]||{n:k,c:0,m:0,cpu:0,pids:[]}; g[k].c++; g[k].m+=p.memoria||0; g[k].cpu+=p.cpu||0; g[k].pids.push(p.pid); });
  const f=win.state.f.toLowerCase(); const rows=Object.values(g).filter(x=>x.m>0&&(!f||x.n.toLowerCase().includes(f))).sort((a,b)=>b.m-a.m).slice(0,60);
  const keepF=document.activeElement&&document.activeElement.classList.contains("aosmo-q");
  B.innerHTML=`<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">
    <div class="aos-card"><div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:4px"><b style="color:#0d2b5e">CPU</b><span>${s.cpuUso}%</span></div>${aosMeter(s.cpuUso)}<div style="margin-top:6px">${spark}</div><div style="font-size:11.5px;color:#6b7a90">${aosEsc(s.cpu||"")} · ${s.nucleos} ${aosL("núcleos","cores")}</div></div>
    <div class="aos-card"><div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:4px"><b style="color:#0d2b5e">${aosL("Memoria","Memory")}</b><span>${Math.round(mem)}%</span></div>${aosMeter(mem)}<div style="font-size:11.5px;color:#6b7a90;margin-top:6px">${aosFmtBytes(s.memoria.total-s.memoria.libre)} / ${aosFmtBytes(s.memoria.total)}</div>
      ${(s.discos||[]).map(d=>{ const u=100*(1-d.libre/d.total); return `<div style="display:flex;justify-content:space-between;font-size:12px;margin:8px 0 3px"><b style="color:#0d2b5e">${aosL("Disco","Disk")} ${aosEsc(d.unidad)}</b><span>${aosFmtBytes(d.libre)} ${aosL("libres","free")}</span></div>${aosMeter(u)}`; }).join("")}</div>
    <div class="aos-card"><div class="aos-kv"><b>${aosL("Equipo","Computer")}</b><span>${aosEsc(s.equipo)}</span><b>${aosL("Sistema","OS")}</b><span>${aosEsc(s.so)}</span><b>${aosL("Encendido","Uptime")}</b><span>${Math.floor(s.encendido/3600)} h ${Math.floor(s.encendido%3600/60)} min</span>${(s.red||[]).slice(0,3).map(n=>`<b>${aosEsc(n.interfaz)}</b><span>${aosEsc(n.ip)}</span>`).join("")}</div></div></div>
  <div style="display:flex;align-items:center;gap:8px"><b style="color:#0d2b5e;font-size:13px">${aosL("Procesos","Processes")}</b><span class="aos-pill">${P.length}</span><span style="flex:1"></span><input class="aos-in aosmo-q" placeholder="${aosEsc(aosL("Filtrar…","Filter…"))}" value="${aosEsc(win.state.f)}" style="width:170px;padding:4px 9px;font-size:12px"></div>
  <table class="aos-tbl"><thead><tr><th>${aosL("Programa","Program")}</th><th>${aosL("Procesos","Proc.")}</th><th>${aosL("Memoria","Memory")}</th><th></th></tr></thead><tbody>${rows.map((x,i)=>`<tr><td>${aosEsc(x.n)}</td><td>${x.c}</td><td>${aosFmtBytes(x.m)}</td><td style="text-align:right"><button class="aos-btn sm dan" data-k="${i}">${aosL("Cerrar","End")}</button></td></tr>`).join("")}</tbody></table>`;
  const q=B.querySelector(".aosmo-q"); q.oninput=()=>{ win.state.f=q.value; clearTimeout(win.state.qt); win.state.qt=setTimeout(()=>aosmoTick(win),300); };
  if(keepF){ q.focus(); q.setSelectionRange(q.value.length,q.value.length); }
  B.querySelectorAll("[data-k]").forEach(b=>b.onclick=async()=>{ const x=rows[+b.dataset.k]; if(!confirm(aosL("¿Cerrar «"+x.n+"» ("+x.c+" proceso"+(x.c>1?"s":"")+")? Se pueden perder datos sin guardar.","End «"+x.n+"» ("+x.c+" process"+(x.c>1?"es":"")+")? Unsaved data may be lost."))) return;
    let ok=0, err=""; for(const pid of x.pids){ try{ await aosNuc("proc.cerrar",{pid}); ok++; }catch(e){ err=e.message; } }
    aosToast(ok?aosL("Cerrado: ","Ended: ")+x.n:err,ok?"ok":"err"); aosmoTick(win); });
}

/* ---------- Aplicaciones de la PC ---------- */
aosRegister("apps",{title:()=>aosL("Aplicaciones","Applications"),sub:()=>aosL("Programas instalados en la PC","Programs installed on the PC"),icon:"apps",desk:true,order:30,w:720,h:540,kw:"aplicaciones programas apps instaladas",
  render(win){ win.state={f:"",L:null}; win.body.innerHTML=`<div class="aos-tbar"><input class="aos-in aosap-q" placeholder="${aosEsc(aosL("Buscar aplicación…","Search apps…"))}" style="flex:1;padding:6px 10px"><button class="aos-btn sm" data-r="1">${aosL("Actualizar","Refresh")}</button></div><div class="aosap-l" style="flex:1;overflow:auto;padding:10px"></div>`;
    const q=win.body.querySelector(".aosap-q"); q.oninput=()=>{ win.state.f=q.value; aosapPaint(win); }; q.onkeydown=e=>{ if(e.key==="Enter"){ const b=win.body.querySelector("[data-a]"); if(b) b.click(); } };
    win.body.querySelector("[data-r]").onclick=()=>aosapLoad(win,true); aosapLoad(win); setTimeout(()=>q.focus(),60); },
  reopen(win){ aosapLoad(win); }
});
async function aosapLoad(win,force){
  const L=win.body.querySelector(".aosap-l");
  if(!aosNucOk()){ L.innerHTML=`<div class="aos-empty">${aosL("Ver y abrir los programas de tu PC necesita el núcleo local.","Listing and opening your PC's programs needs the local core.")}<br><button class="aos-btn" style="margin-top:8px" onclick="aosLaunch('config')">${aosL("Configurar el núcleo","Set up the core")}</button></div>`; return; }
  L.innerHTML=`<div class="aos-empty">${aosL("Cargando…","Loading…")}</div>`;
  try{ win.state.L=await aosNuc("app.listar",{actualizar:!!force}); aosapPaint(win); }catch(e){ L.innerHTML=`<div class="aos-empty">${aosEsc(e.message)}</div>`; }
}
function aosapPaint(win){
  const L=win.body.querySelector(".aosap-l"); if(!win.state.L) return; const f=win.state.f.toLowerCase().trim();
  const A=win.state.L.filter(a=>!f||a.nombre.toLowerCase().includes(f)).slice(0,300);
  L.innerHTML=A.length?`<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:6px">${A.map((a,i)=>`<button class="aos-row" data-a="${i}" title="${aosEsc(a.ruta)}" style="border:1px solid #eef2f7;flex-direction:column;align-items:flex-start;gap:3px;padding:9px 10px"><span style="display:flex;align-items:center;gap:7px;color:#0d2b5e;font-weight:600;font-size:12.5px;width:100%"><span class="ib">${aosIcon("apps",15)}</span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${aosEsc(a.nombre)}</span></span>${a.carpeta?`<span style="font-size:11px;color:#8f8f8f">${aosEsc(a.carpeta)}</span>`:""}</button>`).join("")}</div>`:`<div class="aos-empty">${aosL("Sin coincidencias.","No matches.")}</div>`;
  L.querySelectorAll("[data-a]").forEach(b=>b.onclick=async()=>{ const a=A[+b.dataset.a]; try{ const r=await aosNuc("app.abrir",{id:a.id}); aosToast(aosL("Abriendo ","Opening ")+r.abierta,"ok"); }catch(e){ aosToast(e.message,"err"); } });
}

/* ---------- inicio de AR.T.L.A.S. OS ---------- */
(function(){
  try{
    aosFsaLoad().catch(()=>{});
    const V97_gateHide=v61GateHide;
    v61GateHide=function(){ const r=V97_gateHide.apply(this,arguments); try{ if(v60LS("atlas_os_auto","0")==="1"&&!AOS.on&&!(typeof v61GateVisible==="function"&&v61GateVisible())) setTimeout(()=>{ if(!AOS.on) aosOpen(); },350); }catch(e){} return r; };
    setTimeout(()=>{ try{ aosBoot(); aosNucPing().then(()=>{ try{ renderMenu(); }catch(e){} }).catch(()=>{}); }catch(e){ console.error("aos boot",e); } },0);
  }catch(e){ console.error("v97",e); }
})();

/* ---------- v6.9.2 · las APIs de AR.T.L.A.S. Web dentro del OS ----------
   Son las mismas claves y el mismo router: esta sección muestra cuáles están conectadas y deja conectar,
   desbloquear la bóveda o traerlas de la cuenta sin salir del OS. Los diálogos de la plataforma se ven encima. */
const AOS_API_PROVS=["anthropic","openai","gemini","groq","deepseek","kimi","zai","hf","other","felo"];
function aosApiState(){
  const out=[]; for(const pk of AOS_API_PROVS){ try{ if(typeof PROVIDERS!=="undefined"&&!PROVIDERS[pk]&&!(typeof OA_PROVIDERS!=="undefined"&&OA_PROVIDERS[pk])) continue; out.push({pk,ok:!!connected(pk),label:aosPkLabel(pk)}); }catch(e){} }
  return out;
}
function aosApiSection(){
  const L=aosApiState(), on=L.filter(x=>x.ok); let locked=false, logged=false, cloud=false;
  try{ locked=v60VaultLocked(); }catch(e){} try{ logged=!!(typeof user!=="undefined"&&user&&user.id); }catch(e){} try{ cloud=v60CloudKeys(); }catch(e){}
  const fileProto=location.protocol==="file:";
  return `<div class="aos-h">${aosL("APIs de AR.T.L.A.S. Web","AR.T.L.A.S. Web APIs")}</div>
  <p class="aos-sub">${aosL("Son las mismas claves y el mismo router de la plataforma. En «Automático» el asistente del OS las usa; el modelo local queda de respaldo sin internet.","Same keys and router as the platform. In «Automatic» the OS assistant uses them; the local model is the offline fallback.")}</p>
  <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px">${L.map(x=>`<span class="aos-pill ${x.ok?"ok":""}" data-pk="${x.pk}" title="${aosEsc(x.ok?aosL("conectado","connected"):aosL("sin clave","no key"))}">${x.ok?"● ":"○ "}${aosEsc(x.label)}${x.ok?` <a href="#" data-usar="${x.pk}" title="${aosEsc(aosL("Usar como motor del asistente","Use as assistant engine"))}">${aosMotor()===x.pk?"✔":aosL("usar","use")}</a> <a href="#" data-quitar="${x.pk}" title="${aosEsc(aosL("Quitar la clave de este equipo","Remove the key from this device"))}">✕</a>`:""}</span>`).join("")}</div>
  ${locked?`<p class="aos-sub" style="color:#7a5a20">${aosL("Tus claves están en la bóveda cifrada y está bloqueada: desbloqueala para usarlas acá.","Your keys are in the encrypted vault and it's locked: unlock it to use them here.")}</p>`:""}
  ${!on.length&&!locked?`<p class="aos-sub">${fileProto?aosL("Esta copia se abrió desde un archivo del disco: el navegador guarda sus claves aparte de las del sitio web. Para tenerlas acá, activá en la web «Sincronizar API keys con mi cuenta» e ingresá con tu cuenta en esta copia, o conectalas directamente.","This copy was opened from a disk file: the browser stores its keys separately from the website. To get them here, enable «Sync API keys with my account» on the website and sign in here, or connect them directly."):aosL("Todavía no hay APIs conectadas en este navegador.","No APIs connected in this browser yet.")}</p>`:""}
  <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:18px">
    <button class="aos-btn pri" data-api="keys">${aosL("Conectar o editar claves","Connect or edit keys")}</button>
    ${locked?`<button class="aos-btn" data-api="unlock">${aosL("Desbloquear bóveda","Unlock vault")}</button>`:""}
    ${logged?`<button class="aos-btn" data-api="cloud">${aosL("Traer mi configuración de la cuenta","Load my account settings")}</button>`:`<button class="aos-btn" data-api="login">${aosL("Ingresar con mi cuenta","Sign in")}</button>`}
    ${logged&&!cloud?`<span style="font-size:12px;color:#6b7a90;align-self:center">${aosL("(la sincronización de claves con la cuenta está desactivada)","(key sync with your account is off)")}</span>`:""}
  </div>`;
}
const V97_aosmPaint=aosmPaint;
aosmPaint=async function(win){
  await V97_aosmPaint.apply(this,arguments);
  const B=win.body.querySelector(".aosm"); if(!B) return;
  const hs=B.querySelectorAll(".aos-h"); const box=document.createElement("div"); box.className="aosm-api"; box.innerHTML=aosApiSection();
  if(hs[1]) B.insertBefore(box,hs[1]); else B.appendChild(box);
  const rp=()=>{ try{ aosmPaint(win); aosPaintStatus(); }catch(e){} };
  box.querySelectorAll("[data-api]").forEach(b=>b.onclick=async()=>{
    const k=b.dataset.api;
    try{
      if(k==="keys"){ openSettings(); aosWatchOverlay(rp); }
      if(k==="unlock"){ await v60VaultUnlock(); rp(); }
      if(k==="cloud"){ await loadCloud(); rp(); aosToast(aosL("Configuración de la cuenta cargada","Account settings loaded"),"ok"); }
      if(k==="login"){ v61GateLogin(true); }
    }catch(e){ aosToast(e.message||String(e),"err"); }
  });
};
function aosWatchOverlay(cb){   // al cerrar el diálogo de claves, repinta el OS
  const ov=$("overlay"); if(!ov) return; const t=setInterval(()=>{ if(!ov.classList.contains("open")){ clearInterval(t); cb&&cb(); } },400);
}

/* v6.9.2 · versión del núcleo instalado frente a la de la app */
function aosNucOld(){ try{ const v=String(AOSN.ver||""), a=String(AOS.ver||""); if(!v) return true; const n=x=>(x.match(/\d+/g)||[]).map(Number); const A=n(a),V=n(v); for(let i=0;i<Math.max(A.length,V.length);i++){ if((V[i]||0)<(A[i]||0)) return true; if((V[i]||0)>(A[i]||0)) return false; } return false; }catch(e){ return false; } }
const V97_aosNucPing=aosNucPing;
aosNucPing=async function(){
  const r=await V97_aosNucPing.apply(this,arguments);
  try{ if(AOSN.state==="ok"&&aosNucOld()&&!AOS._nucOldWarned&&AOS.on){ AOS._nucOldWarned=true; aosToast(aosL("Tu núcleo local ("+(AOSN.ver||"versión anterior")+") es anterior a la app: actualizalo desde Configuración → Núcleo local.","Your local core ("+(AOSN.ver||"older")+") is older than the app: update it from Settings → Local core."),"warn",9000); } }catch(e){}
  return r;
};

/* ---------- v6.9.4 · Aplicaciones con sus íconos reales ---------- */
AOS._appIco=AOS._appIco||{};
aosapPaint=function(win){
  const L=win.body.querySelector(".aosap-l"); if(!win.state.L) return; const f=win.state.f.toLowerCase().trim();
  const A=win.state.L.filter(a=>!f||a.nombre.toLowerCase().includes(f)||(a.carpeta||"").toLowerCase().includes(f)).slice(0,400);
  if(!A.length){ L.innerHTML=`<div class="aos-empty">${aosL("No hay aplicaciones con ese nombre.","No apps with that name.")}</div>`; return; }
  const ph=n=>`<span class="aosap-ph">${aosEsc((n||"?").replace(/[^A-Za-zÁÉÍÓÚÑáéíóúñ0-9]/g,"").slice(0,1).toUpperCase()||"?")}</span>`;
  L.innerHTML=`<style>.aosap-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(112px,1fr));gap:4px}
    .aosap-i{display:flex;flex-direction:column;align-items:center;gap:6px;padding:12px 6px 10px;border:1px solid transparent;border-radius:12px;background:none;cursor:pointer;text-align:center;min-width:0}
    .aosap-i:hover,.aosap-i:focus-visible{background:#f4f8fd;border-color:#dbe6f3;outline:none}
    .aosap-ic{width:44px;height:44px;display:flex;align-items:center;justify-content:center;flex:none}
    .aosap-ic img{width:40px;height:40px;object-fit:contain;image-rendering:auto;filter:drop-shadow(0 2px 3px rgba(13,43,94,.18))}
    .aosap-ph{width:40px;height:40px;border-radius:11px;display:flex;align-items:center;justify-content:center;font:700 17px system-ui;color:#fff;background:linear-gradient(160deg,#4f9cf9,#1565c0)}
    .aosap-n{font-size:12.5px;color:#0d2b5e;line-height:1.25;max-width:100%;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-break:break-word}
    .aosap-c{font-size:10.5px;color:#8a97ab;max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}</style>
    <div class="aosap-g">${A.map((a,i)=>{ const ic=AOS._appIco[a.id]; return `<button class="aosap-i" data-a="${i}" title="${aosEsc(a.nombre+"\n"+a.ruta)}"><span class="aosap-ic" data-ic="${aosEsc(a.id)}">${ic?`<img src="${ic}" alt="">`:ph(a.nombre)}</span><span class="aosap-n">${aosEsc(a.nombre)}</span>${a.carpeta?`<span class="aosap-c">${aosEsc(a.carpeta)}</span>`:""}</button>`; }).join("")}</div>`;
  L.querySelectorAll("[data-a]").forEach(b=>b.onclick=async()=>{ const a=A[+b.dataset.a]; try{ const r=await aosNuc("app.abrir",{id:a.id}); aosToast(aosL("Abriendo ","Opening ")+r.abierta,"ok"); }catch(e){ aosToast(e.message,"err"); } });
  aosapIcons(win,A);
};
async function aosapIcons(win,A){
  const tok=(win.state.icoTok=(win.state.icoTok||0)+1);
  const falta=A.filter(a=>!(a.id in AOS._appIco)).map(a=>a.id);
  for(let i=0;i<falta.length;i+=40){
    if(tok!==win.state.icoTok||!AOS.wins.includes(win)) return;
    let r; try{ r=await aosNuc("app.iconos",{ids:falta.slice(i,i+40)}); }catch(e){ return; }   // núcleo anterior: quedan las iniciales
    Object.entries(r.iconos||{}).forEach(([id,src])=>{ AOS._appIco[id]=src||""; if(!src) return; const el=win.body.querySelector(`[data-ic="${CSS.escape(id)}"]`); if(el) el.innerHTML=`<img src="${src}" alt="">`; });
  }
}

/* ---------- v7.1 · íconos: progreso visible y precarga en segundo plano ---------- */
AOS._icoPend=AOS._icoPend||new Set();
async function aosIcoFetch(ids,onProg){   // pide al núcleo los íconos que faltan, de a 40, sin duplicar pedidos en curso
  const falta=ids.filter(id=>!(id in AOS._appIco)&&!AOS._icoPend.has(id)); let hechos=0;
  for(let i=0;i<falta.length;i+=40){
    const lote=falta.slice(i,i+40); lote.forEach(id=>AOS._icoPend.add(id));
    try{ const r=await aosNuc("app.iconos",{ids:lote}); Object.entries(r.iconos||{}).forEach(([id,src])=>{ AOS._appIco[id]=src||""; }); }
    catch(e){ lote.forEach(id=>AOS._icoPend.delete(id)); return false; }
    lote.forEach(id=>AOS._icoPend.delete(id)); hechos+=lote.length; if(onProg) onProg(hechos,falta.length,lote);
  }
  return true;
}
async function aosIcoPrefetch(){
  if(AOS._icoPre||!aosNucOk()) return; AOS._icoPre=true;
  try{ const L=await aosNuc("app.listar",{}); AOS._appList=L; await aosIcoFetch(L.map(a=>a.id)); }catch(e){ AOS._icoPre=false; }
}
const V71_aosNucPing=aosNucPing;
aosNucPing=async function(){ const r=await V71_aosNucPing.apply(this,arguments); try{ if(AOSN.state==="ok"&&!AOS._icoPre) setTimeout(aosIcoPrefetch,2500); }catch(e){} return r; };
aosapIcons=async function(win,A){
  const tok=(win.state.icoTok=(win.state.icoTok||0)+1);
  const pinta=()=>A.forEach(a=>{ const src=AOS._appIco[a.id]; if(!src) return; const el=win.body.querySelector(`[data-ic="${CSS.escape(a.id)}"]`); if(el&&!el.querySelector("img")) el.innerHTML=`<img src="${src}" alt="">`; });
  pinta();
  const total=A.filter(a=>!(a.id in AOS._appIco)).length; const bar=win.body.querySelector(".aosap-prog");
  const prog=(n,t)=>{ if(!bar) return; if(n>=t){ bar.style.display="none"; return; } bar.style.display="flex"; bar.querySelector("b").textContent=n+aosL(" de "," of ")+t; bar.querySelector("i").style.width=Math.round(100*n/Math.max(t,1))+"%"; };
  if(!total){ prog(1,1); return; }
  prog(0,total);
  /* si la precarga ya está pidiendo íconos, espera y repinta */
  const wait=setInterval(()=>{ if(tok!==win.state.icoTok||!AOS.wins.includes(win)){ clearInterval(wait); return; } pinta(); const f=A.filter(a=>!(a.id in AOS._appIco)).length; prog(total-f,total); if(!f) clearInterval(wait); },700);
  await aosIcoFetch(A.map(a=>a.id),()=>{ if(tok===win.state.icoTok){ pinta(); prog(total-A.filter(a=>!(a.id in AOS._appIco)).length,total); } });
};
const V71_aosapPaint=aosapPaint;
aosapPaint=function(win){
  const L=win.body.querySelector(".aosap-l");
  if(L&&!win.body.querySelector(".aosap-prog")){ const p=document.createElement("div"); p.className="aosap-prog"; p.style.cssText="display:none;align-items:center;gap:10px;padding:6px 12px;font-size:12px;color:#33445c;background:#f4f8fd;border-bottom:1px solid #e5edf7";
    p.innerHTML=`<span>${aosL("Cargando íconos… ","Loading icons… ")}<b></b></span><span style="flex:1;max-width:220px;height:5px;border-radius:3px;background:#dbe6f3;overflow:hidden"><i style="display:block;height:100%;width:0;background:#1976d2;transition:width .3s"></i></span><span style="color:#8a97ab">${aosL("la primera vez tarda; después quedan guardados","slow the first time; cached afterwards")}</span>`;
    L.parentNode.insertBefore(p,L); }
  return V71_aosapPaint.apply(this,arguments);
};

/* ---------- v7.3 · iniciar el núcleo desde AR.T.L.A.S. OS (web y Escritorio) ----------
   El núcleo registra el protocolo artlas-nucleo:// la primera vez que se abre con Iniciar-Nucleo.bat. Desde entonces,
   si ya fue emparejado, el botón «Iniciar el núcleo» lo abre: Chrome pregunta «¿Abrir AR.T.L.A.S. Nucleo?»
   (se puede tildar «Permitir siempre») y el OS espera a que conecte. */
function aosNucPaired(){ return !!aosNucToken(); }
function aosNucStClick(){ if(AOSN.state!=="ok"&&aosNucPaired()) aosNucStart(); else aosLaunch("config"); }
async function aosNucStart(){
  if(AOSN.state==="ok"){ aosToast(aosL("El núcleo ya está conectado.","The core is already connected."),"ok"); return true; }
  if(AOS._nucStarting) return false; AOS._nucStarting=true;
  aosToast(aosL("Iniciando el núcleo… si Chrome pregunta, elegí «Abrir AR.T.L.A.S. Nucleo».","Starting the core… if Chrome asks, choose «Open AR.T.L.A.S. Nucleo»."),"",9000);
  try{
    const a=document.createElement("a"); a.href="artlas-nucleo://iniciar"; a.rel="noopener"; a.style.display="none"; document.body.appendChild(a); a.click(); a.remove();
    for(let i=0;i<30;i++){ await new Promise(r=>setTimeout(r,1000)); await aosNucPing(); if(AOSN.state==="ok"||AOSN.state==="pair") break; }
    aosPaintStatus(); AOS.wins.filter(w=>w.app==="config").forEach(w=>{ try{ aoscPaint(w); }catch(e){} });
    if(AOSN.state==="ok"){ aosToast(aosL("Núcleo conectado: ","Core connected: ")+(AOSN.equipo||""),"ok"); return true; }
    if(AOSN.state==="pair"){ aosToast(aosNucPaired()?aosL("El núcleo arrancó, pero hay que emparejarlo de nuevo con el código de su ventana.","The core started but needs pairing again with the code in its window."):aosL("El núcleo arrancó. Emparejalo con este sitio: escribí el código de 6 dígitos que muestra su ventana.","The core started. Pair it with this site: type the 6-digit code shown in its window."),"warn",10000); aosLaunch("config"); return false; }
    aosToast(aosL("No arrancó. La primera vez hay que abrir Iniciar-Nucleo.bat a mano (así se habilita este botón). Si ya lo hiciste, revisá que Chrome no haya bloqueado la apertura.","It didn't start. The first time, open Iniciar-Nucleo.bat manually (that enables this button). If you did, check Chrome didn't block it."),"err",12000);
    return false;
  }finally{ AOS._nucStarting=false; }
}
const V73_aoscPaint=aoscPaint;
aoscPaint=async function(win){
  const r=await V73_aoscPaint.apply(this,arguments);
  try{
    const card=win.body.querySelector(".aos-card"); if(!card) return r; const st=AOSN.state;
    if(st!=="ok"&&st!=="pair"&&!aosNucPaired()){   // v7.5: en un sitio donde todavía no se emparejó (p. ej. un sitio oficial nuevo)
      const box=document.createElement("div"); box.className="aosc-start"; box.style.cssText="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:0 0 10px;font-size:12.5px;color:#33445c";
      box.innerHTML=`<button class="aos-btn" data-k="start">▶ ${aosL("Iniciar el núcleo","Start the core")}</button><span style="flex:1;min-width:220px">${aosL("Si ya lo instalaste en esta PC (por ejemplo, desde otro sitio de AR.T.L.A.S.), inicialo desde acá y emparejalo con el código de su ventana.","If it's already installed on this PC (e.g. from another AR.T.L.A.S. site), start it here and pair it with the code in its window.")}</span>`;
      const head=card.firstElementChild; card.insertBefore(box,head?head.nextSibling:null);
      box.querySelector('[data-k="start"]').onclick=()=>aosNucStart();
    }
    if(st!=="ok"&&st!=="pair"&&aosNucPaired()){
      const box=document.createElement("div"); box.className="aosc-start"; box.style.cssText="display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:10px 12px;margin:0 0 10px;border-radius:10px;background:linear-gradient(90deg,#e6f2ff,#f4f8fd);border:1px solid #bcd8f7";
      box.innerHTML=`<button class="aos-btn pri" data-k="start" style="padding:8px 16px;font-size:13.5px">▶ ${aosL("Iniciar el núcleo","Start the core")}</button><span style="font-size:12.5px;color:#33445c;flex:1;min-width:220px">${aosL("Ya está emparejado con este navegador. Si es la primera vez que usás este botón, Chrome te pide permiso para abrirlo: tildá «Permitir siempre».","Already paired with this browser. The first time, Chrome asks for permission: tick «Always allow».")}</span>`;
      const head=card.firstElementChild; card.insertBefore(box,head?head.nextSibling:null);
      box.querySelector('[data-k="start"]').onclick=()=>aosNucStart();
    }
    if(st==="ok"){
      let ne=null; try{ ne=await aosNuc("nucleo.estado",{}); }catch(e){}
      if(ne){ if(ne.protocolo) v60LSset("atlas_os_nuc_proto","1");
        const box=document.createElement("div"); box.style.cssText="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:10px;padding-top:10px;border-top:1px dashed #dbe6f3;font-size:12.5px;color:#33445c";
        box.innerHTML=`${ne.plataforma!=="darwin"?`<label style="display:flex;align-items:center;gap:6px;cursor:pointer"><input type="checkbox" data-k="auto" ${ne.autoinicio?"checked":""}> ${aosL("Iniciar el núcleo automáticamente al prender la PC","Start the core automatically at login")}</label>`:""}
          <span style="flex:1"></span><span class="aos-pill ${ne.protocolo?"ok":""}" title="artlas-nucleo://">${ne.protocolo?aosL("Botón «Iniciar» habilitado","«Start» button enabled"):aosL("Botón «Iniciar» no disponible en este sistema","«Start» button unavailable here")}</span>
          <button class="aos-btn sm" data-k="stop">${aosL("Detener el núcleo","Stop the core")}</button>`;
        card.appendChild(box);
        const au=box.querySelector('[data-k="auto"]'); if(au) au.onchange=async()=>{ try{ const x=await aosNuc("nucleo.autoinicio",{activar:au.checked}); au.checked=!!x.autoinicio; aosToast(x.autoinicio?aosL("El núcleo se va a iniciar solo al prender la PC.","The core will start at login."):aosL("Inicio automático desactivado.","Autostart disabled."),"ok"); }catch(e){ au.checked=!au.checked; aosToast(e.message,"err"); } };
        box.querySelector('[data-k="stop"]').onclick=async()=>{ if(!confirm(aosL("¿Detener el núcleo local? Lo podés volver a iniciar desde acá.","Stop the local core? You can start it again from here."))) return; try{ await aosNuc("nucleo.detener",{}); }catch(e){} setTimeout(async()=>{ await aosNucPing(); aosPaintStatus(); aoscPaint(win); },1200); };
      }
    }
  }catch(e){}
  return r;
};

/* =====================================================================
   v7.6 · MODO APPLIANCE — AR.T.L.A.S. OS como sistema propio (ISO / Raspberry Pi)
   La app la sirve el núcleo en http://127.0.0.1:8770/app/ y se abre en Chromium en modo kiosco.
   · Token automático (POST /appliance/token, solo mismo origen): sin código de 6 dígitos.
   · Configuración → Sistema: Wi-Fi, volumen, zona horaria, apagar y reiniciar.
   · Oficina: «Instalar LibreOffice» (se instala después, a pedido).
   · «Salir» pasa a ser el menú de energía; «Plataforma» se llama AR.T.L.A.S. Escritorio.
   ===================================================================== */
const AOS_APPL=/[?&]appliance=1\b/.test(location.search)||(location.hostname==="127.0.0.1"&&location.pathname.startsWith("/app/"));
if(AOS_APPL){ try{ v60LSset("atlas_os_nuc_url",location.origin); }catch(e){} try{ document.documentElement.classList.add("aos-appliance"); }catch(e){} }
async function aosApplToken(){
  if(!AOS_APPL||aosNucToken()) return;
  try{ const r=await fetch(location.origin+"/appliance/token",{method:"POST"}); if(r.ok){ const j=await r.json(); if(j.token) v60LSset("atlas_os_nuc_tok",j.token); } }catch(e){}
}
const V76_aosNucPing=aosNucPing;
aosNucPing=async function(){ if(AOS_APPL&&!aosNucToken()) await aosApplToken(); return V76_aosNucPing.apply(this,arguments); };
if(AOS_APPL&&AOS.apps.clasico){ AOS.apps.clasico.title=()=>aosL("AR.T.L.A.S. Escritorio","AR.T.L.A.S. Desktop"); AOS.apps.clasico.sub=()=>aosL("La plataforma completa de AR.T.L.A.S.","The full AR.T.L.A.S. platform"); }

/* menú de energía (en el appliance, el botón de la esquina) */
function aosExitClick(ev){
  if(!AOS_APPL){ aosClose(); return; }
  const old=document.querySelector(".aos-pwr"); if(old){ old.remove(); return; }
  const m=document.createElement("div"); m.className="aos-pwr";
  m.style.cssText="position:fixed;top:44px;right:12px;z-index:9800;background:#fff;border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.35);padding:6px;min-width:230px;font-size:13.5px";
  const it=(k,t)=>`<button class="aos-row" data-p="${k}" style="padding:9px 12px">${t}</button>`;
  m.innerHTML=it("escritorio","🖥️ "+aosL("AR.T.L.A.S. Escritorio","AR.T.L.A.S. Desktop"))+it("reiniciar","🔄 "+aosL("Reiniciar","Restart"))+it("apagar","⏻ "+aosL("Apagar","Shut down"));
  document.body.appendChild(m);
  setTimeout(()=>document.addEventListener("click",function f(e){ if(!m.contains(e.target)){ m.remove(); document.removeEventListener("click",f); } }),0);
  m.querySelectorAll("[data-p]").forEach(b=>b.onclick=async()=>{ const k=b.dataset.p; m.remove();
    if(k==="escritorio"){ aosClose(); try{ go("chat"); }catch(e){} return; }
    if(!confirm(k==="apagar"?aosL("¿Apagar el equipo?","Shut down?"):aosL("¿Reiniciar el equipo?","Restart?"))) return;
    try{ await aosNuc("sistema.energia",{accion:k}); aosToast(k==="apagar"?aosL("Apagando…","Shutting down…"):aosL("Reiniciando…","Restarting…"),"ok",20000); }catch(e){ aosToast(e.message,"err"); } });
}

/* Configuración → Sistema */
const AOS_ZONAS=["America/Argentina/Buenos_Aires","America/Argentina/Cordoba","America/Argentina/Tucuman","America/Argentina/Salta","America/Argentina/Mendoza","America/Argentina/Ushuaia","America/Santiago","America/Montevideo","America/Asuncion","America/La_Paz","America/Lima","America/Bogota","America/Mexico_City","America/Sao_Paulo","America/New_York","Europe/Madrid","UTC"];
const V76_aoscPaint=aoscPaint;
aoscPaint=async function(win){
  const r=await V76_aoscPaint.apply(this,arguments);
  if(!AOS_APPL||AOSN.state!=="ok") return r;
  try{
    const B=win.body.querySelector(".aosc"); if(!B||B.querySelector(".aosc-sis")) return r;
    let st={}; try{ st=await aosNuc("sistema.estado",{}); }catch(e){}
    const box=document.createElement("div"); box.className="aosc-sis";
    box.innerHTML=`<div class="aos-h">${aosL("Sistema","System")}</div>
      <div class="aos-card" style="margin-bottom:12px;display:grid;gap:12px">
        <div><div style="font-weight:600;color:#0d2b5e;margin-bottom:6px">Wi-Fi ${st.wifi?`<span class="aos-pill ok">${aosEsc(st.wifi)}</span>`:`<span class="aos-pill">${aosL("sin conexión Wi-Fi","no Wi-Fi")}</span>`}</div>
          <div class="aosc-wifi" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center"><button class="aos-btn sm" data-s="scan">${aosL("Buscar redes","Scan networks")}</button></div></div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap"><span style="font-weight:600;color:#0d2b5e;min-width:90px">${aosL("Volumen","Volume")}</span><input type="range" min="0" max="100" value="${+st.volumen||50}" class="aosc-vol" style="flex:1;min-width:160px"><b class="aosc-volv">${+st.volumen||50}%</b></div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap"><span style="font-weight:600;color:#0d2b5e;min-width:90px">${aosL("Zona horaria","Time zone")}</span><select class="aos-in aosc-zona" style="flex:1;min-width:220px">${AOS_ZONAS.concat(st.zona&&!AOS_ZONAS.includes(st.zona)?[st.zona]:[]).map(z=>`<option ${z===st.zona?"selected":""}>${z}</option>`).join("")}</select></div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end"><span style="flex:1;font-size:12px;color:#6b7a90;align-self:center">${aosL("Equipo: ","Device: ")}${aosEsc(st.equipo||"")}</span><button class="aos-btn sm" data-s="reiniciar">🔄 ${aosL("Reiniciar","Restart")}</button><button class="aos-btn sm dan" data-s="apagar">⏻ ${aosL("Apagar","Shut down")}</button></div>
      </div>`;
    B.insertBefore(box,B.firstChild);
    const q=c=>box.querySelector(c);
    q(".aosc-vol").oninput=e=>{ q(".aosc-volv").textContent=e.target.value+"%"; };
    q(".aosc-vol").onchange=async e=>{ try{ await aosNuc("sistema.volumen",{valor:+e.target.value}); }catch(x){ aosToast(x.message,"err"); } };
    q(".aosc-zona").onchange=async e=>{ try{ await aosNuc("sistema.zona",{zona:e.target.value}); aosToast(aosL("Zona horaria actualizada","Time zone updated"),"ok"); aosClock(); }catch(x){ aosToast(x.message,"err"); } };
    box.querySelectorAll('[data-s="apagar"],[data-s="reiniciar"]').forEach(b=>b.onclick=async()=>{ const k=b.dataset.s; if(!confirm(k==="apagar"?aosL("¿Apagar el equipo?","Shut down?"):aosL("¿Reiniciar el equipo?","Restart?"))) return; try{ await aosNuc("sistema.energia",{accion:k}); aosToast(aosL("Listo…","Done…"),"ok",20000); }catch(x){ aosToast(x.message,"err"); } });
    q('[data-s="scan"]').onclick=async()=>{
      const W=q(".aosc-wifi"); W.innerHTML=`<span style="font-size:12px;color:#6b7a90">${aosL("Buscando…","Scanning…")}</span>`;
      try{ const x=await aosNuc("sistema.wifi",{accion:"listar"});
        W.innerHTML=`<select class="aos-in aosc-ssid" style="min-width:220px">${x.redes.map(n=>`<option value="${aosEsc(n.ssid)}" ${n.activa?"selected":""}>${aosEsc(n.ssid)} · ${n.senal}%${n.segura?" 🔒":""}</option>`).join("")}</select><input class="aos-in aosc-clave" type="password" placeholder="${aosEsc(aosL("Clave","Password"))}" style="width:170px"><button class="aos-btn sm pri" data-s="con">${aosL("Conectar","Connect")}</button>`;
        W.querySelector('[data-s="con"]').onclick=async()=>{ const ssid=W.querySelector(".aosc-ssid").value; try{ aosToast(aosL("Conectando a ","Connecting to ")+ssid+"…","",8000); await aosNuc("sistema.wifi",{accion:"conectar",ssid,clave:W.querySelector(".aosc-clave").value}); aosToast(aosL("Conectado a ","Connected to ")+ssid,"ok"); box.remove(); aoscPaint(win); }catch(x){ aosToast(x.message,"err",8000); } };
      }catch(x){ W.innerHTML=`<span style="color:#c0272d;font-size:12px">${aosEsc(x.message)}</span>`; }
    };
  }catch(e){}
  return r;
};

/* Oficina: instalar LibreOffice a pedido (en el appliance no viene incluido) */
const V76_aosOfPaint=aosOfPaint;
aosOfPaint=async function(win){
  const r=await V76_aosOfPaint.apply(this,arguments);
  try{
    const st=AOSOF.st||{}; if(!AOS_APPL||!st.nucleo||st.disponible) return r;
    const P=win.body.querySelector(".aosof .aos-sub"); if(!P||P.querySelector(".aosof-inst")) return r;
    P.innerHTML=`<span class="aos-pill">${aosL("LibreOffice no instalado","LibreOffice not installed")}</span> ${aosL("Instalalo una sola vez para crear y convertir Word, Excel, PowerPoint y PDF y abrir Writer, Calc e Impress (≈ 400 MB, necesita internet).","Install it once to create and convert Word, Excel, PowerPoint and PDF and open Writer, Calc and Impress (≈ 400 MB, needs internet).")} <button class="aos-btn sm pri aosof-inst">⬇ ${aosL("Instalar LibreOffice","Install LibreOffice")}</button><span class="aosof-instp" style="font-size:12px;color:#6b7a90;margin-left:6px"></span>`;
    P.querySelector(".aosof-inst").onclick=async ev=>{
      ev.target.disabled=true; const pr=P.querySelector(".aosof-instp");
      try{ const j=await aosNuc("sistema.instalar",{paquete:"libreoffice"});
        for(;;){ await new Promise(r=>setTimeout(r,4000)); const t=await aosNuc("sistema.trabajo",{job:j.job});
          if(t.estado==="instalando"){ pr.textContent=aosL("Instalando… ","Installing… ")+Math.floor(t.segundos/60)+":"+String(t.segundos%60).padStart(2,"0"); continue; }
          if(t.estado==="listo"){ aosToast(aosL("LibreOffice instalado","LibreOffice installed"),"ok"); AOSOF.ico=null; await aosOfEstado(true); aosOfPaint(win); return; }
          throw new Error(t.error||aosL("No se pudo instalar","Install failed")); }
      }catch(e){ ev.target.disabled=false; pr.textContent=""; aosToast(e.message,"err",9000); }
    };
  }catch(e){}
  return r;
};

/* AR.T.L.A.S. RAG (asistente sobre tus documentos, 100 % local) */
async function aosRagVivo(){ try{ await fetch("http://127.0.0.1:8760/",{mode:"no-cors",signal:AbortSignal.timeout(1500)}); return true; }catch(e){ return false; } }
aosRegister("rag",{title:()=>"AR.T.L.A.S. RAG",sub:()=>aosL("Preguntale a tus documentos, sin nube","Ask your documents, no cloud"),icon:"office",desk:true,order:97,w:1080,h:680,
  kw:"rag documentos pdf preguntar local llama privado",
  render(win){ win.body.innerHTML=`<div class="aos-pad aosrag"></div>`; aosRagPaint(win); },
  reopen(win){ aosRagPaint(win); }
});
async function aosRagPaint(win){
  const B=win.body.querySelector(".aosrag")||win.body; let st={instalado:false,activo:false,url:"http://127.0.0.1:8760/"};
  if(aosNucOk()){ try{ st=await aosNuc("rag.estado",{}); }catch(e){} } if(!st.activo) st.activo=await aosRagVivo();
  if(st.activo){ win.body.innerHTML=`<iframe src="${aosEsc(st.url||"http://127.0.0.1:8760/")}" style="border:0;width:100%;height:100%;background:#fff"></iframe>`; return; }
  B.innerHTML=`<div style="max-width:620px;margin:20px auto;text-align:center">
    <img src="${aosImg("rag")||""}" alt="" style="width:72px;height:72px;margin-bottom:8px">
    <div class="aos-h" style="justify-content:center">AR.T.L.A.S. RAG</div>
    <p class="aos-sub">${aosL("Un asistente que responde sobre tus documentos (PDF, Word, Excel, texto) con un modelo de IA que corre en este equipo: privado y sin internet una vez descargado el modelo.","An assistant that answers about your documents (PDF, Word, Excel, text) with an AI model running on this device: private and offline once the model is downloaded.")}</p>
    ${st.instalado?`<button class="aos-btn pri" data-r="ini">▶ ${aosL("Iniciar AR.T.L.A.S. RAG","Start AR.T.L.A.S. RAG")}</button><p class="aos-sub" style="margin-top:8px">${aosL("La primera vez se descarga el modelo (0,5 a 2 GB).","The model is downloaded the first time (0.5–2 GB).")}</p>`
      :`<div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap"><button class="aos-btn pri" data-r="dl">⬇ ${aosL("Descargar AR.T.L.A.S. RAG","Download AR.T.L.A.S. RAG")}</button><button class="aos-btn" data-r="re">${aosL("Ya lo abrí: conectar","It's running: connect")}</button></div><p class="aos-sub" style="margin-top:8px">${aosL("En Windows: descomprimilo y abrí INICIAR.bat. Después volvé acá.","On Windows: unzip it and open INICIAR.bat. Then come back here.")}</p>`}
    <div class="aosrag-msg" style="font-size:12px;color:#6b7a90;margin-top:8px"></div></div>`;
  const q=c=>B.querySelector(c), msg=t=>{ const m=q(".aosrag-msg"); if(m) m.textContent=t; };
  if(q('[data-r="ini"]')) q('[data-r="ini"]').onclick=async ev=>{ ev.target.disabled=true; msg(aosL("Iniciando…","Starting…")); try{ const r=await aosNuc("rag.iniciar",{}); if(!r.activo) msg(aosL("Está arrancando; en unos segundos se abre.","Starting; it will open in a few seconds.")); for(let i=0;i<30;i++){ const x=aosNucOk()?await aosNuc("rag.estado",{}).catch(()=>({})):{activo:await aosRagVivo()}; if(x.activo) break; await new Promise(r=>setTimeout(r,1000)); } aosRagPaint(win); }catch(e){ ev.target.disabled=false; msg(e.message); } };
  if(q('[data-r="dl"]')) q('[data-r="dl"]').onclick=()=>{ try{ downloadRagLocal(); }catch(e){ aosToast(e.message,"err"); } };
  if(q('[data-r="re"]')) q('[data-r="re"]').onclick=()=>aosRagPaint(win);
}

/* =====================================================================
   v7.7 · CUENTA LOCAL DEL APPLIANCE (tipo Windows) + IA LOCAL SIN GPU
   · Primer arranque: asistente (bienvenida → cuenta → licencia → listo).
   · Cada arranque y «Bloquear»: pantalla de bloqueo con la contraseña.
   · En el appliance reemplaza el ingreso web (mail) de la plataforma.
   · Configuración: «Cuenta» (nombre y contraseña) e «Inteligencia local (sin GPU)».
   ===================================================================== */
if(AOS_APPL){ try{ v60LSset("atlas_os_nuc_tok",""); }catch(e){} }   // el token se obtiene con la contraseña en cada arranque
AOS_OLLAMA_REC.unshift(["qwen2.5:0.5b","≈400 MB",aosL("Ultra liviano: máquinas virtuales y equipos sin GPU","Ultra light: VMs and no-GPU devices")],["llama3.2:1b","≈1,3 GB",aosL("Liviano, buen español","Light, good Spanish")]);
const V77_v61GateShow=v61GateShow;
v61GateShow=function(){ if(AOS_APPL){ aosApplGate(); return; } return V77_v61GateShow.apply(this,arguments); };
async function aosApplPost(q,b){ const r=await fetch(location.origin+"/appliance/"+q,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b||{})}); let j={}; try{ j=await r.json(); }catch(e){} if(!r.ok) throw Object.assign(new Error(j.error||("HTTP "+r.status)),{pista:j.pista}); return j; }
function aosGateEl(){ let g=$("aos-gate"); if(!g){ g=document.createElement("div"); g.id="aos-gate"; document.body.appendChild(g); } return g; }
const AOS_GATE_CSS=`#aos-gate{position:fixed;inset:0;z-index:2147480000;display:flex;align-items:center;justify-content:center;padding:20px;color:#eaf3ff;font-family:inherit;
  background:radial-gradient(ellipse 60% 70% at 50% 45%,#0c55b4 0%,#0a3f8f 30%,#062b6a 58%,#031a46 82%,#02112f 100%)}
#aos-gate .card{background:rgba(255,255,255,.97);color:#1d2533;border-radius:18px;box-shadow:0 30px 80px rgba(0,0,0,.45);width:min(520px,100%);max-height:calc(100vh - 40px);overflow:auto;padding:26px 28px}
#aos-gate h2{margin:0 0 6px;color:#0d2b5e;font-size:22px} #aos-gate p{margin:0 0 14px;color:#4a5a70;font-size:13.5px;line-height:1.5}
#aos-gate label{display:block;font-size:12.5px;color:#4a5a70;margin:10px 0 4px} #aos-gate input[type=text],#aos-gate input[type=password]{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #c9d6e8;border-radius:10px;font-size:14.5px;outline:none} #aos-gate input:focus{border-color:#1976d2;box-shadow:0 0 0 3px rgba(25,118,210,.15)}
#aos-gate .btns{display:flex;gap:8px;justify-content:flex-end;margin-top:18px} #aos-gate .err{color:#c0272d;font-size:12.5px;min-height:18px;margin-top:8px}
#aos-gate .pasos{display:flex;gap:6px;margin-bottom:16px} #aos-gate .pasos i{flex:1;height:4px;border-radius:2px;background:#dbe6f3} #aos-gate .pasos i.on{background:#1976d2}
#aos-gate .lic{max-height:220px;overflow:auto;border:1px solid #dbe6f3;border-radius:10px;padding:10px 12px;font-size:12px;background:#f8fbff}
#aos-gate .lock{display:flex;flex-direction:column;align-items:center;text-align:center;gap:10px;width:min(380px,100%)}
#aos-gate .reloj{font-size:clamp(28px,4.2vw,48px);font-weight:300;letter-spacing:1px;line-height:1} #aos-gate .fecha{font-size:13.5px;color:#a9cfff;margin-bottom:18px}
#aos-gate .otros{position:fixed;left:20px;bottom:18px;display:flex;flex-direction:column;gap:6px} #aos-gate .otros button{display:flex;align-items:center;gap:10px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);color:#fff;border-radius:12px;padding:6px 14px 6px 6px;cursor:pointer;font-size:13.5px;text-align:left}
#aos-gate .otros button:hover{background:rgba(255,255,255,.18)} #aos-gate .otros i{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-style:normal;font-weight:700;background:linear-gradient(160deg,#22c4ff,#1565c0)}
#aos-gate .av{width:96px;height:96px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:40px;font-weight:600;color:#fff;background:linear-gradient(160deg,#22c4ff,#1565c0);box-shadow:0 0 0 4px rgba(255,255,255,.15),0 10px 30px rgba(0,0,0,.35)}
#aos-gate .quien{font-size:22px;font-weight:600;margin-top:4px} #aos-gate .pw{display:flex;width:100%;gap:0;margin-top:8px} #aos-gate .pw input{border-radius:10px 0 0 10px!important;border:1px solid rgba(255,255,255,.35)!important;background:rgba(255,255,255,.12)!important;color:#fff!important}
#aos-gate .pw input::placeholder{color:#b9d4f5} #aos-gate .pw button{border:none;border-radius:0 10px 10px 0;background:#1976d2;color:#fff;padding:0 16px;font-size:18px;cursor:pointer}
#aos-gate .lock .err{color:#ffb4b4} #aos-gate .pista{font-size:12px;color:#a9cfff} #aos-gate .pwr{position:fixed;right:20px;bottom:18px;display:flex;gap:8px} #aos-gate .pwr button{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.25);color:#fff;border-radius:10px;padding:8px 12px;cursor:pointer;font-size:13px}
#aos-gate .marca{position:fixed;left:22px;top:18px;display:flex;align-items:center;gap:10px;font-weight:700;letter-spacing:3px} #aos-gate .marca img{height:30px}
#aos-gate .licck{display:flex;gap:8px;align-items:flex-start;font-size:12.5px;color:#d6e8ff;text-align:left;margin-top:6px} #aos-gate .licck a{color:#7fd8ff}`;
async function aosApplGate(){
  if(AOS._gateBusy) return; const g0=$("aos-gate"); if(g0&&g0.style.display==="flex"&&g0.firstChild) return;   // ya está en pantalla: no la redibuja
  AOS._gateBusy=true;
  let c={configurada:false}; try{ c=await aosApplPost("cuenta",{usuario:v60LS("atlas_os_ultimo_usuario","")||undefined}); }catch(e){} finally{ AOS._gateBusy=false; }
  AOS._cuenta=c; const g=aosGateEl(); g.style.display="flex";
  try{ const wg=$("v61-gate"); if(wg) wg.style.display="none"; }catch(e){}   // en el appliance no se usa el ingreso web por mail
  if(!$("aos-gate-css")){ const st=document.createElement("style"); st.id="aos-gate-css"; st.textContent=AOS_GATE_CSS; document.head.appendChild(st); }
  if(!c.configurada) aosOobe(g); else aosLock(g,c);
}
function aosGateMarca(){ const lg=aosImg("logo"); return `<div class="marca">${lg?`<img src="${lg}" alt="">`:""}AR.T.L.A.S. OS</div>`; }
function aosApplEnter(){
  const g=$("aos-gate"); if(g){ g.style.display="none"; g.innerHTML=""; }
  if(AOS.on){ aosNucPing().then(()=>aosPaintStatus()); return; }
  try{ v61GateGuest(); }catch(e){}
  setTimeout(()=>{ try{ if(!AOS.on) aosOpen(); aosNucPing().then(()=>aosPaintStatus()); }catch(e){} },300);
}
function aosOobe(g){
  const S={paso:0,nombre:"",usuario:"",clave:"",clave2:"",pista:"",acepto:false};
  const pasos=n=>`<div class="pasos">${[0,1,2,3].map(i=>`<i class="${i<=n?"on":""}"></i>`).join("")}</div>`;
  const pinta=()=>{
    let h=aosGateMarca()+`<div class="card">`+pasos(S.paso);
    if(S.paso===0) h+=`<h2>${aosL("Bienvenido a AR.T.L.A.S. OS","Welcome to AR.T.L.A.S. OS")}</h2><p>${aosL("Vamos a dejar el equipo listo en unos pasos: crear tu cuenta, aceptar la licencia y empezar. Después, cada vez que lo prendas, solo vas a escribir tu contraseña.","Let's set up this device in a few steps: create your account, accept the license and start. Afterwards you'll only type your password at each start.")}</p>
      <label>${aosL("Idioma","Language")}</label><div style="display:flex;gap:8px"><button class="aos-btn ${atlasLang!=="en"?"pri":""}" data-l="es">Español</button><button class="aos-btn ${atlasLang==="en"?"pri":""}" data-l="en">English</button></div>
      <div class="btns"><button class="aos-btn pri" data-n="1">${aosL("Empezar","Start")} →</button></div>`;
    if(S.paso===1) h+=`<h2>${aosL("Creá tu cuenta","Create your account")}</h2><p>${aosL("Es la cuenta de este equipo (no hace falta mail ni internet).","This is the device account (no email or internet needed).")}</p>
      <label>${aosL("Tu nombre","Your name")}</label><input type="text" class="f-nom" value="${aosEsc(S.nombre)}" placeholder="Mario Figueroa" autocomplete="off">
      <label>${aosL("Usuario","Username")}</label><input type="text" class="f-usu" value="${aosEsc(S.usuario)}" placeholder="mario" autocomplete="off">
      <label>${aosL("Contraseña","Password")}</label><input type="password" data-v63eye="1" class="f-c1" value="${aosEsc(S.clave)}" autocomplete="new-password">
      <label>${aosL("Repetí la contraseña","Repeat password")}</label><input type="password" data-v63eye="1" class="f-c2" value="${aosEsc(S.clave2)}" autocomplete="new-password">
      <label>${aosL("Pista para recordarla (opcional)","Password hint (optional)")}</label><input type="text" class="f-pis" value="${aosEsc(S.pista)}" autocomplete="off">
      <div class="err"></div><div class="btns"><button class="aos-btn" data-n="0">← ${aosL("Atrás","Back")}</button><button class="aos-btn pri" data-n="2">${aosL("Siguiente","Next")} →</button></div>`;
    if(S.paso===2){ let doc=""; try{ doc=v69DocHtml(); }catch(e){} h+=`<h2>${aosL("Licencia","License")}</h2><p>${aosL("Leé y aceptá la Política de Privacidad, los Términos de Uso y la Licencia AR.T.L.A.S. ","Read and accept the Privacy Policy, Terms of Use and AR.T.L.A.S. License ")}${aosEsc(V69.ver)}.</p>
      <div class="lic">${doc||aosL("Documento de licencia AR.T.L.A.S.","AR.T.L.A.S. license document")}</div>
      <label style="display:flex;gap:8px;align-items:flex-start;color:#1d2533;font-size:13px;margin-top:12px"><input type="checkbox" class="f-lic" ${S.acepto?"checked":""} style="margin-top:3px"> ${aosL("He leído y acepto la Política de Privacidad, los Términos de Uso y la Licencia AR.T.L.A.S. ","I have read and accept the Privacy Policy, Terms of Use and AR.T.L.A.S. License ")}${aosEsc(V69.ver)}</label>
      <div class="err"></div><div class="btns"><button class="aos-btn" data-n="1">← ${aosL("Atrás","Back")}</button><button class="aos-btn pri" data-n="3">${aosL("Aceptar y crear la cuenta","Accept and create account")}</button></div>`; }
    if(S.paso===3) h+=`<h2>${aosL("¡Listo, ","All set, ")}${aosEsc(S.nombre.split(" ")[0])}!</h2><p>${aosL("Tu cuenta quedó creada. La próxima vez que prendas el equipo vas a ver tu nombre y solo vas a escribir la contraseña.","Your account is ready. Next time you'll see your name and just type your password.")}</p><div class="btns"><button class="aos-btn pri" data-n="fin">${aosL("Entrar a AR.T.L.A.S. OS","Enter AR.T.L.A.S. OS")} →</button></div>`;
    g.innerHTML=h+`</div>`;
    const q=c=>g.querySelector(c), err=t=>{ const e=q(".err"); if(e) e.textContent=t; };
    g.querySelectorAll("[data-l]").forEach(b=>b.onclick=()=>{ if((b.dataset.l==="en")!==(atlasLang==="en")){ try{ toggleLang(); }catch(e){} } pinta(); });
    if(q(".f-nom")){ const nom=q(".f-nom"), usu=q(".f-usu"); nom.oninput=()=>{ if(!S._usuTocado) usu.value=nom.value.trim().split(/\s+/)[0].toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9._-]/g,""); }; usu.oninput=()=>{ S._usuTocado=true; }; setTimeout(()=>nom.focus(),50); }
    g.querySelectorAll("[data-n]").forEach(b=>b.onclick=async()=>{
      const n=b.dataset.n;
      if(S.paso===1){ S.nombre=q(".f-nom").value.trim(); S.usuario=q(".f-usu").value.trim().toLowerCase(); S.clave=q(".f-c1").value; S.clave2=q(".f-c2").value; S.pista=q(".f-pis").value.trim();
        if(n==="2"){ if(!S.nombre) return err(aosL("Escribí tu nombre.","Type your name.")); if(!/^[a-z][a-z0-9._-]{1,31}$/.test(S.usuario)) return err(aosL("Usuario: letras minúsculas, números, punto o guion (empezando con letra).","Username: lowercase letters, digits, dot or dash (starting with a letter).")); if(S.clave.length<4) return err(aosL("La contraseña debe tener al menos 4 caracteres.","Password must be at least 4 characters.")); if(S.clave!==S.clave2) return err(aosL("Las contraseñas no coinciden.","Passwords don't match.")); } }
      if(S.paso===2&&n==="3"){ S.acepto=q(".f-lic").checked; if(!S.acepto) return err(aosL("Para continuar tenés que aceptar la licencia.","You must accept the license to continue."));
        b.disabled=true; try{ const r=await aosApplPost("crear",{usuario:S.usuario,nombre:S.nombre,clave:S.clave,pista:S.pista,licencia:V69.ver}); v60LSset("atlas_os_nuc_tok",r.token); AOS._cuenta=r.cuenta; }catch(e){ b.disabled=false; return err(e.message); } }
      if(n==="fin"){ aosApplEnter(); return; }
      S.paso=+n; pinta();
    });
    g.querySelectorAll("input").forEach(i=>i.addEventListener("keydown",ev=>{ if(ev.key==="Enter"){ const nx=g.querySelector(".btns .pri"); if(nx) nx.click(); } }));
  };
  pinta();
}
function aosLock(g,c){
  const necesitaLic=!c.licencia||c.licencia.ver!==V69.ver;
  const ini=(c.nombre||c.usuario||"?").trim().charAt(0).toUpperCase();
  g.innerHTML=aosGateMarca()+`<div class="lock"><div class="reloj"></div><div class="fecha"></div><div class="av">${aosEsc(ini)}</div><div class="quien">${aosEsc(c.nombre||c.usuario)}</div>
    <form class="pw" onsubmit="return false"><input type="password" data-v63eye="1" placeholder="${aosEsc(aosL("Contraseña","Password"))}" autocomplete="current-password"><button type="submit" aria-label="${aosEsc(aosL("Ingresar","Sign in"))}">→</button></form>
    ${necesitaLic?`<label class="licck"><input type="checkbox" class="f-lic"> <span>${aosL("Acepto la Licencia AR.T.L.A.S. ","I accept the AR.T.L.A.S. License ")}${aosEsc(V69.ver)} (<a href="#" class="f-ver">${aosL("leer","read")}</a>)</span></label>`:""}
    <div class="err"></div><div class="pista"></div></div>
    ${(c.usuarios||[]).length>1?`<div class="otros">${c.usuarios.filter(u=>u.usuario!==c.usuario).map(u=>`<button data-u="${aosEsc(u.usuario)}"><i>${aosEsc((u.nombre||u.usuario).charAt(0).toUpperCase())}</i>${aosEsc(u.nombre||u.usuario)}</button>`).join("")}</div>`:""}
    <div class="pwr"><button data-e="reiniciar">🔄 ${aosL("Reiniciar","Restart")}</button><button data-e="apagar">⏻ ${aosL("Apagar","Shut down")}</button></div>`;
  const q=s=>g.querySelector(s), inp=q(".pw input");
  const tick=()=>{ if(!document.body.contains(q(".reloj")||document.createElement("i"))) return; const d=new Date(); q(".reloj").textContent=d.toLocaleTimeString(atlasLang==="en"?"en-US":"es-AR",{hour:"2-digit",minute:"2-digit"}); q(".fecha").textContent=d.toLocaleDateString(atlasLang==="en"?"en-US":"es-AR",{weekday:"long",day:"numeric",month:"long"}); setTimeout(tick,15000); }; tick();
  setTimeout(()=>inp.focus(),80);
  if(q(".f-ver")) q(".f-ver").onclick=ev=>{ ev.preventDefault(); let doc=""; try{ doc=v69DocHtml(); }catch(e){} const box=document.createElement("div"); box.className="card"; box.style.cssText="position:fixed;inset:6% 8%;width:auto;z-index:3"; box.innerHTML=`<div class="lic" style="max-height:calc(100% - 60px)">${doc}</div><div class="btns"><button class="aos-btn pri">${aosL("Cerrar","Close")}</button></div>`; g.appendChild(box); box.querySelector("button").onclick=()=>box.remove(); };
  q(".pw").onsubmit=async(ev)=>{
    if(ev) ev.preventDefault();   // sin esto el formulario recarga la página
    const e=q(".err"), p=q(".pista"); e.textContent="";
    if(necesitaLic&&!q(".f-lic").checked){ e.textContent=aosL("Aceptá la licencia para continuar.","Accept the license to continue."); return false; }
    try{ const r=await aosApplPost("token",{usuario:c.usuario,clave:inp.value,licencia:necesitaLic?V69.ver:undefined}); v60LSset("atlas_os_nuc_tok",r.token); v60LSset("atlas_os_ultimo_usuario",r.cuenta.usuario); AOS._cuenta=r.cuenta; aosApplEnter(); }
    catch(x){ e.textContent=x.message; inp.value=""; inp.focus(); if(x.pista) p.textContent=aosL("Pista: ","Hint: ")+x.pista; }
    return false;
  };
  g.querySelectorAll(".otros [data-u]").forEach(b=>b.onclick=async()=>{ try{ const c2=await aosApplPost("cuenta",{usuario:b.dataset.u}); AOS._cuenta=c2; aosLock(g,c2); }catch(e){} });
  g.querySelectorAll("[data-e]").forEach(b=>b.onclick=async()=>{ if(!confirm(b.dataset.e==="apagar"?aosL("¿Apagar el equipo?","Shut down?"):aosL("¿Reiniciar el equipo?","Restart?"))) return; try{ await aosApplPost("energia",{accion:b.dataset.e}); }catch(e){} });
}
function aosApplLock(){ v60LSset("atlas_os_nuc_tok",""); const g=$("aos-gate"); if(g){ g.style.display="none"; g.innerHTML=""; } aosApplGate(); }

/* menú de energía: nombre del usuario y «Bloquear» */
const V77_aosExitClick=aosExitClick;
aosExitClick=function(ev){
  V77_aosExitClick.apply(this,arguments);
  const m=document.querySelector(".aos-pwr"); if(!m||!AOS_APPL) return;
  const c=AOS._cuenta||{}; const h=document.createElement("div"); h.style.cssText="padding:8px 12px 6px;font-size:12px;color:#6b7a90;border-bottom:1px solid #eef2f7;margin-bottom:4px";
  h.innerHTML=`${aosL("Sesión de ","Signed in as ")}<b style="color:#0d2b5e">${aosEsc(c.nombre||c.usuario||"")}</b>`; m.insertBefore(h,m.firstChild);
  const b=document.createElement("button"); b.className="aos-row"; b.style.padding="9px 12px"; b.textContent="🔒 "+aosL("Bloquear","Lock"); b.onclick=()=>{ m.remove(); aosApplLock(); };
  m.insertBefore(b,m.querySelector('[data-p="reiniciar"]'));
};

/* Configuración: Cuenta e Inteligencia local (sin GPU) */
const V77_aoscPaint=aoscPaint;
aoscPaint=async function(win){
  const r=await V77_aoscPaint.apply(this,arguments);
  try{
    const B=win.body.querySelector(".aosc"); if(!B) return r;
    if(AOS_APPL&&AOSN.state==="ok"&&!B.querySelector(".aosc-cta")){
      let c={}; try{ c=await aosNuc("cuenta.estado",{usuario:(AOS._cuenta||{}).usuario}); }catch(e){}
      if(c.configurada){
        const box=document.createElement("div"); box.className="aosc-cta";
        box.innerHTML=`<div class="aos-h">${aosL("Cuenta","Account")}</div><div class="aos-card" style="margin-bottom:12px;display:grid;gap:8px">
          <div style="display:flex;align-items:center;gap:10px"><span style="width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;background:linear-gradient(160deg,#22c4ff,#1565c0)">${aosEsc((c.nombre||"?").charAt(0).toUpperCase())}</span><div><b style="color:#0d2b5e">${aosEsc(c.nombre)}</b><div style="font-size:12px;color:#6b7a90">${aosL("usuario: ","user: ")}${aosEsc(c.usuario)}${c.licencia?" · "+aosL("licencia ","license ")+aosEsc(c.licencia.ver):""}</div></div></div>
          <div style="display:flex;gap:6px;flex-wrap:wrap"><input class="aos-in a-nom" value="${aosEsc(c.nombre)}" style="flex:1;min-width:180px"><button class="aos-btn sm" data-c="nom">${aosL("Cambiar nombre","Rename")}</button></div>
          <div style="display:flex;gap:6px;flex-wrap:wrap"><input type="password" class="aos-in a-act" placeholder="${aosEsc(aosL("Contraseña actual","Current password"))}" style="flex:1;min-width:140px"><input type="password" class="aos-in a-n1" placeholder="${aosEsc(aosL("Nueva","New"))}" style="flex:1;min-width:120px"><input type="password" class="aos-in a-n2" placeholder="${aosEsc(aosL("Repetir","Repeat"))}" style="flex:1;min-width:120px"><button class="aos-btn sm" data-c="clave">${aosL("Cambiar contraseña","Change password")}</button></div>
          <div style="display:flex;justify-content:flex-end"><button class="aos-btn sm" data-c="lock">🔒 ${aosL("Bloquear ahora","Lock now")}</button></div></div>
          <div class="aos-h" style="font-size:14px">${aosL("Usuarios de este equipo","Users on this device")} (${(c.usuarios||[]).length}/4)</div><div class="aos-card" style="margin-bottom:12px;display:grid;gap:6px">
          ${(c.usuarios||[]).map(u=>`<div style="display:flex;align-items:center;gap:8px"><b style="color:#0d2b5e;flex:1">${aosEsc(u.nombre)}</b><span style="font-size:12px;color:#6b7a90">${aosEsc(u.usuario)}${u.admin?" · "+aosL("administrador","admin"):""}</span>${u.admin?"":`<button class="aos-btn sm dan" data-del="${aosEsc(u.usuario)}">✕</button>`}</div>`).join("")}
          ${(c.usuarios||[]).length<4?`<div style="display:flex;gap:6px;flex-wrap:wrap;border-top:1px dashed #dbe6f3;padding-top:8px"><input class="aos-in u-nom" placeholder="${aosEsc(aosL("Nombre","Name"))}" style="flex:1;min-width:140px"><input class="aos-in u-usu" placeholder="${aosEsc(aosL("usuario","username"))}" style="width:120px"><input type="password" data-v63eye="1" class="aos-in u-cla" placeholder="${aosEsc(aosL("Contraseña","Password"))}" style="width:130px"><button class="aos-btn sm pri" data-c="add">${aosL("Agregar usuario","Add user")}</button></div>`:`<div style="font-size:12px;color:#6b7a90">${aosL("Máximo: 4 usuarios.","Maximum: 4 users.")}</div>`}</div>`;
        const sis=B.querySelector(".aosc-sis"); B.insertBefore(box,sis?sis.nextSibling:B.firstChild);
        const q=s=>box.querySelector(s);
        q('[data-c="nom"]').onclick=async()=>{ try{ AOS._cuenta=await aosNuc("cuenta.nombre",{usuario:c.usuario,nombre:q(".a-nom").value}); aosToast(aosL("Nombre actualizado","Name updated"),"ok"); }catch(e){ aosToast(e.message,"err"); } };
        q('[data-c="clave"]').onclick=async()=>{ if(q(".a-n1").value!==q(".a-n2").value){ aosToast(aosL("Las contraseñas nuevas no coinciden","New passwords don't match"),"err"); return; } try{ await aosNuc("cuenta.cambiar",{usuario:c.usuario,actual:q(".a-act").value,nueva:q(".a-n1").value}); ["a-act","a-n1","a-n2"].forEach(k=>q("."+k).value=""); aosToast(aosL("Contraseña cambiada","Password changed"),"ok"); }catch(e){ aosToast(e.message,"err"); } };
        q('[data-c="lock"]').onclick=()=>aosApplLock();
        const admin=(c.usuarios||[]).find(u=>u.admin)||{};
        const pideAdmin=()=>prompt(aosL("Contraseña del administrador (","Administrator password (")+(admin.nombre||"")+"):");
        if(q('[data-c="add"]')) q('[data-c="add"]').onclick=async()=>{ const ac=pideAdmin(); if(ac==null) return; try{ await aosNuc("cuenta.agregar",{admin_clave:ac,nombre:q(".u-nom").value,usuario:q(".u-usu").value,clave:q(".u-cla").value}); aosToast(aosL("Usuario agregado: aparece en la pantalla de inicio","User added: shown on the sign-in screen"),"ok"); box.remove(); aoscPaint(win); }catch(e){ aosToast(e.message,"err",7000); } };
        box.querySelectorAll("[data-del]").forEach(b=>b.onclick=async()=>{ if(!confirm(aosL("¿Borrar el usuario ","Delete user ")+b.dataset.del+"?")) return; const ac=pideAdmin(); if(ac==null) return; try{ await aosNuc("cuenta.borrar",{admin_clave:ac,usuario:b.dataset.del}); aosToast(aosL("Usuario borrado","User deleted"),"ok"); box.remove(); aoscPaint(win); }catch(e){ aosToast(e.message,"err"); } });
      }
    }
    if(AOSN.state==="ok"&&!B.querySelector(".aosc-ia")){
      const box=document.createElement("div"); box.className="aosc-ia";
      box.innerHTML=`<div class="aos-h">${aosL("Inteligencia local (sin GPU)","Local intelligence (no GPU)")}</div><p class="aos-sub">${aosL("Un modelo de IA gratuito que corre en este equipo con el procesador: el asistente funciona sin internet y sin enviar datos afuera. Empezá por uno liviano.","A free AI model running on this device's CPU: the assistant works offline without sending data out. Start with a light one.")}</p><div class="aos-card aosm-oll" style="margin-bottom:12px"></div>`;
      B.appendChild(box);
      let st={}; try{ st=await aosNuc("ia.estado"); }catch(e){}
      if(!st.activo&&AOS_APPL){
        const o=box.querySelector(".aosm-oll");
        o.innerHTML=`<p class="aos-sub">${aosL("Falta el motor de IA local (Ollama, gratuito). Se instala una sola vez (≈ 100 MB, necesita internet).","The local AI engine (Ollama, free) is missing. Install it once (≈ 100 MB, needs internet).")}</p><button class="aos-btn pri a-oll">⬇ ${aosL("Instalar el motor de IA local","Install the local AI engine")}</button><span class="a-ollp" style="font-size:12px;color:#6b7a90;margin-left:8px"></span>`;
        o.querySelector(".a-oll").onclick=async ev=>{ ev.target.disabled=true; const pr=o.querySelector(".a-ollp");
          try{ const j=await aosNuc("sistema.instalar",{paquete:"ollama"});
            for(;;){ await new Promise(r=>setTimeout(r,3000)); const t=await aosNuc("sistema.trabajo",{job:j.job}); if(t.estado==="instalando"){ pr.textContent=aosL("Instalando… ","Installing… ")+t.segundos+" s"; continue; } if(t.estado==="listo"){ aosToast(aosL("Motor de IA local instalado","Local AI engine installed"),"ok"); aosmOllama(win); return; } throw new Error(t.error||"error"); }
          }catch(e){ ev.target.disabled=false; pr.textContent=""; aosToast(e.message,"err",9000); } };
      } else aosmOllama(win);
    }
  }catch(e){}
  return r;
};
/* Modelos IA en el appliance: sin la sección del navegador (WebGPU) */
const V77_aosmPaint=aosmPaint;
aosmPaint=async function(win){
  const r=await V77_aosmPaint.apply(this,arguments);
  if(AOS_APPL){ try{ const hs=[...win.body.querySelectorAll(".aosm .aos-h")]; const h=hs.find(x=>/WebGPU/.test(x.textContent)); if(h){ let n=h; const fin=hs[hs.indexOf(h)+1]; while(n&&n!==fin){ const nx=n.nextElementSibling; n.style.display="none"; n=nx; } } }catch(e){} }
  return r;
};

/* ---------- v7.7 · modelos: catálogo ampliado de Ollama, «Mis modelos» por API (usar / quitar) ---------- */
AOS_OLLAMA_REC.push(["mistral:7b","≈4,1 GB",aosL("Clásico, muy versátil","Classic, versatile")],["deepseek-r1:1.5b","≈1,1 GB",aosL("Razona paso a paso","Step-by-step reasoning")],["gemma3:1b","≈800 MB",aosL("Google, muy liviano","Google, very light")],["smollm2:1.7b","≈1,8 GB",aosL("Pequeño y rápido","Small and fast")],["granite3.3:2b","≈1,5 GB",aosL("IBM, buen seguimiento de instrucciones","IBM, good instruction following")]);
const V77b_aosmPaint=aosmPaint;
aosmPaint=async function(win){
  const r=await V77b_aosmPaint.apply(this,arguments);
  try{
    win.body.querySelectorAll("[data-usar]").forEach(a=>a.onclick=ev=>{ ev.preventDefault(); v60LSset("atlas_os_motor",a.dataset.usar); aosToast(aosL("El asistente usa ahora ","The assistant now uses ")+aosPkLabel(a.dataset.usar),"ok"); aosPaintStatus(); aosmPaint(win); });
    win.body.querySelectorAll("[data-quitar]").forEach(a=>a.onclick=ev=>{ ev.preventDefault(); const pk=a.dataset.quitar; if(!confirm(aosL("¿Quitar la clave de ","Remove the key of ")+aosPkLabel(pk)+aosL(" de este equipo?"," from this device?"))) return; try{ if(cfg[pk]){ cfg[pk].key=""; cfg[pk].enabled=false; } save(); try{ renderMenu(); }catch(e){} }catch(e){} if(aosMotor()===pk) v60LSset("atlas_os_motor","auto"); aosmPaint(win); aosPaintStatus(); });
  }catch(e){}
  return r;
};
const V77b_aosmOllama=aosmOllama;
aosmOllama=async function(win){
  const r=await V77b_aosmOllama.apply(this,arguments);
  try{ const box=win.body.querySelector(".aosm-oll"); if(box&&!box.querySelector(".aosm-cat")&&box.querySelector(".aosm-on")){ const a=document.createElement("div"); a.className="aosm-cat"; a.style.cssText="font-size:12px;color:#6b7a90;margin-top:6px";
    a.innerHTML=aosL("Cualquier modelo gratuito de Ollama se puede bajar escribiendo su nombre arriba. ","Any free Ollama model can be downloaded by typing its name above. ")+`<a href="#">${aosL("Ver el catálogo completo","See the full catalog")}</a>`;
    a.querySelector("a").onclick=ev=>{ ev.preventDefault(); aosLaunch("navegador",{url:"https://ollama.com/library",nuevo:true}); }; box.insertBefore(a,box.querySelector(".aosm-prog")); } }catch(e){}
  return r;
};

/* ---------- v7.7 · Configuración → Pantalla (resolución y escala) ---------- */
const V77b_aoscPaint=aoscPaint;
aoscPaint=async function(win){
  const r=await V77b_aoscPaint.apply(this,arguments);
  try{
    const B=win.body.querySelector(".aosc"); if(!AOS_APPL||AOSN.state!=="ok"||!B||B.querySelector(".aosc-pan")) return r;
    let p={salidas:[]}; try{ p=await aosNuc("sistema.pantalla",{accion:"listar"}); }catch(e){}
    const o=(p.salidas||[]).find(x=>x.activa)||(p.salidas||[])[0];
    const box=document.createElement("div"); box.className="aosc-pan";
    const modos=o?[...new Map(o.modos.map(m=>[m.modo,m])).values()]:[];
    const act=o&&(o.modos.find(m=>m.actual)||{}).modo;
    box.innerHTML=`<div class="aos-h">${aosL("Pantalla","Display")}</div><div class="aos-card" style="margin-bottom:12px;display:grid;gap:8px">
      ${o?`<div style="font-size:12.5px;color:#6b7a90">${aosL("Pantalla: ","Output: ")}<b style="color:#0d2b5e">${aosEsc(o.nombre)}</b> · ${aosL("actual: ","current: ")}${aosEsc(act||"?")}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><select class="aos-in p-modo" style="min-width:200px">${modos.map(m=>`<option value="${m.modo}" ${m.modo===act?"selected":""}>${m.modo}${m.preferido?" ★":""}</option>`).join("")}</select>
      <select class="aos-in p-esc">${["0.8","1","1.25","1.5","1.75","2"].map(e=>`<option value="${e}" ${String(o.escala||1)===e?"selected":""}>${aosL("Escala ","Scale ")}${Math.round(+e*100)}%</option>`).join("")}</select>
      <button class="aos-btn pri sm p-apl">${aosL("Aplicar","Apply")}</button></div>
      <div style="font-size:12px;color:#6b7a90">${aosL("En VirtualBox: elegí la resolución acá; la ventana de la máquina se ajusta con Ver → Ajustar tamaño de ventana. Se recuerda en cada arranque.","In VirtualBox: pick the resolution here; adjust the VM window with View → Adjust Window Size. It's remembered at each start.")}</div>`
      :`<div class="aos-sub">${aosL("No se pudo leer la pantalla.","Couldn't read the display.")}</div>`}</div>`;
    const cta=B.querySelector(".aosc-cta"), sis=B.querySelector(".aosc-sis"); B.insertBefore(box,(cta||sis)?((cta||sis).nextSibling):B.firstChild);
    const ap=box.querySelector(".p-apl"); if(ap) ap.onclick=async()=>{ try{ await aosNuc("sistema.pantalla",{accion:"aplicar",modo:box.querySelector(".p-modo").value,escala:box.querySelector(".p-esc").value}); aosToast(aosL("Pantalla actualizada","Display updated"),"ok"); }catch(e){ aosToast(e.message,"err"); } };
  }catch(e){}
  return r;
};

/* ---------- v7.7 · Instalar software (Flathub y paquetes .deb) ---------- */
const AOS_TIENDA=[["com.visualstudio.code","Visual Studio Code","Programación"],["org.mozilla.firefox","Firefox","Navegador"],["org.gimp.GIMP","GIMP","Imágenes"],["org.videolan.VLC","VLC","Video y música"],["org.inkscape.Inkscape","Inkscape","Diseño vectorial"],["org.audacityteam.Audacity","Audacity","Audio"],["org.mozilla.Thunderbird","Thunderbird","Correo"],["us.zoom.Zoom","Zoom","Videollamadas"],["org.wireshark.Wireshark","Wireshark","Redes"],["org.telegram.desktop","Telegram","Mensajería"],["com.obsproject.Studio","OBS Studio","Grabación"],["org.kde.krita","Krita","Dibujo"],["org.geogebra.GeoGebra","GeoGebra","Matemática"],["org.kicad.KiCad","KiCad","Electrónica"],["com.spotify.Client","Spotify","Música"]];
aosRegister("tienda",{title:()=>aosL("Instalar software","Install software"),sub:()=>aosL("VS Code, GIMP, VLC, Wireshark, Packet Tracer…","VS Code, GIMP, VLC, Wireshark, Packet Tracer…"),icon:"apps",desk:AOS_APPL,order:38,w:900,h:620,
  kw:"instalar software tienda aplicaciones flatpak vscode packet tracer deb",
  render(win){ win.body.innerHTML=`<div class="aos-pad aost"></div>`; aostPaint(win); }, reopen(win){ aostPaint(win); }
});
async function aostPaint(win){
  const B=win.body.querySelector(".aost"); if(!B) return;
  if(!AOS_APPL){ B.innerHTML=`<div class="aos-empty">${aosL("Disponible en AR.T.L.A.S. OS instalado como sistema (ISO o Raspberry Pi).","Available in AR.T.L.A.S. OS installed as a system (ISO or Raspberry Pi).")}</div>`; return; }
  let inst=new Set(); try{ inst=new Set((await aosNuc("sistema.software",{})).flatpak); }catch(e){}
  let debs=[]; try{ const h=await aosNuc("fs.raices",{}); const d=h.find(x=>/Descargas|Downloads/.test(x.ruta)); if(d){ const r=await aosNuc("fs.buscar",{patron:"*.deb",ruta:d.ruta,max:20}); debs=(r.resultados||[]).filter(x=>x.tipo!=="dir"); } }catch(e){}
  B.innerHTML=`<p class="aos-sub" style="margin-top:0">${aosL("Programas gratuitos de Flathub, listos para instalar. Se abren desde Aplicaciones y cada ventana tiene su botón de cerrar.","Free apps from Flathub, ready to install. Open them from Applications; each window has its own close button.")}</p>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:8px;margin-bottom:16px">${AOS_TIENDA.map(([id,n,c])=>`<div class="aos-card" style="padding:10px 12px;display:flex;align-items:center;gap:10px"><div style="flex:1;min-width:0"><b style="color:#0d2b5e">${aosEsc(n)}</b><div style="font-size:11.5px;color:#8a97ab">${aosEsc(c)}</div></div>${inst.has(id)?`<span class="aos-pill ok">${aosL("Instalado","Installed")}</span><button class="aos-btn sm" data-des="${id}" title="${aosEsc(aosL("Desinstalar","Uninstall"))}">✕</button>`:`<button class="aos-btn sm pri" data-ins="${id}">${aosL("Instalar","Install")}</button>`}</div>`).join("")}</div>
    <div class="aos-h">Cisco Packet Tracer ${aosL("y otros paquetes .deb","and other .deb packages")}</div>
    <p class="aos-sub">${aosL("Packet Tracer se descarga con tu cuenta de Cisco Networking Academy (netacad.com): bajá el instalador para Linux (.deb) a la carpeta Descargas y después instalalo desde acá.","Packet Tracer is downloaded with your Cisco Networking Academy account (netacad.com): get the Linux installer (.deb) into Downloads and then install it here.")}</p>
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px"><button class="aos-btn sm" data-net="1">${aosL("Abrir netacad.com","Open netacad.com")}</button><button class="aos-btn sm" data-rec="1">${aosL("Buscar de nuevo en Descargas","Search Downloads again")}</button></div>
    ${debs.length?debs.map((d,i)=>`<div class="aos-card" style="padding:8px 12px;display:flex;align-items:center;gap:10px;margin-bottom:6px"><span style="flex:1">${aosEsc(d.nombre)}</span><button class="aos-btn sm pri" data-deb="${i}">${aosL("Instalar","Install")}</button></div>`).join(""):`<div style="font-size:12px;color:#8a97ab">${aosL("No hay paquetes .deb en Descargas.","No .deb packages in Downloads.")}</div>`}
    <div class="aost-p" style="font-size:12px;color:#6b7a90;margin-top:10px"></div>`;
  const pr=B.querySelector(".aost-p");
  const trabajo=async(args,nombre)=>{ B.querySelectorAll("button").forEach(b=>b.disabled=true);
    try{ const j=await aosNuc("sistema.instalar",args); for(;;){ await new Promise(r=>setTimeout(r,3000)); const t=await aosNuc("sistema.trabajo",{job:j.job}); if(t.estado==="instalando"){ pr.textContent=aosL("Instalando ","Installing ")+nombre+"… "+Math.floor(t.segundos/60)+":"+String(t.segundos%60).padStart(2,"0"); continue; } if(t.estado==="listo"){ aosToast(nombre+aosL(" instalado: abrilo desde Aplicaciones"," installed: open it from Applications"),"ok",7000); AOS._appIco={}; break; } throw new Error(t.error||"error"); } }
    catch(e){ aosToast(e.message,"err",9000); } aostPaint(win); };
  B.querySelectorAll("[data-ins]").forEach(b=>b.onclick=()=>trabajo({flatpak:b.dataset.ins},(AOS_TIENDA.find(x=>x[0]===b.dataset.ins)||[])[1]));
  B.querySelectorAll("[data-deb]").forEach(b=>b.onclick=()=>{ const d=debs[+b.dataset.deb]; trabajo({deb:d.ruta},d.nombre); });
  B.querySelectorAll("[data-des]").forEach(b=>b.onclick=async()=>{ const n=(AOS_TIENDA.find(x=>x[0]===b.dataset.des)||[])[1]; if(!confirm(aosL("¿Desinstalar ","Uninstall ")+n+"?")) return; B.querySelectorAll("button").forEach(x=>x.disabled=true); try{ await aosNuc("sistema.desinstalar",{flatpak:b.dataset.des}); aosToast(n+aosL(" desinstalado"," uninstalled"),"ok"); }catch(e){ aosToast(e.message,"err"); } aostPaint(win); });
  const net=B.querySelector("[data-net]"); if(net) net.onclick=()=>aosnExternal("https://www.netacad.com/");
  const rec=B.querySelector("[data-rec]"); if(rec) rec.onclick=()=>aostPaint(win);
}

/* ---------- v7.8 · motor de IA local propio (llama.cpp), modelos pagos y WebLLM sin GPU ---------- */
async function aosIaMotor(){ if(AOS._iaMotor) return AOS._iaMotor; try{ AOS._iaMotor=(await aosNuc("ia.catalogo",{})).motor; }catch(e){ AOS._iaMotor="ollama"; } return AOS._iaMotor; }
const V78_aosmOllama=aosmOllama;
aosmOllama=async function(win){
  const r=await V78_aosmOllama.apply(this,arguments);
  try{ if(await aosIaMotor()!=="artlas") return r; const box=win.body.querySelector(".aosm-oll"); if(!box) return r;
    const tw=document.createTreeWalker(box,NodeFilter.SHOW_TEXT); let n; while((n=tw.nextNode())) if(/Ollama/.test(n.nodeValue)) n.nodeValue=n.nodeValue.replace(/Ollama(\s*\(gratuito\))?/g,"AR.T.L.A.S. IA local");
    const cat=box.querySelector(".aosm-cat"); if(cat){ cat.innerHTML=aosL("Modelos gratuitos en formato GGUF (los mismos de AR.T.L.A.S. RAG). También podés escribir un repositorio GGUF de Hugging Face (usuario/repositorio). ","Free GGUF models (the same as AR.T.L.A.S. RAG). You can also type a Hugging Face GGUF repository (user/repo). ")+`<a href="#">${aosL("Ver modelos GGUF","Browse GGUF models")}</a>`; cat.querySelector("a").onclick=ev=>{ ev.preventDefault(); aosLaunch("navegador",{url:"https://huggingface.co/models?library=gguf&sort=trending",nuevo:true}); }; }
  }catch(e){}
  return r;
};
const V78_aoscPaint=aoscPaint;
aoscPaint=async function(win){
  const r=await V78_aoscPaint.apply(this,arguments);
  try{ const ia=win.body.querySelector(".aosc-ia"); if(ia&&!ia.querySelector(".aosc-pago")){ const d=document.createElement("div"); d.className="aosc-pago"; d.style.cssText="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:-4px 0 12px;font-size:12.5px;color:#33445c";
    d.innerHTML=`<span>${aosL("¿Más potencia? Modelos pagos por API: OpenAI, Claude, Gemini, Groq, DeepSeek…","More power? Paid API models: OpenAI, Claude, Gemini, Groq, DeepSeek…")}</span><button class="aos-btn sm">${aosL("Configurar modelos pagos","Set up paid models")}</button>`;
    d.querySelector("button").onclick=()=>aosLaunch("modelos"); ia.appendChild(d); } }catch(e){}
  return r;
};
/* WebLLM necesita WebGPU: sin GPU, «ARTLAS Local» usa el motor local del núcleo con un modelo equivalente */
async function aosSinGpu(){ try{ if(!navigator.gpu) return true; const a=await navigator.gpu.requestAdapter(); return !a; }catch(e){ return true; } }
function aosWebllmEquiv(id){ id=String(id||"").toLowerCase(); if(/qwen2\.5-0\.5b/.test(id)) return "qwen2.5:0.5b"; if(/qwen2\.5-1\.5b/.test(id)) return "qwen2.5:1.5b"; if(/qwen2\.5-3b/.test(id)) return "qwen2.5:3b"; if(/llama-3\.2-1b/.test(id)) return "llama3.2:1b"; if(/llama-3\.2-3b/.test(id)) return "llama3.2:3b"; if(/phi-3\.5|phi-4/.test(id)) return "phi4-mini"; return "qwen2.5:0.5b"; }
if(typeof webllmLoad==="function"){
  const V78_webllmLoad=webllmLoad;
  webllmLoad=async function(){
    if(!(await aosSinGpu())) return V78_webllmLoad.apply(this,arguments);
    if(!aosNucOk()){ aosToast(aosL("Este equipo no tiene GPU compatible con WebGPU. Conectá el núcleo local para usar el motor de IA local por procesador (sin GPU).","No WebGPU-capable GPU. Connect the local core to use the CPU AI engine."),"warn",9000); return; }
    let sel=""; try{ sel=(document.querySelector("#webllm-model")||{}).value||(cfg.webllm&&cfg.webllm.model)||""; }catch(e){}
    const m=aosWebllmEquiv(sel);
    try{
      const st=await aosNuc("ia.estado",{});
      if(!(st.modelos||[]).some(x=>x.nombre===m)){
        aosToast(aosL("Sin GPU: descargo ","No GPU: downloading ")+m+aosL(" para el motor local por procesador…"," for the CPU engine…"),"",8000);
        const {job}=await aosNuc("ia.descargar",{modelo:m});
        for(;;){ await new Promise(r=>setTimeout(r,2000)); const j=await aosNuc("ia.progreso",{job}); if(j.estado==="listo") break; if(j.estado==="error") throw new Error(j.error); }
      }
      cfg.ollama=Object.assign({},cfg.ollama,{url:aosNucUrl()+"/ollama/"+aosNucToken(),model:m,enabled:true}); save();
      try{ renderMenu(); }catch(e){}
      aosToast(aosL("Listo: «ARTLAS Local» funciona con ","Ready: «ARTLAS Local» runs with ")+m+aosL(" en el procesador (sin GPU)."," on the CPU (no GPU)."),"ok",8000);
    }catch(e){ aosToast(e.message||String(e),"err",9000); }
  };
}

/* ---------- v7.8 · páginas web y ventanas emergentes con su X para cerrar ----------
   En el kiosco, una ventana que abre la propia interfaz (window.open o enlaces que salen del sitio) ocupaba toda
   la pantalla sin barra ni X. Ahora se abren en el Chromium aparte del sistema (pestañas, barra y X). */
if(AOS_APPL){
  const V78_open=window.open.bind(window);
  window.open=function(u,n,f){ try{ const url=new URL(String(u||""),location.href); if(/^https?:$/.test(url.protocol)&&url.origin!==location.origin){ aosnExternal(url.href); return null; } }catch(e){} return V78_open(u,n,f); };
  document.addEventListener("click",ev=>{
    const a=ev.target&&ev.target.closest&&ev.target.closest("a[href]"); if(!a) return;
    const h=a.getAttribute("href")||""; if(!/^https?:/i.test(h)) return;
    let u; try{ u=new URL(h,location.href); }catch(e){ return; } if(u.origin===location.origin) return;
    if(a.closest(".aosn-read,.aosn-res")) return;   // el Navegador interno maneja sus enlaces
    ev.preventDefault(); ev.stopPropagation(); aosnExternal(u.href);
  },true);
  // el AI Navigator Hub abre en el Chromium aparte, así sus enlaces quedan en pestañas con X
  if(AOS.apps.hub){ const H=AOS.apps.hub; H.render=function(win){ win.body.innerHTML=`<div class="aos-empty" style="padding:30px;text-align:center">${aosL("AI Navigator Hub se abrió en Chromium, con sus pestañas y la X para cerrar.","AI Navigator Hub opened in Chromium, with tabs and an X to close.")}<div style="margin-top:12px"><button class="aos-btn pri">${aosL("Abrir de nuevo","Open again")}</button></div></div>`; win.body.querySelector("button").onclick=()=>aosnExternal(AOS_HUB_URL); aosnExternal(AOS_HUB_URL); }; }
}
const V78_aosExitClick=aosExitClick;
aosExitClick=function(ev){
  V78_aosExitClick.apply(this,arguments);
  const m=document.querySelector(".aos-pwr"); if(!m||!AOS_APPL) return;
  const b=document.createElement("button"); b.className="aos-row"; b.style.padding="9px 12px"; b.textContent="✕ "+aosL("Cerrar ventanas abiertas (Chromium, LibreOffice)","Close open windows (Chromium, LibreOffice)");
  b.onclick=async()=>{ m.remove(); try{ await aosNuc("sistema.cerrar_ventanas",{}); aosToast(aosL("Ventanas cerradas","Windows closed"),"ok"); }catch(e){ aosToast(e.message,"err"); } };
  m.insertBefore(b,m.querySelector('[data-p="reiniciar"]'));
};

/* ---------- v7.8.1 · modo liviano sin aceleración gráfica (máquinas virtuales) ----------
   Con dibujado por software, los desenfoques (backdrop-filter), sombras con filtro y animaciones hacen
   todo muy lento. El kiosco agrega «sw=1» a la URL cuando no hay GPU, y entonces se desactivan. */
if(/[?&]sw=1\b/.test(location.search)||v60LS("atlas_os_liviano","")==="1"){
  try{ document.documentElement.classList.add("aos-sw"); const st=document.createElement("style"); st.textContent=`.aos-sw *,.aos-sw *::before,.aos-sw *::after{backdrop-filter:none!important;-webkit-backdrop-filter:none!important;transition:none!important;animation:none!important;scroll-behavior:auto!important}
    .aos-sw #aos-hero img,.aos-sw .aos-dicon .ib,.aos-sw #aos-top .brand .lg,.aos-sw .aos-ic img{filter:none!important}
    .aos-sw .aos-win{box-shadow:0 2px 10px rgba(0,0,0,.35)!important} .aos-sw #aos-desk::after{display:none!important}
    .aos-sw #aos-top,.aos-sw #aos-bar{background:#04173d!important}`; document.head.appendChild(st); }catch(e){}
}
