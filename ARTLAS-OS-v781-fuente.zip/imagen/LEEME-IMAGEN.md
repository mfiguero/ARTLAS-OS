# AR.T.L.A.S. OS · Imágenes del sistema (ISO y Raspberry Pi)

AR.T.L.A.S. OS como sistema propio: la PC, la máquina virtual o la Raspberry Pi arrancan directo en la interfaz de AR.T.L.A.S. OS, sin escritorio de Linux de por medio. Debajo hay un Debian 13 mínimo. Arriba hay un kiosco Wayland (`cage`) con Chromium, el núcleo local como servicio, Ollama para los modelos de IA locales y AR.T.L.A.S. RAG.

| Imagen | Para | Archivo |
|---|---|---|
| ISO amd64 | VirtualBox, VMware, Hyper-V, QEMU, PC o mini-PC, USB booteable | `ARTLAS-OS-<versión>-amd64.iso` |
| Raspberry Pi arm64 | Raspberry Pi 4, 5, 400, CM4 y CM5 | `ARTLAS-OS-<versión>-raspberrypi-arm64.img.xz` |

## Qué trae

- **AR.T.L.A.S. OS** con todas sus apps:
  - Asistente, Archivos, Aplicaciones, Terminal, Monitor y Configuración;
  - **Navegador**, **AI Navigator Hub** y **Modelos IA** (descargar un LLM para que funcione sin internet);
  - **AR.T.L.A.S. RAG** y **AR.T.L.A.S. Escritorio** (la plataforma completa).
- **Oficina, con LibreOffice a pedido:** el ícono está y, la primera vez, ofrece «Instalar LibreOffice» (unos 400 MB, con internet). Mientras tanto se crean .docx y .xlsx en el navegador.
- **Configuración → Sistema:** Wi-Fi, volumen, zona horaria, reiniciar y apagar. La esquina superior derecha abre el menú de energía.
- **Primer arranque:** un asistente crea **tu cuenta** (nombre, usuario y contraseña) y pide aceptar la licencia. Después, en cada arranque, aparece la **pantalla de bloqueo** con tu nombre: solo escribís la contraseña. El usuario interno de Linux es `artlas` (contraseña de sistema `artlas`).
- **Configuración:** Cuenta, Pantalla (resolución y escala), Sistema (Wi-Fi, volumen, zona horaria) e **Inteligencia local (sin GPU)**, para instalar el motor gratuito y bajar modelos de Ollama.
- **Instalar software:** VS Code, GIMP, VLC, Wireshark y más (Flathub), y paquetes .deb como Cisco Packet Tracer.

## Construir

### Opción A: GitHub Actions (recomendada; no necesita Linux)

1. Subí la fuente al repositorio. El workflow `.github/workflows/imagenes.yml` ya está incluido.
2. En GitHub, andá a **Actions → «Imágenes AR.T.L.A.S. OS» → Run workflow** y elegí `ambas`, `iso` o `raspberry`.
3. Al terminar, descargá los artefactos `ARTLAS-OS-iso-amd64` y `ARTLAS-OS-raspberrypi-arm64`.
   - La ISO tarda unos 40 a 60 minutos.
   - La Raspberry tarda de 1,5 a 3 horas, porque se emula arm64.

Si pi-gen falla con `trixie`, volvé a lanzar el workflow con `rama_pigen = master`.

### Opción B: en una PC con Linux (Debian, Ubuntu o WSL2 con Docker)

```bash
node build.mjs                    # compila la app, el núcleo y RAG en dist/
sudo imagen/iso/construir.sh      # ISO; en Debian 13 usa live-build directo y, si no, Docker
sudo imagen/rpi/construir.sh      # Raspberry Pi; usa pi-gen con Docker y necesita qemu-user-static en x86
```

Los resultados quedan en `imagen/salida/`, junto con sus `.sha256`. Hacen falta de 25 a 40 GB libres.

## Probar en una máquina virtual (VirtualBox)

1. Creá una máquina nueva, tipo Linux / Debian (64-bit), con **4 GB de RAM o más**, 2 CPU o más y un disco de **25 GB**.
2. En Pantalla, activá la aceleración 3D (o elegí el controlador VMSVGA) y asigná 128 MB de video.
3. Elegí la ISO y arrancá. En el menú:
   - **Live** prueba el sistema sin instalar.
   - **Install** lo instala en el disco virtual. El particionado se confirma a mano.
4. Arranca en AR.T.L.A.S. OS. Aceptá la licencia, elegí cuenta o invitado y listo. El núcleo ya está conectado: no pide código.

## Grabar la Raspberry Pi

1. Abrí **Raspberry Pi Imager** → «Elegir SO» → **Usar personalizado** → el `.img.xz`.
2. Grabalo en una microSD o SSD de 32 GB o más.
3. Arrancá la Pi con monitor, teclado y mouse. La primera vez el sistema se expande y reinicia solo.
4. En Configuración → Sistema conectá el Wi-Fi.

Para modelos locales, conviene la Pi 5 con 8 GB: Qwen2.5 1.5B da unos 8 a 10 tokens por segundo. En la Pi 4 conviene usar modelos por API.

## Cómo está armado

```
UEFI/BIOS → GRUB (ISO) o firmware de la Pi → Linux 6.x → systemd
  ├─ artlas-primer-arranque.service   usuario, carpetas y config del núcleo (modo appliance); idempotente
  ├─ ollama.service                   modelos de IA locales (127.0.0.1:11434)
  ├─ artlas-nucleo.service            núcleo: sirve la app en 127.0.0.1:8770/app y da acceso al sistema
  └─ getty@tty1 (ingreso automático de artlas) → artlas-kiosco → cage → Chromium (modo kiosco)
```

| Pieza | Ubicación |
|---|---|
| Archivos comunes | `imagen/comun/` (`raiz/` se copia tal cual a la raíz; `instalar-artlas.sh` corre dentro de la imagen) |
| ISO | `imagen/iso/` (live-build: `auto/config`, listas de paquetes, hook y respuestas del instalador) |
| Raspberry Pi | `imagen/rpi/` (pi-gen: `config` y la etapa `stage-artlas`) |
| Seguridad | El usuario `artlas` solo puede ejecutar como root `/usr/local/sbin/artlas-sistema`, con lista cerrada de subcomandos y argumentos validados. El token del núcleo solo se entrega a la app servida por el propio núcleo (mismo origen). |
| Licencias de terceros | La imagen incluye software libre (GPL, LGPL, MPL, Apache, MIT). Al distribuirla hay que ofrecer las fuentes de los componentes GPL. Debian y pi-gen conservan los avisos en `/usr/share/doc/*/copyright`. La capa de AR.T.L.A.S. sigue siendo propietaria (Licencia AR.T.L.A.S.). |
