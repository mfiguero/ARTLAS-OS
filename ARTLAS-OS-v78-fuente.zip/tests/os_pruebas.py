"""
AR.T.L.A.S. OS · pruebas del núcleo local, la IA local y el asistente del sistema.
Se llama desde tests/suite.py (S = módulo de la suite, con suite/ck/new_ctx/new_page/ev/guest).
· Levanta el núcleo real (src/nucleo/artlas-nucleo.mjs) con una carpeta temporal como única raíz.
· Simula Ollama (modelo local) con un servidor propio: no descarga modelos ni usa internet.
"""
import json, os, re, subprocess, tempfile, threading, time, urllib.request, urllib.error
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ---------------- Ollama simulado ----------------
OLL = {"script": [], "calls": []}
class FakeOllama(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _j(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path.startswith("/api/version"): return self._j(200, {"version": "0.9.9-sim"})
        if self.path.startswith("/api/tags"): return self._j(200, {"models": [{"name": "qwen2.5:1.5b", "size": 986000000, "details": {"family": "qwen2", "parameter_size": "1.5B", "quantization_level": "Q4_K_M"}}]})
        if self.path.startswith("/api/ps"): return self._j(200, {"models": []})
        self._j(404, {"error": "no"})
    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0); body = json.loads(self.rfile.read(n) or b"{}")
        if self.path.startswith("/api/chat"):
            OLL["calls"].append(body)
            txt = OLL["script"].pop(0) if OLL["script"] else "Listo."
            return self._j(200, {"model": body.get("model"), "message": {"role": "assistant", "content": txt}, "done": True})
        self._j(404, {"error": "no"})
    def do_DELETE(self): self._j(200, {})

def start_ollama():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), FakeOllama); threading.Thread(target=srv.serve_forever, daemon=True).start()
    return f"http://127.0.0.1:{srv.server_address[1]}"

# ---------------- sitio web de prueba ----------------
class FakeWeb(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        if self.path == "/r": self.send_response(302); self.send_header("Location", "/fspl"); self.end_headers(); return
        if self.path == "/otra": b = "<html><head><title>Otra</title></head><body><main><h1>Segunda página</h1><p>Texto de la segunda página del sitio de prueba, con suficiente contenido para la vista de lectura.</p></main></body></html>"
        else: b = "<html><head><title>Radioenlaces &amp; FSPL</title><script>alert(1)</script></head><body><nav>menú</nav><main><h1>Pérdida en espacio libre</h1><p>La <b>FSPL</b> a 12 km y 5,8 GHz es de 129,3 dB según el sitio de prueba. Ver <a href=\"/otra\">otra página</a>.</p><ul><li>uno</li><li>dos</li></ul></main><footer>pie</footer></body></html>"
        b = b.encode(); self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
def start_web():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), FakeWeb); threading.Thread(target=srv.serve_forever, daemon=True).start()
    return f"http://127.0.0.1:{srv.server_address[1]}"

# ---------------- núcleo real ----------------
class Nucleo:
    def __init__(self, oll, extra=None):
        self.dir = tempfile.mkdtemp(prefix="nuc-"); self.root = tempfile.mkdtemp(prefix="raiz-"); self.out = []
        os.makedirs(os.path.join(self.root, "Cátedras"), exist_ok=True)
        for n, t in [("notas.txt", "Teleinformática II — notas"), ("enlace.csv", "d_km,f_ghz\n12,5.8\n"), ("programa.pdf", "%PDF-1.4 sim")]:
            open(os.path.join(self.root, "Cátedras", n), "w", encoding="utf-8").write(t)
        json.dump(dict({"raices": [self.root], "ollama": oll, "web_red_local": True}, **(extra or {})), open(os.path.join(self.dir, "config.json"), "w"))
        import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); self.port = s.getsockname()[1]; s.close()
        self.url = f"http://127.0.0.1:{self.port}"
        self.home = tempfile.mkdtemp(prefix="home-")
        env = dict(os.environ, ARTLAS_NUCLEO_DIR=self.dir, HOME=self.home)
        self.p = subprocess.Popen(["node", os.path.join(R, "src", "nucleo", "artlas-nucleo.mjs"), "--puerto", str(self.port)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env)
        threading.Thread(target=lambda: [self.out.append(l) for l in self.p.stdout], daemon=True).start()
        for _ in range(100):
            if self.code(): break
            time.sleep(0.1)
    def code(self):
        c = re.findall(r"emparejamiento: (\d{6})", "".join(self.out)); return c[-1] if c else None
    def req(self, path, body=None, tok=None, origin="http://127.0.0.1:1", host=None, method=None):
        h = {"Content-Type": "application/json"}
        if origin: h["Origin"] = origin
        if tok: h["Authorization"] = "Bearer " + tok
        if host: h["Host"] = host
        rq = urllib.request.Request(self.url + path, data=json.dumps(body).encode() if body is not None else None, headers=h, method=method or ("POST" if body is not None else "GET"))
        try:
            with urllib.request.urlopen(rq, timeout=20) as r: return r.status, json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            try: return e.code, json.loads(e.read() or b"{}")
            except Exception: return e.code, {}
    def rpc(self, tok, op, **args): return self.req("/rpc", {"op": op, "args": args}, tok)[1]
    def stop(self):
        try: self.p.terminate(); self.p.wait(5)
        except Exception: pass


async def run(S, b, FS):
    oll = start_ollama(); N = Nucleo(oll); WEB = start_web()
    try:
        # ======================= núcleo: seguridad y operaciones =======================
        s = S.suite("AR.T.L.A.S. OS · Núcleo local")
        st, j = N.req("/estado")
        S.ck(s, "el núcleo arranca y responde /estado (sin emparejar)", st == 200 and j.get("ok") and j.get("emparejado") is False, str(j)[:120])
        S.ck(s, "muestra un código de emparejamiento de 6 dígitos en su consola", bool(N.code()))
        S.ck(s, "sin token: las operaciones se rechazan (401)", N.req("/rpc", {"op": "fs.raices"})[0] == 401)
        S.ck(s, "origen ajeno (otro sitio web): rechazado (403)", N.req("/estado", origin="https://sitio-malicioso.com")[0] == 403)
        S.ck(s, "sitios oficiales nuevos (artlas-ucasal, artlas-os y sus vistas previas) pueden hablar con el núcleo", all(N.req("/estado", origin=o)[0] == 200 for o in ["https://artlas-ucasal.netlify.app", "https://artlas-os.netlify.app", "https://main--artlas-os.netlify.app", "https://artlas.ar"]) and N.req("/estado", origin="https://artlas-ucasal.netlify.app.copia.com")[0] == 403)
        S.ck(s, "Host distinto de 127.0.0.1 (DNS rebinding): rechazado (403)", N.req("/estado", host="atacante.com")[0] == 403)
        S.ck(s, "código incorrecto: no empareja", N.req("/emparejar", {"codigo": "000000"})[0] == 401)
        st, j = N.req("/emparejar", {"codigo": N.code(), "nombre": "pruebas"}); tok = j.get("token")
        S.ck(s, "código correcto: devuelve un token", st == 200 and bool(tok))
        S.ck(s, "el código se renueva después de usarse", N.req("/emparejar", {"codigo": "x"})[0] in (401, 410))
        r = N.rpc(tok, "fs.raices")
        S.ck(s, "fs.raices: solo la carpeta permitida", r.get("ok") and len(r["r"]) == 1 and r["r"][0]["ruta"] == N.root, str(r)[:160])
        r = N.rpc(tok, "fs.listar", ruta=os.path.join(N.root, "Cátedras"))
        S.ck(s, "fs.listar con acentos en la ruta", r.get("ok") and sorted(e["nombre"] for e in r["r"]["entradas"]) == ["enlace.csv", "notas.txt", "programa.pdf"], str(r)[:200])
        r = N.rpc(tok, "fs.leer", ruta=os.path.join(N.root, "Cátedras", "notas.txt"))
        S.ck(s, "fs.leer devuelve el texto en UTF-8", r.get("ok") and "Teleinformática" in r["r"]["texto"])
        r1 = N.rpc(tok, "fs.leer", ruta="/etc/hostname"); r2 = N.rpc(tok, "fs.listar", ruta=os.path.join(N.root, "..", ".."))
        S.ck(s, "fuera de las carpetas permitidas (ruta absoluta y ../..): bloqueado", not r1.get("ok") and not r2.get("ok") and "permitidas" in (r1.get("error", "") + r2.get("error", "")))
        lnk = os.path.join(N.root, "atajo"); os.symlink("/etc", lnk)
        r = N.rpc(tok, "fs.listar", ruta=lnk)
        S.ck(s, "un enlace simbólico que apunta afuera: bloqueado", not r.get("ok"))
        os.remove(lnk)
        f = os.path.join(N.root, "Cátedras", "plan.md")
        r1 = N.rpc(tok, "fs.escribir", ruta=f, texto="v1"); r2 = N.rpc(tok, "fs.escribir", ruta=f, texto="v2")
        r3 = N.rpc(tok, "fs.escribir", ruta=f, texto="v3", sobrescribir=True)
        S.ck(s, "escribir: no pisa sin permiso; al sobrescribir guarda copia en la papelera", r1.get("ok") and not r2.get("ok") and r3.get("ok") and r3["r"]["respaldo"] and open(f).read() == "v3")
        r = N.rpc(tok, "fs.papelera", ruta=os.path.join(N.root, "Cátedras", "programa.pdf"))
        pap = N.rpc(tok, "fs.verPapelera")["r"]; it = [x for x in pap if x["nombre"] == "programa.pdf"]
        rr = N.rpc(tok, "fs.restaurar", id=it[0]["id"]) if it else {}
        S.ck(s, "borrar = papelera del núcleo, y se restaura", r.get("ok") and bool(it) and rr.get("ok") and os.path.exists(os.path.join(N.root, "Cátedras", "programa.pdf")))
        S.ck(s, "no se puede borrar una carpeta raíz", not N.rpc(tok, "fs.papelera", ruta=N.root).get("ok"))
        r = N.rpc(tok, "fs.buscar", patron="*.csv")
        S.ck(s, "fs.buscar con comodines", r.get("ok") and any(x["nombre"] == "enlace.csv" for x in r["r"]["resultados"]))
        r = N.rpc(tok, "sys.info")
        S.ck(s, "sys.info: equipo, CPU, memoria y discos", r.get("ok") and r["r"]["nucleos"] >= 1 and r["r"]["memoria"]["total"] > 0 and r["r"]["discos"])
        r = N.rpc(tok, "proc.listar")
        S.ck(s, "proc.listar: procesos del equipo", r.get("ok") and any(p["pid"] == N.p.pid for p in r["r"]))
        S.ck(s, "proc.cerrar: no cierra el propio núcleo ni PIDs del sistema", not N.rpc(tok, "proc.cerrar", pid=N.p.pid).get("ok") and not N.rpc(tok, "proc.cerrar", pid=1).get("ok"))
        r = N.rpc(tok, "shell.ejecutar", cmd="hostname")
        S.ck(s, "terminal: comando de la lista blanca (hostname)", r.get("ok") and r["r"]["code"] == 0 and r["r"]["salida"].strip())
        bad = {"rm -rf /tmp/x": "lista blanca", "python -c print(1)": "lista blanca", "node -e 1": "lista blanca", "curl -o /tmp/x http://a.b": "lista blanca",
               "git log --output=/tmp/x": "no permitida", "ip route add 1.2.3.0/24 dev lo": "consultar"}
        res = {c: N.rpc(tok, "shell.ejecutar", cmd=c) for c in bad}
        S.ck(s, "terminal: bloquea ejecutar código, escribir archivos y cambiar la red", all(not v.get("ok") and bad[c] in v.get("error", "") for c, v in res.items()), str({c: v.get("error", "OK")[:40] for c, v in res.items()}))
        S.ck(s, "terminal libre desactivada aunque se confirme", not N.rpc(tok, "shell.ejecutar", cmd="echo hola", confirmado=True).get("ok"))
        reg = N.rpc(tok, "registro.ver", n=50)["r"]
        S.ck(s, "registro de actividad (jsonl) con las acciones y los rechazos", any(x["op"] == "fs.escribir" and x["ok"] for x in reg) and any(x["op"] == "shell.ejecutar" and not x["ok"] for x in reg))
        lo = N.rpc(tok, "office.estado")["r"]
        HAS_LO = bool(lo.get("disponible"))
        S.ck(s, "office.estado: detecta LibreOffice en la PC" if HAS_LO else "office.estado: sin LibreOffice lo informa (pruebas con LibreOffice omitidas)", (lo.get("suite") == "LibreOffice") if HAS_LO else lo.get("disponible") is False, str(lo))
        if lo.get("disponible"):
            h = "<html><head><meta charset='utf-8'></head><body><h1>Informe de enlace</h1><p>Pérdida: <b>129,3 dB</b></p><table><tr><th>d</th><th>f</th></tr><tr><td>12 km</td><td>5,8 GHz</td></tr></table></body></html>"
            rs = [N.rpc(tok, "office.crear", ruta=os.path.join(N.root, "Informe." + x), contenido=h, origen="html") for x in ("docx", "odt", "pdf")]
            dx = os.path.join(N.root, "Informe.docx")
            import zipfile as _z
            okd = all(x.get("ok") for x in rs) and "Pérdida" in _z.ZipFile(dx).read("word/document.xml").decode("utf-8")
            S.ck(s, "office.crear: Word, ODT y PDF desde el contenido (con tildes y tablas)", okd, str([x.get("error", "ok")[:60] for x in rs]))
            r = N.rpc(tok, "office.crear", ruta=os.path.join(N.root, "Notas.xlsx"), contenido="Alumno,P1,P2,Prom\nPérez,7,9,=AVERAGE(B2:C2)\nGómez,6.5,8,=AVERAGE(B3:C3)\n")
            sx = _z.ZipFile(os.path.join(N.root, "Notas.xlsx")).read("xl/worksheets/sheet1.xml").decode() if r.get("ok") else ""
            S.ck(s, "office.crear: Excel desde CSV con fórmulas evaluadas y punto decimal", "<f" in sx and "AVERAGE(B3:C3)" in sx and "<v>7.25</v>" in sx, r.get("error", "")[:120])
            r = N.rpc(tok, "office.convertir", ruta=dx, formato="pdf", destino=os.path.join(N.root, "Informe-conv.pdf"))
            S.ck(s, "office.convertir: Word → PDF", r.get("ok") and open(os.path.join(N.root, "Informe-conv.pdf"), "rb").read(5) == b"%PDF-")
            r = N.rpc(tok, "office.convertir", ruta=os.path.join(N.root, "Notas.xlsx"), formato="csv")
            S.ck(s, "office.convertir: Excel → CSV (UTF-8)", r.get("ok") and "Pérez" in open(os.path.join(N.root, "Notas.csv"), encoding="utf-8").read())
            S.ck(s, "office.convertir: no pisa un archivo existente sin permiso", not N.rpc(tok, "office.convertir", ruta=dx, formato="pdf", destino=os.path.join(N.root, "Informe-conv.pdf")).get("ok"))
            S.ck(s, "office: fuera de las carpetas permitidas, bloqueado", not N.rpc(tok, "office.crear", ruta="/tmp/fuera.docx", contenido="x").get("ok") and not N.rpc(tok, "office.convertir", ruta="/etc/hostname", formato="pdf").get("ok"))
            S.ck(s, "office: presentaciones no se generan (se abren o convierten)", "presentaciones" in N.rpc(tok, "office.crear", ruta=os.path.join(N.root, "x.pptx"), contenido="x").get("error", ""))
        r = N.rpc(tok, "web.leer", url=WEB + "/r")
        S.ck(s, "web.leer: sigue redirecciones y devuelve la página limpia (título, texto, enlaces absolutos; sin scripts ni menú)", r.get("ok") and r["r"]["titulo"] == "Radioenlaces & FSPL" and "# Pérdida en espacio libre" in r["r"]["texto"] and "[otra página](" + WEB + "/otra)" in r["r"]["texto"] and "alert" not in r["r"]["texto"] and "menú" not in r["r"]["texto"], str(r)[:220])
        S.ck(s, "web.leer: solo http/https", not N.rpc(tok, "web.leer", url="file:///etc/passwd").get("ok"))
        N2 = Nucleo(oll, {"web_red_local": False})
        try:
            t2 = N2.req("/emparejar", {"codigo": N2.code()})[1]["token"]; r2 = N2.rpc(t2, "web.leer", url=WEB + "/fspl"); r3 = N2.rpc(t2, "web.abrir", url="http://192.168.0.1/")
        finally: N2.stop()
        S.ck(s, "web: por defecto no lee ni abre direcciones de la red local (127.x, 192.168.x)", not r2.get("ok") and "red local" in r2.get("error", "") and not r3.get("ok"), str(r2)[:120])
        L = N.rpc(tok, "app.listar")["r"]
        ic = N.rpc(tok, "app.iconos", ids=[a["id"] for a in L[:30]] + ["no-existe", "../../etc/passwd"])
        okic = ic.get("ok") and set(ic["r"]["iconos"]) <= {a["id"] for a in L} and (not any(a.get("icono") for a in L) or any(v.startswith("data:image/") for v in ic["r"]["iconos"].values()))
        S.ck(s, "app.iconos: devuelve los íconos de las apps instaladas (solo de la lista, no rutas arbitrarias)", okic, str({k: (v or "")[:24] for k, v in list(ic.get("r", {}).get("iconos", {}).items())[:4]}))
        oi = N.rpc(tok, "office.iconos")
        S.ck(s, "office.iconos: íconos de Writer, Calc e Impress" + ("" if HAS_LO else " (sin LibreOffice: vacío)"), oi.get("ok") and ((set(oi["r"]["iconos"]) == {"writer", "calc", "impress"} and all(v.startswith("data:image/") for v in oi["r"]["iconos"].values())) if HAS_LO else oi["r"]["iconos"] == {}), str(oi)[:160])
        S.ck(s, "carpetas multimedia (Imágenes, Música, Videos) se suman una vez a la configuración", json.load(open(os.path.join(N.dir, "config.json"))).get("raices_v") == 2)
        ne = N.rpc(tok, "nucleo.estado")
        S.ck(s, "nucleo.estado: informa protocolo artlas-nucleo://, inicio automático y plataforma", ne.get("ok") and "protocolo" in ne["r"] and ne["r"]["autoinicio"] is False and ne["r"]["script"].endswith("artlas-nucleo.mjs"), str(ne)[:160])
        r1 = N.rpc(tok, "nucleo.autoinicio", activar=True); f_auto = os.path.join(N.home, ".config", "autostart", "artlas-nucleo.desktop")
        ok1 = r1.get("ok") and r1["r"]["autoinicio"] and os.path.isfile(f_auto) and "artlas-nucleo.mjs" in open(f_auto).read()
        r2 = N.rpc(tok, "nucleo.autoinicio", activar=False)
        S.ck(s, "nucleo.autoinicio: activa y desactiva el inicio con la sesión del sistema", ok1 and r2.get("ok") and not r2["r"]["autoinicio"] and not os.path.exists(f_auto))
        S.ck(s, "registro del protocolo (Linux: .desktop con x-scheme-handler/artlas-nucleo)", os.path.isfile(os.path.join(N.home, ".local", "share", "applications", "artlas-nucleo.desktop")) and "x-scheme-handler/artlas-nucleo" in open(os.path.join(N.home, ".local", "share", "applications", "artlas-nucleo.desktop")).read())
        r = N.rpc(tok, "ia.estado")
        S.ck(s, "ia.estado: detecta Ollama y sus modelos", r.get("ok") and r["r"]["activo"] and r["r"]["modelos"][0]["nombre"] == "qwen2.5:1.5b")
        st, _ = N.req(f"/ollama/{tok}/api/tags"); st2, _ = N.req("/ollama/token-falso/api/tags")
        S.ck(s, "puente a Ollama: solo con token válido", st == 200 and st2 == 401)

        # ======================= OS en el navegador =======================
        s = S.suite("AR.T.L.A.S. OS · Escritorio, archivos, IA local y asistente")
        ctx = await S.new_ctx(b)
        await ctx.add_init_script("try{localStorage.setItem('atlas_os_nuc_url', %s)}catch(e){}" % json.dumps(N.url))
        pg = await S.new_page(ctx, FS + "app.html?os=1"); await S.guest(pg); await pg.wait_for_timeout(1500)
        S.ck(s, "app.html?os=1 abre el escritorio después del ingreso", await S.ev(pg, "AOS.on&&!!$('aos-desk')"))
        apps = await S.ev(pg, "Object.keys(AOS.apps)")
        S.ck(s, "apps registradas: asistente, archivos, editor, aplicaciones, terminal, monitor, modelos, configuración", all(a in apps for a in ["asistente", "archivos", "editor", "apps", "terminal", "monitor", "modelos", "config", "clasico"]), str(apps))
        await pg.wait_for_function("!!window.ARTLAS_OS_IMG", timeout=15000)
        await S.ev(pg, "aosIcons();aosArt();0")
        S.ck(s, "tema v6.9.1: imágenes de las apps en app-recursos.js (una por app del escritorio, más logo y portada)", await S.ev(pg, "Object.values(AOS.apps).filter(a=>a.desk).every(a=>ARTLAS_OS_IMG[a.id])&&!!ARTLAS_OS_IMG.logo&&!!ARTLAS_OS_IMG.hero"))
        S.ck(s, "tema v6.9.1: el escritorio usa los íconos ilustrados y AR.T.L.A.S. el logo propio", await S.ev(pg, "document.querySelectorAll('#aos-icons img.ib').length===Object.values(AOS.apps).filter(a=>a.desk).length&&document.querySelector('.aos-dicon.main img').src===ARTLAS_OS_IMG.asistente"))
        S.ck(s, "tema v6.9.1: portada con logo, «AR.T.L.A.S. OS» y lema; logo en la barra y en «Salir»", await S.ev(pg, "!document.querySelector('#aos-hero img').hidden&&$('aos-hero').innerText.includes('INTELIGENCIA')&&[...document.querySelectorAll('#aos-top .aos-logo')].every(i=>!i.hidden&&i.naturalWidth>0)"))
        S.ck(s, "tema v6.9.1: columnas como el diseño (AR.T.L.A.S., Archivos, Aplicaciones, Oficina | Terminal…)", await S.ev(pg, "(()=>{const b=[...document.querySelectorAll('#aos-icons .aos-dicon')].map(e=>e.getBoundingClientRect());return b[0].left===b[3].left&&b[4].left>b[0].left&&b[4].top===b[0].top})()"))
        S.ck(s, "el núcleo aparece como «sin emparejar»", await S.ev(pg, "AOSN.state") == "pair")
        await S.ev(pg, "aosNucPair(%s).then(()=>window.__p=1).catch(e=>window.__p=e.message)" % json.dumps(N.code()))
        await pg.wait_for_function("window.__p!==undefined", timeout=10000)
        S.ck(s, "emparejar con el código desde la app", await S.ev(pg, "window.__p===1&&AOSN.state==='ok'"), str(await S.ev(pg, "window.__p")))
        await S.ev(pg, "aosLaunch('config');0"); await pg.wait_for_timeout(800)
        S.ck(s, "Configuración con el núcleo conectado: sigue el botón para descargar o actualizar el núcleo", await S.ev(pg, "!!AOS.wins.find(w=>w.app==='config').body.querySelector('[data-k=dl]')"))
        await pg.wait_for_timeout(4500)
        L0 = N.rpc(tok, "app.listar")["r"]
        S.ck(s, "v7.1: los íconos de las apps se precargan en segundo plano al conectar el núcleo", (not L0) or await S.ev(pg, "AOS._icoPre===true&&Object.keys(AOS._appIco).length>0"))
        src = await S.ev(pg, "AOSFS.sources().then(x=>x.map(y=>y.uri))")
        S.ck(s, "Archivos: la carpeta de la PC aparece como fuente pc:", any(u == "pc:" + N.root for u in src), str(src))
        L = await S.ev(pg, "AOSFS.list(%s).then(r=>r.entries.map(e=>e.nombre))" % json.dumps("pc:" + os.path.join(N.root, "Cátedras")))
        S.ck(s, "Archivos: lista una carpeta real del disco", "notas.txt" in L and "enlace.csv" in L, str(L))
        await S.ev(pg, "AOSFS.write('opfs:/pruebas/hola.txt','hola OS').then(()=>AOSFS.readText('opfs:/pruebas/hola.txt')).then(t=>window.__o=(t&&t.texto!=null)?t.texto:t)")
        await pg.wait_for_function("window.__o!==undefined")
        S.ck(s, "Unidad AR.T.L.A.S. del navegador (OPFS): escribir y leer", await S.ev(pg, "window.__o") == "hola OS")
        await S.ev(pg, "aosLaunch('archivos',{uri:%s})" % json.dumps("pc:" + N.root)); await pg.wait_for_timeout(900)
        S.ck(s, "ventana Archivos con la carpeta abierta", await S.ev(pg, "!!AOS.wins.find(w=>w.app==='archivos')&&document.body.innerText.includes('Cátedras')"))
        await S.ev(pg, "aosLaunch('modelos')"); await pg.wait_for_timeout(1500)
        S.ck(s, "Modelos IA: muestra Ollama del núcleo con su modelo instalado", await S.ev(pg, "AOS.wins.find(w=>w.app==='modelos').body.querySelector('.aosm-oll').innerText.includes('qwen2.5:1.5b')"))
        await S.ev(pg, "AOS.wins.find(w=>w.app==='modelos').body.querySelector(\".aosm-oll [data-ou='qwen2.5:1.5b']\").click();0"); await pg.wait_for_timeout(500)
        S.ck(s, "«Usar»: el asistente pasa a «Local primero» con Ollama a través del núcleo (sin CORS)", await S.ev(pg, "aosMotor()==='local'&&aosLocalPk()==='ollama'&&cfg.ollama.url.startsWith(aosNucUrl()+'/ollama/')"))
        S.ck(s, "el modelo local se suma al router de la plataforma (Simultáneo / Consenso)", await S.ev(pg, "connectedProviders().includes('ollama')"))
        S.ck(s, "estrategia «Local primero» (métrica privacidad) en el Router", await S.ev(pg, "!!V60_STRATS.local&&V60_STRATS.local.metric==='privacidad'"))
        S.ck(s, "métrica privacidad: el router elige el modelo local", await S.ev(pg, "MODELS[v60PickFor('general','privacidad')].prov==='ollama'"))
        S.ck(s, "sin internet: el router pasa solo al modelo local", await S.ev(pg, "(()=>{const d=Object.getOwnPropertyDescriptor(Navigator.prototype,'onLine');Object.defineProperty(navigator,'onLine',{configurable:true,get:()=>false});const r=MODELS[smartPick('hola')].prov;Object.defineProperty(navigator,'onLine',d);delete navigator.onLine;return r})()==='ollama'"))

        # --- asistente con el modelo local: mirar, proponer, aprobar, ejecutar ---
        cat = os.path.join(N.root, "Cátedras")
        OLL["script"] = [
            '```tool:os\n{"op":"fs.listar","ruta":%s}\n```' % json.dumps("pc:" + cat),
            'Propongo ordenar.\n```tool:os\n[{"op":"fs.crearCarpeta","ruta":%s},{"op":"fs.mover","de":%s,"a":%s},{"op":"fs.borrar","ruta":%s}]\n```' % (
                json.dumps("pc:" + os.path.join(cat, "Datos")), json.dumps("pc:" + os.path.join(cat, "enlace.csv")), json.dumps("pc:" + os.path.join(cat, "Datos")), json.dumps("pc:" + os.path.join(cat, "notas.txt"))),
            "Listo: creé **Datos** y moví el CSV. No borré las notas."]
        OLL["calls"].clear()
        await S.ev(pg, "aosLaunch('asistente')"); await pg.wait_for_timeout(500)
        await S.ev(pg, "aosAgentAsk(AOS.wins.find(w=>w.app==='asistente'),'Ordená la carpeta Cátedras');0")
        await pg.wait_for_selector("button[data-k=ok]:not([disabled])", timeout=20000)
        S.ck(s, "el asistente leyó primero (fs.listar se ejecuta solo, sin pedir permiso)", len(OLL["calls"]) == 2 and "notas.txt" in json.dumps(OLL["calls"][1]["messages"][-1], ensure_ascii=False))
        S.ck(s, "el modelo local recibe las instrucciones del sistema (versión breve para modelos chicos)", "AR.T.L.A.S. OS" in OLL["calls"][0]["messages"][0]["content"] and "breve" in OLL["calls"][0]["messages"][0]["content"])
        S.ck(s, "el plan que modifica pide aprobación (3 acciones) y todavía no tocó el disco", await S.ev(pg, "document.querySelectorAll('.aosa-m input[data-i]').length") == 3 and not os.path.exists(os.path.join(cat, "Datos")))
        await S.ev(pg, "document.querySelector('input[data-i=\"2\"]').click()")   # destildar el borrado
        await pg.click("button[data-k=ok]")
        await pg.wait_for_function("!AOS.wins.find(w=>w.app==='asistente').state.busy", timeout=20000)
        S.ck(s, "aprobado: creó la carpeta y movió el archivo en el disco real", os.path.isfile(os.path.join(cat, "Datos", "enlace.csv")) and not os.path.exists(os.path.join(cat, "enlace.csv")))
        S.ck(s, "la acción destildada no se ejecutó (notas.txt sigue)", os.path.exists(os.path.join(cat, "notas.txt")) and "CANCELADO" in json.dumps(OLL["calls"][-1]["messages"][-1], ensure_ascii=False))
        txt = await S.ev(pg, "document.querySelector('.aosa-m').innerText")
        S.ck(s, "respuesta final con los pasos del agente", "No borré las notas" in txt)
        # --- oficina ---
        S.ck(s, "Oficina: app registrada y en el escritorio", await S.ev(pg, "!!AOS.apps.oficina&&AOS.apps.oficina.desk"))
        await S.ev(pg, "aosLaunch('oficina')"); await pg.wait_for_timeout(1200)
        if HAS_LO: S.ck(s, "Oficina: muestra LibreOffice listo", await S.ev(pg, "AOS.wins.find(w=>w.app==='oficina').body.innerText.includes('LibreOffice')&&aosOfLO(AOSOF.st)"))
        dst = "pc:" + os.path.join(N.root, "Cátedras", "Plan de estudio.docx")
        if HAS_LO:
          r = await S.ev(pg, "aosOfCreate(%s,'# Plan de estudio\\n\\n## Semana 1\\n- Modelo OSI\\n- **TCP/IP**\\n\\n| Tema | Horas |\\n|---|---|\\n| Fibra | 4 |').then(r=>r.via).catch(e=>'ERR '+e.message)" % json.dumps(dst))
          import zipfile as _z
          dxml = _z.ZipFile(os.path.join(N.root, "Cátedras", "Plan de estudio.docx")).read("word/document.xml").decode("utf-8") if r == "LibreOffice" else ""
          S.ck(s, "crear un Word desde Markdown con LibreOffice (títulos, lista y tabla)", "Semana 1" in dxml and "TCP/IP" in dxml and "<w:tbl" in dxml, str(r))
        r = await S.ev(pg, "aosOfCreate('opfs:/pruebas/plan.docx','# Título\\n\\nTexto con **negrita**\\n\\n| a | b |\\n|---|---|\\n| 1 | 2 |').then(r=>AOSFS.blob(r.uri)).then(b=>b.arrayBuffer()).then(a=>JSZip.loadAsync(a)).then(z=>z.file('word/document.xml').async('string')).catch(e=>'ERR '+e.message)")
        S.ck(s, "sin LibreOffice (unidad del navegador): genera un .docx válido", "<w:b/>" in r and "<w:tbl>" in r and "Título" in r, str(r)[:120])
        r = await S.ev(pg, "aosOfCreate('opfs:/pruebas/notas.xlsx','Alumno,Nota\\nPérez,8\\nGómez,9.5').then(r=>AOSFS.blob(r.uri)).then(b=>b.arrayBuffer()).then(a=>{const wb=XLSX.read(a,{type:'array'});return XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]])}).catch(e=>'ERR '+e.message)")
        S.ck(s, "sin LibreOffice: genera un .xlsx con números de verdad (SheetJS)", isinstance(r, list) and r[1].get("Nota") == 9.5 and r[0].get("Alumno") == "Pérez", str(r)[:120])
        r = await S.ev(pg, "aosOfCreate('opfs:/pruebas/x.pdf','# x').then(()=>'ok').catch(e=>e.message)")
        S.ck(s, "sin LibreOffice: PDF/ODT explican que hace falta LibreOffice", "LibreOffice" in r, r)
        await S.ev(pg, "(()=>{const w=AOS.wins.find(w=>w.app==='archivos');w.state.sel={uri:%s,nombre:'Plan de estudio.docx',tipo:'archivo'};aosfAct(w)})()" % json.dumps(dst))
        if HAS_LO: S.ck(s, "Archivos: un .docx elegido suma «PDF», «Convertir…» y «LibreOffice»", await S.ev(pg, "(t=>t.includes('PDF')&&t.includes('Convertir')&&t.includes('LibreOffice'))(AOS.wins.find(w=>w.app==='archivos').body.querySelector('.aosf-act').innerText)"))
        OLL["script"] = ['```tool:os\n{"op":"office.crear","ruta":%s,"contenido":"Alumno,Nota\\nPérez,8\\nGómez,9.5"}\n```' % json.dumps("pc:" + os.path.join(N.root, "Cátedras", "Notas TI2.xlsx")), "Creé la planilla."]
        OLL["calls"].clear()
        await S.ev(pg, "aosLaunch('asistente');0"); await pg.wait_for_timeout(300)
        await S.ev(pg, "aosAgentAsk(AOS.wins.find(w=>w.app==='asistente'),'Armá una planilla de notas de TI2');0")
        await pg.wait_for_selector(".aosa-m button[data-k=ok]:not([disabled])", timeout=20000)
        S.ck(s, "asistente: conoce las herramientas de oficina y office.crear pide aprobación", "office.crear" in OLL["calls"][0]["messages"][0]["content"] and not os.path.exists(os.path.join(N.root, "Cátedras", "Notas TI2.xlsx")))
        await pg.click(".aosa-m button[data-k=ok]:not([disabled])")
        await pg.wait_for_function("!AOS.wins.find(w=>w.app==='asistente').state.busy", timeout=30000)
        S.ck(s, "asistente: aprobado, crea el Excel en la PC" + (" con LibreOffice" if HAS_LO else " (en el navegador)"), os.path.exists(os.path.join(N.root, "Cátedras", "Notas TI2.xlsx")))
        q = await S.ev(pg, "aosQuick('abrí una planilla')")
        S.ck(s, "atajo: «abrí una planilla» → LibreOffice Calc", q and q[0]["op"] == "office.abrir" and q[0]["app"] == "calc")

        # --- v6.9.2: abrir documentos, APIs de la plataforma, idioma ---
        r = await S.ev(pg, "aosNuc('fs.estadoCopia',{id:'../x'}).then(()=>'ok').catch(e=>e.message)")
        S.ck(s, "copias abiertas: un id con ruta (../) se rechaza", "inválida" in r, r)
        await S.ev(pg, "aosOfOpenDoc('opfs:/pruebas/plan.docx');0"); await pg.wait_for_timeout(1500)
        cid = await S.ev(pg, "Object.keys(AOSOF.copias)[0]||''")
        cdir = os.path.join(N.dir, "abiertos", cid) if cid else ""
        S.ck(s, "abrir un .docx de una carpeta del navegador: el núcleo abre una copia (con LibreOffice)", bool(cid) and os.path.isfile(os.path.join(cdir, "plan.docx")), str(cid))
        if cid:
            import zipfile as _z, io as _io, shutil as _sh
            _sh.copy(os.path.join(N.root, "Cátedras", "Plan de estudio.docx") if HAS_LO else os.path.join(cdir, "plan.docx"), os.path.join(cdir, "plan.docx"))
            os.utime(os.path.join(cdir, "plan.docx"), (time.time() + 5, time.time() + 5))
            await S.ev(pg, "aosOfSyncCopias()"); await pg.wait_for_timeout(500)
            got = await S.ev(pg, "AOSFS.blob('opfs:/pruebas/plan.docx').then(b=>b.arrayBuffer()).then(a=>JSZip.loadAsync(a)).then(z=>z.file('word/document.xml').async('string'))")
            S.ck(s, "al volver al navegador, los cambios guardados en la copia pasan al original", ("Semana 1" in got) if HAS_LO else True, got[:80])
        S.ck(s, "abrir un .docx del disco (pc:) va directo a LibreOffice, sin copia", await S.ev(pg, "(async()=>{const n=Object.keys(AOSOF.copias).length;await aosOfOpenDoc(%s);return Object.keys(AOSOF.copias).length===n})()" % json.dumps(dst)))
        await S.ev(pg, "cfg.groq=Object.assign({},cfg.groq,{key:'gsk_prueba'});aosLaunch('modelos');0"); await pg.wait_for_timeout(900)
        S.ck(s, "Modelos IA: sección «APIs de AR.T.L.A.S. Web» con las claves conectadas en la plataforma", await S.ev(pg, "(b=>b.innerText.includes('APIs de AR.T.L.A.S. Web')&&[...b.querySelectorAll('.aosm-api .aos-pill.ok')].some(p=>p.innerText.includes('Groq')))(AOS.wins.find(w=>w.app==='modelos').body)"))
        await S.ev(pg, "document.querySelector('.aosm-api [data-api=keys]').click();0"); await pg.wait_for_timeout(400)
        S.ck(s, "«Conectar o editar claves» abre el diálogo de la plataforma encima del OS", await S.ev(pg, "$('overlay').classList.contains('open')&&+getComputedStyle($('overlay')).zIndex>+getComputedStyle($('aos')).zIndex"))
        await S.ev(pg, "$('overlay').classList.remove('open');delete cfg.groq.key;0")
        await S.ev(pg, "toggleLang();0"); await pg.wait_for_timeout(300)
        en = await S.ev(pg, "[$('aos-ask-in').placeholder,document.querySelector('#aos .aos-exit .lbx').textContent,document.querySelector('#aos-hero .s').textContent]")
        await S.ev(pg, "toggleLang();0"); await pg.wait_for_timeout(300)
        es = await S.ev(pg, "[$('aos-ask-in').placeholder,document.querySelector('#aos .aos-exit .lbx').textContent]")
        S.ck(s, "idioma: la barra, «Salir» y el lema del OS cambian con el botón ES/EN", en[0].startswith("Ask") and en[1] == "Exit" and "INTELLIGENCE" in en[2] and es[0].startswith("Pedile") and es[1] == "Salir", str(en + es))
        sz = await S.ev(pg, "(()=>{const i=document.querySelector('#aos-icons img.ib').getBoundingClientRect();const d=$('aos-desk').getBoundingClientRect();const L=[...document.querySelectorAll('#aos-icons .aos-dicon')].map(e=>e.getBoundingClientRect());return [i.width,innerWidth,Math.max(...L.map(r=>r.bottom))<=d.bottom]})()")
        S.ck(s, "íconos proporcionales a la pantalla (≈4% del ancho) y las 4 filas entran en el escritorio", sz[0] <= sz[1] * 0.042 + 1 and sz[0] >= 40 and sz[2], str(sz))

        # --- v6.9.3: Navegador ---
        await S.ev(pg, "aosLaunch('navegador',{url:%s,nuevo:true});0" % json.dumps(WEB + "/fspl")); await pg.wait_for_timeout(1500)
        S.ck(s, "Navegador: abre una página en modo Lectura a través del núcleo", await S.ev(pg, "(w=>w.body.querySelector('.aosn-read').innerText.includes('129,3 dB')&&w.title.includes('Radioenlaces'))(AOS.wins.filter(w=>w.app==='navegador').pop())"))
        await S.ev(pg, "AOS.wins.filter(w=>w.app==='navegador').pop().body.querySelector('.aosn-read a[href$=\"/otra\"]').click();0"); await pg.wait_for_timeout(1200)
        S.ck(s, "Navegador: los enlaces de la página navegan dentro del OS", await S.ev(pg, "AOS.wins.filter(w=>w.app==='navegador').pop().body.innerText.includes('Segunda página')"))
        await S.ev(pg, "aosnCmd(AOS.wins.filter(w=>w.app==='navegador').pop(),'back');0"); await pg.wait_for_timeout(600)
        S.ck(s, "Navegador: «Atrás» vuelve a la página anterior", await S.ev(pg, "AOS.wins.filter(w=>w.app==='navegador').pop().body.innerText.includes('129,3 dB')"))
        await S.ev(pg, "window.v63Ddg=async q=>({items:[{title:'FSPL — calculadora',url:%s,snip:'Pérdida en espacio libre a 12 km',src:'DuckDuckGo'}]});window.v63Wiki=async q=>({items:[]});0" % json.dumps(WEB + "/fspl"))
        await S.ev(pg, "aosnGo(AOS.wins.filter(w=>w.app==='navegador').pop(),'pérdida en espacio libre');0"); await pg.wait_for_timeout(1000)
        S.ck(s, "Navegador: una búsqueda muestra los resultados de los buscadores de la plataforma", await S.ev(pg, "AOS.wins.filter(w=>w.app==='navegador').pop().body.querySelectorAll('.aosn-r').length===1"))
        S.ck(s, "Navegador: «Original» muestra la página dentro de la ventana", await S.ev(pg, "(w=>{w.state.modo='original';aosnShow(w,{tipo:'url',url:%s},true);return !!w.body.querySelector('iframe[src$=\"/fspl\"]')})(AOS.wins.filter(w=>w.app==='navegador').pop())" % json.dumps(WEB + "/fspl")))
        await S.ev(pg, "(w=>{w.state.modo='lectura';v60LSset('atlas_os_nav_modo','lectura')})(AOS.wins.filter(w=>w.app==='navegador').pop());0")
        q = await S.ev(pg, "Promise.all([aosQuick('buscá en la web radioenlaces'),aosQuick('abrí wikipedia.org')])")
        S.ck(s, "atajos: «buscá en la web …» y «abrí wikipedia.org» abren el Navegador", q[0][0]["op"] == "web.navegar" and q[0][0]["q"] == "radioenlaces" and q[1][0]["url"] == "https://wikipedia.org")
        OLL["script"] = ['```tool:os\n{"op":"web.leer","url":%s}\n```' % json.dumps(WEB + "/fspl"), "Según la página, la FSPL es de 129,3 dB."]
        OLL["calls"].clear()
        await S.ev(pg, "aosaReset(AOS.wins.find(w=>w.app==='asistente'));aosAgentAsk(AOS.wins.find(w=>w.app==='asistente'),'¿Cuánto da la FSPL según la página de prueba?');0")
        await pg.wait_for_function("!AOS.wins.find(w=>w.app==='asistente').state.busy", timeout=20000)
        S.ck(s, "asistente: web.leer se ejecuta solo y el modelo recibe el texto de la página", len(OLL["calls"]) == 2 and "129,3 dB" in json.dumps(OLL["calls"][1]["messages"][-1], ensure_ascii=False) and "web.buscar" in OLL["calls"][0]["messages"][0]["content"])
        OLL["script"] = ["No tengo información sobre el resultado del partido de ayer.", "Según la búsqueda, ganó el equipo local [1]."]
        OLL["calls"].clear()
        await S.ev(pg, "aosAgentAsk(AOS.wins.find(w=>w.app==='asistente'),'¿Quién ganó el partido de ayer?');0")
        await pg.wait_for_selector(".aosa-web [data-w=buscar]", timeout=20000)
        S.ck(s, "asistente sin el dato: ofrece «Buscar en la web y responder» y «Abrir en el Navegador»", await S.ev(pg, "document.querySelectorAll('.aosa-web button').length===2"))
        await S.ev(pg, "document.querySelector('.aosa-web [data-w=buscar]').click();0")
        await pg.wait_for_function("document.querySelector('.aosa-m').innerText.includes('ganó el equipo local')", timeout=20000)
        S.ck(s, "«Buscar en la web y responder»: busca, lee la página y el modelo responde con las fuentes", len(OLL["calls"]) == 2 and "INSTRUCCIÓN" in json.dumps(OLL["calls"][1]["messages"], ensure_ascii=False) and (WEB + "/fspl") in json.dumps(OLL["calls"][1]["messages"], ensure_ascii=False))
        await S.ev(pg, "localStorage.setItem('atlas_os_motor','solo-local');0")
        r = await S.ev(pg, "aosExec({op:'web.buscar',q:'x'},{}).then(r=>r.text)")
        S.ck(s, "modo «Solo local»: el asistente no sale a internet", "Solo local" in r, r)
        await S.ev(pg, "localStorage.setItem('atlas_os_motor','local');0")

        # --- v7.2: AR.T.L.A.S. WEB con íconos, AI Navigator Hub y resaltado en Archivos ---
        await S.ev(pg, "aosLaunch('navegador',{nuevo:true});0"); await pg.wait_for_timeout(700)
        r = await S.ev(pg, "(b=>[b.querySelectorAll('.aosn-tiles button').length,[...b.querySelectorAll('.aosn-tiles img')].filter(i=>i.src.includes('favicons')).length,!!b.querySelector('.aosn-brand img')])(AOS.wins.filter(w=>w.app==='navegador').pop().body)")
        S.ck(s, "AR.T.L.A.S. WEB: logo y accesos con el ícono oficial de cada sitio (o su inicial sin conexión)", r[0] == 6 and (r[1] == 6 or r[1] == 0) and r[2], str(r))
        await S.ev(pg, "aosLaunch('hub');0"); await pg.wait_for_timeout(500)
        S.ck(s, "AI Navigator Hub: app en el escritorio con su ícono y el hub dentro de la ventana", await S.ev(pg, "AOS.apps.hub.desk&&!!ARTLAS_OS_IMG.hub&&AOS.wins.find(w=>w.app==='hub').body.querySelector('iframe').src.startsWith('https://ainavigatorhub-v2.netlify.app')"))
        await S.ev(pg, "aosLaunch('archivos',{uri:%s,nuevo:true});0" % json.dumps("pc:" + os.path.join(N.root, "Cátedras"))); await pg.wait_for_timeout(1200)
        await S.ev(pg, "(w=>w.body.querySelector('.aosf-list tr[data-i]').click())(AOS.wins.filter(w=>w.app==='archivos').pop());0")
        await pg.wait_for_timeout(400)
        r = await S.ev(pg, "(w=>[w.body.querySelectorAll('.aosf-list tr.sel').length,getComputedStyle(w.body.querySelector('.aosf-list tr.sel td')).backgroundColor,!!w.body.querySelector('.aosf-side .aos-row.sel')])(AOS.wins.filter(w=>w.app==='archivos').pop())")
        S.ck(s, "Archivos: el elegido se resalta en color y la carpeta activa se marca en la barra lateral", r[0] == 1 and r[1] == "rgb(207, 229, 255)" and r[2], str(r))
        S.ck(s, "Archivos: al pasar el mouse la fila se resalta (regla de estilo presente)", await S.ev(pg, "[...document.styleSheets].some(ss=>{try{return [...ss.cssRules].some(r=>r.selectorText&&r.selectorText.includes('.aosf-list tr[data-i]:hover'))}catch(e){return false}})"))

        # --- v7.3: iniciar / detener el núcleo desde el OS ---
        await S.ev(pg, "aosLaunch('config');0"); await pg.wait_for_timeout(1500)
        r = await S.ev(pg, "(b=>[!!b.querySelector('[data-k=auto]'),!!b.querySelector('[data-k=stop]'),!!b.querySelector('[data-k=dl]')])(AOS.wins.find(w=>w.app==='config').body)")
        S.ck(s, "Configuración con núcleo conectado: inicio automático, «Detener el núcleo» y descarga", r == [True, True, True], str(r))
        await S.ev(pg, "window.__realNuc=localStorage.getItem('atlas_os_nuc_url');localStorage.setItem('atlas_os_nuc_url','http://127.0.0.1:9');aoscPaint(AOS.wins.find(w=>w.app==='config'));0"); await pg.wait_for_timeout(2500)
        S.ck(s, "núcleo apagado pero emparejado antes: aparece «▶ Iniciar el núcleo»", await S.ev(pg, "!!AOS.wins.find(w=>w.app==='config').body.querySelector('.aosc-start [data-k=start]')"))
        await S.ev(pg, "window.__nav=[];const _c=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){ if(this.href.startsWith('artlas-nucleo:')){window.__nav.push(this.href);localStorage.setItem('atlas_os_nuc_url',window.__realNuc);return;} return _c.call(this); };aosNucStart();0"); await pg.wait_for_timeout(3500)
        S.ck(s, "«Iniciar el núcleo» abre artlas-nucleo:// y vuelve a conectar solo", await S.ev(pg, "window.__nav[0]==='artlas-nucleo://iniciar'&&AOSN.state==='ok'"))

        # --- v7.4: Chrome bloquea cambios en carpeta conectada → se hace con el núcleo; «Mover a…» con selector ---
        fdir = os.path.join(N.root, "Facturas UCASAL"); os.makedirs(fdir, exist_ok=True)
        for n in ("DESCUENTOS.doc", "Constancia.pdf", "Viejo.doc"): open(os.path.join(fdir, n), "w").write(n)
        await S.ev(pg, """(async()=>{ const r=await navigator.storage.getDirectory(); const t=await r.getDirectoryHandle('fsatest',{create:true}); const d=await t.getDirectoryHandle('Facturas UCASAL',{create:true});
          for(const n of ['DESCUENTOS.doc','Constancia.pdf','Viejo.doc']){ const f=await d.getFileHandle(n,{create:true}); const w=await f.createWritable(); await w.write(n); await w.close(); }
          AOSF.handles['Facturas UCASAL']=d; AOSF.perm['Facturas UCASAL']='granted';
          const bl=n=>/[.]doc$/i.test(n), err=()=>new DOMException('It was determined that certain files are unsafe for access within a Web application, or that too many calls are being made on file resources.','SecurityError');
          const rm=FileSystemDirectoryHandle.prototype.removeEntry; FileSystemDirectoryHandle.prototype.removeEntry=function(n,o){ if(bl(n)) return Promise.reject(err()); return rm.call(this,n,o); };
          for(const P of [FileSystemHandle.prototype,FileSystemFileHandle.prototype]){ const mv=Object.getOwnPropertyDescriptor(P,'move'); if(mv&&mv.value){ const f=mv.value; P.move=function(...a){ if(bl(this.name)) return Promise.reject(err()); return f.apply(this,a); }; } }
          const cw=FileSystemFileHandle.prototype.createWritable; FileSystemFileHandle.prototype.createWritable=function(o){ if(bl(this.name)) return Promise.reject(err()); return cw.call(this,o); };
        })()""")
        r = await S.ev(pg, "AOSFS.remove('fsa:Facturas UCASAL/DESCUENTOS.doc').then(r=>r.via||'ok').catch(e=>'ERR '+e.message)")
        S.ck(s, "borrar un .doc que Chrome bloquea en una carpeta conectada: se hace por el núcleo (carpeta ubicada sola)", r == "núcleo" and not os.path.exists(os.path.join(fdir, "DESCUENTOS.doc")), r)
        r = await S.ev(pg, "AOSFS.rename('fsa:Facturas UCASAL/Viejo.doc','Nuevo.doc').then(r=>r.via||'ok').catch(e=>'ERR '+e.message)")
        S.ck(s, "renombrar un .doc bloqueado: también por el núcleo", r == "núcleo" and os.path.exists(os.path.join(fdir, "Nuevo.doc")) and not os.path.exists(os.path.join(fdir, "Viejo.doc")), r)
        r = await S.ev(pg, "AOSFS.remove('fsa:Facturas UCASAL/Constancia.pdf').then(r=>r.via||'ok').catch(e=>'ERR '+e.message)")
        S.ck(s, "lo que Chrome sí permite (.pdf) se sigue haciendo directo en la carpeta conectada", r == "ok" and os.path.exists(os.path.join(fdir, "Constancia.pdf")), r)
        r = await S.ev(pg, "AOSF.pcMap['Facturas UCASAL']")
        S.ck(s, "la carpeta conectada queda asociada a su ruta real del disco", r == fdir, str(r))
        await S.ev(pg, "window.__pick=aosfPickFolder(AOS.wins.filter(w=>w.app==='archivos').pop(),'Mover «x» a…','fsa:Facturas UCASAL/');0"); await pg.wait_for_timeout(900)
        r = await S.ev(pg, "(o=>[!!o,[...o.querySelectorAll('optgroup')].map(g=>g.label),o.querySelectorAll('option').length])(document.querySelector('.aosf-pick'))")
        S.ck(s, "«Mover a…»: desplegable con las carpetas del núcleo, las conectadas y las del navegador", r[0] and len(r[1]) >= 2 and r[2] >= 3 and any("conectadas" in g for g in r[1]), str(r))
        await S.ev(pg, "(o=>{const sel=o.querySelector('.aosfp-src');sel.value=sel.querySelector('option').value;sel.onchange();})(document.querySelector('.aosf-pick'));0"); await pg.wait_for_timeout(900)
        await S.ev(pg, "document.querySelector('.aosf-pick [data-d]').click();0"); await pg.wait_for_timeout(700)
        await S.ev(pg, "document.querySelector('.aosf-pick .aosfp-ok').click();0")
        r = await S.ev(pg, "window.__pick")
        S.ck(s, "«Mover a…»: se navega a una subcarpeta y se elige el destino", isinstance(r, str) and r.startswith("pc:") and r != "pc:" + N.root, str(r))

        # --- v7.6.1: ordenar columnas y barra de acciones fija ---
        await S.ev(pg, """(async()=>{ for(const [n,t] of [['Archivo 10.txt','xxxxxxxxxx'],['Archivo 2.txt','xx'],['b.txt','xxxxx']]) await AOSFS.write('opfs:/orden/'+n,t,{sobrescribir:true}); await AOSFS.mkdir('opfs:/orden/Zeta').catch(()=>{}); })()""")
        await S.ev(pg, "aosLaunch('archivos',{uri:'opfs:/orden',nuevo:true});0"); await pg.wait_for_timeout(1200)
        W = "AOS.wins.filter(w=>w.app==='archivos').pop()"
        n0 = await S.ev(pg, W + ".state.view.map(e=>e.nombre)")
        S.ck(s, "Archivos: carpetas primero y nombres en orden natural (2 antes que 10)", n0[0] == "Zeta" and n0.index("Archivo 2.txt") < n0.index("Archivo 10.txt"), str(n0))
        await S.ev(pg, W + ".body.querySelector('th[data-ord=tam]').click();0"); await pg.wait_for_timeout(300)
        n1 = await S.ev(pg, W + ".state.view.map(e=>e.nombre)")
        await S.ev(pg, W + ".body.querySelector('th[data-ord=tam]').click();0"); await pg.wait_for_timeout(300)
        n2 = await S.ev(pg, W + ".state.view.map(e=>e.nombre)")
        S.ck(s, "Archivos: ordenar por tamaño (mayor primero y, con otro clic, menor primero)", n1 == ["Zeta", "Archivo 10.txt", "b.txt", "Archivo 2.txt"] and n2 == ["Zeta", "Archivo 2.txt", "b.txt", "Archivo 10.txt"], str(n1) + str(n2))
        await S.ev(pg, W + ".body.querySelector('th[data-ord=mod]').click();0"); await pg.wait_for_timeout(300)
        S.ck(s, "Archivos: ordenar por fecha de modificación, con la flecha en la columna activa", await S.ev(pg, "(b=>b.querySelector('th.on').dataset.ord==='mod'&&/[▲▼]/.test(b.querySelector('th.on .ar').textContent))(" + W + ".body)") and await S.ev(pg, "JSON.parse(localStorage.getItem('atlas_os_orden')).k==='mod'"))
        r = await S.ev(pg, "(w=>{ const L=w.body.querySelector('.aosf-list'); const y0=L.getBoundingClientRect().top; w.body.querySelectorAll('.aosf-list tr[data-i]')[2].click(); const y1=L.getBoundingClientRect().top; return [y0,y1,w.state.sel.nombre,w.body.querySelector('.aosf-list tr.sel td').innerText.trim()]; })(" + W + ")")
        S.ck(s, "elegir un archivo no corre la lista (la barra de acciones tiene altura fija): el clic marca la fila correcta", r[0] == r[1] and r[2] == r[3], str(r))

        # --- v7.1: licencia ---
        r = await S.ev(pg, "[ARTLAS_LIC.original,ARTLAS_LIC.ver,ARTLAS_LIC.html.includes('AR.T.L.A.S. OS: núcleo local'),ARTLAS_LIC.html_en.includes('AR.T.L.A.S. OS: local core')]")
        LVN = json.load(open(os.path.join(R, "artlas.config.json")))["licencia"]["ver"]
        S.ck(s, "licencia: versión original v6.8.3 y versión nueva " + LVN + ", con la sección de AR.T.L.A.S. OS en español e inglés", r == ["v6.8.3", LVN, True, True], str(r))
        pdf = subprocess.run(["pdftotext", os.path.join(R, "dist", "fullstack", "licencia-artlas.pdf"), "-"], capture_output=True, text=True).stdout if os.path.exists("/usr/bin/pdftotext") else "v6.8.3 (original v7.1 19. AR.T.L.A.S. OS"
        S.ck(s, "licencia en PDF: «v6.8.3 (original» arriba y «" + LVN + "» abajo, más la sección 19 y los sitios oficiales", pdf.find("v6.8.3 (original") >= 0 and pdf.find(LVN) > pdf.find("v6.8.3 (original") and "AR.T.L.A.S. OS" in pdf and "artlas-ucasal.netlify.app" in pdf)

        # --- v6.9.4: íconos y renombrar ---
        await S.ev(pg, "aosLaunch('apps');0"); await pg.wait_for_timeout(2500)
        r = await S.ev(pg, "(b=>[b.querySelectorAll('.aosap-i').length,b.querySelectorAll('.aosap-ic img').length])(AOS.wins.find(w=>w.app==='apps').body)")
        S.ck(s, "Aplicaciones: cuadrícula con el ícono real de cada programa (o su inicial)", r[0] > 0 and (r[1] > 0 or not any(a.get("icono") for a in L)), str(r))
        await S.ev(pg, "aosLaunch('oficina');0"); await pg.wait_for_timeout(1200)
        r = await S.ev(pg, "(b=>[b.querySelectorAll('.aosof-tile').length,b.querySelectorAll('.aosof-tile img,.aosof-tile svg').length])(AOS.wins.find(w=>w.app==='oficina').body)")
        S.ck(s, "Oficina: Documento, Hoja de cálculo y Presentación con ícono", r == [3, 3], str(r))
        await S.ev(pg, "AOSFS.write('opfs:/pruebas/Clau y yo.png',new Blob([new Uint8Array([137,80,78,71])]),{sobrescribir:true})")
        await S.ev(pg, "(async()=>{const w=aosLaunch('archivos',{uri:'opfs:/pruebas',nuevo:true});await new Promise(r=>setTimeout(r,600));w.state.sel={uri:'opfs:/pruebas/Clau y yo.png',nombre:'Clau y yo.png',tipo:'archivo'};const P=window.prompt;window.prompt=()=>'Clau y Mario';await aosfDo(w,'ren');window.prompt=P;})()")
        await pg.wait_for_timeout(600)
        L2 = await S.ev(pg, "AOSFS.list('opfs:/pruebas').then(r=>r.entries.map(e=>e.nombre))")
        S.ck(s, "renombrar: conserva la extensión si no se escribe y no deja el original", "Clau y Mario.png" in L2 and "Clau y yo.png" not in L2, str(L2))
        r = await S.ev(pg, "aosFsErr({name:'SecurityError',message:'It was determined that certain files are unsafe for access within a Web application, or that too many calls are being made on file resources.'})")
        S.ck(s, "el error de seguridad de Chrome se explica en castellano, con la salida por el núcleo", r.startswith("Chrome no permitió") and "núcleo" in r, r)

        # privacidad: con «solo local» los archivos no salen a una API externa
        await S.ev(pg, "localStorage.setItem('atlas_os_priv','1');localStorage.setItem('atlas_os_motor','basic');0")
        r = await S.ev(pg, "aosExec({op:'fs.leer',ruta:%s},{priv:true,pk:'basic'}).then(r=>r.text)" % json.dumps("pc:" + os.path.join(cat, "notas.txt")))
        S.ck(s, "privacidad: con un modelo externo, el contenido de los archivos se retiene", "retenido" in r and "Teleinformática" not in r)
        r = await S.ev(pg, "aosExec({op:'fs.leer',ruta:%s},{priv:true,pk:'ollama'}).then(r=>r.text)" % json.dumps("pc:" + os.path.join(cat, "notas.txt")))
        S.ck(s, "privacidad: con el modelo local, sí lo lee", "Teleinformática" in r)
        await S.ev(pg, "localStorage.setItem('atlas_os_priv','0');localStorage.setItem('atlas_os_motor','local');0")
        q = await S.ev(pg, "aosQuick('ping 8.8.8.8')")
        S.ck(s, "atajos sin modelo: «ping 8.8.8.8» → terminal (pide aprobación)", q and q[0]["op"] == "shell")
        await S.ev(pg, "aosLaunch('terminal')"); await pg.wait_for_timeout(400)
        await S.ev(pg, "aostRun(AOS.wins.find(w=>w.app==='terminal'),'hostname')"); await pg.wait_for_timeout(1500)
        S.ck(s, "Terminal: ejecuta un comando de diagnóstico", await S.ev(pg, "AOS.wins.find(w=>w.app==='terminal').body.innerText.includes(%s)" % json.dumps(os.uname().nodename)))
        await S.ev(pg, "aosLaunch('monitor')"); await pg.wait_for_timeout(1800)
        S.ck(s, "Monitor del sistema: CPU, memoria y procesos", await S.ev(pg, "(t=>t.includes('CPU')&&/node/i.test(t))(AOS.wins.find(w=>w.app==='monitor').body.innerText)"))
        S.ck(s, "sin errores de JavaScript", not pg.errs, str(pg.errs[:2]))
        await ctx.close()

        # ---------- móvil y descarga del núcleo ----------
        mctx = await b.new_context(viewport={"width": 390, "height": 844}, accept_downloads=True)
        await mctx.add_init_script("window.ARTLAS_DIRECT_ONLY=true;")
        if S.LIBS: await mctx.route("https://cdnjs.cloudflare.com/**", S.r_lib)
        await mctx.route(re.compile(r"https://[^/]*supabase\.co/.*"), lambda r: r.abort())
        mp = await S.new_page(mctx, FS + "app.html?os=1"); await S.guest(mp); await mp.wait_for_timeout(1200)
        w = await S.ev(mp, "[document.documentElement.scrollWidth,$('aos-top').scrollHeight]")
        S.ck(s, "móvil: el escritorio entra en el ancho y la barra superior en una línea", w[0] <= 390 and w[1] <= 40, str(w))
        r = await S.ev(mp, "aosOfCreate('opfs:/pv/notas.xlsx','Alumno,Nota\\nPérez,8').then(()=>{aosOpenFile('opfs:/pv/notas.xlsx');return 1}).catch(e=>e.message)"); await mp.wait_for_timeout(1500)
        S.ck(s, "sin núcleo: abrir un .xlsx muestra una vista previa en el navegador", await S.ev(mp, "!!AOS.wins.find(w=>w.app==='vistadoc'&&w.body.innerText.includes('Pérez'))"), str(r))
        dmsg = []; mp.on("dialog", lambda d: dmsg.append(d.message))
        await S.ev(mp, "aosNucDownload();0"); await mp.wait_for_timeout(500)
        S.ck(s, "descargar el núcleo: invitado → pide registrarse", any("núcleo" in x and "registrados" in x for x in dmsg), str(dmsg)[:120])
        await S.ev(mp, "user={id:'u-os',email:'os@artlas.ar',user_metadata:{}};updateUserUI();0"); await mp.wait_for_timeout(300)
        try:
            async with mp.expect_download(timeout=15000) as dl:
                await S.ev(mp, "aosNucDownload();0"); await mp.wait_for_timeout(300)
                if await S.ev(mp, "!!document.getElementById('v69-modal')"):
                    await mp.click("#v69-ck2"); await mp.click("#v69-ok")
            d = await dl.value; zp = os.path.join(tempfile.mkdtemp(), "n.zip"); await d.save_as(zp)
            import zipfile as _z; names = _z.ZipFile(zp).namelist(); src = _z.ZipFile(zp).read("ARTLAS-OS-Nucleo/artlas-nucleo.mjs").decode()
        except Exception as e: names, src = [str(e)], ""
        S.ck(s, "registrado: descarga el zip del núcleo (Windows .bat, macOS/Linux .sh, LÉAME y licencia)", all(("ARTLAS-OS-Nucleo/" + f) in names for f in ["artlas-nucleo.mjs", "Iniciar-Nucleo.bat", "iniciar-nucleo.sh", "LEEME-NUCLEO.txt"]), str(names)[:200])
        S.ck(s, "el núcleo descargado trae la versión y la ofimática", "office.crear" in src and "__ARTLAS_VER__" not in src)
        sctx = await b.new_context(viewport={"width": 1361, "height": 582})
        await sctx.add_init_script("window.ARTLAS_DIRECT_ONLY=true;")
        if S.LIBS: await sctx.route("https://cdnjs.cloudflare.com/**", S.r_lib)
        await sctx.route(re.compile(r"https://[^/]*supabase\.co/.*"), lambda r: r.abort())
        sp = await S.new_page(sctx, FS + "app.html?os=1"); await S.guest(sp); await sp.wait_for_function("!!window.ARTLAS_OS_IMG", timeout=15000); await S.ev(sp, "aosIcons();0")
        r = await S.ev(sp, "(()=>{const L=[...document.querySelectorAll('#aos-icons .aos-dicon')].map(e=>e.getBoundingClientRect());const d=$('aos-desk').getBoundingClientRect();return [L[0].left===L[3].left,L[4].top===L[0].top,Math.max(...L.map(r=>r.bottom))<=d.bottom,Math.round(document.querySelector('#aos-icons img.ib').getBoundingClientRect().width)]})()")
        S.ck(s, "ventana de navegador baja (1361×582): íconos chicos en 4 filas, como el diseño", r[0] and r[1] and r[2] and r[3] <= 52, str(r))
        await sctx.close()
        S.ck(s, "el núcleo que se descarga trae la lista de sitios autorizados de la compilación (incluye artlas-ucasal y artlas-os)", await S.ev(mp, "(t=>t.includes('artlas-ucasal.netlify.app')&&t.includes('*--artlas-os.netlify.app')&&!t.includes('\"__ARTLAS_DOMINIOS__\"'))(ARTLAS_NUCLEO['artlas-nucleo.mjs'])"))
        S.ck(s, "el paquete del núcleo viaja en app-recursos.js (sirve también sin red)", await S.ev(mp, "typeof ARTLAS_NUCLEO==='object'&&'artlas-nucleo.mjs' in ARTLAS_NUCLEO&&!ARTLAS_NUCLEO['artlas-nucleo.mjs'].includes('__ARTLAS_VER__')"))
        await mctx.close()
        # ======================= v7.6: modo appliance (imagen ISO / Raspberry Pi) =======================
        s = S.suite("AR.T.L.A.S. OS · Modo appliance (sistema propio)")
        import socket as _so; _k = _so.socket(); _k.bind(("127.0.0.1", 0)); RPORT = _k.getsockname()[1]; _k.close()
        AD = os.path.join(R, "tests", "datos", "appliance"); LOGF = tempfile.mktemp(prefix="sis-")
        ragdir = tempfile.mkdtemp(prefix="rag-"); import shutil as _sh; _sh.copy(os.path.join(AD, "rag_local.py"), ragdir)
        os.environ["ARTLAS_PRUEBA_LOG"] = LOGF
        NA = Nucleo(oll, {"appliance": True, "app_dir": os.path.join(R, "dist", "web-only"), "sistema_cmd": os.path.join(AD, "artlas-sistema-prueba.sh"), "sistema_sin_sudo": True, "rag_dir": ragdir, "rag_python": "python3", "rag_puerto": RPORT, "protocolo": False})
        try:
            st, j = NA.req("/appliance/token", {}, origin="https://artlas.ar"); st2, _ = NA.req("/appliance/token", {}, origin=None)
            S.ck(s, "token automático: solo para la app servida por el mismo núcleo (otro sitio o sin origen → 403)", st == 403 and st2 == 403)
            st, j = NA.req("/app/../config.json", origin=None)
            S.ck(s, "la app servida no deja leer fuera de su carpeta", st in (403, 404))
            sp = await S.new_page(await S.new_ctx(b), NA.url + "/app/app.html?os=1&appliance=1"); await S.guest(sp)
            await sp.wait_for_function("typeof AOSN!=='undefined'&&AOSN.state==='ok'", timeout=20000)
            S.ck(s, "el núcleo sirve AR.T.L.A.S. OS en 127.0.0.1 y se conecta solo, sin código de 6 dígitos", await S.ev(sp, "AOS_APPL&&AOS.on&&!!aosNucToken()&&location.origin===aosNucUrl()"))
            S.ck(s, "«Plataforma» se presenta como AR.T.L.A.S. Escritorio; RAG, Navegador, Hub y Oficina en el escritorio", await S.ev(sp, "AOS.apps.clasico.title()==='AR.T.L.A.S. Escritorio'&&['rag','navegador','hub','oficina','modelos'].every(k=>AOS.apps[k]&&AOS.apps[k].desk)&&!!ARTLAS_OS_IMG.rag"))
            await S.ev(sp, "aosLaunch('config');0"); await sp.wait_for_selector(".aosc-sis", timeout=15000)
            S.ck(s, "Configuración → Sistema: Wi-Fi conectado, volumen y zona horaria", await S.ev(sp, "(b=>b.innerText.includes('Casa')&&b.querySelector('.aosc-vol').value==='55'&&!!b.querySelector('.aosc-zona'))(document.querySelector('.aosc-sis'))"))
            await S.ev(sp, "document.querySelector('.aosc-sis [data-s=scan]').click();0"); await sp.wait_for_selector(".aosc-ssid", timeout=10000)
            S.ck(s, "Wi-Fi: lista las redes con señal y candado", await S.ev(sp, "document.querySelector('.aosc-ssid').options.length===2&&document.querySelector('.aosc-ssid').innerText.includes('🔒')"))
            await S.ev(sp, "aosNuc('sistema.volumen',{valor:30}).then(()=>aosNuc('sistema.zona',{zona:'America/Argentina/Tucuman'}))")
            r = await S.ev(sp, "aosNuc('sistema.zona',{zona:'x; rm -rf /'}).then(()=>'ok').catch(e=>e.message)")
            log = open(LOGF).read()
            S.ck(s, "volumen y zona pasan por el ayudante con argumentos validados (se rechaza una zona inválida)", "volumen 30" in log and "zona America/Argentina/Tucuman" in log and "inválida" in r, r)
            await S.ev(sp, "aosExitClick();0"); await sp.wait_for_timeout(300)
            S.ck(s, "la esquina superior abre el menú de energía (Escritorio, Reiniciar, Apagar)", await S.ev(sp, "document.querySelectorAll('.aos-pwr [data-p]').length===3"))
            await S.ev(sp, "document.querySelector('.aos-pwr [data-p=apagar]').click();0"); await sp.wait_for_timeout(1500)
            S.ck(s, "«Apagar» llama al ayudante del sistema (con confirmación)", "apagar" in open(LOGF).read())
            await S.ev(sp, "aosLaunch('oficina');0"); await sp.wait_for_timeout(1200)
            await S.ev(sp, "AOSOF.st={nucleo:true,disponible:false};AOSOF.t=Date.now();aosOfPaint(AOS.wins.find(w=>w.app==='oficina'));0"); await sp.wait_for_timeout(700)
            S.ck(s, "Oficina sin LibreOffice: botón «Instalar LibreOffice»", await S.ev(sp, "!!document.querySelector('.aosof-inst')"))
            jj = await S.ev(sp, "aosNuc('sistema.instalar',{paquete:'libreoffice'})"); await sp.wait_for_timeout(2500)
            t = await S.ev(sp, "aosNuc('sistema.trabajo',{job:%s})" % json.dumps(jj["job"]))
            r = await S.ev(sp, "aosNuc('sistema.instalar',{paquete:'firefox'}).then(()=>'ok').catch(e=>e.message)")
            S.ck(s, "instalar LibreOffice es un trabajo en segundo plano; otros paquetes no se aceptan", t["estado"] == "listo" and "instalar libreoffice" in open(LOGF).read() and "no disponible" in r, str(t) + r)
            await S.ev(sp, "aosLaunch('rag');0"); await sp.wait_for_selector(".aosrag [data-r=ini]", timeout=10000)
            await S.ev(sp, "document.querySelector('.aosrag [data-r=ini]').click();0")
            await sp.wait_for_function("!!AOS.wins.find(w=>w.app==='rag').body.querySelector('iframe')", timeout=30000)
            S.ck(s, "AR.T.L.A.S. RAG: el núcleo lo inicia y se abre dentro del OS", await S.ev(sp, "AOS.wins.find(w=>w.app==='rag').body.querySelector('iframe').src.includes(':%d')" % RPORT))
            S.ck(s, "sin errores de JavaScript en el modo appliance", not sp.errs, str(sp.errs[:2]))
            # --- v7.7: cuenta local (primer arranque y pantalla de bloqueo) ---
            gp = await S.new_page(await S.new_ctx(b), NA.url + "/app/app.html?os=1&appliance=1")
            await gp.wait_for_selector("#aos-gate .card", timeout=15000)
            S.ck(s, "primer arranque: en lugar del ingreso por mail aparece el asistente de AR.T.L.A.S. OS", await S.ev(gp, "!v61GateVisible()&&document.querySelector('#aos-gate').innerText.includes('Bienvenido')"))
            await gp.click("#aos-gate [data-n='1']")
            await gp.fill("#aos-gate .f-nom", "Mario Figueroa"); await gp.wait_for_timeout(300)
            await S.ev(gp, "(()=>{const g=document.querySelector('#aos-gate');g.querySelector('.f-c1').value='clave1';g.querySelector('.f-c2').value='clave1';g.querySelector('.f-pis').value='la de siempre';})()")
            usu = await S.ev(gp, "document.querySelector('#aos-gate .f-usu').value")
            await gp.click("#aos-gate [data-n='2']")
            try: await gp.wait_for_selector("#aos-gate .f-lic", timeout=8000)
            except Exception: print("    (asistente: " + str(await S.ev(gp, "[document.querySelector('#aos-gate .err')&&document.querySelector('#aos-gate .err').textContent, document.querySelector('#aos-gate .f-usu')&&document.querySelector('#aos-gate .f-usu').value]")) + ")"); raise
            await gp.click("#aos-gate [data-n='3']"); err1 = await S.ev(gp, "document.querySelector('#aos-gate .err').textContent")
            await gp.check("#aos-gate .f-lic"); await gp.click("#aos-gate [data-n='3']"); await gp.wait_for_selector("#aos-gate [data-n='fin']", timeout=10000)
            cfgA = json.load(open(os.path.join(NA.dir, "config.json")))
            S.ck(s, "asistente: usuario sugerido del nombre, licencia obligatoria y cuenta creada con la contraseña cifrada", usu == "mario" and "licencia" in err1 and cfgA["cuentas"][0]["usuario"] == "mario" and "clave1" not in json.dumps(cfgA) and len(cfgA["cuentas"][0]["hash"]) == 64 and cfgA["cuentas"][0]["licencia"]["ver"], usu + " | " + err1)
            await gp.click("#aos-gate [data-n='fin']"); await gp.wait_for_function("typeof AOSN!=='undefined'&&AOSN.state==='ok'&&AOS.on", timeout=20000)
            S.ck(s, "al terminar entra directo a AR.T.L.A.S. OS con el núcleo conectado", await S.ev(gp, "getComputedStyle($('aos-gate')).display==='none'"))
            await gp.reload(); await gp.wait_for_selector("#aos-gate .pw input", timeout=15000)
            S.ck(s, "en cada arranque: pantalla de bloqueo con el nombre, el reloj y la contraseña (sin token guardado)", await S.ev(gp, "document.querySelector('#aos-gate .quien').textContent==='Mario Figueroa'&&!!document.querySelector('#aos-gate .reloj').textContent&&!aosNucToken()"))
            await gp.fill("#aos-gate .pw input", "mala"); await gp.click("#aos-gate .pw button"); await gp.wait_for_timeout(500)
            S.ck(s, "contraseña incorrecta: avisa y muestra la pista", await S.ev(gp, "document.querySelector('#aos-gate .err').textContent.includes('incorrecta')&&document.querySelector('#aos-gate .pista').textContent.includes('la de siempre')"))
            for _ in range(5): NA.req("/appliance/token", {"clave": "x"}, origin=NA.url)
            st429, _j = NA.req("/appliance/token", {"clave": "clave1"}, origin=NA.url)
            S.ck(s, "5 intentos fallidos: espera de 30 segundos (incluso con la contraseña correcta)", st429 == 429, str(st429))
            NA.stop(); NA.p = subprocess.Popen(["node", os.path.join(R, "src", "nucleo", "artlas-nucleo.mjs"), "--puerto", str(NA.port)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=dict(os.environ, ARTLAS_NUCLEO_DIR=NA.dir, HOME=NA.home))
            for _ in range(50):
                try:
                    if NA.req("/estado", origin=None)[0] == 200: break
                except Exception: pass
                time.sleep(0.2)
            await gp.fill("#aos-gate .pw input", "clave1"); await gp.click("#aos-gate .pw button")
            await gp.wait_for_function("getComputedStyle($('aos-gate')).display==='none'&&!!aosNucToken()", timeout=15000)
            S.ck(s, "contraseña correcta: desbloquea y recibe el token", True)
            await gp.wait_for_function("AOSN.state==='ok'", timeout=15000)
            r = await S.ev(gp, "aosNuc('cuenta.cambiar',{actual:'clave1',nueva:'nueva22'}).then(()=>aosApplPost('token',{clave:'nueva22'})).then(x=>!!x.token).catch(e=>e.message)")
            S.ck(s, "Configuración → Cuenta: cambiar la contraseña (pide la actual)", r is True, str(r))
            await S.ev(gp, "aosExitClick();0"); await gp.wait_for_timeout(300)
            S.ck(s, "menú de energía: muestra la sesión y «Bloquear»", await S.ev(gp, "document.querySelector('.aos-pwr').innerText.includes('Mario Figueroa')&&document.querySelector('.aos-pwr').innerText.includes('Bloquear')"))
            await S.ev(gp, "[...document.querySelectorAll('.aos-pwr .aos-row')].find(b=>b.textContent.includes('Bloquear')).click();0"); await gp.wait_for_selector("#aos-gate .pw input", timeout=10000)
            S.ck(s, "«Bloquear» vuelve a la pantalla de bloqueo y quita el token", await S.ev(gp, "!aosNucToken()"))
            await S.ev(gp, "aosApplPost('token',{clave:'nueva22'}).then(x=>{v60LSset('atlas_os_nuc_tok',x.token);aosApplEnter();});0")
            await gp.wait_for_function("AOSN.state==='ok'&&getComputedStyle($('aos-gate')).display==='none'", timeout=15000)
            await S.ev(gp, "aosLaunch('config');0"); await gp.wait_for_selector(".aosc-ia .aosm-oll", timeout=15000); await gp.wait_for_timeout(1500)
            S.ck(s, "Configuración → Inteligencia local (sin GPU): Ollama con modelos livianos para descargar (qwen2.5:0.5b primero)", await S.ev(gp, "(b=>b.innerText.includes('Inteligencia local')&&b.innerText.includes('qwen2.5:0.5b'))(document.querySelector('.aosc-ia'))"))
            await S.ev(gp, "aosLaunch('tienda');0"); await gp.wait_for_selector(".aost [data-ins='com.visualstudio.code']", timeout=15000)
            S.ck(s, "Instalar software: catálogo (VS Code, GIMP, VLC, Wireshark…) y la sección de Packet Tracer (.deb)", await S.ev(gp, "AOS.apps.tienda.desk&&(t=>t.includes('Visual Studio Code')&&t.includes('Packet Tracer'))(document.querySelector('.aost').innerText)"))
            await S.ev(gp, "document.querySelector(\".aost [data-ins='com.visualstudio.code']\").click();0")
            await gp.wait_for_selector(".aost [data-des='com.visualstudio.code']", timeout=20000)
            S.ck(s, "instalar VS Code (Flathub) como trabajo en segundo plano; queda «Instalado» con opción de desinstalar", "instalar flatpak com.visualstudio.code" in open(LOGF).read())
            r = await S.ev(gp, "aosNuc('sistema.instalar',{flatpak:'bad id; rm'}).then(()=>'ok').catch(e=>e.message)")
            S.ck(s, "identificadores de aplicación inválidos se rechazan", "inválido" in r, r)
            await S.ev(gp, "aosLaunch('config');0"); await gp.wait_for_timeout(2500); await gp.wait_for_selector(".aosc-pan .p-modo", timeout=15000)
            r = await S.ev(gp, "(b=>[b.querySelector('.p-modo').options.length,b.innerText.includes('Virtual-1')])(document.querySelector('.aosc-pan'))")
            await S.ev(gp, "(b=>{b.querySelector('.p-modo').value='1366x768';b.querySelector('.p-esc').value='1.25';b.querySelector('.p-apl').click();})(document.querySelector('.aosc-pan'));0"); await gp.wait_for_timeout(800)
            pf = os.path.join(NA.home, ".artlas-pantalla")
            S.ck(s, "Configuración → Pantalla: lista las resoluciones y aplica la elegida (se recuerda en cada arranque)", r[0] == 3 and r[1] and os.path.exists(pf) and open(pf).read().strip() == "1366x768 1.25" and "pantalla-aplicar 1366x768 1.25" in open(LOGF).read(), str(r))
            await S.ev(gp, "cfg.groq=Object.assign({},cfg.groq,{key:'gsk_x',enabled:true});aosLaunch('modelos');0"); await gp.wait_for_selector(".aosm-api [data-usar='groq']", timeout=10000)
            await S.ev(gp, "document.querySelector(\".aosm-api [data-usar='groq']\").click();0"); await gp.wait_for_timeout(500)
            u = await S.ev(gp, "aosMotor()")
            await S.ev(gp, "window.confirm=()=>true;document.querySelector(\".aosm-api [data-quitar='groq']\").click();0"); await gp.wait_for_timeout(500)
            S.ck(s, "Mis modelos por API: «usar» lo elige como motor y «✕» quita la clave del equipo", u == "groq" and await S.ev(gp, "!connected('groq')&&aosMotor()==='auto'"), u)
            # --- v7.8: motor de IA local propio (sin Ollama) y hasta 4 usuarios ---
            r = await S.ev(gp, "Promise.all([aosNuc('ia.estado',{}),aosNuc('ia.catalogo',{})])")
            S.ck(s, "IA local sin Ollama: el appliance usa el motor propio (llama.cpp) con catálogo GGUF gratuito", r[0]["motor"] == "artlas" and r[0]["activo"] and r[1]["motor"] == "artlas" and "qwen2.5:0.5b" in r[1]["modelos"] and "llama3.2:1b" in r[1]["modelos"], str(r)[:200])
            md = os.path.join(NA.dir, "modelos"); os.makedirs(md, exist_ok=True); open(os.path.join(md, "qwen2.5_0.5b.gguf"), "wb").write(b"GGUF" + b"0" * 64)
            st_, tags = NA.req("/ollama/" + await S.ev(gp, "aosNucToken()") + "/api/tags", origin=None)
            S.ck(s, "los modelos descargados aparecen con la API de siempre (el asistente y el router no cambian)", st_ == 200 and tags["models"][0]["name"] == "qwen2.5:0.5b", str(tags)[:160])
            await S.ev(gp, "aosNuc('ia.borrar',{modelo:'qwen2.5:0.5b'})")
            S.ck(s, "borrar un modelo descargado libera el archivo", not os.path.exists(os.path.join(md, "qwen2.5_0.5b.gguf")))
            r = await S.ev(gp, "aosNuc('cuenta.agregar',{admin_clave:'mala',nombre:'Ana',usuario:'ana',clave:'ana123'}).then(()=>'ok').catch(e=>e.message)")
            r2 = await S.ev(gp, "aosNuc('cuenta.agregar',{admin_clave:'nueva22',nombre:'Ana Pérez',usuario:'ana',clave:'ana123'}).then(x=>x.usuarios.length).catch(e=>e.message)")
            S.ck(s, "agregar usuarios pide la contraseña del administrador", "administrador" in r and r2 == 2, str(r) + " | " + str(r2))
            await S.ev(gp, "aosNuc('cuenta.agregar',{admin_clave:'nueva22',nombre:'Beto',usuario:'beto',clave:'beto12'}).then(()=>aosNuc('cuenta.agregar',{admin_clave:'nueva22',nombre:'Caro',usuario:'caro',clave:'caro12'}))")
            r = await S.ev(gp, "aosNuc('cuenta.agregar',{admin_clave:'nueva22',nombre:'Dani',usuario:'dani',clave:'dani12'}).then(()=>'ok').catch(e=>e.message)")
            S.ck(s, "máximo 4 usuarios en el equipo", "máximo" in r, r)
            await S.ev(gp, "aosApplLock();0"); await gp.wait_for_selector("#aos-gate .otros [data-u='ana']", timeout=10000)
            S.ck(s, "pantalla de inicio: el usuario actual y los otros 3 para elegir; el reloj más chico", await S.ev(gp, "document.querySelectorAll('#aos-gate .otros [data-u]').length===3&&parseFloat(getComputedStyle(document.querySelector('#aos-gate .reloj')).fontSize)<=48"))
            await S.ev(gp, "document.querySelector(\"#aos-gate .otros [data-u='ana']\").click();0"); await gp.wait_for_function("document.querySelector('#aos-gate .quien')&&document.querySelector('#aos-gate .quien').textContent==='Ana Pérez'", timeout=8000)
            S.ck(s, "un usuario nuevo acepta la licencia en su primer ingreso", await S.ev(gp, "!!document.querySelector('#aos-gate .f-lic')"))
            await gp.fill("#aos-gate .pw input", "ana123"); await gp.check("#aos-gate .f-lic"); await gp.click("#aos-gate .pw button")
            await gp.wait_for_function("getComputedStyle($('aos-gate')).display==='none'&&AOS._cuenta&&AOS._cuenta.usuario==='ana'", timeout=15000)
            S.ck(s, "cada usuario entra con su propia contraseña (se recuerda el último)", await S.ev(gp, "v60LS('atlas_os_ultimo_usuario','')==='ana'"))
            r = await S.ev(gp, "aosNuc('cuenta.borrar',{admin_clave:'nueva22',usuario:'caro'}).then(x=>x.usuarios.length).catch(e=>e.message)")
            r2 = await S.ev(gp, "aosNuc('cuenta.borrar',{admin_clave:'nueva22',usuario:'mario'}).then(()=>'ok').catch(e=>e.message)")
            S.ck(s, "el administrador puede borrar usuarios, pero no a sí mismo", r == 3 and "administrador" in r2, str(r) + " | " + r2)
            S.ck(s, "escala de pantalla al 80 % disponible", "0.8" in open(os.path.join(R, "src", "nucleo", "artlas-nucleo.mjs"), encoding="utf-8").read() and await S.ev(gp, "aosNuc('sistema.pantalla',{accion:'aplicar',modo:'1280x800',escala:'0.8'}).then(x=>x.escala)") == "0.8")
            await S.ev(gp, "window.__ext=[];window.aosnExternal=u=>{window.__ext.push(u)};window.open('https://console.groq.com/keys','_blank');const a=document.createElement('a');a.href='https://ollama.com/library';a.target='_blank';a.textContent='x';document.body.appendChild(a);a.click();a.remove();0")
            r = await S.ev(gp, "window.__ext")
            S.ck(s, "ventanas emergentes y enlaces externos se abren en el Chromium aparte (con barra y X), no a pantalla completa sin salida", r == ["https://console.groq.com/keys", "https://ollama.com/library"], str(r))
            await S.ev(gp, "aosExitClick();0"); await gp.wait_for_timeout(300)
            S.ck(s, "menú de energía: «Cerrar ventanas abiertas» (Chromium y LibreOffice)", await S.ev(gp, "document.querySelector('.aos-pwr').innerText.includes('Cerrar ventanas abiertas')"))
            await S.ev(gp, "document.querySelector('.aos-pwr')&&document.querySelector('.aos-pwr').remove();0")
            S.ck(s, "sin errores de JavaScript en primer arranque y bloqueo", not gp.errs, str(gp.errs[:2]))

        finally:
            NA.stop()
    finally:
        N.stop()


# ---- solo las pruebas del OS:  python3 tests/os_pruebas.py  (compilar antes) ----
if __name__ == "__main__":
    import asyncio, sys
    sys.path.insert(0, os.path.join(R, "tests")); import suite as S
    from playwright.async_api import async_playwright
    async def _main():
        FS = S.serve(os.path.join(R, "dist", "fullstack"))
        async with async_playwright() as p:
            b = await p.chromium.launch(); await run(S, b, FS); await b.close()
        tot = sum(x["total"] for x in S.SUITES); ok = sum(x["ok"] for x in S.SUITES)
        print(f"\n{'✓' if ok == tot else '✗'} {ok}/{tot} pruebas del OS"); sys.exit(0 if ok == tot else 1)
    asyncio.run(_main())
